"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7459], {
        27459: (e, r, t) => {
            t.d(r, {
                FirmsTableWrapper: () => q
            });
            var n, i = t(12428),
                l = t(35022),
                a = t(11800),
                s = t(6185),
                o = t(69615),
                u = t(28422),
                d = t(94062),
                c = t(17322),
                p = t(83352),
                m = t(32029),
                f = t(93264),
                _ = t(95772);
            let v = _.z.object({
                type: _.z.array(_.z.nativeEnum(c.co)).optional(),
                firms: _.z.array(_.z.string()).optional(),
                reviewScore: _.z.array(_.z.number()).optional(),
                countryFeatureIds: _.z.array(_.z.string()).optional(),
                yearsInOperation: _.z.array(_.z.number()).optional(),
                trustpilot: _.z.array(_.z.number()).optional(),
                assets: _.z.array(_.z.nativeEnum(c.fo)).optional(),
                platforms: _.z.array(_.z.string()).optional(),
                programType: _.z.array(_.z.string()).optional(),
                maxAllocation: _.z.array(_.z.number()).optional()
            });

            function C() {
                let [e, r] = (0, l.v1)("filters", (0, l.WJ)(v.parse).withDefault({}));
                return {
                    filtersState: e,
                    setFiltersState: r
                }
            }
            var x = t(85473),
                h = t(5313),
                E = t(47576),
                S = t(58652),
                g = t(89309),
                I = t(64608),
                j = t(34719),
                T = t(14887),
                y = t(49433),
                N = t(24040),
                b = t(95805),
                A = t(39540),
                L = t(26185),
                F = t(30758),
                R = t(88998),
                M = t(78655),
                O = t(43748),
                k = t(42619),
                P = t(13920),
                w = t(43121),
                U = t(3934),
                D = t(74777);

            function z(e) {
                let {
                    t: r
                } = (0, s.$G)(), t = (0, f.useMemo)(() => [{
                    enabled: e.firm.assetCryptoEnabled,
                    label: r("Crypto")
                }, {
                    enabled: e.firm.assetFuturesEnabled,
                    label: r("Futures")
                }, {
                    enabled: e.firm.assetEnergyEnabled,
                    label: r("Energy")
                }, {
                    enabled: e.firm.assetFxEnabled,
                    label: r("FX")
                }, {
                    enabled: e.firm.assetIndicesEnabled,
                    label: r("Indices")
                }, {
                    enabled: e.firm.assetMetalsEnabled,
                    label: r("Metals")
                }, {
                    enabled: e.firm.assetOtherCommoditiesEnabled,
                    label: r("Other Commodities")
                }, {
                    enabled: e.firm.assetStocksEnabled,
                    label: r("Stocks")
                }].filter(e => e.enabled), [e.firm.assetCryptoEnabled, e.firm.assetFuturesEnabled, e.firm.assetEnergyEnabled, e.firm.assetFxEnabled, e.firm.assetIndicesEnabled, e.firm.assetMetalsEnabled, e.firm.assetOtherCommoditiesEnabled, e.firm.assetStocksEnabled, r]);
                return (0, i.jsx)("div", {
                    className: "flex flex-wrap gap-1 max-w-52 justify-center",
                    children: null == t ? void 0 : t.map(e => (0, i.jsx)(D.C, {
                        className: "rounded-full whitespace-nowrap font-medium",
                        variant: "secondary",
                        size: "md",
                        children: e.label
                    }, e.label))
                })
            }
            var B = t(40850),
                G = t(24080),
                W = t(30455),
                Z = t(43220);

            function H(e) {
                let {
                    reviewScoreColumn: r,
                    reviewsCountColumn: t,
                    setSorting: n
                } = e, {
                    t: l
                } = (0, s.$G)();
                return (0, i.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [(0, i.jsx)("span", {
                        className: "text-[8px] md:text-[10px] font-semibold",
                        children: l("Rank")
                    }), (0, i.jsxs)(B.zx, {
                        size: "iconXs",
                        variant: "ghost",
                        className: "px-0 w-3",
                        onClick: () => {
                            let e = r.getIsSorted(),
                                t = [{
                                    id: r.id,
                                    desc: "desc" == ("desc" === e ? "asc" : "desc")
                                }];
                            null == n || n(t)
                        },
                        children: ["asc" === r.getIsSorted() && (0, i.jsx)(G.Z, {
                            className: "w-3"
                        }), "desc" === r.getIsSorted() && (0, i.jsx)(W.Z, {
                            className: "w-3"
                        }), !r.getIsSorted() && (0, i.jsx)(Z.Z, {
                            className: "w-3"
                        })]
                    }), (0, i.jsx)("span", {
                        className: "text-[8px] md:text-[10px] font-semibold",
                        children: "/"
                    }), (0, i.jsx)("span", {
                        className: "text-[8px] md:text-[10px] font-semibold",
                        children: l("Reviews")
                    }), (0, i.jsxs)(B.zx, {
                        size: "iconXs",
                        variant: "ghost",
                        className: "px-0 w-3",
                        onClick: () => {
                            let e = t.getIsSorted(),
                                r = [{
                                    id: t.id,
                                    desc: "desc" == ("desc" === e ? "asc" : "desc")
                                }];
                            null == n || n(r)
                        },
                        children: ["asc" === t.getIsSorted() && (0, i.jsx)(G.Z, {
                            className: "w-3"
                        }), "desc" === t.getIsSorted() && (0, i.jsx)(W.Z, {
                            className: "w-3"
                        }), !t.getIsSorted() && (0, i.jsx)(Z.Z, {
                            className: "w-3"
                        })]
                    })]
                })
            }
            let K = !1;

            function V(e) {
                var r, t, n, l, a;
                let {
                    refetch: d,
                    ...c
                } = e, {
                    t: p
                } = (0, s.$G)(), {
                    getFileReadUrl: _
                } = (0, N.lA)(), v = (0, T.y)(), C = x.trpc.useUtils(), E = x.trpc.protected.firmActions.likeFirm.useMutation({
                    onSuccess() {
                        d(), C.firm.countFavorites.invalidate()
                    }
                }), S = x.trpc.protected.firmActions.unlikeFirm.useMutation({
                    onSuccess() {
                        d(), C.firm.countFavorites.invalidate()
                    }
                });
                (0, f.useEffect)(() => {
                    !K && v.isLoaded && (K = !0, v.isSignedIn && d())
                }, [v.isLoaded, v.isSignedIn, d]);
                let g = (0, P.Cl)(),
                    I = (0, y.ll)(),
                    D = (0, f.useMemo)(() => {
                        let e = new Date;
                        return [{
                            accessorKey: "id",
                            header: () => p("Firm"),
                            enableSorting: !0,
                            cell: e => {
                                let {
                                    row: r
                                } = e;
                                return (0, i.jsx)(o.mA, {
                                    firm: r.original,
                                    favoriteSlot: (0, i.jsx)(A._, {
                                        isFavorite: !!r.original.userLikes,
                                        onToggle: () => {
                                            if (!v.isSignedIn) {
                                                I.redirectToSignIn();
                                                return
                                            }
                                            return r.original.userLikes ? S.mutate({
                                                firmId: r.original.id
                                            }) : E.mutate({
                                                firmId: r.original.id
                                            })
                                        }
                                    })
                                })
                            }
                        }, {
                            accessorKey: "reviewScore",
                            enableSorting: !0,
                            sortDescFirst: !0,
                            header: () => null,
                            cell: () => null
                        }, {
                            accessorKey: "reviewsCount",
                            enableSorting: !0,
                            sortDescFirst: !0,
                            header: () => null,
                            cell: () => null
                        }, g.display({
                            id: "combinedDisplay",
                            sortDescFirst: !0,
                            header: e => {
                                var r;
                                let {
                                    table: t
                                } = e, n = t.getAllColumns().find(e => "reviewScore" === e.id), l = t.getAllColumns().find(e => "reviewsCount" === e.id);
                                return n && l ? (0, i.jsx)(H, {
                                    reviewScoreColumn: n,
                                    reviewsCountColumn: l,
                                    setSorting: null === (r = c.sortingHookResult) || void 0 === r ? void 0 : r.onSortingChange
                                }) : null
                            },
                            cell: e => {
                                var r, t;
                                let {
                                    row: n
                                } = e;
                                return (0, i.jsx)(u.C1, {
                                    children: n.original.reviewsCount < j.nu ? (0, i.jsxs)("div", {
                                        className: "flex flex-col items-center w-fit",
                                        children: [(0, i.jsx)(h.k0, {
                                            className: "size-3"
                                        }), (0, i.jsxs)("div", {
                                            className: "text-xs font-normal text-center",
                                            children: [(0, i.jsx)("p", {
                                                children: p("Less than")
                                            }), (0, i.jsx)("p", {
                                                className: "text-primary-theme",
                                                children: "".concat(j.nu, " reviews")
                                            })]
                                        })]
                                    }) : (0, i.jsx)(R.O, {
                                        rank: null !== (r = n.original.reviewScore) && void 0 !== r ? r : 0,
                                        children: (0, i.jsxs)("div", {
                                            className: "text-xs flex items-center justify-center space-x-1",
                                            children: [(0, i.jsx)("p", {
                                                className: "text-primary-theme",
                                                children: null !== (t = n.original.reviewsCount) && void 0 !== t ? t : 0
                                            }), (0, i.jsx)("p", {
                                                className: "text-foreground-secondary",
                                                children: p("reviews")
                                            })]
                                        })
                                    })
                                })
                            }
                        }), {
                            accessorKey: "country",
                            enableSorting: !0,
                            sortDescFirst: !0,
                            header: () => p("Country"),
                            cell: e => {
                                var r;
                                let {
                                    row: t
                                } = e;
                                return (0, i.jsx)(u.C1, {
                                    children: (0, i.jsx)(L.l, {
                                        countryCode: null !== (r = t.original.country) && void 0 !== r ? r : "US"
                                    })
                                })
                            }
                        }, {
                            accessorKey: "dateEstablished",
                            enableSorting: !0,
                            header: () => p("Years in operation"),
                            cell: r => {
                                var t;
                                let {
                                    row: n
                                } = r;
                                return (0, i.jsx)(u.C1, {
                                    children: (0, i.jsx)(M.c, {
                                        years: (0, w.o)(e, null !== (t = n.original.dateEstablished) && void 0 !== t ? t : e)
                                    })
                                })
                            }
                        }, {
                            accessorKey: "supportedAssets",
                            header: () => p("Assets"),
                            cell: e => {
                                let {
                                    row: r
                                } = e;
                                return (0, i.jsx)(u.C1, {
                                    children: (0, i.jsx)(z, {
                                        firm: r.original
                                    })
                                })
                            }
                        }, {
                            accessorKey: "platforms",
                            header: () => p("Platforms"),
                            cell: e => {
                                var r;
                                let {
                                    row: t
                                } = e;
                                return (0, i.jsx)(u.C1, {
                                    className: "gap-2 w-36 flex-wrap",
                                    children: null === (r = t.original.firmPlatforms) || void 0 === r ? void 0 : r.map(e => (0, i.jsxs)(k.J2, {
                                        children: [(0, i.jsx)(k.xo, {
                                            children: (0, i.jsx)(b.Avatar, {
                                                className: "size-5",
                                                children: e.icon ? (0, i.jsx)(b.AvatarImage, {
                                                    src: _(e.icon)
                                                }) : (0, i.jsx)(b.Q, {
                                                    title: e.name,
                                                    children: e.name.substring(0, 2)
                                                })
                                            }, e.id)
                                        }), (0, i.jsx)(k.yk, {
                                            side: "bottom",
                                            children: (0, i.jsx)("p", {
                                                children: e.name
                                            })
                                        })]
                                    }, e.id))
                                })
                            }
                        }, {
                            accessorKey: "maxAllocation",
                            enableSorting: !0,
                            header: () => p("Max Allocations"),
                            cell: e => {
                                var r, t;
                                let {
                                    row: n
                                } = e;
                                return (0, i.jsx)(F.G, {
                                    label: (0, m.uf)({
                                        value: null !== (r = n.original.maxAllocation) && void 0 !== r ? r : 0,
                                        currency: m.Mf.USD,
                                        maximumFractionDigits: 2,
                                        notation: "compact"
                                    }),
                                    value: null !== (t = n.original.maxAllocation) && void 0 !== t ? t : 0
                                })
                            }
                        }, {
                            accessorKey: "promo",
                            enableSorting: !1,
                            header: () => p("Promo"),
                            cell: e => {
                                let {
                                    row: r
                                } = e;
                                return (0, i.jsx)(u.C1, {
                                    children: (0, i.jsx)(o.bD, {
                                        firm: r.original
                                    })
                                })
                            }
                        }, {
                            accessorKey: "actions",
                            header: () => p("Actions"),
                            cell: e => {
                                let {
                                    row: r
                                } = e;
                                return (0, i.jsx)(O.G7, {
                                    variant: "pfmDarkOutline",
                                    asChild: !0,
                                    children: (0, i.jsx)(U.default, {
                                        href: "/prop-firms/".concat(r.original.slug),
                                        children: (0, i.jsx)(O.MB, {
                                            className: "px-3 py-2",
                                            children: p("Firm")
                                        })
                                    })
                                })
                            }
                        }]
                    }, [v.isSignedIn, g, _, E, p, S, I]);
                return (0, i.jsx)(u.tf, {
                    columns: D,
                    data: null !== (a = null === (r = c.result) || void 0 === r ? void 0 : r.data) && void 0 !== a ? a : [],
                    pinFirstColumn: !0,
                    pinLastColumn: !1,
                    columnVisibility: {
                        reviewScore: !1,
                        reviewsCount: !1
                    },
                    sorting: null === (t = c.sortingHookResult) || void 0 === t ? void 0 : t.sorting,
                    setSorting: null === (n = c.sortingHookResult) || void 0 === n ? void 0 : n.onSortingChange,
                    pagination: null === (l = c.paginationHookResult) || void 0 === l ? void 0 : l.pagination,
                    rowCount: null == c ? void 0 : c.result.count,
                    enableMultiSort: !1,
                    noDataPlaceholder: (0, i.jsx)(u.zP, {})
                })
            }

            function X() {
                var e, r, t, n, a, s, o, u, d;
                let c = (0, g.r)(),
                    [p] = (0, l.v1)("search", _.z.string().optional()),
                    m = (0, S.h)(),
                    [f] = (0, I.Nr)(p, 500),
                    {
                        filtersState: v
                    } = C(),
                    [h, {
                        refetch: E
                    }] = x.trpc.firm.listAll.useSuspenseQuery({
                        search: null != f ? f : "",
                        limit: m.take,
                        skip: m.skip,
                        ...(null === (r = c.sorting) || void 0 === r ? void 0 : null === (e = r[0]) || void 0 === e ? void 0 : e.id) ? {
                            order: {
                                by: c.sorting[0].id,
                                direction: c.sorting[0].desc ? "desc" : "asc"
                            }
                        } : {},
                        filter: {
                            reviewScore: null === (t = v.reviewScore) || void 0 === t ? void 0 : t[0],
                            yearsInOperation: null === (n = v.yearsInOperation) || void 0 === n ? void 0 : n[0],
                            countryFeatureIds: null === (a = v.countryFeatureIds) || void 0 === a ? void 0 : a.filter(e => e),
                            assets: v.assets,
                            trustPilotScore: null === (s = v.trustpilot) || void 0 === s ? void 0 : s[0],
                            platformIds: null === (o = v.platforms) || void 0 === o ? void 0 : o.filter(e => e),
                            programType: null === (u = v.programType) || void 0 === u ? void 0 : u.filter(e => e),
                            maxAllocation: null === (d = v.maxAllocation) || void 0 === d ? void 0 : d[0],
                            firmIds: v.firms,
                            type: v.type
                        }
                    });
                return (0, i.jsx)(V, {
                    result: h,
                    refetch: E,
                    paginationHookResult: m,
                    sortingHookResult: c
                })
            }

            function Y() {
                var e, r, t;
                let n = (0, g.r)(),
                    [a] = (0, l.v1)("search", _.z.string().optional()),
                    s = (0, I.Nr)(a, 500),
                    [o, {
                        refetch: u
                    }] = x.trpc.firm.listMyFavorites.useSuspenseQuery({
                        search: null !== (t = s[0]) && void 0 !== t ? t : "",
                        ...(null === (r = n.sorting) || void 0 === r ? void 0 : null === (e = r[0]) || void 0 === e ? void 0 : e.id) ? {
                            order: {
                                by: n.sorting[0].id,
                                direction: n.sorting[0].desc ? "desc" : "asc"
                            }
                        } : {}
                    });
                return (0, i.jsx)(V, {
                    result: {
                        data: o,
                        hasMore: !1,
                        count: o.length,
                        nextPage: null
                    },
                    refetch: u,
                    sortingHookResult: n
                })
            }

            function Q() {
                var e, r, t, n, a, s, o, u, d;
                let c = (0, g.r)(),
                    [p] = (0, l.v1)("search", _.z.string().optional()),
                    [m] = (0, I.Nr)(p, 500),
                    f = (0, S.h)(),
                    {
                        filtersState: v
                    } = C(),
                    [h, {
                        refetch: E
                    }] = x.trpc.firm.listNew.useSuspenseQuery({
                        search: null != m ? m : "",
                        limit: f.take,
                        skip: f.skip,
                        ...(null === (r = c.sorting) || void 0 === r ? void 0 : null === (e = r[0]) || void 0 === e ? void 0 : e.id) ? {
                            order: {
                                by: c.sorting[0].id,
                                direction: c.sorting[0].desc ? "desc" : "asc"
                            }
                        } : {},
                        filter: {
                            reviewScore: null === (t = v.reviewScore) || void 0 === t ? void 0 : t[0],
                            yearsInOperation: null === (n = v.yearsInOperation) || void 0 === n ? void 0 : n[0],
                            countryFeatureIds: null === (a = v.countryFeatureIds) || void 0 === a ? void 0 : a.filter(e => e),
                            assets: v.assets,
                            trustPilotScore: null === (s = v.trustpilot) || void 0 === s ? void 0 : s[0],
                            platformIds: null === (o = v.platforms) || void 0 === o ? void 0 : o.filter(e => e),
                            programType: null === (u = v.programType) || void 0 === u ? void 0 : u.filter(e => e),
                            maxAllocation: null === (d = v.maxAllocation) || void 0 === d ? void 0 : d[0]
                        }
                    });
                return (0, i.jsx)(V, {
                    result: h,
                    refetch: E,
                    paginationHookResult: f,
                    sortingHookResult: c
                })
            }

            function $() {
                var e, r, t, n, a, s, o, u, d;
                let c = (0, g.r)(),
                    [p] = (0, l.v1)("search", _.z.string().optional()),
                    m = C(),
                    [f] = (0, I.Nr)(p, 500),
                    {
                        filtersState: v
                    } = m,
                    [h, {
                        refetch: E
                    }] = x.trpc.firm.listPopular.useSuspenseQuery({
                        search: null != f ? f : "",
                        ...(null === (r = c.sorting) || void 0 === r ? void 0 : null === (e = r[0]) || void 0 === e ? void 0 : e.id) ? {
                            order: {
                                by: c.sorting[0].id,
                                direction: c.sorting[0].desc ? "desc" : "asc"
                            }
                        } : {},
                        filter: {
                            reviewScore: null === (t = v.reviewScore) || void 0 === t ? void 0 : t[0],
                            yearsInOperation: null === (n = v.yearsInOperation) || void 0 === n ? void 0 : n[0],
                            countryFeatureIds: null === (a = v.countryFeatureIds) || void 0 === a ? void 0 : a.filter(e => e),
                            assets: v.assets,
                            trustPilotScore: null === (s = v.trustpilot) || void 0 === s ? void 0 : s[0],
                            platformIds: null === (o = v.platforms) || void 0 === o ? void 0 : o.filter(e => e),
                            programType: null === (u = v.programType) || void 0 === u ? void 0 : u.filter(e => e),
                            maxAllocation: null === (d = v.maxAllocation) || void 0 === d ? void 0 : d[0],
                            type: v.type
                        }
                    });
                return (0, i.jsx)(V, {
                    result: h,
                    refetch: E,
                    sortingHookResult: c
                })
            }

            function q() {
                var e;
                let {
                    t: r
                } = (0, s.$G)(), [t] = (0, l.v1)("tab", _.z.nativeEnum(n).default("popular")), {
                    push: S
                } = (0, E.useRouter)(), g = (0, E.usePathname)(), I = (0, f.useCallback)(e => {
                    let r = new URLSearchParams;
                    r.set("tab", e), S("".concat(g, "?").concat(r.toString()))
                }, [g, S]), j = x.trpc.firm.countFavorites.useQuery(), T = x.trpc.firm.getListFilteringOptions.useQuery(), y = x.trpc.firm.listAll.useQuery({
                    limit: 100
                }), N = C(), b = function(e) {
                    var r, t, n, l, _, C, x, h, E, S, g, I;
                    let {
                        t: j
                    } = (0, s.$G)(), T = (0, a.J)();
                    return (0, f.useMemo)(() => {
                        var r, t, n, l, a, s, f, _, C, x, h, E, S, g, I, y, N, b, A;
                        return (0, d.g)(v, [(0, u.On)({
                            name: "type",
                            label: j("Type Of Firm"),
                            labelClassName: "md:text-base text-xs text-primary-theme",
                            options: [{
                                label: T[c.co.CFD],
                                value: c.co.CFD
                            }, {
                                label: T[c.co.Futures],
                                value: c.co.Futures
                            }, {
                                label: T[c.co.CryptoOnly],
                                value: c.co.CryptoOnly
                            }, {
                                label: T[c.co.StocksOnly],
                                value: c.co.StocksOnly
                            }]
                        }), ...(null === (r = e.allFirms) || void 0 === r ? void 0 : r.length) ? (0, d.g)(v, [(0, u.kV)({
                            name: "firms",
                            label: j("Firms"),
                            options: e.allFirms.map(e => ({
                                value: e.id,
                                ...e
                            })),
                            renderItem: e => (0, i.jsxs)("div", {
                                className: "flex space-x-2.5 items-center",
                                children: [(0, i.jsx)(o.wK, {
                                    firm: e,
                                    className: "w-8 h-8"
                                }), (0, i.jsx)("div", {
                                    className: "space-y-1.5",
                                    children: (0, i.jsx)("div", {
                                        className: "flex space-x-1.5",
                                        children: (0, i.jsx)(p.o3, {
                                            maxWidth: "2xs",
                                            children: (0, i.jsx)("p", {
                                                className: "text-base font-semibold",
                                                children: e.name
                                            })
                                        })
                                    })
                                })]
                            })
                        })]).options : [], (0, u.rV)({
                            name: "reviewScore",
                            label: j("Rank"),
                            sliderProps: {
                                min: 1,
                                max: 5
                            }
                        }), (0, u.On)({
                            name: "countryFeatureIds",
                            label: null !== (g = null === (n = e.filters) || void 0 === n ? void 0 : null === (t = n.countryFeatureCategory) || void 0 === t ? void 0 : t.name) && void 0 !== g ? g : j("Country"),
                            options: (null !== (I = null === (a = e.filters) || void 0 === a ? void 0 : null === (l = a.countryFeatureCategory) || void 0 === l ? void 0 : l.features) && void 0 !== I ? I : []).map(e => ({
                                value: e.id,
                                label: e.name
                            }))
                        }), (0, u.rV)({
                            name: "yearsInOperation",
                            label: j("Years in Operation"),
                            sliderProps: {
                                min: 0,
                                max: 10
                            },
                            labelTransformer: e => 10 === e ? "10+" : e.toString()
                        }), (0, u.On)({
                            name: "assets",
                            label: j("Assets"),
                            options: [{
                                label: "FX",
                                value: c.fo.FX
                            }, {
                                label: "Energy",
                                value: c.fo.Energy
                            }, {
                                label: "Stocks",
                                value: c.fo.Stocks
                            }, {
                                label: "Crypto",
                                value: c.fo.Crypto
                            }, {
                                label: "Indices",
                                value: c.fo.Indices
                            }, {
                                label: "Other Commodities",
                                value: c.fo.OtherCommodities
                            }, {
                                label: "Metals",
                                value: c.fo.Metals
                            }]
                        }), (0, u.On)({
                            name: "platforms",
                            label: null !== (y = null === (f = e.filters) || void 0 === f ? void 0 : null === (s = f.platformsFeatureCategory) || void 0 === s ? void 0 : s.name) && void 0 !== y ? y : j("Platforms"),
                            options: (null !== (N = null === (C = e.filters) || void 0 === C ? void 0 : null === (_ = C.platformsFeatureCategory) || void 0 === _ ? void 0 : _.features) && void 0 !== N ? N : []).map(e => ({
                                value: e.id,
                                label: e.name
                            }))
                        }), (0, u.On)({
                            name: "programType",
                            label: j("Program Type"),
                            options: [{
                                label: "Instant",
                                value: c.oi.Instant
                            }, {
                                label: "1 Step",
                                value: c.oi.OneStep
                            }, {
                                label: "2 Step",
                                value: c.oi.TwoSteps
                            }, {
                                label: "3 Step",
                                value: c.oi.ThreeSteps
                            }, {
                                label: "4 Step",
                                value: c.oi.FourSteps
                            }]
                        }), (0, u.rV)({
                            name: "maxAllocation",
                            label: j("Max Allocation"),
                            sliderProps: {
                                min: null !== (b = null === (h = e.filters) || void 0 === h ? void 0 : null === (x = h.limits) || void 0 === x ? void 0 : x.minMaxAllocation) && void 0 !== b ? b : 0,
                                max: null !== (A = null === (S = e.filters) || void 0 === S ? void 0 : null === (E = S.limits) || void 0 === E ? void 0 : E.maxMaxAllocation) && void 0 !== A ? A : 1e7,
                                step: 1e4
                            },
                            labelTransformer: e => (0, m.uf)({
                                value: e,
                                currency: "USD",
                                locale: "en-US"
                            })
                        })])
                    }, [j, T, e.allFirms, null === (t = e.filters) || void 0 === t ? void 0 : null === (r = t.countryFeatureCategory) || void 0 === r ? void 0 : r.name, null === (l = e.filters) || void 0 === l ? void 0 : null === (n = l.countryFeatureCategory) || void 0 === n ? void 0 : n.features, null === (C = e.filters) || void 0 === C ? void 0 : null === (_ = C.platformsFeatureCategory) || void 0 === _ ? void 0 : _.name, null === (h = e.filters) || void 0 === h ? void 0 : null === (x = h.platformsFeatureCategory) || void 0 === x ? void 0 : x.features, null === (S = e.filters) || void 0 === S ? void 0 : null === (E = S.limits) || void 0 === E ? void 0 : E.minMaxAllocation, null === (I = e.filters) || void 0 === I ? void 0 : null === (g = I.limits) || void 0 === g ? void 0 : g.maxMaxAllocation])
                }({
                    filters: T.data,
                    allFirms: "all" === t ? null === (e = y.data) || void 0 === e ? void 0 : e.data : void 0
                }), [A, L] = (0, l.v1)("search", _.z.string().optional()), F = (0, f.useMemo)(() => {
                    var e;
                    return [{
                        icon: (0, i.jsx)(h.Yq, {
                            className: "fill-foreground-secondary"
                        }),
                        value: "popular",
                        label: r("Popular")
                    }, {
                        icon: (0, i.jsx)(h.h_, {
                            className: "fill-foreground-secondary"
                        }),
                        value: "favorite",
                        label: r("Favorite {{ itemsCount }}/{{ max }}", {
                            itemsCount: "".concat(null !== (e = j.data) && void 0 !== e ? e : 0),
                            max: "".concat(5)
                        })
                    }, {
                        icon: (0, i.jsx)(h.js, {
                            className: "fill-foreground-secondary"
                        }),
                        value: "new",
                        label: r("New")
                    }, {
                        value: "all",
                        label: r("All")
                    }]
                }, [r, j.data]);
                return (0, i.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, i.jsx)(u.ew, {
                        extendedFilter: {
                            defaultOpen: !1,
                            onOpenChange: () => {}
                        },
                        quickFilters: {
                            items: F,
                            onQuickFilterChange: e => I(e),
                            defaultValue: null != t ? t : "popular"
                        },
                        search: {
                            placeholder: t && "popular" !== t ? r("Search for Firms") : r("Searching Popular Firms"),
                            onSearch: L,
                            defaultValue: null != A ? A : ""
                        }
                    }), (0, i.jsx)(u.F_, {
                        filtersHookResult: { ...N,
                            filters: b
                        },
                        children: (0, i.jsxs)(f.Suspense, {
                            fallback: (0, i.jsx)(u.OO, {
                                columns: 10,
                                rows: 5
                            }),
                            children: [(!t || "popular" === t) && (0, i.jsx)($, {}), "favorite" === t && (0, i.jsx)(Y, {}), "new" === t && (0, i.jsx)(Q, {}), "all" === t && (0, i.jsx)(X, {})]
                        })
                    })]
                })
            }! function(e) {
                e.Popular = "popular", e.Favorite = "favorite", e.New = "new", e.All = "all"
            }(n || (n = {}))
        },
        14887: (e, r, t) => {
            t.d(r, {
                PromisifiedAuthProvider: () => d,
                y: () => c
            });
            var n = t(49433),
                i = t(33906),
                l = t(91297),
                a = t(68042),
                s = t(93264),
                o = t(32608);
            let u = s.createContext(null);

            function d(e) {
                let {
                    authPromise: r,
                    children: t
                } = e;
                return s.createElement(u.Provider, {
                    value: r
                }, t)
            }

            function c() {
                let e = (0, l.useRouter)(),
                    r = s.useContext(u),
                    t = r;
                if (r && "then" in r && (t = s.use(r)), "undefined" != typeof window) return (0, n.aC)(t);
                if (e) return (0, n.aC)();
                if (!t && o.env.NEXT_PHASE !== a.PHASE_PRODUCTION_BUILD) throw Error("Clerk: useAuth() called in static mode, wrap this component in <ClerkProvider dynamic> to make auth data available during server-side rendering.");
                return (0, i.aw)(t)
            }
        },
        68042: (e, r, t) => {
            Object.defineProperty(r, "__esModule", {
                    value: !0
                }),
                function(e, r) {
                    for (var t in r) Object.defineProperty(e, t, {
                        enumerable: !0,
                        get: r[t]
                    })
                }(r, {
                    APP_BUILD_MANIFEST: function() {
                        return h
                    },
                    APP_CLIENT_INTERNALS: function() {
                        return Q
                    },
                    APP_PATHS_MANIFEST: function() {
                        return v
                    },
                    APP_PATH_ROUTES_MANIFEST: function() {
                        return C
                    },
                    BARREL_OPTIMIZATION_PREFIX: function() {
                        return G
                    },
                    BLOCKED_PAGES: function() {
                        return w
                    },
                    BUILD_ID_FILE: function() {
                        return P
                    },
                    BUILD_MANIFEST: function() {
                        return x
                    },
                    CLIENT_PUBLIC_FILES_PATH: function() {
                        return U
                    },
                    CLIENT_REFERENCE_MANIFEST: function() {
                        return W
                    },
                    CLIENT_STATIC_FILES_PATH: function() {
                        return D
                    },
                    CLIENT_STATIC_FILES_RUNTIME_AMP: function() {
                        return q
                    },
                    CLIENT_STATIC_FILES_RUNTIME_MAIN: function() {
                        return X
                    },
                    CLIENT_STATIC_FILES_RUNTIME_MAIN_APP: function() {
                        return Y
                    },
                    CLIENT_STATIC_FILES_RUNTIME_POLYFILLS: function() {
                        return ee
                    },
                    CLIENT_STATIC_FILES_RUNTIME_POLYFILLS_SYMBOL: function() {
                        return er
                    },
                    CLIENT_STATIC_FILES_RUNTIME_REACT_REFRESH: function() {
                        return $
                    },
                    CLIENT_STATIC_FILES_RUNTIME_WEBPACK: function() {
                        return J
                    },
                    COMPILER_INDEXES: function() {
                        return l
                    },
                    COMPILER_NAMES: function() {
                        return i
                    },
                    CONFIG_FILES: function() {
                        return k
                    },
                    DEFAULT_RUNTIME_WEBPACK: function() {
                        return et
                    },
                    DEFAULT_SANS_SERIF_FONT: function() {
                        return es
                    },
                    DEFAULT_SERIF_FONT: function() {
                        return ea
                    },
                    DEV_CLIENT_MIDDLEWARE_MANIFEST: function() {
                        return R
                    },
                    DEV_CLIENT_PAGES_MANIFEST: function() {
                        return A
                    },
                    EDGE_RUNTIME_WEBPACK: function() {
                        return en
                    },
                    EDGE_UNSUPPORTED_NODE_APIS: function() {
                        return ep
                    },
                    EXPORT_DETAIL: function() {
                        return j
                    },
                    EXPORT_MARKER: function() {
                        return I
                    },
                    FUNCTIONS_CONFIG_MANIFEST: function() {
                        return E
                    },
                    IMAGES_MANIFEST: function() {
                        return N
                    },
                    INTERCEPTION_ROUTE_REWRITE_MANIFEST: function() {
                        return V
                    },
                    MIDDLEWARE_BUILD_MANIFEST: function() {
                        return H
                    },
                    MIDDLEWARE_MANIFEST: function() {
                        return L
                    },
                    MIDDLEWARE_REACT_LOADABLE_MANIFEST: function() {
                        return K
                    },
                    MODERN_BROWSERSLIST_TARGET: function() {
                        return n.default
                    },
                    NEXT_BUILTIN_DOCUMENT: function() {
                        return B
                    },
                    NEXT_FONT_MANIFEST: function() {
                        return g
                    },
                    PAGES_MANIFEST: function() {
                        return f
                    },
                    PHASE_DEVELOPMENT_SERVER: function() {
                        return c
                    },
                    PHASE_EXPORT: function() {
                        return o
                    },
                    PHASE_INFO: function() {
                        return m
                    },
                    PHASE_PRODUCTION_BUILD: function() {
                        return u
                    },
                    PHASE_PRODUCTION_SERVER: function() {
                        return d
                    },
                    PHASE_TEST: function() {
                        return p
                    },
                    PRERENDER_MANIFEST: function() {
                        return T
                    },
                    REACT_LOADABLE_MANIFEST: function() {
                        return M
                    },
                    ROUTES_MANIFEST: function() {
                        return y
                    },
                    RSC_MODULE_TYPES: function() {
                        return ec
                    },
                    SERVER_DIRECTORY: function() {
                        return O
                    },
                    SERVER_FILES_MANIFEST: function() {
                        return b
                    },
                    SERVER_PROPS_ID: function() {
                        return el
                    },
                    SERVER_REFERENCE_MANIFEST: function() {
                        return Z
                    },
                    STATIC_PROPS_ID: function() {
                        return ei
                    },
                    STATIC_STATUS_PAGES: function() {
                        return eo
                    },
                    STRING_LITERAL_DROP_BUNDLE: function() {
                        return z
                    },
                    SUBRESOURCE_INTEGRITY_MANIFEST: function() {
                        return S
                    },
                    SYSTEM_ENTRYPOINTS: function() {
                        return em
                    },
                    TRACE_OUTPUT_VERSION: function() {
                        return eu
                    },
                    TURBOPACK_CLIENT_MIDDLEWARE_MANIFEST: function() {
                        return F
                    },
                    TURBO_TRACE_DEFAULT_MEMORY_LIMIT: function() {
                        return ed
                    },
                    UNDERSCORE_NOT_FOUND_ROUTE: function() {
                        return a
                    },
                    UNDERSCORE_NOT_FOUND_ROUTE_ENTRY: function() {
                        return s
                    },
                    WEBPACK_STATS: function() {
                        return _
                    }
                });
            let n = t(81838)._(t(85302)),
                i = {
                    client: "client",
                    server: "server",
                    edgeServer: "edge-server"
                },
                l = {
                    [i.client]: 0,
                    [i.server]: 1,
                    [i.edgeServer]: 2
                },
                a = "/_not-found",
                s = "" + a + "/page",
                o = "phase-export",
                u = "phase-production-build",
                d = "phase-production-server",
                c = "phase-development-server",
                p = "phase-test",
                m = "phase-info",
                f = "pages-manifest.json",
                _ = "webpack-stats.json",
                v = "app-paths-manifest.json",
                C = "app-path-routes-manifest.json",
                x = "build-manifest.json",
                h = "app-build-manifest.json",
                E = "functions-config-manifest.json",
                S = "subresource-integrity-manifest",
                g = "next-font-manifest",
                I = "export-marker.json",
                j = "export-detail.json",
                T = "prerender-manifest.json",
                y = "routes-manifest.json",
                N = "images-manifest.json",
                b = "required-server-files.json",
                A = "_devPagesManifest.json",
                L = "middleware-manifest.json",
                F = "_clientMiddlewareManifest.json",
                R = "_devMiddlewareManifest.json",
                M = "react-loadable-manifest.json",
                O = "server",
                k = ["next.config.js", "next.config.mjs", "next.config.ts"],
                P = "BUILD_ID",
                w = ["/_document", "/_app", "/_error"],
                U = "public",
                D = "static",
                z = "__NEXT_DROP_CLIENT_FILE__",
                B = "__NEXT_BUILTIN_DOCUMENT__",
                G = "__barrel_optimize__",
                W = "client-reference-manifest",
                Z = "server-reference-manifest",
                H = "middleware-build-manifest",
                K = "middleware-react-loadable-manifest",
                V = "interception-route-rewrite-manifest",
                X = "main",
                Y = "" + X + "-app",
                Q = "app-pages-internals",
                $ = "react-refresh",
                q = "amp",
                J = "webpack",
                ee = "polyfills",
                er = Symbol(ee),
                et = "webpack-runtime",
                en = "edge-runtime-webpack",
                ei = "__N_SSG",
                el = "__N_SSP",
                ea = {
                    name: "Times New Roman",
                    xAvgCharWidth: 821,
                    azAvgWidth: 854.3953488372093,
                    unitsPerEm: 2048
                },
                es = {
                    name: "Arial",
                    xAvgCharWidth: 904,
                    azAvgWidth: 934.5116279069767,
                    unitsPerEm: 2048
                },
                eo = ["/500"],
                eu = 1,
                ed = 6e3,
                ec = {
                    client: "client",
                    server: "server"
                },
                ep = ["clearImmediate", "setImmediate", "BroadcastChannel", "ByteLengthQueuingStrategy", "CompressionStream", "CountQueuingStrategy", "DecompressionStream", "DomException", "MessageChannel", "MessageEvent", "MessagePort", "ReadableByteStreamController", "ReadableStreamBYOBRequest", "ReadableStreamDefaultController", "TransformStreamDefaultController", "WritableStreamDefaultController"],
                em = new Set([X, $, q, Y]);
            ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
                value: !0
            }), Object.assign(r.default, r), e.exports = r.default)
        },
        85302: e => {
            e.exports = ["chrome 64", "edge 79", "firefox 67", "opera 51", "safari 12"]
        },
        78655: (e, r, t) => {
            t.d(r, {
                c: () => s
            });
            var n = t(12428),
                i = t(62993);

            function l() {
                return (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)("stop", {
                        stopColor: "hsl(var(--color-purple))"
                    }), (0, n.jsx)("stop", {
                        offset: "1",
                        stopColor: "hsl(var(--color-primary))"
                    })]
                })
            }

            function a(e) {
                let {
                    years: r
                } = e;

                function t(e, t) {
                    return r > e ? t : "hsl(var(--border))"
                }
                return (0, n.jsxs)("svg", {
                    width: "40",
                    height: "40",
                    viewBox: "0 0 40 40",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, n.jsxs)("g", {
                        clipPath: "url(#clip0_18024_75482)",
                        children: [(0, n.jsx)("mask", {
                            id: "path-1-inside-1_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M20.349 1.69333C20.3519 1.41012 20.5839 1.18214 20.8669 1.19244C24.216 1.31427 27.4773 2.29748 30.3357 4.04698C30.5772 4.19484 30.6446 4.51306 30.4904 4.75065L28.9264 7.16123C28.7722 7.39883 28.455 7.46568 28.2125 7.31942C25.9762 5.97075 23.4367 5.20519 20.8276 5.09309C20.5447 5.08094 20.3173 4.84992 20.3201 4.56671L20.349 1.69333Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M20.349 1.69333C20.3519 1.41012 20.5839 1.18214 20.8669 1.19244C24.216 1.31427 27.4773 2.29748 30.3357 4.04698C30.5772 4.19484 30.6446 4.51306 30.4904 4.75065L28.9264 7.16123C28.7722 7.39883 28.455 7.46568 28.2125 7.31942C25.9762 5.97075 23.4367 5.20519 20.8276 5.09309C20.5447 5.08094 20.3173 4.84992 20.3201 4.56671L20.349 1.69333Z",
                            stroke: t(0, "url(#paint0_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-1-inside-1_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-2-inside-2_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M31.5272 5.46782C31.6968 5.24096 32.0187 5.19402 32.241 5.36949C34.8715 7.44581 36.9226 10.1654 38.1958 13.2654C38.3034 13.5274 38.1698 13.8239 37.9051 13.9246L35.2193 14.9461C34.9545 15.0467 34.6591 14.9134 34.5498 14.6521C33.5417 12.243 31.9447 10.1254 29.9055 8.49391C29.6843 8.31698 29.6373 7.99627 29.8068 7.76942L31.5272 5.46782Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M31.5272 5.46782C31.6968 5.24096 32.0187 5.19402 32.241 5.36949C34.8715 7.44581 36.9226 10.1654 38.1958 13.2654C38.3034 13.5274 38.1698 13.8239 37.9051 13.9246L35.2193 14.9461C34.9545 15.0467 34.6591 14.9134 34.5498 14.6521C33.5417 12.243 31.9447 10.1254 29.9055 8.49391C29.6843 8.31698 29.6373 7.99627 29.8068 7.76942L31.5272 5.46782Z",
                            stroke: t(1, "url(#paint1_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-2-inside-2_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-3-inside-3_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M38.3743 15.3533C38.6462 15.274 38.9316 15.43 39.0037 15.7039C39.8574 18.9446 39.8612 22.3509 39.0149 25.5935C38.9434 25.8676 38.6583 26.0242 38.3862 25.9455L35.6259 25.1469C35.3538 25.0682 35.198 24.784 35.2677 24.5095C35.9106 21.9784 35.9076 19.326 35.259 16.7964C35.1886 16.522 35.3439 16.2375 35.6157 16.1581L38.3743 15.3533Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M38.3743 15.3533C38.6462 15.274 38.9316 15.43 39.0037 15.7039C39.8574 18.9446 39.8612 22.3509 39.0149 25.5935C38.9434 25.8676 38.6583 26.0242 38.3862 25.9455L35.6259 25.1469C35.3538 25.0682 35.198 24.784 35.2677 24.5095C35.9106 21.9784 35.9076 19.326 35.259 16.7964C35.1886 16.522 35.3439 16.2375 35.6157 16.1581L38.3743 15.3533Z",
                            stroke: t(2, "url(#paint2_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-3-inside-3_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-4-inside-4_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M37.9726 27.2064C38.2385 27.3038 38.3757 27.5988 38.2713 27.862C37.0355 30.9771 35.0174 33.7213 32.4121 35.8292C32.1919 36.0073 31.8695 35.9642 31.6972 35.7394L29.9492 33.4588C29.7769 33.234 29.82 32.9127 30.039 32.7331C32.0584 31.0772 33.6298 28.9405 34.6087 26.5194C34.7149 26.2568 35.0087 26.1199 35.2746 26.2174L37.9726 27.2064Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M37.9726 27.2064C38.2385 27.3038 38.3757 27.5988 38.2713 27.862C37.0355 30.9771 35.0174 33.7213 32.4121 35.8292C32.1919 36.0073 31.8695 35.9642 31.6972 35.7394L29.9492 33.4588C29.7769 33.234 29.82 32.9127 30.039 32.7331C32.0584 31.0772 33.6298 28.9405 34.6087 26.5194C34.7149 26.2568 35.0087 26.1199 35.2746 26.2174L37.9726 27.2064Z",
                            stroke: t(3, "url(#paint3_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-4-inside-4_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-5-inside-5_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M30.7166 36.4309C30.8744 36.6661 30.8118 36.9853 30.5725 37.1368C27.7409 38.9292 24.4947 39.9615 21.1479 40.1338C20.8651 40.1483 20.6297 39.9239 20.6225 39.6407L20.5503 36.7681C20.5432 36.485 20.7671 36.2506 21.0498 36.2342C23.6569 36.0827 26.1845 35.279 28.4003 33.8968C28.6406 33.7469 28.9587 33.8089 29.1164 34.0442L30.7166 36.4309Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M30.7166 36.4309C30.8744 36.6661 30.8118 36.9853 30.5725 37.1368C27.7409 38.9292 24.4947 39.9615 21.1479 40.1338C20.8651 40.1483 20.6297 39.9239 20.6225 39.6407L20.5503 36.7681C20.5432 36.485 20.7671 36.2506 21.0498 36.2342C23.6569 36.0827 26.1845 35.279 28.4003 33.8968C28.6406 33.7469 28.9587 33.8089 29.1164 34.0442L30.7166 36.4309Z",
                            stroke: t(4, "url(#paint4_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-5-inside-5_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-6-inside-6_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M19.583 39.6351C19.5745 39.9182 19.338 40.1415 19.0553 40.1256C15.7093 39.937 12.4682 38.889 9.64531 37.0829C9.40674 36.9303 9.34576 36.6108 9.50462 36.3763L11.1164 33.9974C11.2753 33.7629 11.5937 33.7024 11.8333 33.8534C14.0423 35.2464 16.566 36.0624 19.1723 36.2265C19.455 36.2443 19.6777 36.4798 19.6692 36.7629L19.583 39.6351Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M19.583 39.6351C19.5745 39.9182 19.338 40.1415 19.0553 40.1256C15.7093 39.937 12.4682 38.889 9.64531 37.0829C9.40674 36.9303 9.34576 36.6108 9.50462 36.3763L11.1164 33.9974C11.2753 33.7629 11.5937 33.7024 11.8333 33.8534C14.0423 35.2464 16.566 36.0624 19.1723 36.2265C19.455 36.2443 19.6777 36.4798 19.6692 36.7629L19.583 39.6351Z",
                            stroke: t(5, "url(#paint5_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-6-inside-6_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-7-inside-7_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M8.5883 35.7043C8.41559 35.9288 8.0931 35.9713 7.87326 35.7927C5.27196 33.6798 3.25908 30.9319 2.02925 27.8144C1.92531 27.551 2.06305 27.2563 2.32916 27.1593L5.029 26.1755C5.2951 26.0785 5.58864 26.216 5.6943 26.4788C6.66862 28.9017 8.23594 31.0414 10.2522 32.7012C10.4708 32.8812 10.5134 33.2025 10.3407 33.427L8.5883 35.7043Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M8.5883 35.7043C8.41559 35.9288 8.0931 35.9713 7.87326 35.7927C5.27196 33.6798 3.25908 30.9319 2.02925 27.8144C1.92531 27.551 2.06305 27.2563 2.32916 27.1593L5.029 26.1755C5.2951 26.0785 5.58864 26.216 5.6943 26.4788C6.66862 28.9017 8.23594 31.0414 10.2522 32.7012C10.4708 32.8812 10.5134 33.2025 10.3407 33.427L8.5883 35.7043Z",
                            stroke: t(6, "url(#paint6_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-7-inside-7_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-8-inside-8_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M1.96583 26.0571C1.69429 26.1376 1.4082 25.9828 1.33486 25.7093C0.467132 22.4723 0.448503 19.066 1.28078 15.8198C1.35112 15.5454 1.6355 15.3875 1.9079 15.4651L4.67167 16.2516C4.94408 16.3292 5.10118 16.6127 5.03265 16.8875C4.40073 19.4214 4.41524 22.0737 5.07483 24.6006C5.14637 24.8746 4.99237 25.1598 4.72083 25.2403L1.96583 26.0571Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M1.96583 26.0571C1.69429 26.1376 1.4082 25.9828 1.33486 25.7093C0.467132 22.4723 0.448503 19.066 1.28078 15.8198C1.35112 15.5454 1.6355 15.3875 1.9079 15.4651L4.67167 16.2516C4.94408 16.3292 5.10118 16.6127 5.03265 16.8875C4.40073 19.4214 4.41524 22.0737 5.07483 24.6006C5.14637 24.8746 4.99237 25.1598 4.72083 25.2403L1.96583 26.0571Z",
                            stroke: t(7, "url(#paint7_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-8-inside-8_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-9-inside-9_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M2.24696 14.4095C1.97957 14.3161 1.83786 14.0234 1.93822 13.7585C3.1258 10.6247 5.10134 7.84979 7.67383 5.70197C7.89124 5.52045 8.21427 5.55853 8.39001 5.78064L10.173 8.03409C10.3487 8.25619 10.3105 8.57807 10.0943 8.76102C8.10072 10.4479 6.56247 12.6086 5.621 15.0445C5.5189 15.3087 5.22725 15.4501 4.95986 15.3568L2.24696 14.4095Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M2.24696 14.4095C1.97957 14.3161 1.83786 14.0234 1.93822 13.7585C3.1258 10.6247 5.10134 7.84979 7.67383 5.70197C7.89124 5.52045 8.21427 5.55853 8.39001 5.78064L10.173 8.03409C10.3487 8.25619 10.3105 8.57807 10.0943 8.76102C8.10072 10.4479 6.56247 12.6086 5.621 15.0445C5.5189 15.3087 5.22725 15.4501 4.95986 15.3568L2.24696 14.4095Z",
                            stroke: t(8, "url(#paint8_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-9-inside-9_18024_75482)"
                        }), (0, n.jsx)("mask", {
                            id: "path-10-inside-10_18024_75482",
                            fill: "white",
                            children: (0, n.jsx)("path", {
                                d: "M9.28343 5.12408C9.12106 4.89202 9.17722 4.57164 9.41347 4.41543C12.2089 2.56703 15.4339 1.47037 18.7766 1.23149C19.0591 1.2113 19.2989 1.43103 19.3117 1.71396L19.441 4.58457C19.4538 4.86751 19.2346 5.10633 18.9523 5.12838C16.3487 5.33165 13.8376 6.18556 11.6498 7.61161C11.4125 7.76626 11.0932 7.71054 10.9308 7.47849L9.28343 5.12408Z"
                            })
                        }), (0, n.jsx)("path", {
                            d: "M9.28343 5.12408C9.12106 4.89202 9.17722 4.57164 9.41347 4.41543C12.2089 2.56703 15.4339 1.47037 18.7766 1.23149C19.0591 1.2113 19.2989 1.43103 19.3117 1.71396L19.441 4.58457C19.4538 4.86751 19.2346 5.10633 18.9523 5.12838C16.3487 5.33165 13.8376 6.18556 11.6498 7.61161C11.4125 7.76626 11.0932 7.71054 10.9308 7.47849L9.28343 5.12408Z",
                            stroke: t(9, "url(#paint9_linear_18024_75482)"),
                            strokeWidth: "8.20513",
                            strokeLinecap: "round",
                            mask: "url(#path-10-inside-10_18024_75482)"
                        })]
                    }), (0, n.jsxs)("defs", {
                        children: [(0, n.jsx)("linearGradient", {
                            id: "paint0_linear_18024_75482",
                            x1: "39.4567",
                            y1: "40.3664",
                            x2: "0.859375",
                            y2: "0.984375",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint1_linear_18024_75482",
                            x1: "24.1052",
                            y1: "47.9604",
                            x2: "16.2188",
                            y2: "-6.61523",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint2_linear_18024_75482",
                            x1: "6.89576",
                            y1: "44.8459",
                            x2: "33.4062",
                            y2: "-3.50586",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint3_linear_18024_75482",
                            x1: "-4.86535",
                            y1: "32.2676",
                            x2: "45.1641",
                            y2: "9.07813",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint4_linear_18024_75482",
                            x1: "-6.90453",
                            y1: "15.3275",
                            x2: "47.1953",
                            y2: "26",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint5_linear_18024_75482",
                            x1: "1.24999",
                            y1: "0.588926",
                            x2: "39.0547",
                            y2: "40.7324",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint6_linear_18024_75482",
                            x1: "16.603",
                            y1: "-6.68044",
                            x2: "23.7266",
                            y2: "48",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint7_linear_18024_75482",
                            x1: "33.3161",
                            y1: "-3.57177",
                            x2: "7.01562",
                            y2: "44.8945",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint8_linear_18024_75482",
                            x1: "45.0017",
                            y1: "8.68815",
                            x2: "-4.66406",
                            y2: "32.6465",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("linearGradient", {
                            id: "paint9_linear_18024_75482",
                            x1: "1.24999",
                            y1: "40.3664",
                            x2: "39.0547",
                            y2: "0.984375",
                            gradientUnits: "userSpaceOnUse",
                            children: (0, n.jsx)(l, {})
                        }), (0, n.jsx)("clipPath", {
                            id: "clip0_18024_75482",
                            children: (0, n.jsx)("rect", {
                                width: "40",
                                height: "40",
                                fill: "white",
                                transform: "translate(0 0.5)"
                            })
                        })]
                    })]
                })
            }

            function s(e) {
                let {
                    years: r
                } = e;
                return (0, n.jsxs)("div", {
                    className: "relative",
                    children: [(0, n.jsx)(a, {
                        years: r
                    }), (0, n.jsx)("p", {
                        className: (0, i.cn)("absolute font-semibold", r > 9 ? "top-3 left-2.5 text-xs" : "top-2.5 left-4 text-sm"),
                        children: r > 9 ? "10+" : r
                    })]
                })
            }
        }
    }
]);