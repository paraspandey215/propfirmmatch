"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9365], {
        36022: (e, a, s) => {
            s.d(a, {
                j: () => r
            });
            var t = s(12428),
                l = s(30245);
            let r = e => (0, t.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [e.count ? (0, t.jsx)("p", {
                    className: "font-semibold leading-6",
                    children: "".concat(e.count, " ").concat(e.itemsLabel)
                }) : (0, t.jsx)("div", {}), e.sorting && (0, t.jsx)(l.h, { ...e.sorting
                })]
            })
        },
        61180: (e, a, s) => {
            s.d(a, {
                h: () => W
            });
            var t, l = s(12428),
                r = s(85473),
                n = s(74607),
                i = s(97385),
                o = s(20533),
                d = s(93264),
                c = s(37742),
                u = s(6185),
                m = s(24040),
                x = s(95805),
                p = s(74777),
                f = s(26185),
                h = s(30758),
                v = s(45253),
                g = s(32029),
                j = s(90861);

            function b(e) {
                var a, s, t, r, n, i, o, d, b, y, N, w, S, C, z, k;
                let {
                    challenge: R
                } = e, {
                    t: P
                } = (0, u.$G)(), T = (0, c.F)(), {
                    getFileReadUrl: F
                } = (0, m.lA)(), A = [{
                    label: P("PropFirmMatch Score"),
                    value: (0, l.jsx)(v.$, {
                        reviews: null !== (y = null === (a = R.firm) || void 0 === a ? void 0 : a.reviewsCount) && void 0 !== y ? y : 0,
                        reviewScore: null !== (N = null === (s = R.firm) || void 0 === s ? void 0 : s.reviewScore) && void 0 !== N ? N : 0
                    })
                }, {
                    label: P("Trustpilot Score"),
                    value: null === (t = R.firm) || void 0 === t ? void 0 : t.trustPilotScore
                }, {
                    label: P("Country"),
                    value: (0, l.jsx)(f.l, {
                        countryCode: null !== (w = null === (r = R.firm) || void 0 === r ? void 0 : r.country) && void 0 !== w ? w : "US"
                    })
                }, {
                    label: P("Favorite By"),
                    value: (0, l.jsx)(j.Lr, {
                        value: null !== (S = null === (n = R.firm) || void 0 === n ? void 0 : n.likesCount) && void 0 !== S ? S : 0
                    })
                }, {
                    label: P("Platform Available"),
                    value: (0, l.jsx)("div", {
                        className: "flex gap-1 flex-wrap justify-end",
                        children: null === (i = R.firmPlatforms) || void 0 === i ? void 0 : i.map(e => (0, l.jsx)(p.C, {
                            variant: "secondary",
                            className: "rounded-full py-0.5 px-1.5",
                            children: (0, l.jsxs)("div", {
                                className: "flex items-center space-x-px",
                                children: [(0, l.jsx)(x.Avatar, {
                                    className: "size-4",
                                    children: e.icon ? (0, l.jsx)(x.AvatarImage, {
                                        src: F(e.icon)
                                    }) : (0, l.jsx)(x.Q, {
                                        title: e.name,
                                        children: e.name.substring(0, 2)
                                    })
                                }), (0, l.jsx)("p", {
                                    className: "text-xs font-normal",
                                    children: e.name
                                })]
                            })
                        }, e.id))
                    })
                }, {
                    label: P("Program Type"),
                    value: R.steps ? (0, l.jsx)(j.UW, {
                        labels: [T[R.steps]]
                    }) : null
                }, {
                    label: P("Max Allocation"),
                    value: (0, l.jsx)(h.G, {
                        className: "w-24",
                        align: "right",
                        label: (0, g.uf)({
                            value: null !== (C = null === (o = R.firm) || void 0 === o ? void 0 : o.maxAllocation) && void 0 !== C ? C : 0,
                            currency: null !== (z = null === (d = R.firm) || void 0 === d ? void 0 : d.currency) && void 0 !== z ? z : g.Mf.USD,
                            maximumFractionDigits: 2,
                            notation: "compact"
                        }),
                        value: null !== (k = null === (b = R.firm) || void 0 === b ? void 0 : b.maxAllocation) && void 0 !== k ? k : 0
                    })
                }];
                return (0, l.jsx)(j.BR, {
                    title: P("Firm Overview"),
                    fields: A
                })
            }
            var y = s(69615),
                N = s(40850),
                w = s(1456),
                S = s(45752),
                C = s(45258),
                z = s(25845),
                k = s(3934),
                R = s(47576),
                P = s(35022),
                T = s(67266),
                F = s(95772),
                A = s(98661);

            function O(e) {
                var a, s, t, r;
                let {
                    challenge: n
                } = e, {
                    t: o
                } = (0, u.$G)(), d = (0, A.mM)(), c = (0, R.usePathname)(), [m] = (0, P.v1)("applyDiscount", F.z.boolean().optional());
                return (0, l.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, l.jsxs)("div", {
                        className: "flex items-center space-x-4",
                        children: [n.firm && (0, l.jsx)(y.wK, {
                            firm: n.firm
                        }), (0, l.jsxs)("div", {
                            className: "space-y-0.5",
                            children: [(0, l.jsx)(w.$N, {
                                className: "text-base font-semibold",
                                children: null === (a = n.firm) || void 0 === a ? void 0 : a.name
                            }), (0, l.jsx)(S.L, {
                                points: null !== (t = n.loyaltyPoints) && void 0 !== t ? t : 0
                            })]
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "flex items-center space-x-4",
                        children: [(0, l.jsxs)("div", {
                            className: "flex item-center space-x-5",
                            children: [(0, l.jsx)(T.Q, {
                                challenge: n,
                                applyDiscount: null == m || m,
                                currency: null !== (r = null === (s = n.firm) || void 0 === s ? void 0 : s.currency) && void 0 !== r ? r : "USD"
                            }), !c.startsWith("/prop-firm-challenges/") && !c.startsWith("/checkout") && (0, l.jsx)(N.zx, {
                                variant: "pfmGradient",
                                rounded: "full",
                                asChild: !0,
                                children: (0, l.jsx)(k.default, {
                                    href: d.NEXT_PUBLIC_MAIN_WEBSITE_URL + "/prop-firm-challenges/".concat(n.slug),
                                    children: o("Buy")
                                })
                            })]
                        }), (0, l.jsx)(i.Separator, {
                            orientation: "vertical",
                            className: "h-[42px] bg-border w-px"
                        }), (0, l.jsx)(C.x8, {
                            className: "rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
                            children: (0, l.jsx)(z.Z, {
                                className: "h-6 w-6"
                            })
                        })]
                    })]
                })
            }
            var M = s(80501),
                E = s(37672),
                L = s(92494),
                I = s(62993);
            ! function(e) {
                e.Top = "top", e.Bottom = "bottom", e.Inline = "inline"
            }(t || (t = {}));
            let D = e => {
                let {
                    minimumLimit: a = -10,
                    maximumLimit: s = 10,
                    value: t,
                    valueLabel: r,
                    showMinimumLimit: n,
                    variant: i = "orangeToGreenGradient",
                    valuePosition: o = "top"
                } = e, d = (0, g._G)({
                    minLimit: a,
                    maxLimit: s,
                    value: t
                }), c = s / t * 100;
                return (0, l.jsxs)("div", {
                    className: "space-y-2",
                    children: ["top" === o && (0, l.jsxs)("div", {
                        className: "flex items-center text-xs px-1",
                        children: [n && (0, l.jsxs)("p", {
                            className: "text-red-theme",
                            children: [a, "%"]
                        }), (0, l.jsxs)("div", {
                            className: "flex flex-1 justify-end space-x-1 text-right",
                            children: [(0, l.jsx)("p", {
                                children: r
                            }), (0, l.jsxs)("p", {
                                className: "text-green-theme",
                                children: [t, "%"]
                            })]
                        })]
                    }), (0, l.jsxs)("div", {
                        className: (0, I.cn)("relative", "bottom" === o ? "mt-2" : ""),
                        children: [(0, l.jsx)(L.P, {
                            value: s,
                            minLimit: a,
                            maxLimit: s,
                            variant: i,
                            size: "xxs",
                            className: "opacity-20"
                        }), (0, l.jsx)("div", {
                            className: "absolute overflow-hidden h-full bg-transparent top-0",
                            style: {
                                width: "".concat(d, "%")
                            },
                            children: (0, l.jsx)(L.P, {
                                value: s,
                                minLimit: a,
                                maxLimit: s,
                                variant: i,
                                size: "xxs",
                                customStyle: {
                                    backgroundSize: "".concat(c, "% 100%")
                                }
                            })
                        }), (0, l.jsx)("p", {
                            className: "absolute -top-[9px] left-1/2",
                            children: "|"
                        })]
                    }), "bottom" === o && (0, l.jsxs)("div", {
                        className: "flex items-center text-xs px-1",
                        children: [n && (0, l.jsxs)("p", {
                            className: "text-red-theme",
                            children: [a, "%"]
                        }), (0, l.jsxs)("div", {
                            className: "flex flex-1 justify-end space-x-1 text-right",
                            children: [(0, l.jsx)("p", {
                                children: r
                            }), (0, l.jsxs)("p", {
                                className: "text-green-theme",
                                children: [t, "%"]
                            })]
                        })]
                    })]
                })
            };

            function _(e) {
                return (0, l.jsxs)(E.Zb, {
                    className: "px-4 min-h-[87px] h-full flex flex-col justify-center space-y-1",
                    children: [(0, l.jsx)("p", {
                        className: "text-xs text-foreground-secondary mt-px",
                        children: e.label
                    }), (0, l.jsx)("p", {
                        className: "text-sm font-semibold text-foreground mb-px",
                        children: e.value
                    })]
                })
            }

            function G(e) {
                let {
                    t: a
                } = (0, u.$G)(), s = (0, d.useMemo)(() => {
                    let a = [];
                    return e.challenge.phase1ProfitTarget && a.push({
                        profitTarget: e.challenge.phase1ProfitTarget,
                        maxLoss: e.challenge.phase1MaxDrawdown
                    }), e.challenge.phase2ProfitTarget && a.push({
                        profitTarget: e.challenge.phase2ProfitTarget,
                        maxLoss: e.challenge.phase2MaxDrawdown
                    }), e.challenge.phase3ProfitTarget && a.push({
                        profitTarget: e.challenge.phase3ProfitTarget,
                        maxLoss: e.challenge.phase3MaxDrawdown
                    }), e.challenge.phase4ProfitTarget && a.push({
                        profitTarget: e.challenge.phase4ProfitTarget,
                        maxLoss: e.challenge.phase4MaxDrawdown
                    }), a
                }, [e.challenge.phase1ProfitTarget, e.challenge.phase2ProfitTarget, e.challenge.phase3ProfitTarget, e.challenge.phase4ProfitTarget, e.challenge.phase1MaxDrawdown, e.challenge.phase2MaxDrawdown, e.challenge.phase3MaxDrawdown, e.challenge.phase4MaxDrawdown]), t = (0, M.z)(), r = (0, d.useMemo)(() => {
                    var a, s, t, l;
                    return Math.max(null !== (a = e.challenge.phase1ProfitTarget) && void 0 !== a ? a : 0, null !== (s = e.challenge.phase2ProfitTarget) && void 0 !== s ? s : 0, null !== (t = e.challenge.phase3ProfitTarget) && void 0 !== t ? t : 0, null !== (l = e.challenge.phase4ProfitTarget) && void 0 !== l ? l : 0)
                }, [e.challenge.phase1ProfitTarget, e.challenge.phase2ProfitTarget, e.challenge.phase3ProfitTarget, e.challenge.phase4ProfitTarget, s]);
                return (0, l.jsxs)("div", {
                    className: "grid grid-cols-2 grid-rows-4 gap-2",
                    children: [(0, l.jsx)(E.Zb, {
                        className: "row-span-2",
                        children: (0, l.jsxs)(E.aY, {
                            className: "p-4 space-y-3",
                            children: [(0, l.jsxs)("div", {
                                className: "flex items-center justify-between text-xs font-normal text-foreground-secondary",
                                children: [(0, l.jsx)("p", {
                                    children: a("Max Drawdown")
                                }), (0, l.jsx)("p", {
                                    children: a("Profit Target")
                                })]
                            }), s.map((e, s) => {
                                var t, n;
                                return (0, l.jsx)(D, {
                                    showMinimumLimit: !!e.maxLoss,
                                    value: null !== (t = e.profitTarget) && void 0 !== t ? t : 0,
                                    minimumLimit: -((null !== (n = e.maxLoss) && void 0 !== n ? n : 0) * 1),
                                    maximumLimit: r,
                                    valueLabel: "".concat(s + 1, " ").concat(a("step"), ":")
                                }, s)
                            })]
                        })
                    }), (0, l.jsx)(_, {
                        value: e.challenge.maxDailyLoss ? "%".concat(e.challenge.maxDailyLoss) : "None",
                        label: a("Daily Loss:")
                    }), (0, l.jsx)(_, {
                        value: e.challenge.maxLossType ? String(e.challenge.maxLossType) : "None",
                        label: a("Max Loss Type:")
                    }), (0, l.jsx)(_, {
                        value: e.challenge.name,
                        label: a("Program Name:")
                    }), (0, l.jsx)(_, {
                        value: e.challenge.drawdownType ? t[e.challenge.drawdownType] : "None",
                        label: a("Daily Drawdown Reset Type:")
                    }), (0, l.jsx)(_, {
                        value: e.challenge.minimumTradingDays ? a("{{ amount }} days", {
                            amount: "" + e.challenge.minimumTradingDays
                        }) : "None",
                        label: a("Min Trading Days:")
                    }), (0, l.jsx)(_, {
                        value: e.challenge.maximumTradingDays ? a("{{ amount }} days", {
                            amount: "" + e.challenge.maximumTradingDays
                        }) : "∞ Unlimited",
                        label: a("Time Limit:")
                    })]
                })
            }

            function B(e) {
                var a, s, t, r, n, i, o, d, c;
                let {
                    challenge: m
                } = e, {
                    t: x
                } = (0, u.$G)(), p = [{
                    label: x("Profit Split"),
                    description: null !== (r = null === (a = m.firm) || void 0 === a ? void 0 : a.profitSplit) && void 0 !== r ? r : "",
                    value: (null !== (n = m.profitSplit) && void 0 !== n ? n : "") + "%"
                }, {
                    label: x("Refundable Fee"),
                    description: null !== (i = null === (s = m.firm) || void 0 === s ? void 0 : s.refundFee) && void 0 !== i ? i : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (o = m.refundableFee) && void 0 !== o && o,
                        children: x(m.refundableFee ? "Yes" : "No")
                    })
                }, {
                    label: x("Payout Frequency"),
                    description: null !== (d = null === (t = m.firm) || void 0 === t ? void 0 : t.payoutFrequency) && void 0 !== d ? d : "",
                    value: null !== (c = m.payoutFrequencyDescription) && void 0 !== c ? c : ""
                }];
                return (0, l.jsx)(j.BR, {
                    title: x("Payout Overview"),
                    fields: p
                })
            }

            function U(e) {
                var a, s, t, r, n, i, o, d, c, m, x, p, f, h, v, g, b, y, N;
                let {
                    challenge: w
                } = e, {
                    t: S
                } = (0, u.$G)(), C = [...w.activationFee ? [{
                    label: S("Activation Fee"),
                    value: null !== (o = w.activationFee) && void 0 !== o ? o : ""
                }] : [], {
                    label: S("Max Leverage"),
                    description: null !== (d = null === (a = w.firm) || void 0 === a ? void 0 : a.maxLeverage) && void 0 !== d ? d : "",
                    value: null !== (c = w.maxLeverage) && void 0 !== c ? c : ""
                }, {
                    label: S("News-Trading"),
                    description: null !== (m = null === (s = w.firm) || void 0 === s ? void 0 : s.newsTrading) && void 0 !== m ? m : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (x = w.newsTradingEnabled) && void 0 !== x && x,
                        children: S(w.newsTradingEnabled ? "Yes" : "No")
                    })
                }, {
                    label: S("Copy-Trading"),
                    description: null !== (p = null === (t = w.firm) || void 0 === t ? void 0 : t.copyTrading) && void 0 !== p ? p : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (f = w.copyTradingEnabled) && void 0 !== f && f,
                        children: S(w.copyTradingEnabled ? "Yes" : "No")
                    })
                }, {
                    label: S("EA's"),
                    description: null !== (h = null === (r = w.firm) || void 0 === r ? void 0 : r.expertAdvisors) && void 0 !== h ? h : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (v = w.expertAdvisorsEnabled) && void 0 !== v && v,
                        children: S(w.expertAdvisorsEnabled ? "Allowed" : "Not allowed")
                    })
                }, {
                    label: S("Weekend Holding"),
                    description: null !== (g = null === (n = w.firm) || void 0 === n ? void 0 : n.weekendHolding) && void 0 !== g ? g : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (b = w.weekendHoldingEnabled) && void 0 !== b && b,
                        children: S(w.weekendHoldingEnabled ? "Yes" : "No")
                    })
                }, {
                    label: S("Overnight Holding"),
                    description: null !== (y = null === (i = w.firm) || void 0 === i ? void 0 : i.overnightHolding) && void 0 !== y ? y : "",
                    value: (0, l.jsx)(j.io, {
                        value: null !== (N = w.overnightHoldingEnabled) && void 0 !== N && N,
                        children: S(w.overnightHoldingEnabled ? "Yes" : "No")
                    })
                }];
                return (0, l.jsx)(j.BR, {
                    title: S("Challenge Trading Overview"),
                    fields: C
                })
            }

            function V(e) {
                let [a] = r.trpc.challenge.getWithFullDetails.useSuspenseQuery({
                    challengeId: e.challengeId
                });
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)(n.Tu, {
                        className: "pb-10",
                        children: (0, l.jsx)(O, {
                            challenge: a
                        })
                    }), (0, l.jsxs)("div", {
                        className: "space-y-2",
                        children: [(0, l.jsx)(G, {
                            challenge: a
                        }), (0, l.jsxs)("div", {
                            children: [(0, l.jsx)(U, {
                                challenge: a
                            }), (0, l.jsx)(i.Separator, {
                                className: "w-full bg-border"
                            }), (0, l.jsx)(B, {
                                challenge: a
                            }), (0, l.jsx)(i.Separator, {
                                className: "w-full bg-border"
                            }), (0, l.jsx)(b, {
                                challenge: a
                            })]
                        })]
                    })]
                })
            }

            function $() {
                return (0, l.jsxs)("div", {
                    children: [(0, l.jsxs)(n.Tu, {
                        className: "mb-8",
                        children: [(0, l.jsx)(n.bC, {
                            children: (0, l.jsx)(o.O, {
                                className: "w-full h-6"
                            })
                        }), (0, l.jsx)(n.Ei, {
                            children: "\xa0"
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "w-full h-screen",
                        children: [(0, l.jsxs)("div", {
                            className: "grid grid-cols-2 gap-2",
                            children: [(0, l.jsx)(o.O, {
                                className: "w-full h-40 row-span-2"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-full"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-full"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-24"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-24"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-24"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-24"
                            })]
                        }), Array.from({
                            length: 3
                        }).map((e, a) => (0, l.jsxs)("div", {
                            className: "space-y-4 mt-8",
                            children: [(0, l.jsx)(o.O, {
                                className: "w-full h-8 bg-background-tertiary"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-6"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-6"
                            }), (0, l.jsx)(o.O, {
                                className: "w-full h-6"
                            })]
                        }, a))]
                    })]
                })
            }

            function W(e) {
                let {
                    children: a,
                    challengeId: s
                } = e;
                return (0, l.jsxs)(n.yo, {
                    children: [(0, l.jsx)(n.aM, {
                        asChild: !0,
                        children: a
                    }), (0, l.jsx)(n.ue, {
                        className: "overflow-y-auto max-w-[540px] w-full rounded-l-lg p-5 lg:p-10",
                        children: (0, l.jsx)(d.Suspense, {
                            fallback: (0, l.jsx)($, {}),
                            children: (0, l.jsx)(V, {
                                challengeId: s
                            })
                        })
                    })]
                })
            }
        },
        67266: (e, a, s) => {
            s.d(a, {
                Q: () => n
            });
            var t = s(12428),
                l = s(62993),
                r = s(32029);

            function n(e) {
                var a, s;
                let {
                    challenge: n,
                    applyDiscount: i,
                    currency: o
                } = e, d = i && n.discountedPrice;
                return (0, t.jsxs)("div", {
                    className: (0, l.cn)("flex flex-col space-y-0.5 items-center", d ? "justify-between " : "justify-center"),
                    children: [(0, t.jsx)("p", {
                        className: (0, l.cn)("font-semibold text-[10px] md:text-sm"),
                        children: (0, r.uf)({
                            value: d && n.discountedPrice ? n.discountedPrice : null !== (a = n.price) && void 0 !== a ? a : 0,
                            currency: o,
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        })
                    }), d && (0, t.jsx)("p", {
                        className: "line-through text-[10px] md:text-xs font-medium text-foreground-tertiary",
                        children: (0, r.uf)({
                            value: null !== (s = n.price) && void 0 !== s ? s : 0,
                            currency: o,
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        })
                    })]
                })
            }
        },
        90861: (e, a, s) => {
            s.d(a, {
                BR: () => x,
                Lr: () => m,
                Q0: () => u,
                UW: () => c,
                io: () => d
            });
            var t = s(12428),
                l = s(65151),
                r = s(5313),
                n = s(42619),
                i = s(62993),
                o = s(7528);

            function d(e) {
                let {
                    value: a,
                    children: s
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, i.cn)(a ? "text-green-theme" : "text-foreground-tertiary"),
                    children: s
                })
            }
            let c = e => {
                    let {
                        labels: a
                    } = e;
                    return (0, t.jsx)("div", {
                        className: "flex gap-1 flex-wrap justify-end",
                        children: a.map((e, a) => (0, t.jsx)(l._, {
                            label: (0, t.jsx)("span", {
                                className: "font-semibold",
                                children: e
                            })
                        }, a))
                    })
                },
                u = e => {
                    let {
                        label: a,
                        image: s
                    } = e;
                    return (0, t.jsxs)("div", {
                        className: "flex items-center gap-1 w-max",
                        children: [(0, t.jsx)("img", {
                            src: s,
                            alt: a,
                            className: "size-4 rounded-full"
                        }), a]
                    })
                },
                m = e => {
                    let {
                        value: a
                    } = e;
                    return (0, t.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [(0, t.jsx)(r.dJ, {
                            color: "primary",
                            className: "size-3.5"
                        }), a]
                    })
                };

            function x(e) {
                return (0, t.jsxs)("div", {
                    className: "py-5 space-y-4",
                    children: [(0, t.jsx)("p", {
                        className: "font-semibold",
                        children: e.title
                    }), (0, t.jsx)("div", {
                        className: "space-y-1",
                        children: e.fields.map(e => (0, t.jsxs)("div", {
                            className: "flex items-center justify-between gap-4",
                            children: [(0, t.jsxs)("p", {
                                className: "text-xs font-normal text-foreground-secondary",
                                children: [e.label, ":"]
                            }), (0, t.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, t.jsx)("div", {
                                    className: "text-sm font-semibold",
                                    children: e.value
                                }), e.description && (0, t.jsxs)(n.J2, {
                                    children: [(0, t.jsx)(n.xo, {
                                        children: (0, t.jsx)(o.Z, {
                                            className: "w-3.5 h-3.5 text-muted-foreground cursor-help"
                                        })
                                    }), (0, t.jsx)(n.yk, {
                                        side: "bottom",
                                        className: "max-w-md",
                                        children: e.description
                                    })]
                                })]
                            })]
                        }, e.label))
                    })]
                })
            }
        },
        34298: (e, a, s) => {
            s.d(a, {
                L: () => o,
                X: () => c
            });
            var t = s(12428),
                l = s(62993),
                r = s(32029),
                n = s(51699),
                i = s(93264);
            let o = e => {
                    let a = (0, i.useMemo)(() => (0, r.mv)(e.country), [e.country]);
                    return (0, t.jsx)("img", {
                        src: a,
                        alt: e.country,
                        className: (0, l.cn)("inline w-4", e.className)
                    })
                },
                d = (0, n.j)("font-semibold", {
                    variants: {
                        size: {
                            xs: "text-xs font-normal"
                        }
                    },
                    defaultVariants: {
                        size: "xs"
                    }
                }),
                c = e => {
                    let a = (0, i.useMemo)(() => {
                        var a, s;
                        return null !== (s = null === (a = r.$Y.find(a => a.isoAlpha2 === e.country)) || void 0 === a ? void 0 : a.isoAlpha2) && void 0 !== s ? s : e.country
                    }, [e.country]);
                    return (0, t.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [(0, t.jsx)(o, {
                            country: e.country
                        }), (0, t.jsx)("span", {
                            className: (0, l.cn)(d({
                                size: e.size
                            }), e.className),
                            children: a
                        })]
                    })
                }
        },
        14892: (e, a, s) => {
            s.d(a, {
                AspectRatioEnum: () => t,
                D: () => c
            });
            var t, l = s(12428),
                r = s(6185),
                n = s(24040),
                i = s(40850),
                o = s(97385),
                d = s(93264);

            function c(e) {
                let {
                    t: a
                } = (0, r.$G)(), s = (0, n.lA)(), t = (0, d.useCallback)(a => {
                    try {
                        if (e.images[a]) {
                            let t = document.createElement("a"),
                                l = e.images[a];
                            if (!l) throw Error("Image URL is empty");
                            t.href = s.getFileReadUrl(l), t.target = "_blank", t.download = "share.png", t.click()
                        }
                    } catch (e) {
                        console.error("Failed to download image:", e)
                    }
                }, [s, e.images]);
                return (0, l.jsxs)("div", {
                    className: "space-y-4 w-full",
                    children: [(0, l.jsxs)("div", {
                        className: "space-x-6 flex items-center py-2.5",
                        children: [(0, l.jsx)(o.Separator, {
                            className: "flex-1 bg-border"
                        }), (0, l.jsx)("p", {
                            className: "text-sm text-foreground-tertiary",
                            children: a("or Download as Image")
                        }), (0, l.jsx)(o.Separator, {
                            className: "flex-1 bg-border"
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "flex gap-4",
                        children: [(0, l.jsx)(i.zx, {
                            className: "flex-1",
                            disabled: !e.images[0],
                            onClick: () => t(0),
                            rounded: "full",
                            variant: "outline",
                            children: a("Square (1:1)")
                        }), (0, l.jsx)(i.zx, {
                            className: "flex-1",
                            disabled: !e.images[1],
                            onClick: () => t(1),
                            rounded: "full",
                            variant: "outline",
                            children: a("Wide (16:9)")
                        })]
                    })]
                })
            }! function(e) {
                e[e.SQUARE = 0] = "SQUARE", e[e.WIDE = 1] = "WIDE"
            }(t || (t = {}))
        },
        45151: (e, a, s) => {
            s.d(a, {
                K: () => l
            });
            var t = s(12428);

            function l(e) {
                return (0, t.jsx)("img", {
                    alt: "instagram-logo",
                    src: "/instagram-logo.svg",
                    className: e.className
                })
            }
        },
        54328: (e, a, s) => {
            s.d(a, {
                B: () => l
            });
            var t = s(12428);

            function l(e) {
                return (0, t.jsx)("img", {
                    alt: "twitter-logo",
                    src: "/twitter-logo.svg",
                    className: e.className
                })
            }
        },
        65151: (e, a, s) => {
            s.d(a, {
                _: () => o
            });
            var t = s(12428),
                l = s(37672),
                r = s(51699),
                n = s(62993);
            let i = (0, r.j)("py-0.5 px-2 bg-background-tertiary border-border w-fit", {
                variants: {
                    variant: {
                        default: "",
                        green: "bg-green text-green-theme border-0",
                        yellow: "bg-yellow text-yellow-foreground border-0",
                        red: "bg-red text-red-theme border-0"
                    }
                },
                defaultVariants: {
                    variant: "default"
                }
            });

            function o(e) {
                let {
                    label: a,
                    variant: s,
                    className: r
                } = e;
                return (0, t.jsx)(l.Zb, {
                    rounded: "full",
                    className: (0, n.cn)(i({
                        variant: s
                    }), r),
                    children: "string" == typeof a ? (0, t.jsx)("p", {
                        className: "text-xs font-medium",
                        children: a
                    }) : a
                })
            }
        },
        27273: (e, a, s) => {
            s.d(a, {
                $E: () => N,
                $S: () => S,
                FM: () => w,
                Me: () => T,
                RS: () => C,
                S1: () => P,
                VD: () => R,
                X1: () => b,
                Zx: () => j,
                _4: () => z,
                iJ: () => k,
                ky: () => y,
                wW: () => F
            });
            var t = s(12428),
                l = s(6185),
                r = s(74777),
                n = s(56764),
                i = s(43748),
                o = s(5313),
                d = s(62993),
                c = s(30455),
                u = s(93264),
                m = s(56360),
                x = s(95262),
                p = s(65747),
                f = s(97385),
                h = s(51131);

            function v(e) {
                return (0, t.jsx)(m.E.div, {
                    className: (0, d.cn)("top" === e.position ? "top-0 -translate-y-1/2" : "bottom-0 translate-y-1/2", "absolute z-10 bg-background rounded-full size-9 transition-colors border", e.active ? "border-primary-theme" : "border-border-secondary", {
                        "left-[270px]": "default" === e.size,
                        "left-[210px]": "slim" === e.size
                    }, e.className),
                    role: "none"
                })
            }

            function g(e) {
                let {
                    className: a
                } = e;
                return (0, t.jsx)("div", {
                    role: "separator",
                    className: (0, d.cn)("absolute h-full z-0 top-0 right-0 bottom-0 w-0.5 transform translate-x-1/2 text-border flex items-stretch py-4", a),
                    children: (0, t.jsxs)("svg", {
                        viewBox: "0 0 2 60",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, t.jsx)("line", {
                            x1: "0",
                            y1: "0",
                            x2: "0",
                            y2: "5",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        }), (0, t.jsx)("line", {
                            x1: "0",
                            y1: "15",
                            x2: "0",
                            y2: "25",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        }), (0, t.jsx)("line", {
                            x1: "0",
                            y1: "35",
                            x2: "0",
                            y2: "45",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        }), (0, t.jsx)("line", {
                            x1: "0",
                            y1: "55",
                            x2: "0",
                            y2: "60",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        })]
                    })
                })
            }

            function j(e) {
                let a = (0, u.useRef)(null);
                return (0, t.jsx)(i.G7, {
                    variant: "pfmPaleOutline",
                    ref: a,
                    className: "md:rounded-2xl rounded-xl relative md:min-h-20 min-h-12",
                    children: (0, t.jsxs)(i.MB, {
                        className: "md:py-2",
                        children: [e.icon ? (0, t.jsx)(i.G7, {
                            variant: "pfmSolid",
                            className: "absolute top-0 left-0 md:[&_svg]:h-3 md:[&_svg]:w-[11px] rounded-none md:rounded-tl-2xl rounded-tl-xl md:rounded-br-2xl rounded-br-lg md:min-w-8 md:min-h-7 min-w-5 min-h-[17.5px] flex justify-center items-center",
                            style: {
                                backgroundSize: a.current ? "".concat(a.current.clientWidth, "px ").concat(a.current.clientHeight, "px") : "auto"
                            },
                            children: e.icon
                        }) : null, e.children]
                    })
                })
            }

            function b(e) {
                return (0, t.jsx)("div", {
                    className: (0, d.cn)("md:text-2xl text-sm font-semibold bg-[image:var(--pfm-gradient)] bg-clip-text text-transparent text-center", e.className),
                    children: e.children
                })
            }

            function y(e) {
                var a;
                let s = null !== (a = e.size) && void 0 !== a ? a : "default";
                return (0, t.jsxs)("div", {
                    className: (0, d.cn)("relative pr-7", e.className),
                    children: [(0, t.jsx)("div", {
                        className: (0, d.cn)("default" === s && "w-screen md:max-w-[242px] max-w-[122px]", "slim" === s && "w-screen max-w-[180px]"),
                        children: (0, t.jsx)(j, {
                            icon: e.icon,
                            children: e.children
                        })
                    }), (0, t.jsx)(g, {
                        className: "lg:block hidden"
                    })]
                })
            }

            function N(e) {
                var a;
                let s = null !== (a = e.size) && void 0 !== a ? a : "default";
                return (0, t.jsx)("div", {
                    className: (0, d.cn)("flex justify-between flex-1 overflow-x-auto", "slim" === s && "justify-end", "default" === s && "pl-7 pr-5", e.className),
                    children: e.children
                })
            }

            function w(e) {
                var a;
                let s = null !== (a = e.size) && void 0 !== a ? a : "default";
                return (0, t.jsx)(x.M, {
                    children: (0, t.jsxs)(m.E.div, {
                        className: (0, d.cn)("bg-background-primary rounded-2xl border md:p-5 p-3 transition-colors", e.isExpanded ? "border-primary-theme" : "border-border-secondary"),
                        children: [(0, t.jsx)(v, {
                            active: e.isExpanded,
                            className: "lg:block hidden",
                            position: "top",
                            size: s
                        }), (0, t.jsx)(v, {
                            active: e.isExpanded,
                            className: "lg:block hidden",
                            position: "bottom",
                            size: s
                        }), e.children]
                    })
                })
            }

            function S(e) {
                return (0, t.jsxs)(m.E.div, { ...e.isChild ? {
                        initial: {
                            opacity: 0,
                            height: 0
                        },
                        animate: {
                            opacity: 1,
                            height: "auto"
                        },
                        exit: {
                            opacity: 0,
                            height: 0
                        }
                    } : {},
                    transition: p.S,
                    children: [e.isChild && (0, t.jsx)(m.E.div, {
                        className: "lg:w-full lg:ml-0 md:-ml-5 -ml-3 md:w-[calc(100%+40px)] w-[calc(100%+24px)] md:my-5 my-2.5",
                        exit: {
                            margin: 0
                        },
                        children: (0, t.jsx)(f.Separator, {
                            className: "bg-border-secondary"
                        })
                    }), (0, t.jsx)("div", {
                        className: (0, d.cn)("flex items-center", e.className),
                        children: e.children
                    })]
                })
            }

            function C(e) {
                return (0, t.jsx)(x.M, {
                    children: (0, t.jsx)("div", {
                        className: "relative overflow-hidden",
                        children: e.children
                    })
                })
            }

            function z(e) {
                return (0, t.jsx)("span", {
                    className: "text-foreground uppercase md:text-xs md:leading-[18px] leading-[10px] text-[7px] font-semibold ",
                    children: e.children
                })
            }

            function k(e) {
                return (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsxs)(r.C, {
                        variant: "yellow",
                        size: "chipsSm",
                        rounded: "full",
                        className: "md:inline-flex hidden",
                        children: [(0, t.jsx)(o.Og, {}), e.children]
                    }), (0, t.jsxs)(r.C, {
                        variant: "yellow",
                        size: "chipXxs",
                        rounded: "full",
                        className: "md:hidden inline-flex items-center",
                        children: [(0, t.jsx)(o.Og, {}), e.children]
                    })]
                })
            }

            function R(e) {
                return (0, t.jsx)("div", {
                    className: (0, d.cn)("flex items-center justify-end md:space-x-4 space-x-2 ml-auto", e.className),
                    children: e.children
                })
            }

            function P(e) {
                var a, s;
                let {
                    t: r
                } = (0, l.$G)();
                return (0, t.jsx)(h.f, {
                    firmSlug: null !== (a = e.firmSlug) && void 0 !== a ? a : "",
                    id: null !== (s = e.id) && void 0 !== s ? s : "",
                    btnClassName: (0, d.cn)("py-1.5 px-3 rounded-full bg-primary text-base border border-dashed border-primary-theme font-semibold relative self-center hover:bg-primary/50 transition-all", {
                        "py-[3px] px-2": "xs" === e.size
                    }, e.className),
                    size: e.size,
                    codeClassName: (0, d.cn)("", {
                        "md:text-base": "default" === e.size,
                        "!text-[11.3px] leading-[17px]": "xs" === e.size
                    }),
                    value: e.code,
                    children: "default" === e.size && (0, t.jsx)("span", {
                        className: "md:inline hidden text-primary-theme text-xs font-normal border-r border-primary-hover pr-1.5 mr-1.5",
                        children: r("Code")
                    })
                })
            }

            function T(e) {
                let {
                    endDate: a
                } = e;
                return (0, t.jsxs)("div", {
                    className: "flex items-center justify-center md:text-xs md:leading-[18px] text-xxs leading-[15px] text-center",
                    children: [(0, t.jsx)(o.Qu, {
                        className: "md:inline hidden size-4 text-primary-theme mr-1.5"
                    }), (0, t.jsx)("span", {
                        children: (0, t.jsx)(l.cC, {
                            i18nKey: "Ends <date />",
                            components: {
                                date: () => (0, t.jsx)(n.r, {
                                    date: a,
                                    format: "xs"
                                })
                            }
                        })
                    })]
                })
            }

            function F(e) {
                return (0, t.jsx)(i.G7, {
                    asChild: !0,
                    variant: "pfmPaleOutline",
                    className: "md:h-9 h-[23px]",
                    children: (0, t.jsx)("button", {
                        onClick: e.onClick,
                        children: (0, t.jsxs)(i.MB, {
                            className: "md:px-3 md:py-1.5 py-1 px-2 space-x-1",
                            children: [(0, t.jsx)(o.dG, {
                                className: "md:w-4 md:h-4 h-2.5 w-2.5"
                            }), (0, t.jsx)("span", {
                                className: "md:text-base md:leading-6 text-xxs leading-[15px] font-semibold",
                                children: e.count
                            }), (0, t.jsx)(c.Z, {
                                className: (0, d.cn)("md:h-4 md:w-4 h-3.5 w-3.5 text-foreground-secondary transition-all transform origin-center", e.expanded && "rotate-180")
                            })]
                        })
                    })
                })
            }
        },
        72172: (e, a, s) => {
            s.d(a, {
                T: () => P,
                I: () => T
            });
            var t = s(12428),
                l = s(6185),
                r = s(69615),
                n = s(68944),
                i = s(17322),
                o = s(74777),
                d = s(40850),
                c = s(45253),
                u = s(5313),
                m = s(64741),
                x = s(42619),
                p = s(97385),
                f = s(83352),
                h = s(62993),
                v = s(32029),
                g = s(95262),
                j = s(3934),
                b = s(93264),
                y = s(43748),
                N = s(20533),
                w = s(27273);

            function S() {
                return (0, t.jsx)(w.RS, {
                    children: (0, t.jsx)(w.FM, {
                        children: (0, t.jsxs)(w.$S, {
                            isChild: !1,
                            children: [(0, t.jsx)(w.ky, {
                                className: "lg:block hidden",
                                children: (0, t.jsxs)("div", {
                                    className: "flex justify-center items-center flex-col space-y-2",
                                    children: [(0, t.jsx)(w.X1, {
                                        children: (0, t.jsx)(N.O, {
                                            className: "h-8 w-16 bg-primary-theme/30"
                                        })
                                    }), (0, t.jsx)(N.O, {
                                        className: "h-6 w-24 bg-yellow/30"
                                    })]
                                })
                            }), (0, t.jsxs)(w.$E, {
                                className: "lg:flex-row lg:gap-0 flex-col gap-3 lg:pl-7 px-0",
                                children: [(0, t.jsxs)("div", {
                                    className: "lg:block flex items-center justify-between",
                                    children: [(0, t.jsx)(N.O, {
                                        className: "h-12 w-40"
                                    }), (0, t.jsx)(w.ky, {
                                        className: "lg:hidden block pr-0",
                                        children: (0, t.jsxs)("div", {
                                            className: "flex justify-center items-center flex-col space-y-2",
                                            children: [(0, t.jsx)(w.X1, {
                                                children: (0, t.jsx)(N.O, {
                                                    className: "h-8 w-16 bg-primary-theme/30"
                                                })
                                            }), (0, t.jsx)(N.O, {
                                                className: "h-6 w-24 bg-yellow/30"
                                            })]
                                        })
                                    })]
                                }), (0, t.jsxs)(w.VD, {
                                    children: [(0, t.jsx)(N.O, {
                                        className: "h-6 w-16"
                                    }), (0, t.jsx)(p.Separator, {
                                        orientation: "vertical"
                                    }), (0, t.jsx)(N.O, {
                                        className: "h-6 w-16"
                                    }), (0, t.jsx)(N.O, {
                                        className: "w-36 h-8 bg-primary-theme/30"
                                    }), (0, t.jsx)("div", {
                                        children: (0, t.jsx)(y.G7, {
                                            children: (0, t.jsx)(y.MB, {
                                                children: (0, t.jsx)(N.O, {
                                                    className: "h-8 w-16"
                                                })
                                            })
                                        })
                                    })]
                                })]
                            })]
                        })
                    })
                })
            }
            var C = s(36879),
                z = s(34719);

            function k(e) {
                var a, s, l, n;
                let i = null !== (a = e.nameUrl) && void 0 !== a ? a : "/prop-firms";
                return (0, t.jsxs)("div", {
                    className: (0, h.cn)("flex items-center md:gap-4 gap-2", e.className),
                    children: [(0, t.jsx)(j.default, {
                        href: "".concat(i, "/").concat(null !== (s = e.firm.slug) && void 0 !== s ? s : ""),
                        children: (0, t.jsx)(r.wK, {
                            firm: e.firm,
                            className: "md:h-[74px] md:w-[74px] w-12 h-12 box-content"
                        })
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col items-start gap-0.5",
                        children: [(0, t.jsxs)("div", {
                            className: "flex space-x-1.5",
                            children: [null !== (n = e.nameSlot) && void 0 !== n ? n : (0, t.jsx)(f.o3, {
                                maxWidth: "2xs",
                                children: (0, t.jsx)(j.default, {
                                    href: "".concat(i, "/").concat(null !== (l = e.firm.slug) && void 0 !== l ? l : ""),
                                    children: (0, t.jsx)("p", {
                                        className: "hover:underline md:text-lg md:leading-[27px] text-xs font-semibold",
                                        children: e.firm.name
                                    })
                                })
                            }), e.favoriteSlot]
                        }), e.children ? e.children : null]
                    })]
                })
            }

            function R(e) {
                var a, s, r, f, h, g, y, N, S, R;
                let {
                    alwaysShowCode: P,
                    hideNewBadge: T = !1,
                    isChild: F,
                    promo: A,
                    setShowSiblings: O,
                    showSiblings: M,
                    size: E = "default"
                } = e, {
                    t: L
                } = (0, l.$G)(), I = (0, b.useMemo)(() => (0, C.f)(A), [A]), D = (0, b.useCallback)(() => {
                    var e, a, s, l, r, n, i, o;
                    return A.firm && (0, t.jsx)(k, {
                        firm: A.firm,
                        children: A.firm.reviewsCount < z.nu ? (0, t.jsx)(z.YO, {}) : (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)("div", {
                                className: "md:block hidden",
                                children: (0, t.jsx)(c.$, {
                                    reviewScore: null !== (r = null == A ? void 0 : null === (e = A.firm) || void 0 === e ? void 0 : e.reviewScore) && void 0 !== r ? r : 0,
                                    reviews: null !== (n = null == A ? void 0 : null === (a = A.firm) || void 0 === a ? void 0 : a.reviewsCount) && void 0 !== n ? n : 0,
                                    className: "[&>p:first-child]:leading-[21px] [&>.reviews]:max-h-[13px] md:[&_.gradientPillContent]:px-1"
                                })
                            }), (0, t.jsx)("div", {
                                className: "md:hidden block",
                                children: (0, t.jsx)(c.$, {
                                    reviewScore: null !== (i = null == A ? void 0 : null === (s = A.firm) || void 0 === s ? void 0 : s.reviewScore) && void 0 !== i ? i : 0,
                                    reviews: null !== (o = null == A ? void 0 : null === (l = A.firm) || void 0 === l ? void 0 : l.reviewsCount) && void 0 !== o ? o : 0,
                                    size: "xs",
                                    className: "[&>.reviews]:max-h-1.5"
                                })
                            })]
                        })
                    })
                }, [A.firm]), _ = (0, b.useCallback)(() => {
                    var e, a, s, l;
                    return (0, t.jsxs)("div", {
                        className: "md:pt-0 py-[3px] md:h-auto",
                        children: [(0, t.jsxs)(w.X1, {
                            className: "md:text-2xl md:leading-9 leading-[21px] md:mb-0 mb-0.5",
                            children: [(0, t.jsx)("span", {
                                className: "inline-block",
                                children: (null == I ? void 0 : I.strategy) === i.Qx.Amount ? (0, v.uf)({
                                    value: null !== (a = null == I ? void 0 : I.amount) && void 0 !== a ? a : 0,
                                    currency: null !== (s = null === (e = A.firm) || void 0 === e ? void 0 : e.currency) && void 0 !== s ? s : v.Mf.USD
                                }) : (null == I ? void 0 : I.strategy) === i.Qx.Percentage ? "".concat(null !== (l = null == I ? void 0 : I.amount) && void 0 !== l ? l : 0, "%") : null == I ? void 0 : I.amount
                            }), (null == I ? void 0 : I.type) === i.LH.Standard && (0, t.jsx)("span", {
                                className: "text-foreground ml-[5px] inline-block",
                                children: L("OFF")
                            }), (null == I ? void 0 : I.type) === i.LH.ProfitSplit && (0, t.jsx)("span", {
                                className: "text-foreground text-lg ml-[5px] inline-block",
                                children: L("Profit Split")
                            }), (null == I ? void 0 : I.type) === i.LH.RefundFee && (0, t.jsx)("span", {
                                className: "text-foreground text-lg ml-[5px] inline-block",
                                children: L("Refund Fee")
                            })]
                        }), A.extraAccountPromo && (0, t.jsx)(w.iJ, {
                            children: (0, t.jsx)(w._4, {
                                children: L("+ Free Account")
                            })
                        })]
                    })
                }, [null == I ? void 0 : I.strategy, null == I ? void 0 : I.amount, null == I ? void 0 : I.type, null === (a = A.firm) || void 0 === a ? void 0 : a.currency, A.extraAccountPromo, L]);
                return (0, t.jsxs)(w.$S, {
                    isChild: null != F && F,
                    children: [(0, t.jsx)(w.ky, {
                        className: "lg:block hidden",
                        icon: A.exclusive && (0, t.jsx)(u.Yq, {
                            className: "w-4"
                        }),
                        size: E,
                        children: (0, t.jsx)(_, {})
                    }), (0, t.jsxs)(w.$E, {
                        size: E,
                        className: "lg:flex-row lg:gap-0 flex-col gap-3 lg:pl-7 px-0",
                        children: [(0, t.jsxs)("div", {
                            className: "lg:block flex items-center justify-between",
                            children: ["default" === E && (0, t.jsx)(D, {}), (0, t.jsx)(w.ky, {
                                className: "lg:hidden block pr-0",
                                icon: A.exclusive && (0, t.jsx)(u.Yq, {
                                    className: "md:h-4 md:w-4 w-2 h-2"
                                }),
                                size: E,
                                children: (0, t.jsx)(_, {})
                            })]
                        }), (0, t.jsx)("hr", {
                            className: "lg:hidden block"
                        }), (0, t.jsxs)(w.VD, {
                            className: "justify-end lg:ml-auto ml-0",
                            children: [(0, t.jsxs)("div", {
                                className: "flex lg:flex-row md:gap-4 gap-1.5 flex-row-reverse items-center lg:mr-0 mr-auto",
                                children: [!T && !!(null == A ? void 0 : A.isNew) && (0, t.jsxs)(t.Fragment, {
                                    children: [(0, t.jsx)(o.C, {
                                        variant: "green",
                                        className: "uppercase md:inline-flex hidden",
                                        size: "chips",
                                        rounded: "full",
                                        children: (0, t.jsx)("span", {
                                            className: "inline-block leading-[18px]",
                                            children: L("New")
                                        })
                                    }), (0, t.jsx)(o.C, {
                                        variant: "green",
                                        className: "uppercase md:hidden inline-flex !text-xxs !leading-[15px] h-[23px] w-10 text-green-foreground justify-center",
                                        size: "chipXxs",
                                        rounded: "full",
                                        children: L("New")
                                    })]
                                }), !!(null === (s = A.siblings) || void 0 === s ? void 0 : s.length) && (null == A ? void 0 : null === (r = A.firmCount) || void 0 === r ? void 0 : r.count) !== void 0 && (null === (f = A.firmCount) || void 0 === f ? void 0 : f.count) > 1 && (0, t.jsx)(w.wW, {
                                    count: A.siblings.length,
                                    onClick: () => O(!M),
                                    expanded: M
                                })]
                            }), T ? null : (0, t.jsx)(p.Separator, {
                                orientation: "vertical",
                                className: "lg:block md:h-8 md:min-h-0 hidden first:hidden last:hidden"
                            }), (0, t.jsxs)("div", {
                                className: "flex items-center md:gap-4 gap-1.5",
                                children: [A.description && (0, t.jsxs)(x.J2, {
                                    children: [(0, t.jsx)(x.xo, {
                                        children: (0, t.jsx)(d.zx, {
                                            variant: "darkOutline",
                                            rounded: "full",
                                            size: "iconLg",
                                            className: "md:h-[42px] md:w-[42px] md:p-[13px] h-[22px] w-[22px] p-1",
                                            asChild: !0,
                                            children: (0, t.jsx)(u.sz, {
                                                className: "md:size-3.5 size-3 text-foreground"
                                            })
                                        })
                                    }), (0, t.jsx)(x.yk, {
                                        side: "bottom",
                                        className: "w-full max-w-[305px] text-sm tracking-tight text-center p-3",
                                        children: (0, t.jsx)(m.$, {
                                            markdown: A.description,
                                            className: "text-xs no-underline"
                                        })
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "md:block inline-flex flex-row-reverse items-center md:space-y-3 md:gap-0 gap-1.5",
                                    children: [A.code && (A.exclusive || P) ? (0, t.jsx)(w.S1, {
                                        code: A.code,
                                        id: A.id,
                                        firmSlug: null !== (S = null === (h = A.firm) || void 0 === h ? void 0 : h.slug) && void 0 !== S ? S : "",
                                        size: "default",
                                        className: "md:flex hidden"
                                    }) : null, A.code && (A.exclusive || P) ? (0, t.jsx)(w.S1, {
                                        code: A.code,
                                        id: A.id,
                                        firmSlug: null !== (R = null === (g = A.firm) || void 0 === g ? void 0 : g.slug) && void 0 !== R ? R : "",
                                        size: "xs",
                                        className: "md:hidden flex !mt-0 h-[23px]"
                                    }) : null, A.endDate && (0, t.jsx)(w.Me, {
                                        endDate: new Date(A.endDate)
                                    })]
                                }), "default" === E && (0, t.jsx)(d.zx, {
                                    variant: "pfmGradient",
                                    rounded: "full",
                                    asChild: !0,
                                    className: "md:h-auto md:px-5 md:py-2.5 px-2 py-1 h-[23px]",
                                    children: (0, t.jsx)(j.default, {
                                        href: (null === (y = A.firm) || void 0 === y ? void 0 : y.slug) ? "/prop-firms/".concat(null === (N = A.firm) || void 0 === N ? void 0 : N.slug, "?tab=").concat(n.rr.challenges) : "#",
                                        className: "md:text-sm md:leading-[21px] text-xxs leading-[15px]",
                                        children: L("Buy")
                                    })
                                })]
                            })]
                        })]
                    })]
                })
            }

            function P(e) {
                var a;
                let {
                    alwaysShowCode: s,
                    hideNewBadge: l = !1,
                    promo: r,
                    size: n = "default"
                } = e, [i, o] = (0, b.useState)(!1);
                return (0, t.jsx)(w.RS, {
                    children: (0, t.jsxs)(w.FM, {
                        size: n,
                        isExpanded: i,
                        children: [(0, t.jsx)(R, {
                            alwaysShowCode: s,
                            hideNewBadge: l,
                            isChild: !1,
                            promo: r,
                            setShowSiblings: o,
                            showSiblings: i,
                            size: n
                        }), (0, t.jsx)(g.M, {
                            children: i && (null === (a = r.siblings) || void 0 === a ? void 0 : a.filter(e => e.id !== r.id).map(e => (0, t.jsx)(R, {
                                alwaysShowCode: s,
                                hideNewBadge: l,
                                isChild: !0,
                                promo: e,
                                setShowSiblings: o,
                                showSiblings: i,
                                size: n
                            }, e.id)))
                        })]
                    })
                })
            }

            function T() {
                return (0, t.jsxs)("div", {
                    className: "space-y-4",
                    children: [(0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {}), (0, t.jsx)(S, {})]
                })
            }
        },
        36879: (e, a, s) => {
            s.d(a, {
                f: () => l
            });
            var t = s(17322);
            let l = e => {
                for (let s of [t.LH.Standard, t.LH.ProfitSplit, t.LH.RefundFee]) {
                    var a;
                    let t = null === (a = e.discounts) || void 0 === a ? void 0 : a.find(e => e.type === s);
                    if (t) return t
                }
                return null
            }
        },
        7986: (e, a, s) => {
            s.d(a, {
                h: () => j
            });
            var t = s(12428),
                l = s(40850),
                r = s(93264),
                n = s(3934),
                i = s(62993),
                o = s(6185),
                d = s(6536),
                c = s(47576),
                u = (s(60105), s(62312), s(23029));
            let m = e => {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsx)("nav", {
                    role: "navigation",
                    "aria-label": "pagination",
                    className: (0, i.cn)("mx-auto flex w-full justify-center", a),
                    ...s
                })
            };
            m.displayName = "Pagination";
            let x = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("ul", {
                    ref: a,
                    className: (0, i.cn)("flex flex-row items-center gap-1", s),
                    ...l
                })
            });
            x.displayName = "PaginationContent";
            let p = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("li", {
                    ref: a,
                    className: (0, i.cn)("", s),
                    ...l
                })
            });
            p.displayName = "PaginationItem";
            let f = e => {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsxs)("span", {
                    "aria-hidden": !0,
                    className: (0, i.cn)("flex h-9 w-9 items-center justify-center", a),
                    ...s,
                    children: [(0, t.jsx)(u.Z, {
                        className: "h-4 w-4"
                    }), (0, t.jsx)("span", {
                        className: "sr-only",
                        children: "More pages"
                    })]
                })
            };
            f.displayName = "PaginationEllipsis";
            let h = e => {
                let {
                    className: a,
                    isActive: s,
                    size: r = "icon",
                    ...o
                } = e;
                return (0, t.jsx)(n.default, {
                    "aria-current": s ? "page" : void 0,
                    shallow: !0,
                    replace: !0,
                    scroll: !0,
                    className: (0, i.cn)((0, l.dc)({
                        variant: "ghost",
                        size: r
                    }), "px-3 border border-border-secondary -ml-px rounded-none", s ? "bg-background-secondary focus:bg-background-secondary hover:bg-background-secondary" : "bg-background-primary text-foreground-secondary", a),
                    ...o
                })
            };
            h.displayName = "WebsitePaginationLink";
            let v = e => {
                let {
                    className: a,
                    ...s
                } = e, {
                    t: l
                } = (0, o.$G)();
                return (0, t.jsx)(h, {
                    "aria-label": "Go to previous page",
                    size: "default",
                    className: (0, i.cn)("gap-1 ml-0 rounded-l-full h-8.5 text-foreground", s["aria-disabled"] && "text-foreground-disabled", a),
                    ...s,
                    children: (0, t.jsx)("span", {
                        children: l("Previous")
                    })
                })
            };
            v.displayName = "WebsitePaginationPrevious";
            let g = e => {
                let {
                    className: a,
                    ...s
                } = e, {
                    t: l
                } = (0, o.$G)();
                return (0, t.jsx)(h, {
                    "aria-label": "Go to next page",
                    size: "default",
                    className: (0, i.cn)("gap-1 rounded-r-full h-8.5 text-foreground", s["aria-disabled"] && "text-foreground-disabled", a),
                    ...s,
                    children: (0, t.jsx)("span", {
                        children: l("Next")
                    })
                })
            };

            function j(e) {
                let {
                    pageSizeSelectOptions: a,
                    pageSize: s,
                    totalCount: l,
                    page: n,
                    pageSearchParam: o,
                    onPageChange: d
                } = e, u = (0, c.useRouter)(), j = (0, c.usePathname)(), y = (0, c.useSearchParams)(), N = Math.ceil(l / s), w = (0, r.useCallback)(e => {
                    let a = o || "page";
                    if (!y) return "".concat(j, "?").concat(a, "=").concat(e);
                    let s = new URLSearchParams(y);
                    return s.set(a, String(e)), "".concat(j, "?").concat(s.toString())
                }, [o, y, j]), S = (0, r.useCallback)(e => {
                    let s = (null == a ? void 0 : a.pageSizeSearchParam) || "pageSize",
                        t = new URLSearchParams(y || void 0);
                    t.set(s, String(e)), u.replace("".concat(j, "?").concat(t.toString()))
                }, [null == a ? void 0 : a.pageSizeSearchParam, y, u, j]);
                return (0, t.jsxs)("div", {
                    className: "flex flex-col md:flex-row items-center gap-3 w-full",
                    children: [a && (0, t.jsx)("div", {
                        className: "flex flex-col gap-4 flex-1",
                        children: (0, t.jsx)(b, {
                            options: a.pageSizeOptions,
                            setPageSize: S,
                            pageSize: s
                        })
                    }), (0, t.jsx)(m, {
                        className: (0, i.cn)({
                            "md:justify-end": a
                        }),
                        children: (0, t.jsxs)(x, {
                            className: "gap-0",
                            children: [(0, t.jsx)(p, {
                                children: (0, t.jsx)(v, {
                                    href: w(Math.max(n - 1, 1)),
                                    "aria-disabled": 1 === n,
                                    tabIndex: 1 === n ? -1 : void 0,
                                    onClick: () => null == d ? void 0 : d(n - 1),
                                    className: (0, i.cn)(1 === n ? "pointer-events-none opacity-50" : void 0)
                                })
                            }), (() => {
                                let e = [];
                                if (N <= 5)
                                    for (let a = 1; a <= N; a++) e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(h, {
                                            href: w(a),
                                            isActive: n === a,
                                            onClick: () => null == d ? void 0 : d(a),
                                            children: a
                                        })
                                    }, a));
                                else {
                                    e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(h, {
                                            href: w(1),
                                            isActive: 1 === n,
                                            children: "1"
                                        })
                                    }, 1)), n > 3 && e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(f, {})
                                    }, "ellipsis-start"));
                                    let a = Math.max(2, n - 1),
                                        s = Math.min(N - 1, n + 1);
                                    for (let l = a; l <= s; l++) e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(h, {
                                            href: w(l),
                                            isActive: n === l,
                                            children: l
                                        })
                                    }, l));
                                    n < N - 2 && e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(f, {})
                                    }, "ellipsis-end")), e.push((0, t.jsx)(p, {
                                        children: (0, t.jsx)(h, {
                                            href: w(N),
                                            isActive: n === N,
                                            children: N
                                        })
                                    }, N))
                                }
                                return e
                            })(), (0, t.jsx)(p, {
                                children: (0, t.jsx)(g, {
                                    href: w(Math.min(n + 1, N)),
                                    "aria-disabled": n === N,
                                    tabIndex: n === N ? -1 : void 0,
                                    onClick: () => null == d ? void 0 : d(n + 1),
                                    className: (0, i.cn)(n === N ? "pointer-events-none opacity-50" : void 0)
                                })
                            })]
                        })
                    })]
                })
            }

            function b(e) {
                let {
                    options: a,
                    setPageSize: s,
                    pageSize: l
                } = e;
                return (0, t.jsxs)("div", {
                    className: "flex items-center gap-4",
                    children: [(0, t.jsx)("span", {
                        className: "whitespace-nowrap text-sm",
                        children: "Rows per page"
                    }), (0, t.jsxs)(d.Select, {
                        value: String(l),
                        onValueChange: e => s(Number(e)),
                        children: [(0, t.jsx)(d.SelectTrigger, {
                            children: (0, t.jsx)(d.SelectValue, {
                                placeholder: "Select page size",
                                children: String(l)
                            })
                        }), (0, t.jsx)(d.SelectContent, {
                            children: a.map(e => (0, t.jsx)(d.SelectItem, {
                                value: String(e),
                                children: e
                            }, e))
                        })]
                    })]
                })
            }
            g.displayName = "WebsitePaginationNext"
        },
        30245: (e, a, s) => {
            s.d(a, {
                h: () => o
            });
            var t, l = s(12428),
                r = s(6185),
                n = s(6536);

            function i(e) {
                return "".concat(e.value, ":").concat(e.desc ? "desc" : "asc")
            }! function(e) {
                e.desc = "desc", e.asc = "asc"
            }(t || (t = {}));
            let o = e => {
                let {
                    options: a,
                    onSortingChange: s,
                    placeholder: t,
                    defaultValue: o
                } = e, {
                    t: d
                } = (0, r.$G)(), c = o ? i(o) : void 0, u = a.map(e => ({ ...e,
                    selectValue: i(e)
                }));
                return (0, l.jsxs)("div", {
                    className: "flex items-center gap-2.5",
                    children: [(0, l.jsx)("p", {
                        className: "text-foreground-secondary text-sm whitespace-nowrap",
                        children: d("Sort by")
                    }), (0, l.jsxs)(n.Select, {
                        onValueChange: e => {
                            let [a, t] = e.split(":");
                            a && (null == s || s([{
                                id: a,
                                desc: "desc" === t
                            }]))
                        },
                        defaultValue: c,
                        children: [(0, l.jsx)(n.SelectTrigger, {
                            className: "h-9 text-xs",
                            rounded: "full",
                            children: (0, l.jsx)(n.SelectValue, {
                                placeholder: t
                            })
                        }), (0, l.jsx)(n.SelectContent, {
                            children: u.map(e => {
                                let {
                                    selectValue: a,
                                    label: s
                                } = e;
                                return (0, l.jsx)(n.SelectItem, {
                                    value: a,
                                    children: (0, l.jsx)("span", {
                                        className: "px-2 font-semibold",
                                        children: s
                                    })
                                }, a)
                            })
                        })]
                    })]
                })
            }
        },
        51037: (e, a, s) => {
            s.d(a, {
                e: () => r
            });
            var t = s(6185),
                l = s(17322);

            function r() {
                let {
                    t: e
                } = (0, t.$G)();
                return {
                    [l.fo.FX]: e("FX"),
                    [l.fo.Energy]: e("Energy"),
                    [l.fo.Stocks]: e("Stocks"),
                    [l.fo.Crypto]: e("Crypto"),
                    [l.fo.Indices]: e("Indices"),
                    [l.fo.OtherCommodities]: e("Other Commodities"),
                    [l.fo.Metals]: e("Metals"),
                    [l.fo.Futures]: e("Futures")
                }
            }
        },
        11800: (e, a, s) => {
            s.d(a, {
                J: () => r
            });
            var t = s(6185),
                l = s(17322);

            function r() {
                let {
                    t: e
                } = (0, t.$G)();
                return {
                    [l.co.CFD]: e("CFD"),
                    [l.co.CryptoOnly]: e("Crypto Only"),
                    [l.co.StocksOnly]: e("Stocks Only"),
                    [l.co.Futures]: e("Futures")
                }
            }
        },
        58652: (e, a, s) => {
            s.d(a, {
                h: () => i
            });
            var t = s(93264),
                l = s(95772),
                r = s(47576);
            let n = l.z.preprocess(e => Number(e), l.z.number().int().min(1).default(1));

            function i() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10,
                    a = (0, r.useSearchParams)(),
                    s = (0, t.useMemo)(() => ({
                        pageIndex: function(e) {
                            let a = e.get("page"),
                                s = n.safeParse(a);
                            return s.success ? s.data : 1
                        }(a),
                        pageSize: e
                    }), [a, e]),
                    l = (0, t.useMemo)(() => (s.pageIndex - 1) * e, [s.pageIndex, e]);
                return {
                    pagination: s,
                    skip: l,
                    take: e
                }
            }
        },
        37742: (e, a, s) => {
            s.d(a, {
                F: () => r
            });
            var t = s(6185),
                l = s(17322);

            function r() {
                let {
                    t: e
                } = (0, t.$G)();
                return {
                    [l.oi.Instant]: e("Instant"),
                    [l.oi.OneStep]: e("1 Step"),
                    [l.oi.TwoSteps]: e("2 Steps"),
                    [l.oi.ThreeSteps]: e("3 Steps"),
                    [l.oi.FourSteps]: e("4 Steps")
                }
            }
        },
        89309: (e, a, s) => {
            s.d(a, {
                r: () => i
            });
            var t = s(47576),
                l = s(93264),
                r = s(95772);
            let n = r.z.object({
                id: r.z.string(),
                desc: r.z.boolean()
            });

            function i() {
                let e = (0, t.useRouter)(),
                    a = (0, t.useSearchParams)(),
                    s = (0, t.usePathname)(),
                    r = (0, l.useMemo)(() => {
                        let e = a.get("sort");
                        if (!e) return [];
                        try {
                            let a = n.parse(JSON.parse(e));
                            return [{
                                id: a.id,
                                desc: a.desc
                            }]
                        } catch (e) {
                            return []
                        }
                    }, [a]),
                    i = (0, l.useCallback)(t => {
                        let l = Array.isArray(t) ? t : t(r),
                            n = l.length ? JSON.stringify(l[0]) : "",
                            i = new URLSearchParams(a);
                        i.set("sort", n), e.push(s + "?".concat(i.toString()))
                    }, [s, a, e, r]);
                return {
                    sorting: r,
                    onSortingChange: i
                }
            }
        },
        29038: (e, a, s) => {
            s.r(a), s.d(a, {
                AnnouncementCard: () => g,
                AnnouncementCardWithFirm: () => j
            });
            var t = s(12428),
                l = s(6185),
                r = s(69615),
                n = s(24040),
                i = s(17322),
                o = s(74777),
                d = s(37672),
                c = s(45253),
                u = s(43748),
                m = s(97385),
                x = s(62993),
                p = s(68586),
                f = s(1057),
                h = s(3934),
                v = s(64741);

            function g(e) {
                let {
                    getFileReadUrl: a
                } = (0, n.lA)(), {
                    t: s
                } = (0, l.$G)();
                return (0, t.jsx)(d.Zb, {
                    rounded: "2xl",
                    className: (0, x.cn)("w-full", e.className),
                    children: (0, t.jsxs)(d.aY, {
                        className: "p-3 md:p-5",
                        children: [e.showStatus && (0, t.jsx)("div", {
                            className: "mb-2",
                            children: (0, t.jsx)(o.C, {
                                variant: e.status === i.ny.Active ? "green" : "secondary",
                                size: "chipsXs",
                                rounded: "full",
                                className: "whitespace-nowrap",
                                children: e.status
                            })
                        }), (0, t.jsxs)("div", {
                            className: "space-y-4",
                            children: [(0, t.jsxs)("div", {
                                className: "flex flex-col md:flex-row items-start gap-6",
                                children: [!e.hideImage && e.image ? (0, t.jsx)("div", {
                                    className: "space-y-4",
                                    children: e.image.map((e, s) => (0, t.jsx)("div", {
                                        className: "w-full md:w-auto",
                                        children: (0, t.jsx)("img", {
                                            src: a(e),
                                            alt: e.name,
                                            className: "max-w-full md:max-w-[300px] aspect-video rounded-2xl object-cover"
                                        })
                                    }, s))
                                }) : null, (0, t.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [(0, t.jsx)("p", {
                                        className: "text-sm font-semibold leading-5",
                                        children: e.title
                                    }), (0, t.jsx)(v.$, {
                                        markdown: e.markdown,
                                        className: "text-xs text-foreground-secondary"
                                    })]
                                })]
                            }), (0, t.jsx)(m.Separator, {
                                className: "bg-border"
                            }), (0, t.jsxs)("div", {
                                className: "flex items-center",
                                children: [e.date && (0, t.jsxs)("div", {
                                    className: "flex flex-1 items-center gap-1.5 text-foreground-secondary",
                                    children: [(0, t.jsx)(f.Z, {
                                        size: "16"
                                    }), (0, t.jsx)("p", {
                                        className: "text-xs pt-0.5",
                                        children: (0, p.WU)(new Date(e.date), e.shortDate ? "MMM d, yyyy" : "MMMM d, yyyy")
                                    })]
                                }), e.buttonLink && (0, t.jsx)("div", {
                                    className: "flex-1 flex justify-end",
                                    children: (0, t.jsx)(h.default, {
                                        href: e.buttonLink,
                                        target: "_blank",
                                        children: (0, t.jsx)(u.G7, {
                                            variant: "pfm",
                                            children: (0, t.jsx)(u.MB, {
                                                className: "text-sm px-3 py-2 cursor-pointer bg-background-secondary hover:bg-background-tertiary",
                                                children: e.buttonText || s("Announcement Link")
                                            })
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }

            function j(e) {
                var a, s, l, n;
                return (0, t.jsx)(d.Zb, {
                    rounded: "2xl",
                    children: (0, t.jsxs)(d.aY, {
                        className: "p-3 md:p-5 flex flex-col lg:flex-row gap-4 lg:gap-6",
                        children: [(0, t.jsx)("div", {
                            children: e.announcement.firm && e.announcement.authorType === i.DD.Firm ? (0, t.jsx)(r.mA, {
                                size: "xl",
                                firm: e.announcement.firm,
                                className: "items-start space-x-4 w-full md:w-auto",
                                children: (0, t.jsx)(c.$, {
                                    reviewScore: null !== (l = null === (a = e.announcement.firm) || void 0 === a ? void 0 : a.reviewScore) && void 0 !== l ? l : 0,
                                    reviews: null !== (n = null === (s = e.announcement.firm) || void 0 === s ? void 0 : s.reviewsCount) && void 0 !== n ? n : 0
                                })
                            }) : e.announcement.authorType === i.DD.Pfm ? (0, t.jsx)("div", {
                                className: "w-[214px]",
                                children: (0, t.jsx)("img", {
                                    alt: "pfm-logo-base",
                                    src: "/pfm-logo.svg",
                                    className: "w-full"
                                })
                            }) : null
                        }), (0, t.jsx)(g, { ...e.announcement,
                            className: "bg-background-secondary"
                        })]
                    })
                })
            }
        },
        3781: (e, a, s) => {
            s.r(a), s.d(a, {
                AnnouncementsContent: () => r
            });
            var t = s(12428),
                l = s(11852);
            let r = () => (0, t.jsx)("div", {
                className: "mb-20",
                children: (0, t.jsx)(l.w8, {})
            })
        },
        84774: (e, a, s) => {
            s.r(a), s.d(a, {
                AnnouncementsEmpty: () => n
            });
            var t = s(12428),
                l = s(6185),
                r = s(5455);

            function n() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsx)("div", {
                    className: "flex flex-col items-center justify-center gap-4 pt-20",
                    children: (0, t.jsx)("div", {
                        className: "flex flex-col items-center justify-center space-y-2 text-center",
                        children: (0, t.jsxs)("div", {
                            className: "flex flex-col items-center justify-center h-full gap-1 min-h-[248px]",
                            children: [(0, t.jsx)(r.Z, {
                                className: "size-5 text-muted-foreground"
                            }), (0, t.jsx)("span", {
                                className: "text-muted-foreground text-[12px]",
                                children: e("No Announcements")
                            })]
                        })
                    })
                })
            }
        },
        93838: (e, a, s) => {
            s.r(a), s.d(a, {
                AnnouncementsHeader: () => n
            });
            var t = s(12428),
                l = s(6185),
                r = s(6767);

            function n() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsxs)("header", {
                    className: "text-center mt-24 mb-16",
                    children: [(0, t.jsx)(r.S, {
                        className: "mb-1",
                        children: e("Announcements")
                    }), (0, t.jsx)("p", {
                        className: "text-xs md:text-base text-foreground-secondary",
                        children: e("Discover the firms traders are choosing right now")
                    })]
                })
            }
        },
        71555: (e, a, s) => {
            s.r(a), s.d(a, {
                AnnouncementsList: () => b
            });
            var t = s(12428),
                l = s(89309),
                r = s(6185),
                n = s(28422),
                i = s(35022),
                o = s(93264),
                d = s(95772),
                c = s(37672),
                u = s(97385),
                m = s(20533);

            function x() {
                return (0, t.jsx)(c.Zb, {
                    rounded: "2xl",
                    children: (0, t.jsxs)(c.aY, {
                        className: "p-3 md:p-5 flex flex-col lg:flex-row gap-4 lg:gap-6",
                        children: [(0, t.jsxs)("div", {
                            className: "flex space-x-4",
                            children: [(0, t.jsx)(m.O, {
                                className: "w-16 h-16"
                            }), (0, t.jsxs)("div", {
                                className: "space-y-1.5",
                                children: [(0, t.jsx)(m.O, {
                                    className: "h-7 w-20"
                                }), (0, t.jsx)(m.O, {
                                    className: "h-4 w-8"
                                }), (0, t.jsx)(m.O, {
                                    className: "h-6 w-44"
                                })]
                            })]
                        }), (0, t.jsx)(c.Zb, {
                            rounded: "2xl",
                            className: "w-full",
                            children: (0, t.jsxs)(c.aY, {
                                className: "p-3 md:p-5",
                                children: [(0, t.jsxs)("div", {
                                    className: "space-y-1.5",
                                    children: [(0, t.jsx)(m.O, {
                                        className: "w-64 h-5"
                                    }), (0, t.jsx)(m.O, {
                                        className: "w-full h-36"
                                    })]
                                }), (0, t.jsx)(u.Separator, {
                                    className: "bg-border my-4"
                                }), (0, t.jsx)(m.O, {
                                    className: "h-5 w-32"
                                })]
                            })
                        })]
                    })
                })
            }
            var p = s(7986),
                f = s(58652),
                h = s(11852),
                v = s(85473),
                g = s(64608);

            function j(e) {
                var a, s, r;
                let {
                    pagination: n,
                    skip: c,
                    take: u
                } = (0, f.h)(), [m, x] = (0, i.v1)("page", d.z.string().optional()), [j] = (0, i.v1)("search", d.z.string().optional()), [b] = (0, g.Nr)(j, 500), y = (0, l.r)();
                (0, o.useEffect)(() => {
                    x("1")
                }, [b, x]);
                let [N] = v.trpc.announcement.listFiltered.useSuspenseQuery({
                    skip: c,
                    limit: u,
                    search: null != b ? b : void 0,
                    firmSlug: null !== (r = e.firmSlug) && void 0 !== r ? r : void 0,
                    ...(null === (s = y.sorting) || void 0 === s ? void 0 : null === (a = s[0]) || void 0 === a ? void 0 : a.id) ? {
                        order: {
                            by: y.sorting[0].id,
                            direction: y.sorting[0].desc ? "desc" : "asc"
                        }
                    } : {
                        order: {
                            by: "date",
                            direction: "desc"
                        }
                    }
                });
                return (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsx)("div", {
                        className: "space-y-4",
                        children: N.count ? (0, t.jsx)("div", {
                            className: "grid gap-4",
                            children: N.data.map(e => (0, t.jsx)(h.mK, {
                                announcement: e
                            }, e.id))
                        }) : (0, t.jsx)(h.en, {})
                    }), N.count > 0 && (0, t.jsx)("div", {
                        className: "mt-16",
                        children: (0, t.jsx)(p.h, {
                            totalCount: N.count,
                            page: n.pageIndex,
                            pageSize: n.pageSize
                        })
                    })]
                })
            }

            function b(e) {
                var a;
                let {
                    t: s
                } = (0, r.$G)(), {
                    sorting: c,
                    onSortingChange: u
                } = (0, l.r)(), [m, p] = (0, i.v1)("search", d.z.string().optional()), f = (0, o.useMemo)(() => [{
                    value: "date",
                    label: s("Recent"),
                    desc: !0
                }, {
                    value: "date",
                    label: s("Oldest"),
                    desc: !1
                }], [s]);
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-5 mb-20",
                    children: [(0, t.jsx)("div", {
                        className: "self-end",
                        children: (0, t.jsx)(n.ew, {
                            sorting: {
                                defaultValue: (null == c ? void 0 : null === (a = c[0]) || void 0 === a ? void 0 : a.id) ? {
                                    value: c[0].id,
                                    desc: c[0].desc
                                } : f[0],
                                options: f,
                                onSortingChange: u
                            },
                            search: e.hideSearch ? void 0 : {
                                placeholder: s("Search"),
                                onSearch: p,
                                defaultValue: null != m ? m : ""
                            }
                        })
                    }), (0, t.jsx)(o.Suspense, {
                        fallback: (0, t.jsx)(x, {}),
                        children: (0, t.jsx)(j, {
                            firmSlug: e.firmSlug
                        })
                    })]
                })
            }
        },
        11852: (e, a, s) => {
            s.d(a, {
                a1: () => t.AnnouncementCard,
                en: () => l.AnnouncementsEmpty,
                mK: () => t.AnnouncementCardWithFirm,
                w8: () => r.AnnouncementsList
            });
            var t = s(29038),
                l = s(84774);
            s(93838);
            var r = s(71555);
            s(3781)
        },
        32158: (e, a, s) => {
            s.r(a), s.d(a, {
                CoreContext: () => l,
                CoreProvider: () => r
            });
            var t = s(12428);
            let l = (0, s(93264).createContext)({
                NEXT_PUBLIC_WEBSITE_URL: "",
                NEXT_PUBLIC_STORAGE_SERVICE_URL: "",
                NEXT_PUBLIC_GOOGLE_RECAPTCHA_SITE_KEY: "",
                NEXT_PUBLIC_BUSINESS_WEBSITE_URL: "",
                NEXT_PUBLIC_DASHBOARD_WEBSITE_URL: "",
                NEXT_PUBLIC_MAIN_WEBSITE_URL: "",
                NEXT_PUBLIC_AUTH_WEBSITE_URL: "",
                NEXT_PUBLIC_WS_SERVER_URL: ""
            });

            function r(e) {
                let {
                    value: a,
                    children: s
                } = e;
                return (0, t.jsx)(l.Provider, {
                    value: a,
                    children: s
                })
            }
        },
        67194: (e, a, s) => {
            s.r(a), s.d(a, {
                useCoreContext: () => r
            });
            var t = s(93264),
                l = s(32158);

            function r() {
                return (0, t.useContext)(l.CoreContext)
            }
        },
        98661: (e, a, s) => {
            s.d(a, {
                mM: () => t.useCoreContext
            }), s(32158);
            var t = s(67194)
        },
        33206: (e, a, s) => {
            s.d(a, {
                ChallengesFilter: () => L,
                r: () => t
            });
            var t, l = s(12428),
                r = s(89309),
                n = s(6185),
                i = s(28422),
                o = s(77838),
                d = s(85473),
                c = s(5313),
                u = s(97993),
                m = s(35022),
                x = s(93264),
                p = s(95772),
                f = s(37076),
                h = s(51037),
                v = s(37742),
                g = s(35229);

            function j(e) {
                return (0, l.jsx)(l.Fragment, {
                    children: e.options.map(a => {
                        var s;
                        return (0, l.jsx)(g.aq, {
                            value: a.value,
                            onCheckedChange: s => {
                                var t, l;
                                if (s) {
                                    let s = [...null !== (t = e.value) && void 0 !== t ? t : [], a.value];
                                    e.onChange(s)
                                } else {
                                    let s = null === (l = e.value) || void 0 === l ? void 0 : l.filter(e => e !== a.value);
                                    e.onChange(s)
                                }
                            },
                            checked: (null !== (s = e.value) && void 0 !== s ? s : []).includes(a.value),
                            variant: "pfmCheckbox",
                            contentClassname: "py-2.5 text-xs",
                            className: a.className,
                            children: a.label
                        }, a.value)
                    })
                })
            }
            var b = s(94062),
                y = s(17322),
                N = s(40850),
                w = s(46354),
                S = s(32029),
                C = s(30455),
                z = s(95289),
                k = s(20533),
                R = s(48842),
                P = s(47576),
                T = s(16891);

            function F() {
                let {
                    t: e
                } = (0, n.$G)();
                return (0, l.jsx)("div", {
                    className: "h-8.5 w-20 text-foreground-secondary flex items-center justify-center text-sm rounded-full bg-background-tertiary",
                    children: e("Error")
                })
            }

            function A(e) {
                var a, s, t;
                let {
                    t: r
                } = (0, n.$G)(), {
                    slug: i = ""
                } = (0, P.useParams)(), [o] = d.trpc.firm.listFirmChallengeCategories.useSuspenseQuery({
                    slug: i
                }), c = o.find(a => {
                    var s;
                    return a.id === (null === (s = e.value) || void 0 === s ? void 0 : s[0])
                });
                return (0, l.jsxs)(w.h_, {
                    modal: !1,
                    children: [(0, l.jsx)(w.$F, {
                        asChild: !0,
                        children: (0, l.jsxs)(N.zx, {
                            variant: "dark",
                            rounded: "full",
                            size: "xs",
                            children: [(0, l.jsxs)("span", {
                                className: "text-foreground-tertiary mr-1",
                                children: [r("Program"), ":"]
                            }), (0, l.jsx)("span", {
                                children: (null === (a = e.value) || void 0 === a ? void 0 : a.length) !== 0 && e.value ? 1 === e.value.length ? null !== (s = null == c ? void 0 : c.name) && void 0 !== s ? s : e.value[0] : r("Multiple") : r("Select")
                            }), (0, l.jsx)(C.Z, {
                                className: "h-4 w-4 ml-2"
                            })]
                        })
                    }), (0, l.jsxs)(w.AW, {
                        side: "bottom",
                        align: "start",
                        className: "max-w-screen-xs w-96",
                        children: [(0, l.jsx)("p", {
                            className: "mb-2 font-sans font-semibold text-sm",
                            children: r(o.length ? "Select one or multiple options" : "No programs")
                        }), (0, l.jsx)("div", {
                            className: "grid gap-2.5",
                            children: (0, l.jsx)(R.t, {
                                onValueChange: e.onChange,
                                type: "multiple",
                                value: null !== (t = e.value) && void 0 !== t ? t : [],
                                className: "justify-start",
                                children: (0, l.jsx)("div", {
                                    className: "flex flex-wrap gap-2",
                                    children: o.map(e => (0, l.jsx)(R.G, {
                                        value: e.id,
                                        size: "xs",
                                        variant: "filterPill",
                                        children: (0, l.jsx)("p", {
                                            children: e.name
                                        })
                                    }, e.id))
                                })
                            })
                        })]
                    })]
                })
            }

            function O(e) {
                return (0, l.jsx)(T.SV, {
                    FallbackComponent: F,
                    children: (0, l.jsx)(x.Suspense, {
                        fallback: (0, l.jsx)(k.O, {
                            className: "h-8.5 w-32 rounded-full"
                        }),
                        children: (0, l.jsx)(A, { ...e
                        })
                    })
                })
            }

            function M(e) {
                let {
                    t: a
                } = (0, n.$G)();
                if ("object" == typeof e.value && "range" in e.value && Array.isArray(e.value.range)) {
                    let [a = 0, s = 0] = e.value.range, t = (0, S.uf)({
                        value: a,
                        currency: S.Mf.USD,
                        notation: "compact"
                    }), r = (0, S.uf)({
                        value: s,
                        currency: S.Mf.USD,
                        notation: "compact"
                    });
                    return (0, l.jsx)("span", {
                        children: "".concat(t, " - ").concat(r)
                    })
                }
                if (Array.isArray(e.value)) {
                    if (1 === e.value.length) return (0, l.jsx)("span", {
                        children: (0, S.uf)({
                            value: e.value[0],
                            currency: S.Mf.USD,
                            notation: "compact"
                        })
                    });
                    if (e.value.length > 1) return (0, l.jsx)("span", {
                        children: a("Multiple")
                    })
                }
                return (0, l.jsx)("span", {
                    children: a("Select")
                })
            }

            function E(e) {
                var a;
                let {
                    t: s
                } = (0, n.$G)(), [k] = d.trpc.challenge.getListFilteringOptions.useSuspenseQuery(), [R, P] = (0, m.v1)("applyDiscount", p.z.boolean().optional()), T = (0, f.r4)(k), F = function(e) {
                    let {
                        t: a
                    } = (0, n.$G)(), s = (0, h.e)(), t = (0, v.F)();
                    return (0, x.useMemo)(() => (0, b.g)(f.d1, [{
                        name: "assets",
                        label: a("Assets"),
                        render(e) {
                            let t = [y.fo.FX, y.fo.Futures, y.fo.Energy, y.fo.Stocks, y.fo.Crypto, y.fo.Indices, y.fo.Metals, y.fo.OtherCommodities];
                            return (0, l.jsx)(z.Qr, {
                                control: e,
                                name: "assets",
                                render: e => {
                                    var r, n;
                                    let {
                                        field: i
                                    } = e;
                                    return (0, l.jsxs)(w.h_, {
                                        modal: !1,
                                        children: [(0, l.jsx)(w.$F, {
                                            asChild: !0,
                                            children: (0, l.jsxs)(N.zx, {
                                                variant: "dark",
                                                rounded: "full",
                                                size: "xs",
                                                children: [(0, l.jsxs)("span", {
                                                    className: "text-foreground-tertiary mr-1",
                                                    children: [a("Assets"), ":"]
                                                }), (0, l.jsx)("span", {
                                                    children: (null === (r = i.value) || void 0 === r ? void 0 : r.length) !== 0 && i.value ? 1 === i.value.length ? s[i.value[0]] : a("Multiple") : a("Select")
                                                }), (0, l.jsx)(C.Z, {
                                                    className: "h-4 w-4 ml-2"
                                                })]
                                            })
                                        }), (0, l.jsxs)(w.AW, {
                                            side: "bottom",
                                            align: "start",
                                            className: "max-w-screen-xs w-96",
                                            children: [(0, l.jsx)("p", {
                                                className: "mb-2 font-sans font-semibold text-sm",
                                                children: a("Select one or multiple options")
                                            }), (0, l.jsx)("div", {
                                                className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
                                                children: (0, l.jsx)(j, {
                                                    value: null !== (n = i.value) && void 0 !== n ? n : [],
                                                    onChange: i.onChange,
                                                    options: t.map(e => ({
                                                        label: s[e],
                                                        value: e,
                                                        className: "last:col-span-full"
                                                    }))
                                                })
                                            })]
                                        })]
                                    })
                                }
                            })
                        }
                    }, {
                        name: "accountSize",
                        render: s => (0, l.jsx)(z.Qr, {
                            control: s,
                            name: "accountSize",
                            render: s => {
                                var t, r, n, o, d, c;
                                let {
                                    field: u
                                } = s;
                                return (0, l.jsxs)(w.h_, {
                                    modal: !1,
                                    children: [(0, l.jsx)(w.$F, {
                                        asChild: !0,
                                        children: (0, l.jsxs)(N.zx, {
                                            variant: "dark",
                                            rounded: "full",
                                            size: "xs",
                                            children: [(0, l.jsxs)("span", {
                                                className: "text-foreground-tertiary mr-1",
                                                children: [a("Size"), ":"]
                                            }), (0, l.jsx)(M, {
                                                value: u.value
                                            }), (0, l.jsx)(C.Z, {
                                                className: "h-4 w-4 ml-2"
                                            })]
                                        })
                                    }), (0, l.jsxs)(w.AW, {
                                        side: "bottom",
                                        align: "start",
                                        className: "max-w-screen-xs w-96",
                                        children: [(0, l.jsx)("p", {
                                            className: "mb-2 font-sans font-semibold text-sm",
                                            children: a("Select one or multiple options")
                                        }), (0, l.jsxs)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-4 gap-2.5",
                                            children: [(0, l.jsx)(j, {
                                                value: Array.isArray(u.value) ? u.value : [],
                                                onChange: u.onChange,
                                                options: [5e3, 1e4, 25e3, 5e4, 1e5, 2e5, 3e5, 5e5].map(e => ({
                                                    label: (0, S.uf)({
                                                        value: e,
                                                        currency: S.Mf.USD,
                                                        notation: "compact"
                                                    }),
                                                    value: e
                                                }))
                                            }), (0, l.jsx)(g.aq, {
                                                value: "custom",
                                                onCheckedChange: e => {
                                                    e ? u.onChange({
                                                        range: []
                                                    }) : u.onChange([])
                                                },
                                                checked: "object" == typeof u.value && "range" in u.value,
                                                variant: "pfmCheckbox",
                                                contentClassname: "py-2.5 text-xs",
                                                className: "col-span-full",
                                                children: a("Custom")
                                            }), u.value && "range" in u.value && (0, l.jsx)("div", {
                                                className: "col-span-full",
                                                children: (0, l.jsx)(i.U2, {
                                                    sliderProps: {
                                                        step: Math.floor((null !== (o = null === (t = e.options.limits) || void 0 === t ? void 0 : t.accountSizeMax) && void 0 !== o ? o : 1e6) / 100),
                                                        min: null !== (d = null === (r = e.options.limits) || void 0 === r ? void 0 : r.accountSizeMin) && void 0 !== d ? d : 0,
                                                        max: null !== (c = null === (n = e.options.limits) || void 0 === n ? void 0 : n.accountSizeMax) && void 0 !== c ? c : 1e6
                                                    },
                                                    label: null,
                                                    value: u.value.range,
                                                    onChange: e => {
                                                        u.onChange({
                                                            range: e
                                                        })
                                                    }
                                                })
                                            })]
                                        })]
                                    })]
                                })
                            }
                        })
                    }, {
                        name: "program",
                        render: e => (0, l.jsx)(z.Qr, {
                            control: e,
                            name: "program",
                            render: e => {
                                var s, r;
                                let {
                                    field: n
                                } = e;
                                return (0, l.jsxs)(w.h_, {
                                    modal: !1,
                                    children: [(0, l.jsx)(w.$F, {
                                        asChild: !0,
                                        children: (0, l.jsxs)(N.zx, {
                                            variant: "dark",
                                            rounded: "full",
                                            size: "xs",
                                            children: [(0, l.jsxs)("span", {
                                                className: "text-foreground-tertiary mr-1",
                                                children: [a("Steps"), ":"]
                                            }), (0, l.jsx)("span", {
                                                children: (null === (s = n.value) || void 0 === s ? void 0 : s.length) !== 0 && n.value ? 1 === n.value.length ? t[n.value[0]] : a("Multiple") : a("Select")
                                            }), (0, l.jsx)(C.Z, {
                                                className: "h-4 w-4 ml-2"
                                            })]
                                        })
                                    }), (0, l.jsxs)(w.AW, {
                                        side: "bottom",
                                        align: "start",
                                        className: "max-w-screen-xs w-96",
                                        children: [(0, l.jsx)("p", {
                                            className: "mb-2 font-sans font-semibold text-sm",
                                            children: a("Select one or multiple options")
                                        }), (0, l.jsx)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
                                            children: (0, l.jsx)(j, {
                                                value: null !== (r = n.value) && void 0 !== r ? r : [],
                                                onChange: n.onChange,
                                                options: [{
                                                    label: t[y.oi.Instant],
                                                    value: y.oi.Instant
                                                }, {
                                                    label: t[y.oi.OneStep],
                                                    value: y.oi.OneStep
                                                }, {
                                                    label: t[y.oi.TwoSteps],
                                                    value: y.oi.TwoSteps
                                                }, {
                                                    label: t[y.oi.ThreeSteps],
                                                    value: y.oi.ThreeSteps
                                                }, {
                                                    label: t[y.oi.FourSteps],
                                                    value: y.oi.FourSteps,
                                                    className: "md:col-span-2"
                                                }]
                                            })
                                        })]
                                    })]
                                })
                            }
                        })
                    }, {
                        name: "firmChallengeCategoryIds",
                        render: a => e.hideProgramFilter ? null : (0, l.jsx)(z.Qr, {
                            control: a,
                            name: "firmChallengeCategoryIds",
                            render: e => {
                                let {
                                    field: a
                                } = e;
                                return (0, l.jsx)(O, { ...a
                                })
                            }
                        })
                    }]), [a, s, e.options.limits, e.hideProgramFilter, t])
                }({
                    options: k,
                    hideProgramFilter: e.hideProgramFilter
                }), A = (0, o.k)(f.d1, e.firmId ? void 0 : f.pJ), {
                    sorting: E,
                    onSortingChange: L
                } = (0, r.r)(), I = (0, x.useMemo)(() => [{
                    value: "createdAt",
                    label: s("Recent"),
                    desc: !0
                }], [s]), [D, _] = (0, m.v1)("tab", p.z.nativeEnum(t).optional()), [G, B] = (0, m.v1)("search", p.z.string().optional()), U = (0, x.useMemo)(() => [{
                    value: "all",
                    label: s("All")
                }, {
                    icon: (0, l.jsx)(c.N, {
                        className: "text-foreground-secondary"
                    }),
                    value: "bookmarks",
                    label: s("Bookmarks")
                }], [s]);
                return (0, l.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, l.jsx)(i.ew, {
                        extendedFilter: e.firmId ? void 0 : {
                            defaultOpen: !1,
                            onOpenChange: () => {}
                        },
                        quickFilters: e.hideQuickFilters ? void 0 : {
                            items: U,
                            onQuickFilterChange: e => _(e),
                            defaultValue: null != D ? D : "all"
                        },
                        selectFilters: (0, l.jsx)(i.Vs, {
                            filtersHookResult: {
                                filters: F,
                                ...A
                            }
                        }),
                        otherFilters: (0, l.jsxs)("div", {
                            className: "flex items-center space-x-3",
                            children: [(0, l.jsx)(u.r, {
                                size: "sm",
                                checked: null == R || R,
                                onCheckedChange: e => P(e)
                            }), (0, l.jsx)("label", {
                                className: "text-xs font-semibold",
                                children: s("Apply Discount")
                            })]
                        }),
                        search: e.hideSearch ? void 0 : {
                            placeholder: s("Search for Challenges"),
                            onSearch: B,
                            defaultValue: null != G ? G : ""
                        },
                        sorting: e.hideSortingFilter ? void 0 : {
                            defaultValue: (null == E ? void 0 : null === (a = E[0]) || void 0 === a ? void 0 : a.id) ? {
                                value: E[0].id,
                                desc: E[0].desc
                            } : I[0],
                            options: I,
                            onSortingChange: L
                        }
                    }), (0, l.jsx)(i.F_, {
                        filtersHookResult: { ...T,
                            ...A
                        },
                        children: e.children
                    })]
                })
            }

            function L(e) {
                return (0, l.jsx)(x.Suspense, {
                    fallback: null,
                    children: (0, l.jsx)(E, {
                        hideQuickFilters: e.hideQuickFilters,
                        hideSearch: e.hideSearch,
                        hideSortingFilter: e.hideSortingFilter,
                        hideProgramFilter: e.hideProgramFilter,
                        firmId: e.firmId,
                        children: e.children
                    })
                })
            }! function(e) {
                e.All = "all", e.Bookmarks = "bookmarks"
            }(t || (t = {}))
        },
        98283: (e, a, s) => {
            s.d(a, {
                ChallengesTable: () => L
            });
            var t = s(12428),
                l = s(61180),
                r = s(67266),
                n = s(58652),
                i = s(89309),
                o = s(6185),
                d = s(69615),
                c = s(28422),
                u = s(77838),
                m = s(1798),
                x = s(85473),
                p = s(40850);
            let f = () => (0, t.jsx)("svg", {
                    width: "4",
                    height: "12",
                    viewBox: "0 0 4 12",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, t.jsx)("rect", {
                        width: "4",
                        height: "12",
                        rx: "1",
                        fill: "hsl(var(--border))"
                    })
                }),
                h = () => (0, t.jsxs)("svg", {
                    width: "4",
                    height: "12",
                    viewBox: "0 0 4 12",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, t.jsx)("rect", {
                        width: "4",
                        height: "12",
                        rx: "1",
                        fill: "url(#paint0_linear_9065_8587)"
                    }), (0, t.jsx)("defs", {
                        children: (0, t.jsxs)("linearGradient", {
                            id: "paint0_linear_9065_8587",
                            x1: "4",
                            y1: "12",
                            x2: "-3.2",
                            y2: "9.6",
                            gradientUnits: "userSpaceOnUse",
                            children: [(0, t.jsx)("stop", {
                                stopColor: "hsl(var(--color-purple))"
                            }), (0, t.jsx)("stop", {
                                offset: "1",
                                stopColor: "hsl(var(--color-primary))"
                            })]
                        })
                    })]
                }),
                v = e => {
                    let a = e.percentage / 10 / 10 * 100;
                    return (0, t.jsxs)("div", {
                        className: "relative flex w-fit",
                        children: [(0, t.jsx)("div", {
                            className: "flex space-x-px",
                            children: Array.from({
                                length: 10
                            }).map((e, a) => (0, t.jsx)(f, {}, a))
                        }), (0, t.jsx)("div", {
                            className: "absolute overflow-hidden h-full",
                            style: {
                                width: "".concat(a, "%")
                            },
                            children: (0, t.jsx)("div", {
                                className: "absolute top-0 left-0 flex overflow-hidden space-x-px",
                                children: Array.from({
                                    length: 10
                                }).map((e, a) => (0, t.jsx)(h, {}, a))
                            })
                        })]
                    })
                },
                g = e => (0, t.jsxs)("div", {
                    className: "flex items-center space-x-1",
                    children: [(0, t.jsxs)("p", {
                        className: "font-semibold text-[10px] md:text-sm",
                        children: [e.percentage, "%"]
                    }), (0, t.jsx)(v, {
                        percentage: e.percentage
                    })]
                });
            var j = s(45752),
                b = s(42619),
                y = s(83352),
                N = s(32029),
                w = s(7528),
                S = s(35022),
                C = s(93264),
                z = s(64608),
                k = s(95772),
                R = s(37076),
                P = s(33206),
                T = s(97385),
                F = s(62993);

            function A(e) {
                let {
                    percentageVal: a,
                    amountVal: s,
                    isFirst: l
                } = e;

                function r() {
                    return (0, t.jsxs)("div", {
                        className: "space-y-0.5 text-center flex flex-col items-center justify-center",
                        children: [a ? (0, t.jsxs)("div", {
                            className: (0, F.cn)("text-[10px] md:text-sm", s && "border-b border-dashed"),
                            children: [a, "%"]
                        }) : null, s ? (0, t.jsx)("div", {
                            className: "text-foreground-tertiary text-[10px] md:text-xs",
                            children: (0, N.uf)({
                                value: null != s ? s : 0,
                                currency: N.Mf.USD
                            })
                        }) : null]
                    })
                }
                return a || s ? l ? (0, t.jsx)(r, {}) : (0, t.jsxs)("div", {
                    className: "flex items-center",
                    children: [(0, t.jsx)(T.Separator, {
                        orientation: "vertical",
                        className: "h-4 mr-2"
                    }), (0, t.jsx)(r, {})]
                }) : null
            }

            function O(e) {
                return (0, t.jsxs)(t.Fragment, {
                    children: [A({
                        percentageVal: e.phase1Percentage,
                        amountVal: e.phase1Amount,
                        isFirst: !0
                    }), A({
                        percentageVal: e.phase2Percentage,
                        amountVal: e.phase2Amount
                    }), A({
                        percentageVal: e.phase3Percentage,
                        amountVal: e.phase3Amount
                    }), A({
                        percentageVal: e.phase4Percentage,
                        amountVal: e.phase4Amount
                    })]
                })
            }
            let M = !1;

            function E(e) {
                var a, s, f;
                let {
                    t: h
                } = (0, o.$G)(), {
                    pagination: v,
                    skip: T,
                    take: F
                } = (0, n.h)(), {
                    sorting: A,
                    onSortingChange: E
                } = (0, i.r)(), L = (0, m.x)(), [I] = (0, S.v1)("filters"), [D, _] = (0, C.useState)(!I && !e.firmId), G = (0, u.k)(R.d1, e.firmId ? void 0 : R.pJ), [B] = (0, S.v1)("search", k.z.string().optional()), [U] = (0, z.Nr)(B, 500), [V] = (0, S.v1)("tab", k.z.nativeEnum(P.r).optional()), [$] = (0, S.v1)("applyDiscount", k.z.boolean().optional());
                (0, C.useEffect)(() => {
                    (I || !D) && _(!1)
                }, [I, D]);
                let W = (0, C.useMemo)(() => {
                        var a, s, t, l, r, n, i, o, d, c, u, m, x, p, f, h, v, g, j, b, y, N, w, S, C;
                        let z = e.bookmarksOnly ? {
                            bookmarksOnly: e.bookmarksOnly
                        } : {
                            distinctPerFirm: D,
                            bookmarksOnly: V === P.r.Bookmarks,
                            firmType: G.filtersState.firmType,
                            assets: G.filtersState.assets,
                            drawdownType: G.filtersState.drawdownType,
                            maxLossType: G.filtersState.maxLossType,
                            programs: G.filtersState.program,
                            firmChallengeCategoryIds: G.filtersState.firmChallengeCategoryIds,
                            brokers: G.filtersState.brokers,
                            features: G.filtersState.features,
                            countryFeatures: G.filtersState.countryFeatureIds,
                            platforms: G.filtersState.platforms,
                            firmIds: e.firmId ? [e.firmId] : G.filtersState.firmIds,
                            extraAccountPromo: null === (a = G.filtersState.extraAccountPromo) || void 0 === a ? void 0 : a.includes("extra"),
                            priceMin: null === (s = G.filtersState.priceRange) || void 0 === s ? void 0 : s[0],
                            priceMax: null === (t = G.filtersState.priceRange) || void 0 === t ? void 0 : t[1],
                            profitSplitMin: null === (l = G.filtersState.profitSplitRange) || void 0 === l ? void 0 : l[0],
                            profitSplitMax: null === (r = G.filtersState.profitSplitRange) || void 0 === r ? void 0 : r[1],
                            profitTargetMin: null === (n = G.filtersState.profitTargetRange) || void 0 === n ? void 0 : n[0],
                            profitTargetMax: null === (i = G.filtersState.profitTargetRange) || void 0 === i ? void 0 : i[1],
                            maxDailyLossMin: null === (o = G.filtersState.maxDailyLossRange) || void 0 === o ? void 0 : o[0],
                            maxDailyLossMax: null === (d = G.filtersState.maxDailyLossRange) || void 0 === d ? void 0 : d[1],
                            maxTotalDrawdownMin: null === (c = G.filtersState.maxTotalDrawdownRange) || void 0 === c ? void 0 : c[0],
                            maxTotalDrawdownMax: null === (u = G.filtersState.maxTotalDrawdownRange) || void 0 === u ? void 0 : u[1],
                            comissionMin: null === (m = G.filtersState.comissionRange) || void 0 === m ? void 0 : m[0],
                            comissionMax: null === (x = G.filtersState.comissionRange) || void 0 === x ? void 0 : x[1],
                            ptDdMin: null === (p = G.filtersState.ptDdRange) || void 0 === p ? void 0 : p[0],
                            ptDdMax: null === (f = G.filtersState.ptDdRange) || void 0 === f ? void 0 : f[1],
                            payoutFrequencyMin: null === (h = G.filtersState.payoutFrequencyRange) || void 0 === h ? void 0 : h[0],
                            payoutFrequencyMax: null === (v = G.filtersState.payoutFrequencyRange) || void 0 === v ? void 0 : v[1],
                            trustPilotRatingMin: null === (g = G.filtersState.trustPilotRatingRange) || void 0 === g ? void 0 : g[0],
                            trustPilotRatingMax: null === (j = G.filtersState.trustPilotRatingRange) || void 0 === j ? void 0 : j[1],
                            yearsInBusinessMin: null === (b = G.filtersState.yearsInBusinessRange) || void 0 === b ? void 0 : b[0],
                            yearsInBusinessMax: null === (y = G.filtersState.yearsInBusinessRange) || void 0 === y ? void 0 : y[1],
                            loyaltyPointsMin: null === (N = G.filtersState.loyaltyPointsRange) || void 0 === N ? void 0 : N[0],
                            loyaltyPointsMax: null === (w = G.filtersState.loyaltyPointsRange) || void 0 === w ? void 0 : w[1],
                            applyDiscount: null === $ || $,
                            ..."object" == typeof G.filtersState.accountSize && "range" in G.filtersState.accountSize ? {
                                accountSizeMin: null === (S = G.filtersState.accountSize.range) || void 0 === S ? void 0 : S[0],
                                accountSizeMax: null === (C = G.filtersState.accountSize.range) || void 0 === C ? void 0 : C[1]
                            } : Array.isArray(G.filtersState.accountSize) ? {
                                accountSizeOptions: G.filtersState.accountSize
                            } : {}
                        };
                        return Object.keys(z).forEach(e => {
                            (void 0 === z[e] || null === z[e]) && delete z[e]
                        }), z
                    }, [$, V, D, G.filtersState.accountSize, G.filtersState.firmChallengeCategoryIds, G.filtersState.assets, G.filtersState.drawdownType, G.filtersState.maxLossType, G.filtersState.comissionRange, G.filtersState.firmType, G.filtersState.extraAccountPromo, G.filtersState.firmIds, G.filtersState.loyaltyPointsRange, G.filtersState.maxDailyLossRange, G.filtersState.maxTotalDrawdownRange, G.filtersState.payoutFrequencyRange, G.filtersState.priceRange, G.filtersState.profitSplitRange, G.filtersState.profitTargetRange, G.filtersState.program, G.filtersState.ptDdRange, G.filtersState.trustPilotRatingRange, G.filtersState.yearsInBusinessRange, G.filtersState.brokers, G.filtersState.features, G.filtersState.countryFeatureIds, G.filtersState.platforms, e.firmId, e.bookmarksOnly]),
                    [Z, {
                        refetch: H
                    }] = x.trpc.challenge.listFiltered.useSuspenseQuery({
                        skip: T,
                        limit: F,
                        search: null != U ? U : void 0,
                        ...(null == A ? void 0 : null === (a = A[0]) || void 0 === a ? void 0 : a.id) ? {
                            order: {
                                by: A[0].id,
                                direction: A[0].desc ? "desc" : "asc"
                            }
                        } : {},
                        filter: W
                    }),
                    Y = x.trpc.useUtils(),
                    K = x.trpc.protected.challengeActions.addBookmark.useMutation({
                        onSuccess() {
                            Y.challenge.listFiltered.invalidate({
                                filter: {
                                    bookmarksOnly: !0
                                }
                            }), H()
                        }
                    }),
                    X = x.trpc.protected.challengeActions.removeBookmark.useMutation({
                        onSuccess() {
                            Y.challenge.listFiltered.invalidate({
                                filter: {
                                    bookmarksOnly: !0
                                }
                            }), H()
                        }
                    });
                (0, C.useEffect)(() => {
                    M || (H(), M = !0)
                }, [H]);
                let J = (0, C.useMemo)(() => [{
                    accessorKey: "firmRank",
                    header: () => h("Firm / Rank"),
                    enableSorting: !0,
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return a.original.firm && (0, t.jsx)(d.$8, {
                            minifiedOnMobile: !0,
                            onToggleBookmarked: e => {
                                K.isPending || X.isPending || (e ? K.mutate({
                                    challengeId: a.original.id
                                }) : X.mutate({
                                    challengeId: a.original.id
                                }))
                            },
                            isBookmarked: a.original.isBookmarked,
                            firm: a.original.firm
                        })
                    }
                }, {
                    accessorKey: "accountSize",
                    header: () => h("Acc. Size"),
                    enableSorting: !0,
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            children: (0, N.uf)({
                                value: null !== (a = s.original.accountSize) && void 0 !== a ? a : 0,
                                maximumFractionDigits: 2,
                                notation: "compact"
                            })
                        })
                    }
                }, {
                    accessorKey: "steps",
                    header: () => h("Program"),
                    enableSorting: !0,
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, t.jsxs)(c.C1, {
                            className: "items-center",
                            children: [a.original.steps && (0, t.jsx)("p", {
                                className: "whitespace-nowrap",
                                children: L[a.original.steps]
                            }), (0, t.jsxs)(b.J2, {
                                children: [(0, t.jsx)(b.xo, {
                                    children: (0, t.jsx)(w.Z, {
                                        className: "ml-2 text-muted-foreground size-3 md:size-4"
                                    })
                                }), (0, t.jsx)(b.yk, {
                                    side: "bottom",
                                    children: (0, t.jsxs)("div", {
                                        className: "space-y-1",
                                        children: [(0, t.jsx)("p", {
                                            className: "text-foreground-secondary",
                                            children: h("Program Name")
                                        }), (0, t.jsx)("p", {
                                            className: "text-sm font-semibold",
                                            children: a.original.name
                                        })]
                                    })
                                })]
                            })]
                        })
                    }
                }, {
                    accessorKey: "profitTargetSum",
                    header: () => h("Profit Target"),
                    enableSorting: !0,
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            className: "flex-wrap flex justify-center gap-2 w-[6.5rem] items-center",
                            children: (0, t.jsx)(O, {
                                phase1Amount: a.original.phase1ProfitTargetAmount,
                                phase2Amount: a.original.phase2ProfitTargetAmount,
                                phase3Amount: a.original.phase3ProfitTargetAmount,
                                phase4Amount: a.original.phase4ProfitTargetAmount,
                                phase1Percentage: a.original.phase1ProfitTarget,
                                phase2Percentage: a.original.phase2ProfitTarget,
                                phase3Percentage: a.original.phase3ProfitTarget,
                                phase4Percentage: a.original.phase4ProfitTarget
                            })
                        })
                    }
                }, {
                    accessorKey: "maxDailyLoss",
                    header: () => h("Daily Loss"),
                    sortDescFirst: !0,
                    enableSorting: !0,
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            className: "flex-wrap flex justify-center gap-2 w-[6.5rem] items-center",
                            children: (0, t.jsx)(O, {
                                phase1Amount: a.original.phase1MaxDailyLossAmount,
                                phase2Amount: a.original.phase2MaxDailyLossAmount,
                                phase3Amount: a.original.phase3MaxDailyLossAmount,
                                phase4Amount: a.original.phase4MaxDailyLossAmount,
                                phase1Percentage: a.original.phase1MaxDailyLoss,
                                phase2Percentage: a.original.phase2MaxDailyLoss,
                                phase3Percentage: a.original.phase3MaxDailyLoss,
                                phase4Percentage: a.original.phase4MaxDailyLoss
                            })
                        })
                    }
                }, {
                    accessorKey: "maxDrawdown",
                    header: () => h("Max Loss"),
                    sortDescFirst: !0,
                    enableSorting: !0,
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            className: "flex-wrap flex justify-center gap-2 w-[6.5rem] items-center",
                            children: (0, t.jsx)(O, {
                                phase1Amount: a.original.phase1MaxDrawdownAmount,
                                phase2Amount: a.original.phase2MaxDrawdownAmount,
                                phase3Amount: a.original.phase3MaxDrawdownAmount,
                                phase4Amount: a.original.phase4MaxDrawdownAmount,
                                phase1Percentage: a.original.phase1MaxDrawdown,
                                phase2Percentage: a.original.phase2MaxDrawdown,
                                phase3Percentage: a.original.phase3MaxDrawdown,
                                phase4Percentage: a.original.phase4MaxDrawdown
                            })
                        })
                    }
                }, {
                    accessorKey: "profitSplit",
                    header: () => h("Profit Split"),
                    sortDescFirst: !0,
                    enableSorting: !0,
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            children: (0, t.jsx)(g, {
                                percentage: null !== (a = s.original.profitSplit) && void 0 !== a ? a : 0
                            })
                        })
                    }
                }, {
                    accessorKey: "payoutFrequency",
                    header: () => h("Payout Freq."),
                    enableSorting: !0,
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            children: (0, t.jsx)(y.o3, {
                                maxWidth: "2xs",
                                children: null !== (a = s.original.payoutFrequencyDescription) && void 0 !== a ? a : s.original.payoutFrequency
                            })
                        })
                    }
                }, {
                    accessorKey: "loyaltyPoints",
                    header: () => h("Loyalty PTS"),
                    sortDescFirst: !0,
                    enableSorting: !0,
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, t.jsx)(c.C1, {
                            children: (0, t.jsx)(j.L, {
                                points: null !== (a = s.original.loyaltyPoints) && void 0 !== a ? a : 0
                            })
                        })
                    }
                }, {
                    accessorKey: "price",
                    enableSorting: !0,
                    header: () => h("Price"),
                    cell: e => {
                        var a, s;
                        let {
                            row: n
                        } = e;
                        return (0, t.jsxs)(c.C1, {
                            className: "flex flex-col md:justify-end items-center lg:flex-row gap-0.5 md:gap-5",
                            children: [(0, t.jsx)(r.Q, {
                                applyDiscount: null == $ || $,
                                challenge: n.original,
                                currency: null !== (s = null === (a = n.original.firm) || void 0 === a ? void 0 : a.currency) && void 0 !== s ? s : "USD"
                            }), (0, t.jsx)(l.h, {
                                challengeId: n.original.id,
                                children: (0, t.jsx)(p.zx, {
                                    variant: "pfmGradient",
                                    rounded: "full",
                                    className: "h-8.5 md:h-10 w-max px-3 md:px-5 md:w-auto",
                                    children: h("Buy")
                                })
                            })]
                        })
                    }
                }], [h, K, L, $, X]);
                return (0, t.jsx)(c.tf, {
                    columns: J,
                    data: null !== (s = Z.data) && void 0 !== s ? s : [],
                    pinFirstColumn: !0,
                    pinLastColumn: !0,
                    sorting: A,
                    setSorting: E,
                    pagination: null === (f = e.showPagination) || void 0 === f || f ? v : void 0,
                    rowCount: Z.count,
                    enableMultiSort: !1,
                    noDataPlaceholder: (0, t.jsx)(c.zP, {})
                })
            }

            function L(e) {
                var a, s;
                return (0, t.jsx)(C.Suspense, {
                    fallback: (0, t.jsx)(c.OO, {
                        columns: 10,
                        rows: 5
                    }),
                    children: (0, t.jsx)(E, {
                        bookmarksOnly: null !== (a = e.bookmarksOnly) && void 0 !== a && a,
                        firmId: e.firmId,
                        showPagination: null === (s = e.showPagination) || void 0 === s || s
                    })
                })
            }
        },
        37076: (e, a, s) => {
            s.d(a, {
                pJ: () => p,
                d1: () => x,
                r4: () => f
            });
            var t = s(12428),
                l = s(11800),
                r = s(6185),
                n = s(28422),
                i = s(94062),
                o = s(17322),
                d = s(80501),
                c = s(32029),
                u = s(93264),
                m = s(95772);
            let x = m.z.object({
                    firmType: m.z.array(m.z.nativeEnum(o.co)).optional(),
                    firmIds: m.z.array(m.z.string()).optional(),
                    countryFeatureIds: m.z.array(m.z.string()).optional(),
                    assets: m.z.array(m.z.nativeEnum(o.fo)).optional(),
                    drawdownType: m.z.array(m.z.nativeEnum(o.wJ)).optional(),
                    maxLossType: m.z.array(m.z.nativeEnum(o.Rn)).optional(),
                    firmChallengeCategoryIds: m.z.string().array().optional(),
                    accountSize: m.z.array(m.z.number()).or(m.z.object({
                        range: m.z.tuple([m.z.number(), m.z.number()])
                    })).optional(),
                    program: m.z.nativeEnum(o.oi).array().optional(),
                    extraAccountPromo: m.z.literal("extra").array().optional(),
                    applyDiscount: m.z.boolean().optional(),
                    instruments: m.z.array(m.z.nativeEnum(o.Yi)).optional(),
                    platforms: m.z.array(m.z.string()).optional(),
                    features: m.z.array(m.z.string()).optional(),
                    brokers: m.z.array(m.z.string()).optional(),
                    priceRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    profitSplitRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    profitTargetRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    maxDailyLossRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    maxTotalDrawdownRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    comissionRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    ptDdRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    payoutFrequencyRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    trustPilotRatingRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    yearsInBusinessRange: m.z.tuple([m.z.number(), m.z.number()]).optional(),
                    loyaltyPointsRange: m.z.tuple([m.z.number(), m.z.number()]).optional()
                }),
                p = {
                    assets: [o.fo.FX],
                    accountSize: [1e5],
                    program: [o.oi.TwoSteps]
                };

            function f(e) {
                let {
                    t: a
                } = (0, r.$G)(), s = (0, l.J)(), m = (0, u.useMemo)(() => {
                    var s, t, l, r, o, d, u, m, p, f, h, v, g, j, b, y, N, w, S, C, z, k, R, P, T, F, A, O, M, E, L, I, D, _, G, B, U, V, $;
                    return (0, i.g)(x, [(0, n.rV)({
                        asChild: !0,
                        label: a("Price"),
                        name: "priceRange",
                        labelTransformer: e => (0, c.uf)({
                            value: e,
                            currency: "USD",
                            locale: "en-US"
                        }),
                        sliderProps: {
                            min: null !== (z = null === (s = e.limits) || void 0 === s ? void 0 : s.priceMin) && void 0 !== z ? z : 0,
                            max: null !== (k = null === (t = e.limits) || void 0 === t ? void 0 : t.priceMax) && void 0 !== k ? k : 1e6
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Profit Split"),
                        name: "profitSplitRange",
                        labelTransformer: e => "".concat(e, "%"),
                        sliderProps: {
                            min: null !== (R = null === (l = e.limits) || void 0 === l ? void 0 : l.profitSplitMin) && void 0 !== R ? R : 0,
                            max: null !== (P = null === (r = e.limits) || void 0 === r ? void 0 : r.profitSplitMax) && void 0 !== P ? P : 100
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Profit Target % (Combined)"),
                        name: "profitTargetRange",
                        labelTransformer: e => "".concat(e, "%"),
                        sliderProps: {
                            min: null !== (T = null === (o = e.limits) || void 0 === o ? void 0 : o.profitTargetSumMin) && void 0 !== T ? T : 0,
                            max: null !== (F = null === (d = e.limits) || void 0 === d ? void 0 : d.profitTargetSumMax) && void 0 !== F ? F : 100
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Max Daily Loss %"),
                        name: "maxDailyLossRange",
                        labelTransformer: e => "".concat(e, "%"),
                        sliderProps: {
                            min: null !== (A = null === (u = e.limits) || void 0 === u ? void 0 : u.maxDailyLossMin) && void 0 !== A ? A : 0,
                            max: null !== (O = null === (m = e.limits) || void 0 === m ? void 0 : m.maxDailyLossMax) && void 0 !== O ? O : 100
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Max Total Drawdown"),
                        labelTransformer: e => "".concat(e, "%"),
                        name: "maxTotalDrawdownRange",
                        sliderProps: {
                            min: null !== (M = null === (p = e.limits) || void 0 === p ? void 0 : p.maxTotalDrawdownMin) && void 0 !== M ? M : 0,
                            max: null !== (E = null === (f = e.limits) || void 0 === f ? void 0 : f.maxTotalDrawdownMax) && void 0 !== E ? E : 100
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Comission"),
                        name: "comissionRange",
                        sliderProps: {
                            min: null !== (L = null === (h = e.limits) || void 0 === h ? void 0 : h.comissionMin) && void 0 !== L ? L : 0,
                            max: null !== (I = null === (v = e.limits) || void 0 === v ? void 0 : v.comissionMax) && void 0 !== I ? I : 1e4
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("PT/DD"),
                        name: "ptDdRange",
                        labelTransformer: e => "1:".concat(e),
                        sliderProps: {
                            min: null !== (D = null === (g = e.limits) || void 0 === g ? void 0 : g.ptDdMin) && void 0 !== D ? D : 0,
                            max: null !== (_ = null === (j = e.limits) || void 0 === j ? void 0 : j.ptDdMax) && void 0 !== _ ? _ : 1,
                            step: .01
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Payout Frequency"),
                        name: "payoutFrequencyRange",
                        sliderProps: {
                            min: null !== (G = null === (b = e.limits) || void 0 === b ? void 0 : b.payoutFrequencyMin) && void 0 !== G ? G : 0,
                            max: null !== (B = null === (y = e.limits) || void 0 === y ? void 0 : y.payoutFrequencyMax) && void 0 !== B ? B : 60
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Trust Pilot Rating"),
                        name: "trustPilotRatingRange",
                        sliderProps: {
                            min: null !== (U = null === (N = e.limits) || void 0 === N ? void 0 : N.trustPilotRatingMin) && void 0 !== U ? U : 0,
                            max: (null === (w = e.limits) || void 0 === w ? void 0 : w.trustPilotRatingMax) || 5,
                            step: .25
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Years In Business"),
                        name: "yearsInBusinessRange",
                        sliderProps: {
                            min: 0,
                            max: 50
                        }
                    }), (0, n.rV)({
                        asChild: !0,
                        label: a("Loyalty Points"),
                        name: "loyaltyPointsRange",
                        sliderProps: {
                            min: null !== (V = null === (S = e.limits) || void 0 === S ? void 0 : S.loyaltyPointsMin) && void 0 !== V ? V : 0,
                            max: null !== ($ = null === (C = e.limits) || void 0 === C ? void 0 : C.loyaltyPointsMax) && void 0 !== $ ? $ : 1e3
                        }
                    })])
                }, [a, e]), p = (0, n.N_)({
                    name: "firmIds",
                    label: a("Firms")
                }), f = (0, d.z)(), h = function() {
                    let {
                        t: e
                    } = (0, r.$G)();
                    return {
                        [o.Rn.Static]: e("Static"),
                        [o.Rn.Trailing]: e("Trailing")
                    }
                }();
                return {
                    filters: (0, u.useMemo)(() => {
                        var l, r, d, c, v, g, j, b, y, N, w, S, C, z, k, R, P, T;
                        return (0, i.g)(x, [(0, n.On)({
                            name: "firmType",
                            label: a("Type Of Firm"),
                            labelClassName: "md:text-base text-xs text-primary-theme",
                            options: [{
                                label: s[o.co.CFD],
                                value: o.co.CFD
                            }, {
                                label: s[o.co.Futures],
                                value: o.co.Futures
                            }, {
                                label: s[o.co.CryptoOnly],
                                value: o.co.CryptoOnly
                            }, {
                                label: s[o.co.StocksOnly],
                                value: o.co.StocksOnly
                            }]
                        }), (0, n.kV)({
                            name: "extraAccountPromo",
                            label: a("Extra Account Promo"),
                            containerClassName: "items-start",
                            options: [{
                                value: "extra",
                                label: a("+1 Free Challenge Account if Reaching Payout")
                            }],
                            renderItem: e => (0, t.jsx)("div", {
                                className: "text-xs",
                                children: e.label
                            })
                        }), p, (0, n.On)({
                            label: a("Daily Drawdown Type"),
                            name: "drawdownType",
                            options: [{
                                value: o.wJ.BalanceBased,
                                label: f[o.wJ.BalanceBased]
                            }, {
                                value: o.wJ.EquityBased,
                                label: f[o.wJ.EquityBased]
                            }, {
                                value: o.wJ.BalanceEquityHighestAtEod,
                                label: f[o.wJ.BalanceEquityHighestAtEod]
                            }, {
                                value: o.wJ.TrailingHighestBalanceEquity,
                                label: f[o.wJ.TrailingHighestBalanceEquity]
                            }]
                        }), (0, n.On)({
                            label: a("Max Loss Type"),
                            name: "maxLossType",
                            options: [{
                                value: o.Rn.Static,
                                label: h[o.Rn.Static]
                            }, {
                                value: o.Rn.Trailing,
                                label: h[o.Rn.Trailing]
                            }]
                        }), {
                            label: a("Advanced Filtering"),
                            name: "priceRange",
                            render: e => (0, t.jsx)("div", {
                                className: "space-y-4",
                                children: m.options.map(a => (0, t.jsx)(u.Fragment, {
                                    children: a.render(e)
                                }, a.name))
                            })
                        }, (0, n.On)({
                            name: "features",
                            label: a("Features"),
                            options: null !== (k = null === (c = e.features) || void 0 === c ? void 0 : null === (d = c.challengesFeatures) || void 0 === d ? void 0 : null === (r = d.filter(e => {
                                var a, s;
                                return (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) > 0
                            })) || void 0 === r ? void 0 : null === (l = r.sort((e, a) => {
                                var s, t, l, r;
                                let n = (null !== (l = null === (s = a.occurencies) || void 0 === s ? void 0 : s.count) && void 0 !== l ? l : 0) - (null !== (r = null === (t = e.occurencies) || void 0 === t ? void 0 : t.count) && void 0 !== r ? r : 0);
                                return 0 !== n ? n : null == e ? void 0 : e.name.localeCompare(null == a ? void 0 : a.name)
                            })) || void 0 === l ? void 0 : l.map(e => {
                                var a, s;
                                return {
                                    label: e.name,
                                    value: e.id,
                                    secondary: (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) < 2
                                }
                            })) && void 0 !== k ? k : []
                        }), (0, n.On)({
                            name: "brokers",
                            label: a("Brokers"),
                            options: null !== (R = null === (b = e.features) || void 0 === b ? void 0 : null === (j = b.brokers) || void 0 === j ? void 0 : null === (g = j.filter(e => {
                                var a, s;
                                return (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) > 0
                            })) || void 0 === g ? void 0 : null === (v = g.sort((e, a) => {
                                var s, t, l, r;
                                let n = (null !== (l = null === (s = a.occurencies) || void 0 === s ? void 0 : s.count) && void 0 !== l ? l : 0) - (null !== (r = null === (t = e.occurencies) || void 0 === t ? void 0 : t.count) && void 0 !== r ? r : 0);
                                return 0 !== n ? n : null == e ? void 0 : e.name.localeCompare(null == a ? void 0 : a.name)
                            })) || void 0 === v ? void 0 : v.map(e => {
                                var a, s;
                                return {
                                    label: e.name,
                                    value: e.id,
                                    secondary: (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) < 2
                                }
                            })) && void 0 !== R ? R : []
                        }), (0, n.On)({
                            name: "platforms",
                            label: a("Platforms"),
                            options: null !== (P = null === (S = e.features) || void 0 === S ? void 0 : null === (w = S.platforms) || void 0 === w ? void 0 : null === (N = w.filter(e => {
                                var a, s;
                                return (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) > 0
                            })) || void 0 === N ? void 0 : null === (y = N.sort((e, a) => {
                                var s, t, l, r;
                                let n = (null !== (l = null === (s = a.occurencies) || void 0 === s ? void 0 : s.count) && void 0 !== l ? l : 0) - (null !== (r = null === (t = e.occurencies) || void 0 === t ? void 0 : t.count) && void 0 !== r ? r : 0);
                                return 0 !== n ? n : null == e ? void 0 : e.name.localeCompare(null == a ? void 0 : a.name)
                            })) || void 0 === y ? void 0 : y.map(e => {
                                var a, s;
                                return {
                                    label: e.name,
                                    value: e.id,
                                    secondary: (null !== (s = null === (a = e.occurencies) || void 0 === a ? void 0 : a.count) && void 0 !== s ? s : 0) < 2
                                }
                            })) && void 0 !== P ? P : []
                        }), (0, n.On)({
                            name: "countryFeatureIds",
                            label: a("Countries"),
                            options: null !== (T = null === (z = e.features) || void 0 === z ? void 0 : null === (C = z.countries) || void 0 === C ? void 0 : C.map(e => ({
                                value: e.id,
                                label: e.name
                            }))) && void 0 !== T ? T : []
                        })])
                    }, [a, s, e, f, h, m, p])
                }
            }
        },
        3161: (e, a, s) => {
            s.d(a, {
                FirmHeader: () => R
            });
            var t = s(12428),
                l = s(72172),
                r = s(69615),
                n = s(85473),
                i = s(49433),
                o = s(39540),
                d = s(26185),
                c = s(93264),
                u = s(6185),
                m = s(97385),
                x = s(68586),
                p = s(43121),
                f = s(7349);

            function h(e) {
                return (0, t.jsxs)("div", {
                    children: [(0, t.jsx)("p", {
                        className: "text-[10px] md:text-sm text-foreground-secondary leading-5",
                        children: e.title
                    }), (0, t.jsx)("div", {
                        className: "text-xs md:text-sm font-semibold",
                        children: e.children
                    })]
                })
            }

            function v(e) {
                let {
                    firm: a,
                    hideCountry: s
                } = e, {
                    t: l
                } = (0, u.$G)(), r = new Date;
                return (0, t.jsxs)("div", {
                    className: "flex flex-wrap xl:items-center gap-4",
                    children: [(0, t.jsx)(h, {
                        title: l("CEO"),
                        children: a.ceo ? a.ceo : (0, t.jsx)(f.J, {})
                    }), (0, t.jsx)(m.Separator, {
                        orientation: "vertical",
                        className: "h-10 bg-border"
                    }), s ? null : (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)(h, {
                            title: l("Country"),
                            children: a.country ? (0, t.jsx)(d.l, {
                                countryCode: a.country
                            }) : (0, t.jsx)(f.J, {})
                        }), (0, t.jsx)(m.Separator, {
                            orientation: "vertical",
                            className: "h-10 bg-border"
                        })]
                    }), (0, t.jsx)(h, {
                        title: l("Trust Pilot"),
                        children: a.trustPilotScore ? a.trustPilotScore : (0, t.jsx)(f.J, {})
                    }), (0, t.jsx)(m.Separator, {
                        orientation: "vertical",
                        className: "h-10 bg-border"
                    }), (0, t.jsx)(h, {
                        title: l("Date Created"),
                        children: a.dateEstablished ? (0, x.WU)(new Date(a.dateEstablished), "MMM yyyy") : (0, t.jsx)(f.J, {})
                    }), (0, t.jsx)(m.Separator, {
                        orientation: "vertical",
                        className: "h-10 bg-border"
                    }), (0, t.jsx)(h, {
                        title: l("Years in Operation"),
                        children: a.dateEstablished ? (0, p.o)(r, a.dateEstablished) : (0, t.jsx)(f.J, {})
                    })]
                })
            }
            var g = s(20533);

            function j() {
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-4 lg:flex-row lg:items-center justify-between",
                    children: [(0, t.jsx)("div", {
                        className: "hidden md:block",
                        children: (0, t.jsxs)("div", {
                            className: "flex gap-4 items-center",
                            children: [(0, t.jsx)(g.O, {
                                className: "w-[110px] h-[110px]"
                            }), (0, t.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, t.jsx)(g.O, {
                                    className: "h-9 w-56"
                                }), (0, t.jsx)(g.O, {
                                    className: "h-11 w-80"
                                })]
                            })]
                        })
                    }), (0, t.jsxs)("div", {
                        className: "md:hidden space-y-4",
                        children: [(0, t.jsxs)("div", {
                            className: "flex items-center gap-4",
                            children: [(0, t.jsx)(g.O, {
                                className: "w-[72px] h-[72px]"
                            }), (0, t.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, t.jsx)(g.O, {
                                    className: "h-9 w-56"
                                }), (0, t.jsx)(g.O, {
                                    className: "h-5 w-20"
                                })]
                            })]
                        }), (0, t.jsx)(g.O, {
                            className: "h-11 w-80"
                        })]
                    }), (0, t.jsx)(g.O, {
                        className: "h-24 w-96"
                    })]
                })
            }
            var b = s(54852),
                y = s(5313),
                N = s(92494),
                w = s(32029);

            function S(e) {
                return (0, t.jsxs)("div", {
                    className: "flex items-center space-x-1.5 h-4.5 w-full md:min-w-[290px]",
                    children: [(0, t.jsxs)("div", {
                        className: "flex w-6 gap-0.5",
                        children: [(0, t.jsx)("p", {
                            className: "text-xs leading-[18px]",
                            children: e.stars
                        }), (0, t.jsx)(y.r7, {
                            className: "h-4 w-4"
                        })]
                    }), (0, t.jsx)("div", {
                        className: "px-0.5 flex-1",
                        children: (0, t.jsx)(N.P, {
                            size: "3xs",
                            variant: "pfmGradient",
                            minLimit: 0,
                            maxLimit: e.totalReviews,
                            value: e.value
                        })
                    }), (0, t.jsx)("p", {
                        className: "text-xs w-6.5 text-left",
                        children: (0, w.uf)({
                            value: e.value,
                            notation: "compact"
                        })
                    })]
                })
            }

            function C(e) {
                var a, s, l;
                let {
                    t: r
                } = (0, u.$G)();
                return (0, t.jsxs)("div", {
                    className: "flex items-center space-x-6",
                    children: [(0, t.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [(0, t.jsx)("p", {
                            className: "text-5xl font-semibold h-16 flex items-end",
                            children: (null !== (a = e.firm.reviewScore) && void 0 !== a ? a : 0).toFixed(1)
                        }), (0, t.jsx)(b.FirmStarsRank, {
                            rank: null !== (s = e.firm.reviewScore) && void 0 !== s ? s : 0
                        }), (0, t.jsxs)("div", {
                            className: "text-xs flex items-center justify-center space-x-1 mt-0.5",
                            children: [(0, t.jsx)("p", {
                                className: "text-primary-theme",
                                children: null !== (l = e.firm.reviewsCount) && void 0 !== l ? l : 0
                            }), (0, t.jsx)("p", {
                                className: "text-foreground-secondary whitespace-nowrap",
                                children: r("total reviews")
                            })]
                        })]
                    }), (0, t.jsx)("div", {
                        className: "flex flex-col flex-1",
                        children: Object.entries(e.firm.starReviewsCount).reverse().map(a => {
                            var s, l;
                            let [r, n] = a;
                            return (0, t.jsx)(S, {
                                stars: r,
                                value: null !== (s = null == n ? void 0 : n.count) && void 0 !== s ? s : 0,
                                totalReviews: null !== (l = e.firm.reviewsCount) && void 0 !== l ? l : 0
                            }, r)
                        })
                    })]
                })
            }
            let z = !1;

            function k(e) {
                var a;
                let {
                    slug: s
                } = e, u = (0, i.ll)(), {
                    user: m,
                    isLoaded: x,
                    isSignedIn: p
                } = (0, i.aF)(), [{
                    firm: f
                }, {
                    refetch: h
                }] = n.trpc.firm.getDetailsPageData.useSuspenseQuery({
                    slug: s
                });
                (0, c.useEffect)(() => {
                    !z && x && (z = !0, p && h())
                }, [x, p, h]);
                let g = n.trpc.protected.firmActions.likeFirm.useMutation({
                        onSuccess() {
                            h()
                        }
                    }),
                    j = n.trpc.protected.firmActions.unlikeFirm.useMutation({
                        onSuccess() {
                            h()
                        }
                    });

                function b() {
                    var e;
                    if (!m) {
                        u.redirectToSignIn();
                        return
                    }
                    return (null === (e = f.userLikes) || void 0 === e ? void 0 : e.id) ? j.mutate({
                        firmId: f.id
                    }) : g.mutate({
                        firmId: f.id
                    })
                }

                function y() {
                    var e;
                    return (0, t.jsx)(o._, {
                        isFavorite: !!(null === (e = f.userLikes) || void 0 === e ? void 0 : e.id),
                        iconClassName: "size-4 md:size-6",
                        onToggle: b
                    })
                }
                return (0, t.jsxs)("div", {
                    className: "space-y-10",
                    children: [(0, t.jsxs)("div", {
                        className: "flex flex-col gap-4 lg:flex-row lg:items-center justify-between",
                        children: [(0, t.jsx)("div", {
                            className: "hidden md:block",
                            children: (0, t.jsx)(r.mA, {
                                size: "3xl",
                                maxWidth: "sm",
                                firm: f,
                                favoriteSlot: (0, t.jsx)(y, {}),
                                children: (0, t.jsx)(v, {
                                    firm: f
                                })
                            })
                        }), (0, t.jsxs)("div", {
                            className: "md:hidden space-y-4",
                            children: [(0, t.jsx)(r.mA, {
                                size: "xl",
                                firm: f,
                                favoriteSlot: (0, t.jsx)(y, {}),
                                children: f.country && (0, t.jsx)(d.l, {
                                    countryCode: f.country
                                })
                            }), (0, t.jsx)(v, {
                                firm: f,
                                hideCountry: !0
                            })]
                        }), (0, t.jsx)(C, {
                            firm: f
                        })]
                    }), (null === (a = f.preferredPromo) || void 0 === a ? void 0 : a.promo) && (0, t.jsx)(l.T, {
                        promo: { ...f.preferredPromo.promo,
                            siblings: [],
                            firm: f
                        }
                    })]
                })
            }

            function R(e) {
                return (0, t.jsx)(c.Suspense, {
                    fallback: (0, t.jsx)(j, {}),
                    children: (0, t.jsx)(k, { ...e
                    })
                })
            }
        },
        7349: (e, a, s) => {
            s.d(a, {
                J: () => r
            });
            var t = s(12428),
                l = s(6185);

            function r() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsx)("p", {
                    className: "text-sm text-foreground-tertiary",
                    children: e("n/a")
                })
            }
        },
        77903: (e, a, s) => {
            s.d(a, {
                FirmDetailsTabsEnum: () => l,
                FirmTabs: () => en
            });
            var t, l, r = s(12428),
                n = s(6185),
                i = s(11852),
                o = s(34719),
                d = s(85473),
                c = s(74777),
                u = s(97385),
                m = s(53859),
                x = s(47576),
                p = s(35022),
                f = s(93264),
                h = s(95772),
                v = s(33206),
                g = s(98283);

            function j(e) {
                let [{
                    firm: a
                }] = d.trpc.firm.getDetailsPageData.useSuspenseQuery({
                    slug: e.slug
                });
                return (0, r.jsx)(v.ChallengesFilter, {
                    hideQuickFilters: !0,
                    hideSearch: !0,
                    firmId: a.id,
                    children: (0, r.jsx)(g.ChallengesTable, {
                        firmId: a.id
                    })
                })
            }

            function b(e) {
                return (0, r.jsx)(f.Suspense, {
                    children: (0, r.jsx)(j, {
                        slug: e.slug
                    })
                })
            }
            var y = s(51037),
                N = s(64677),
                w = s(17322),
                S = s(40850),
                C = s(5313),
                z = s(58365),
                k = s(65151),
                R = s(7349);

            function P(e) {
                return (0, r.jsx)("p", {
                    className: "text-lg md:text-3xl font-semibold leading-normal",
                    children: e.children
                })
            }

            function T(e) {
                return (0, r.jsxs)("div", {
                    className: "space-y-2",
                    children: [(0, r.jsx)("p", {
                        className: "text-sm text-foreground-secondary leading-5",
                        children: e.title
                    }), (0, r.jsx)("div", {
                        className: "flex items-center gap-1.5 flex-wrap",
                        children: e.children
                    })]
                })
            }

            function F(e) {
                let {
                    t: a
                } = (0, n.$G)();
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), (0, r.jsxs)("div", {
                        className: "grid grid-cols-2 gap-5",
                        children: [(0, r.jsx)(T, {
                            title: a("Type of Instruments:"),
                            children: e.type ? (0, r.jsx)(k._, {
                                label: (0, r.jsx)("span", {
                                    className: "text-sm",
                                    children: e.type
                                })
                            }) : (0, r.jsx)(R.J, {})
                        }), (0, r.jsx)(T, {
                            title: a("Assets:"),
                            children: e.assets.length ? e.assets.map(e => (0, r.jsx)(k._, {
                                label: (0, r.jsx)("span", {
                                    className: "text-sm",
                                    children: e.label
                                })
                            }, e.label)) : (0, r.jsx)(R.J, {})
                        })]
                    })]
                })
            }
            var A = s(37672),
                O = s(64741);
            let M = e => {
                let {
                    title: a,
                    commission: s
                } = e, {
                    t
                } = (0, n.$G)();
                return (0, r.jsx)(A.Zb, {
                    rounded: "2xl",
                    className: "",
                    children: (0, r.jsx)(A.aY, {
                        className: "p-4",
                        children: (0, r.jsxs)("div", {
                            className: "space-y-1",
                            children: [(0, r.jsx)("p", {
                                className: "text-[10px] md:text-xs text-foreground-secondary",
                                children: a
                            }), (0, r.jsx)("p", {
                                className: "text-[10px] md:text-sm font-semibold leading-normal",
                                children: null != s ? s : t("No Commissions")
                            })]
                        })
                    })
                })
            };

            function E(e) {
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), e.futuresCommission ? (0, r.jsx)(O.$, {
                        markdown: e.futuresCommission
                    }) : (0, r.jsx)("div", {
                        className: "grid grid-cols-2 gap-2 md:gap-5",
                        children: e.assets.map(e => (0, r.jsx)(M, {
                            title: e.label,
                            commission: e.commission
                        }, e.label))
                    })]
                })
            }
            var L = s(92494),
                I = s(62993);

            function D(e) {
                return (0, r.jsx)("th", {
                    className: (0, I.cn)("border-b border-background-secondary py-3 px-4 text-center font-normal", e.className),
                    children: e.children
                })
            }

            function _(e) {
                return (0, r.jsx)("td", {
                    className: (0, I.cn)("px-4 py-5 text-xs leading-none text-center", e.className),
                    children: e.children
                })
            }

            function G(e) {
                return (0, r.jsx)("div", {
                    className: "flex items-center justify-center",
                    children: (0, r.jsxs)("div", {
                        className: "w-[60px]",
                        children: [(0, r.jsx)("p", {
                            className: "text-xs font-semibold",
                            children: "1:".concat(e.leverage)
                        }), (0, r.jsx)(L.P, {
                            value: e.leverage,
                            variant: "greenToRedGradient",
                            className: "h-0.5"
                        })]
                    })
                })
            }

            function B(e) {
                let {
                    t: a
                } = (0, n.$G)();
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), e.futuresLeverage ? (0, r.jsx)(O.$, {
                        markdown: e.futuresLeverage
                    }) : (0, r.jsx)("div", {
                        className: "overflow-x-auto",
                        children: (0, r.jsxs)("table", {
                            className: "min-w-full table-auto text-sm text-left",
                            children: [(0, r.jsx)("thead", {
                                className: "bg-background-primary",
                                children: (0, r.jsxs)("tr", {
                                    children: [(0, r.jsx)(D, {
                                        className: "pl-4 text-left w-auto md:w-36 font-semibold",
                                        children: a("Assets")
                                    }), (0, r.jsx)(D, {
                                        children: a("Instant")
                                    }), (0, r.jsx)(D, {
                                        children: a("1-Step")
                                    }), (0, r.jsx)(D, {
                                        children: a("2-Steps")
                                    }), (0, r.jsx)(D, {
                                        children: a("3-Steps")
                                    })]
                                })
                            }), (0, r.jsx)("tbody", {
                                children: e.assets.map(e => (0, r.jsxs)("tr", {
                                    className: "transition-colors hover:bg-muted/50",
                                    children: [(0, r.jsx)(_, {
                                        className: "text-left",
                                        children: e.label
                                    }), (0, r.jsx)(_, {
                                        children: e.instant ? (0, r.jsx)(G, {
                                            leverage: e.instant
                                        }) : (0, r.jsx)(R.J, {})
                                    }), (0, r.jsx)(_, {
                                        children: e.oneStep ? (0, r.jsx)(G, {
                                            leverage: e.oneStep
                                        }) : (0, r.jsx)(R.J, {})
                                    }), (0, r.jsx)(_, {
                                        children: e.twoSteps ? (0, r.jsx)(G, {
                                            leverage: e.twoSteps
                                        }) : (0, r.jsx)(R.J, {})
                                    }), (0, r.jsx)(_, {
                                        children: e.threeSteps ? (0, r.jsx)(G, {
                                            leverage: e.threeSteps
                                        }) : (0, r.jsx)(R.J, {})
                                    })]
                                }, e.label))
                            })]
                        })
                    })]
                })
            }
            var U = s(90861),
                V = s(24040),
                $ = s(83352);

            function W(e) {
                var a, s, t, l, i, o, d, c;
                let {
                    t: u
                } = (0, n.$G)(), {
                    getFileReadUrl: m
                } = (0, V.lA)();
                return (0, r.jsxs)("div", {
                    className: "space-y-5 overflow-hidden",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), (0, r.jsxs)("div", {
                        className: "grid grid-cols-2 gap-5",
                        children: [(0, r.jsx)(T, {
                            title: u("Broker:"),
                            children: (null === (s = e.firm.features) || void 0 === s ? void 0 : null === (a = s.brokers) || void 0 === a ? void 0 : a.length) ? e.firm.features.brokers.map(e => (0, r.jsx)(k._, {
                                label: e.icon ? (0, r.jsx)(U.Q0, {
                                    image: m(e.icon),
                                    label: e.name
                                }) : (0, r.jsx)("span", {
                                    className: "text-sm",
                                    children: e.name
                                })
                            }, e.id)) : (0, r.jsx)(R.J, {})
                        }), (0, r.jsx)(T, {
                            title: u("Platform:"),
                            children: (null === (l = e.firm.features) || void 0 === l ? void 0 : null === (t = l.platforms) || void 0 === t ? void 0 : t.length) ? e.firm.features.platforms.map(e => (0, r.jsx)(k._, {
                                label: e.icon ? (0, r.jsx)(U.Q0, {
                                    image: m(e.icon),
                                    label: e.name
                                }) : (0, r.jsx)("span", {
                                    className: "text-sm",
                                    children: e.name
                                })
                            }, e.id)) : (0, r.jsx)(R.J, {})
                        }), (0, r.jsx)(T, {
                            title: u("Payment Methods:"),
                            children: (null === (o = e.firm.features) || void 0 === o ? void 0 : null === (i = o.paymentMethods) || void 0 === i ? void 0 : i.length) ? e.firm.features.paymentMethods.map(e => (0, r.jsx)(k._, {
                                label: e.icon ? (0, r.jsx)(U.Q0, {
                                    image: m(e.icon),
                                    label: e.name
                                }) : (0, r.jsx)("span", {
                                    className: "text-sm",
                                    children: e.name
                                })
                            }, e.id)) : (0, r.jsx)(R.J, {})
                        }), (0, r.jsx)(T, {
                            title: u("Payout Methods:"),
                            children: (null === (c = e.firm.features) || void 0 === c ? void 0 : null === (d = c.payoutMethods) || void 0 === d ? void 0 : d.length) ? e.firm.features.payoutMethods.map(e => (0, r.jsxs)("div", {
                                className: "flex items-center space-x-2",
                                children: [(0, r.jsx)(k._, {
                                    label: e.icon ? (0, r.jsx)(U.Q0, {
                                        image: m(e.icon),
                                        label: e.name
                                    }) : (0, r.jsx)("span", {
                                        className: "text-sm",
                                        children: e.name
                                    })
                                }, e.id), (0, r.jsx)($.o3, {
                                    className: "text-sm border-b border-dotted xl:border-0",
                                    children: e.description
                                })]
                            }, e.name)) : (0, r.jsx)(R.J, {})
                        })]
                    })]
                })
            }

            function Z(e) {
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), e.payoutPolicy ? (0, r.jsx)(O.$, {
                        markdown: e.payoutPolicy,
                        className: "text-xs md:text-base text-foreground-secondary"
                    }) : (0, r.jsx)(R.J, {})]
                })
            }

            function H(e) {
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsx)(P, {
                        children: e.title
                    }), e.firmRules ? (0, r.jsx)(O.$, {
                        markdown: e.firmRules,
                        className: "text-xs md:text-base text-foreground-secondary"
                    }) : (0, r.jsx)(R.J, {})]
                })
            }
            var Y = s(20533);

            function K() {
                return (0, r.jsxs)("div", {
                    className: "flex flex-col lg:flex-row gap-10",
                    children: [(0, r.jsx)(Y.O, {
                        className: "h-10 w-full md:w-4/5 lg:hidden"
                    }), (0, r.jsx)(Y.O, {
                        className: "hidden lg:block w-48 h-52"
                    }), (0, r.jsx)(Y.O, {
                        className: "flex flex-1 h-96"
                    }), (0, r.jsx)(Y.O, {
                        className: "hidden lg:block w-[270px] h-80"
                    })]
                })
            }

            function X(e) {
                var a, s, t;
                let {
                    t: o
                } = (0, n.$G)(), c = (0, y.e)(), [m] = d.trpc.announcement.listFiltered.useSuspenseQuery({
                    skip: 0,
                    limit: 3,
                    firmSlug: null !== (s = e.slug) && void 0 !== s ? s : void 0
                }), [{
                    firm: x
                }] = d.trpc.firm.getDetailsPageData.useSuspenseQuery({
                    slug: e.slug
                }), p = [{
                    label: c[w.fo.FX],
                    enabled: x.assets.assetFxEnabled,
                    commission: x.assets.assetFxCommission,
                    instant: x.assets.assetFxInstantLeverage,
                    oneStep: x.assets.assetFxOneStepLeverage,
                    twoSteps: x.assets.assetFxTwoStepsLeverage,
                    threeSteps: x.assets.assetFxThreeStepsLeverage
                }, {
                    label: c[w.fo.Metals],
                    enabled: x.assets.assetMetalsEnabled,
                    commission: x.assets.assetMetalsComission,
                    instant: x.assets.assetMetalsInstantLeverage,
                    oneStep: x.assets.assetMetalsOneStepLeverage,
                    twoSteps: x.assets.assetMetalsTwoStepsLeverage,
                    threeSteps: x.assets.assetMetalsThreeStepsLeverage
                }, {
                    label: c[w.fo.Indices],
                    enabled: x.assets.assetIndicesEnabled,
                    commission: x.assets.assetIndicesComission,
                    instant: x.assets.assetIndicesInstantLeverage,
                    oneStep: x.assets.assetIndicesOneStepLeverage,
                    twoSteps: x.assets.assetIndicesTwoStepsLeverage,
                    threeSteps: x.assets.assetIndicesThreeStepsLeverage
                }, {
                    label: c[w.fo.Energy],
                    enabled: x.assets.assetEnergyEnabled,
                    commission: x.assets.assetEnergyComission,
                    instant: x.assets.assetEnergyInstantLeverage,
                    oneStep: x.assets.assetEnergyOneStepLeverage,
                    twoSteps: x.assets.assetEnergyTwoStepsLeverage,
                    threeSteps: x.assets.assetEnergyThreeStepsLeverage
                }, {
                    label: c[w.fo.Crypto],
                    enabled: x.assets.assetCryptoEnabled,
                    commission: x.assets.assetCryptoComission,
                    instant: x.assets.assetCryptoInstantLeverage,
                    oneStep: x.assets.assetCryptoOneStepLeverage,
                    twoSteps: x.assets.assetCryptoTwoStepsLeverage,
                    threeSteps: x.assets.assetCryptoThreeStepsLeverage
                }, {
                    label: c[w.fo.Stocks],
                    enabled: x.assets.assetStocksEnabled,
                    commission: x.assets.assetStocksComission,
                    instant: x.assets.assetStocksInstantLeverage,
                    oneStep: x.assets.assetStocksOneStepLeverage,
                    twoSteps: x.assets.assetStocksTwoStepsLeverage,
                    threeSteps: x.assets.assetStocksThreeStepsLeverage
                }, {
                    label: c[w.fo.OtherCommodities],
                    enabled: x.assets.assetOtherCommoditiesEnabled,
                    commission: x.assets.assetOtherCommoditiesComission,
                    instant: x.assets.assetOtherCommoditiesInstantLeverage,
                    oneStep: x.assets.assetOtherCommoditiesOneStepLeverage,
                    twoSteps: x.assets.assetOtherCommoditiesTwoStepsLeverage,
                    threeSteps: x.assets.assetOtherCommoditiesThreeStepsLeverage
                }].filter(e => e.enabled), h = [{
                    id: "firm-overview",
                    title: o("Firm Overview"),
                    component: e => (0, r.jsx)(W, { ...e,
                        firm: x
                    })
                }, {
                    id: "instruments",
                    title: o("Instruments and Assets"),
                    component: e => (0, r.jsx)(F, { ...e,
                        assets: p,
                        type: x.type
                    })
                }, {
                    id: "leverage",
                    title: o("Leverage"),
                    component: e => (0, r.jsx)(B, { ...e,
                        assets: p,
                        futuresLeverage: x.futures.futuresLeverage
                    })
                }, {
                    id: "commissions",
                    title: o("Commissions"),
                    component: e => (0, r.jsx)(E, { ...e,
                        assets: p,
                        futuresCommission: x.futures.futuresCommission
                    })
                }, {
                    id: "firm-rules",
                    title: o("Firm Rules"),
                    component: e => (0, r.jsx)(H, { ...e,
                        firmRules: x.firmRules
                    })
                }, {
                    id: "payout-policy",
                    title: o("Payout Policy"),
                    component: e => (0, r.jsx)(Z, { ...e,
                        payoutPolicy: x.payoutPolicy
                    })
                }], [v, g] = (0, f.useState)(null === (a = h[0]) || void 0 === a ? void 0 : a.id);
                return (0, r.jsxs)("div", {
                    className: "relative flex flex-col lg:flex-row gap-4 xl:gap-8 mb-20",
                    children: [(0, r.jsx)("nav", {
                        className: "bg-background sticky top-[6.25rem] lg:top-32 self-start flex flex-row lg:flex-col gap-4 w-full overflow-y-auto lg:w-48",
                        children: h.map(e => (0, r.jsxs)(f.Fragment, {
                            children: [(0, r.jsx)(N.YC, {
                                className: "hidden lg:block",
                                section: {
                                    id: e.id,
                                    name: e.title
                                },
                                activeSection: v,
                                setActiveSection: g
                            }), (0, r.jsx)(N.YC, {
                                className: "lg:hidden",
                                offset: -150,
                                section: {
                                    id: e.id,
                                    name: e.title
                                },
                                activeSection: v,
                                setActiveSection: g
                            })]
                        }, e.id))
                    }), (0, r.jsx)("div", {
                        className: "flex-1 flex flex-col",
                        children: h.map((e, a) => (0, r.jsx)(z.W_, {
                            name: e.id,
                            children: (0, r.jsxs)("div", {
                                children: [e.component && e.component({
                                    title: e.title
                                }), a < h.length - 1 && (0, r.jsx)(u.Separator, {
                                    className: "bg-border my-10"
                                })]
                            })
                        }, "".concat(e.id, "-element")))
                    }), (0, r.jsx)(u.Separator, {
                        className: "bg-border lg:hidden mt-4"
                    }), (null !== (t = m.data) && void 0 !== t ? t : []).length > 0 && (0, r.jsxs)("div", {
                        className: "pl-4 space-y-3 lg:w-[270px]",
                        children: [(0, r.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [(0, r.jsxs)("div", {
                                className: "flex items-center space-x-2.5",
                                children: [(0, r.jsx)(C.E2, {
                                    className: "w-5 h-5"
                                }), (0, r.jsx)("p", {
                                    className: "font-semibold leading-6",
                                    children: o("Announcements")
                                })]
                            }), (0, r.jsx)(S.zx, {
                                variant: "link",
                                onClick: () => {
                                    e.setActiveTab(l.announcements)
                                },
                                className: "px-0 text-sm text-primary-theme hover:underline",
                                children: o("See all")
                            })]
                        }), (0, r.jsx)("div", {
                            className: "flex flex-row lg:flex-col gap-3 overflow-x-auto",
                            children: m.data.map(e => (0, r.jsx)(i.a1, { ...e,
                                shortDate: !0,
                                hideImage: !0,
                                className: "rounded-lg min-w-[320px] lg:min-w-0 lg:w-full"
                            }, e.id))
                        })]
                    })]
                })
            }

            function J(e) {
                return (0, r.jsx)(f.Suspense, {
                    fallback: (0, r.jsx)(K, {}),
                    children: (0, r.jsx)(X, { ...e
                    })
                })
            }

            function Q() {
                return (0, r.jsxs)("div", {
                    className: "space-y-8",
                    children: [(0, r.jsx)(Y.O, {
                        className: "h-12 w-full md:w-4/5"
                    }), (0, r.jsx)(u.Separator, {}), (0, r.jsx)(Y.O, {
                        className: "w-full h-96"
                    })]
                })
            }! function(e) {
                e.instant = "instant", e.oneStep = "oneStep", e.twoSteps = "twoSteps", e.threeSteps = "threeSteps"
            }(t || (t = {}));
            var q = s(72172),
                ee = s(36022),
                ea = s(89309);

            function es(e) {
                var a;
                let {
                    t: s
                } = (0, n.$G)(), {
                    slug: t
                } = (0, x.useParams)(), [{
                    firm: l
                }] = d.trpc.firm.getDetailsPageData.useSuspenseQuery({
                    slug: t
                }), {
                    sorting: i,
                    onSortingChange: o
                } = (0, ea.r)(), [c] = d.trpc.promo.listAllFiltered.useSuspenseQuery({
                    filter: {
                        firmId: l.id
                    }
                }), u = (0, f.useMemo)(() => [{
                    value: "createdAt",
                    label: s("Recent"),
                    desc: !0
                }], [s]);
                return (0, r.jsxs)("div", {
                    className: "flex flex-col space-y-5",
                    children: [e.children, (0, r.jsx)(ee.j, {
                        count: c.count,
                        sorting: {
                            defaultValue: (null == i ? void 0 : null === (a = i[0]) || void 0 === a ? void 0 : a.id) ? {
                                value: i[0].id,
                                desc: i[0].desc
                            } : u[0],
                            options: u,
                            onSortingChange: o
                        },
                        itemsLabel: 1 === c.count ? s("Offer") : s("Offers")
                    }), (0, r.jsx)("div", {
                        children: (0, r.jsx)("div", {
                            className: "space-y-4 mb-12",
                            children: c.data.map(e => (0, r.jsx)(q.T, {
                                promo: e
                            }, e.id))
                        })
                    })]
                })
            }

            function et() {
                return (0, r.jsx)(f.Suspense, {
                    fallback: (0, r.jsx)(q.I, {}),
                    children: (0, r.jsx)(es, {})
                })
            }

            function el() {
                return (0, r.jsx)(et, {})
            }

            function er(e) {
                let {
                    t: a
                } = (0, n.$G)(), [s] = d.trpc.firm.getDetailsStats.useSuspenseQuery({
                    slug: e.slug
                }), t = (0, x.useRouter)(), f = (0, x.usePathname)(), [v, g] = (0, p.v1)("tab", h.z.nativeEnum(l).optional()), j = e => {
                    let a = new URLSearchParams;
                    a.set("tab", e), t.push("".concat(f, "?").concat(a.toString()))
                };
                return (0, r.jsx)(m.mQ, {
                    value: null != v ? v : "overview",
                    onValueChange: e => {
                        j(e)
                    },
                    children: (0, r.jsxs)("div", {
                        className: "space-y-4 lg:space-y-8",
                        children: [(0, r.jsxs)(m.dr, {
                            size: "lg",
                            variant: "buttonRounded",
                            className: "gap-4 space-x-0 max-w-full overflow-x-auto",
                            children: [(0, r.jsx)(m.SP, {
                                className: "px-5",
                                value: "overview",
                                children: a("Overview")
                            }), (0, r.jsx)(m.SP, {
                                className: "px-5",
                                value: "challenges",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [(0, r.jsx)("p", {
                                        children: a("Challenges")
                                    }), (0, r.jsx)(c.C, {
                                        rounded: "full",
                                        variant: "yellowHighlight",
                                        size: "chipsXs",
                                        children: s.challengesCount
                                    })]
                                })
                            }), (0, r.jsx)(m.SP, {
                                className: "px-5",
                                value: "reviews",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [(0, r.jsx)("p", {
                                        children: a("Reviews")
                                    }), (0, r.jsx)(c.C, {
                                        rounded: "full",
                                        variant: "yellowHighlight",
                                        size: "chipsXs",
                                        children: s.reviewsCount
                                    })]
                                })
                            }), (0, r.jsx)(m.SP, {
                                className: "px-5",
                                value: "offers",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [(0, r.jsx)("p", {
                                        children: a("Offers")
                                    }), (0, r.jsx)(c.C, {
                                        rounded: "full",
                                        variant: "yellowHighlight",
                                        size: "chipsXs",
                                        children: s.promosCount
                                    })]
                                })
                            }), (0, r.jsx)(m.SP, {
                                className: "px-5",
                                value: "announcements",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [(0, r.jsx)("p", {
                                        children: a("Announcements")
                                    }), (0, r.jsx)(c.C, {
                                        rounded: "full",
                                        variant: "yellowHighlight",
                                        size: "chipsXs",
                                        children: s.announcementsCount
                                    })]
                                })
                            }), (0, r.jsx)(m.SP, {
                                disabled: !0,
                                className: "px-5 bg-background-secondary text-foreground-disabled hover:bg-background-secondary",
                                value: "payouts",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center gap-0.5 sm:gap-2",
                                    children: [(0, r.jsx)("p", {
                                        children: a("Payouts")
                                    }), (0, r.jsx)(c.C, {
                                        rounded: "full",
                                        variant: "greenDark",
                                        className: "text-xxs sm:text-xs px-2 whitespace-nowrap text-foreground-secondary",
                                        children: a("Coming Soon")
                                    })]
                                })
                            })]
                        }), (0, r.jsx)(u.Separator, {
                            className: "hidden lg:block bg-border"
                        }), (0, r.jsx)(m.nU, {
                            value: "overview",
                            children: (0, r.jsx)(J, {
                                slug: e.slug,
                                setActiveTab: g
                            })
                        }), (0, r.jsx)(m.nU, {
                            value: "challenges",
                            children: (0, r.jsx)(b, {
                                slug: e.slug
                            })
                        }), (0, r.jsx)(m.nU, {
                            value: "reviews",
                            children: (0, r.jsx)(o.jK, {})
                        }), (0, r.jsx)(m.nU, {
                            value: "offers",
                            children: (0, r.jsx)(el, {})
                        }), (0, r.jsx)(m.nU, {
                            value: "announcements",
                            children: (0, r.jsx)(i.w8, {
                                hideSearch: !0,
                                firmSlug: e.slug
                            })
                        }), (0, r.jsx)(m.nU, {
                            value: "payouts"
                        })]
                    })
                })
            }

            function en(e) {
                return (0, r.jsx)(f.Suspense, {
                    fallback: (0, r.jsx)(Q, {}),
                    children: (0, r.jsx)(er, {
                        slug: e.slug
                    })
                })
            }! function(e) {
                e.overview = "overview", e.challenges = "challenges", e.reviews = "reviews", e.offers = "offers", e.announcements = "announcements", e.payouts = "payouts"
            }(l || (l = {}))
        },
        68944: (e, a, s) => {
            s.d(a, {
                rr: () => t.FirmDetailsTabsEnum
            }), s(3161);
            var t = s(77903)
        },
        42815: (e, a, s) => {
            s.r(a), s.d(a, {
                FirmLogo: () => c,
                firmLogoVariants: () => d
            });
            var t = s(12428),
                l = s(24040),
                r = s(95805),
                n = s(43748),
                i = s(62993),
                o = s(32029);
            let d = (0, s(51699).j)("bg-background-secondary border border-border-disabled relative flex-none flex items-center justify-center", {
                variants: {
                    size: {
                        default: "w-12 h-12",
                        xs: "w-6 h-6",
                        sm: "w-8 h-8",
                        md: "w-10 h-10",
                        lg: "w-16 h-16",
                        xl: "w-[72px] h-[72px]",
                        "2xl": "min-w-[100px] w-[100px] h-[100px]",
                        "3xl": "min-w-[110px] w-[110px] h-[110px]"
                    },
                    rounded: {
                        default: "rounded-lg",
                        full: "rounded-full"
                    }
                },
                defaultVariants: {
                    size: "default",
                    rounded: "default"
                }
            });

            function c(e) {
                var a, s;
                let {
                    className: c,
                    rounded: u,
                    showRank: m = !1,
                    size: x,
                    ...p
                } = e, f = null !== (a = p.firm.logoBackgroundColor) && void 0 !== a ? a : o.Dp, {
                    getFileReadUrl: h
                } = (0, l.lA)();
                return (0, t.jsxs)("div", {
                    className: (0, i.cn)(d({
                        size: x,
                        rounded: u,
                        className: c
                    })),
                    style: {
                        backgroundColor: "rgba(".concat(f.r, ", ").concat(f.g, ", ").concat(f.b, ", ").concat(f.a, ")")
                    },
                    children: [p.firm.rank && m ? (0, t.jsx)("div", {
                        className: "absolute left-[-10px] top-[-10px] rounded-full",
                        children: (0, t.jsx)(n.G7, {
                            variant: "pfmDarkOutline",
                            className: "size-5 p-[1.33px]",
                            children: (0, t.jsx)(n.MB, {
                                className: "text-xs font-semibold",
                                children: p.firm.rank
                            })
                        })
                    }) : null, p.firm.logo ? (0, t.jsx)("img", {
                        src: h(p.firm.logo),
                        alt: null !== (s = p.firm.logoAltText) && void 0 !== s ? s : "Logo",
                        className: "w-8/12 object-contain"
                    }) : (0, t.jsx)(r.Avatar, {
                        className: "size-10",
                        children: (0, t.jsx)(r.Q, {
                            title: p.firm.name,
                            children: p.firm.name.substring(0, 2)
                        })
                    })]
                })
            }
        },
        69615: (e, a, s) => {
            s.d(a, {
                y0: () => S,
                mA: () => f,
                wK: () => m.FirmLogo,
                bD: () => r,
                ou: () => R,
                $8: () => w,
                uq: () => x
            });
            var t = s(12428),
                l = s(40045);

            function r(e) {
                var a;
                return (null === (a = e.firm.preferredPromo) || void 0 === a ? void 0 : a.promo) ? (0, t.jsx)("div", {
                    children: (0, t.jsx)(l.OfferPromo, {
                        offer: { ...e.firm.preferredPromo.promo,
                            firm: e.firm
                        }
                    })
                }) : null
            }
            var n = s(5313);

            function i(e) {
                return (0, t.jsxs)("div", {
                    className: "flex items-center space-x-1 text-primary-theme",
                    children: [(0, t.jsx)(n.h_, {
                        className: "stroke-primary-theme text-transparent size-4"
                    }), (0, t.jsx)("span", {
                        className: "text-xs",
                        children: e.count
                    })]
                })
            }
            var o = s(83352),
                d = s(62993),
                c = s(51699),
                u = s(3934),
                m = s(42815);
            let x = (0, c.j)("font-semibold", {
                    variants: {
                        size: {
                            default: "text-sm",
                            lg: "text-base",
                            xl: "text-xl",
                            "2xl": "text-2xl",
                            "3xl": "text-3xl"
                        }
                    },
                    defaultVariants: {
                        size: "default"
                    }
                }),
                p = (0, c.j)("space-x-2", {
                    variants: {
                        size: {
                            default: "",
                            lg: "",
                            xl: "",
                            "2xl": "space-x-4",
                            "3xl": "space-x-4"
                        }
                    },
                    defaultVariants: {
                        size: "default"
                    }
                });

            function f(e) {
                var a, s, l, r, n;
                let c = e.nameUrl,
                    f = null != c ? c : "/prop-firms/".concat(null !== (a = e.firm.slug) && void 0 !== a ? a : "");
                return (0, t.jsxs)("div", {
                    className: p({
                        size: e.size,
                        className: (0, d.cn)("flex items-center", e.className)
                    }),
                    children: [(0, t.jsx)(u.default, {
                        href: f,
                        target: e.linkTarget,
                        children: (0, t.jsx)(m.FirmLogo, {
                            firm: e.firm,
                            size: e.size
                        })
                    }), (0, t.jsxs)("div", {
                        className: "space-y-1.5",
                        children: [(0, t.jsxs)("div", {
                            className: "flex space-x-1.5",
                            children: [null !== (r = e.nameSlot) && void 0 !== r ? r : (0, t.jsx)(o.o3, {
                                maxWidth: null !== (s = e.maxWidth) && void 0 !== s ? s : "2xs",
                                children: (0, t.jsx)(u.default, {
                                    href: f,
                                    target: e.linkTarget,
                                    children: (0, t.jsx)("p", {
                                        className: x({
                                            size: null !== (l = e.textSize) && void 0 !== l ? l : e.size,
                                            className: "hover:underline"
                                        }),
                                        children: e.firm.name
                                    })
                                })
                            }), e.favoriteSlot]
                        }), void 0 === e.firm.likesCount || null === e.firm.likesCount || e.hideLikesCount ? null : (0, t.jsx)(i, {
                            count: null !== (n = e.firm.likesCount) && void 0 !== n ? n : 0
                        }), e.children ? e.children : null]
                    })]
                })
            }
            var h = s(34719);

            function v(e) {
                return (0, t.jsx)("button", {
                    onClick: () => e.onToggle(!e.isBookmarked),
                    className: "flex items-center justify-center",
                    children: e.isBookmarked ? (0, t.jsx)(n.ce, {}) : (0, t.jsx)(n.pl, {})
                })
            }
            var g = s(45253);

            function j(e) {
                var a;
                return e.onToggleBookmarked && (0, t.jsx)(v, {
                    isBookmarked: null !== (a = e.isBookmarked) && void 0 !== a && a,
                    onToggle: e.onToggleBookmarked
                })
            }

            function b(e) {
                return (0, t.jsx)(u.default, {
                    href: "/prop-firms/".concat(e.firm.slug),
                    children: (0, t.jsx)(o.o3, {
                        maxWidth: "2xs",
                        children: (0, t.jsx)("p", {
                            className: "text-xs md:text-sm font-semibold",
                            children: e.firm.name
                        })
                    })
                })
            }

            function y(e) {
                var a, s;
                return (0, t.jsxs)("div", {
                    className: "space-y-0.5",
                    children: [(0, t.jsx)(b, {
                        firm: e.firm
                    }), e.firm.reviewsCount < h.nu ? (0, t.jsx)(h.YO, {}) : (0, t.jsx)(g.$, {
                        reviewScore: null !== (a = e.firm.reviewScore) && void 0 !== a ? a : 0,
                        reviews: null !== (s = e.firm.reviewsCount) && void 0 !== s ? s : 0
                    })]
                })
            }

            function N(e) {
                return (0, t.jsx)("div", {
                    className: "border-b border-dashed",
                    children: (0, t.jsx)(b, {
                        firm: e.firm
                    })
                })
            }

            function w(e) {
                return e.minifiedOnMobile ? (0, t.jsxs)("div", {
                    className: (0, d.cn)("flex items-center space-x-2", e.className),
                    children: [(0, t.jsx)(u.default, {
                        href: "/prop-firms/".concat(e.firm.slug),
                        children: (0, t.jsx)(m.FirmLogo, {
                            firm: e.firm,
                            showRank: e.showRank
                        })
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col md:flex-row items-start gap-1",
                        children: [(0, t.jsx)("div", {
                            className: "hidden md:block",
                            children: (0, t.jsx)(y, { ...e
                            })
                        }), (0, t.jsx)("div", {
                            className: "md:hidden",
                            children: (0, t.jsx)(N, { ...e
                            })
                        }), (0, t.jsx)(j, {
                            isBookmarked: e.isBookmarked,
                            onToggleBookmarked: e.onToggleBookmarked
                        })]
                    })]
                }) : (0, t.jsxs)("div", {
                    className: (0, d.cn)("flex items-center space-x-2", e.className),
                    children: [(0, t.jsx)(u.default, {
                        href: "/prop-firms/".concat(e.firm.slug),
                        children: (0, t.jsx)(m.FirmLogo, {
                            firm: e.firm,
                            showRank: e.showRank
                        })
                    }), (0, t.jsx)(y, { ...e
                    })]
                })
            }

            function S(e) {
                return (0, t.jsx)("div", {
                    className: (0, d.cn)("p-3 md:p-5 border border-border-secondary rounded-2xl flex items-center justify-between bg-background-primary", e.className),
                    children: e.children
                })
            }
            var C = s(6185),
                z = s(98661),
                k = s(5178);

            function R(e) {
                let {
                    value: a,
                    onChange: s
                } = e, l = (0, z.mM)(), {
                    t: r
                } = (0, C.$G)();
                return (0, t.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, t.jsx)(k._P, {
                        type: "single",
                        labels: {
                            placeholder: r("Search"),
                            emptyResult: r("No firms found"),
                            searchPlaceholder: r("Search for a firm")
                        },
                        value: a,
                        config: {
                            baseUrl: l.NEXT_PUBLIC_WEBSITE_URL
                        },
                        onChange: s
                    }), (0, t.jsx)(k.Tz, {
                        itemsCount: 6,
                        type: "single",
                        value: a,
                        config: {
                            baseUrl: l.NEXT_PUBLIC_WEBSITE_URL
                        },
                        onChange: s
                    })]
                })
            }
        },
        70935: (e, a, s) => {
            s.d(a, {
                u: () => f
            });
            var t = s(12428),
                l = s(79859),
                r = s(92006),
                n = s(51699),
                i = s(93264),
                o = s(62993);
            let d = (0, n.j)("flex items-center justify-between space-x-2", {
                    variants: {
                        type: {
                            default: ""
                        }
                    },
                    defaultVariants: {
                        type: "default"
                    }
                }),
                c = (0, n.j)("", {
                    variants: {
                        color: {
                            default: "bg-primary-theme",
                            purple: "bg-purple-theme",
                            inactive: "bg-border"
                        }
                    },
                    defaultVariants: {
                        color: "default"
                    }
                }),
                u = (0, i.forwardRef)((e, a) => {
                    let {
                        className: s,
                        type: l,
                        current: r,
                        total: n,
                        interactive: i,
                        onStepChange: u,
                        stepVariant: m = "default",
                        ...x
                    } = e, p = Array.from({
                        length: n
                    }, (e, a) => ({
                        value: a + 1,
                        active: a + 1 <= r
                    }));
                    return (0, t.jsx)("div", {
                        ref: a,
                        ...x,
                        className: d({
                            type: l,
                            className: s
                        }),
                        children: p.map(e => (0, t.jsx)("div", {
                            className: (0, o.cn)('flex-1 h-1 rounded-full relative before:content-[""] before:absolute before:-top-1 before:-bottom-1 before:w-full', c({
                                color: e.active ? m : "inactive"
                            }), i && "cursor-pointer"),
                            onClick: i ? () => u(e.value) : void 0
                        }, e.value))
                    })
                });
            u.displayName = "StepsProgress";
            var m = s(56360),
                x = s(95262),
                p = s(95289);

            function f(e, a, s) {
                let n = (0, i.createContext)(void 0),
                    o = () => {
                        let e = (0, i.useContext)(n);
                        if (!e) throw Error("useMultiStepContext must be used within a MultiStepForm");
                        return e
                    },
                    d = (0, i.forwardRef)((o, d) => {
                        let {
                            children: c,
                            defaultStep: u,
                            defaultValue: m,
                            onSubmit: x
                        } = o, f = (0, p.cI)({
                            resolver: (0, l.F)(e),
                            defaultValues: m,
                            mode: "onBlur"
                        }), [h, v] = (0, i.useState)(u), g = f.watch(), j = (0, i.useMemo)(() => a.reduce((e, a) => (e[a] = s[a](g), e), {}), [g]);
                        (0, i.useImperativeHandle)(d, () => ({
                            form: f,
                            setCurrentStep: v
                        }));
                        let b = (0, i.useRef)(h),
                            y = (0, i.useMemo)(() => {
                                let e = a.indexOf(b.current),
                                    s = a.indexOf(h);
                                return (b.current = h, e >= s) ? "right" : "left"
                            }, [h]),
                            N = a[a.indexOf(h) + 1],
                            w = a[a.indexOf(h) - 1];
                        return (0, t.jsx)(n.Provider, {
                            value: {
                                form: f,
                                schema: e,
                                steps: a,
                                currentStep: h,
                                setCurrentStep: v,
                                setNextStep: () => {
                                    v(N || h), window.scrollTo(0, 0)
                                },
                                setPreviousStep: () => v(w || h),
                                completedSteps: j,
                                direction: y
                            },
                            children: (0, t.jsx)(r.l0, { ...f,
                                children: (0, t.jsx)("form", {
                                    onSubmit: f.handleSubmit(x),
                                    children: c
                                })
                            })
                        })
                    });

                function c(e) {
                    let {
                        children: a
                    } = e, {
                        direction: s
                    } = o();
                    return (0, t.jsx)(m.E.div, {
                        className: "top-0",
                        exit: {
                            opacity: 0,
                            position: "absolute",
                            translateX: "left" === s ? "-25%" : "25%"
                        },
                        initial: {
                            opacity: 0,
                            position: "relative",
                            translateX: "left" === s ? "25%" : "-25%"
                        },
                        transition: {
                            duration: .3
                        },
                        animate: {
                            translateX: 0,
                            opacity: 1
                        },
                        children: a
                    })
                }
                return d.displayName = "FormWrapper", {
                    FormWrapper: d,
                    useMultiStepContext: o,
                    Progress: function() {
                        let {
                            stepVariant: e
                        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, {
                            steps: a,
                            currentStep: s
                        } = o();
                        return (0, t.jsx)(u, {
                            total: a.length,
                            current: a.indexOf(s) + 1,
                            stepVariant: e
                        })
                    },
                    Step: function(e) {
                        let {
                            children: a,
                            name: s
                        } = e, {
                            currentStep: l
                        } = o();
                        return (0, t.jsx)(x.M, {
                            children: l === s && (0, t.jsx)(c, {
                                children: a
                            })
                        })
                    },
                    StepsWrapper: function(e) {
                        let {
                            children: a
                        } = e;
                        return (0, t.jsx)("div", {
                            className: "relative",
                            children: a
                        })
                    },
                    steps: a
                }
            }
        },
        77838: (e, a, s) => {
            s.d(a, {
                k: () => l
            });
            var t = s(35022);

            function l(e, a) {
                let [s, l] = (0, t.v1)("filters", (0, t.WJ)(e.parse).withDefault(null != a ? a : {}));
                return {
                    filtersState: s,
                    setFiltersState: l
                }
            }
        },
        28422: (e, a, s) => {
            s.d(a, {
                C1: () => K,
                U2: () => c,
                OO: () => X,
                tf: () => H,
                Gp: () => eo,
                zP: () => ed,
                F_: () => A,
                ew: () => en,
                SY: () => el,
                De: () => er,
                _t: () => et,
                Vs: () => ec,
                Yr: () => u,
                kV: () => i,
                rV: () => m,
                i2: () => D,
                On: () => h,
                N_: () => L
            });
            var t = s(12428),
                l = s(88785),
                r = s(95289),
                n = s(62993);
            let i = e => {
                let {
                    options: a,
                    renderItem: s,
                    containerClassName: i,
                    ...o
                } = e;
                return { ...o,
                    render: e => (0, t.jsx)("div", {
                        className: "flex flex-col space-y-4",
                        children: a.map(a => (0, t.jsx)(r.Qr, {
                            name: o.name,
                            control: e,
                            render: e => {
                                var r;
                                let {
                                    field: o
                                } = e;
                                return (0, t.jsxs)("label", {
                                    htmlFor: a.value,
                                    className: (0, n.cn)("flex space-x-2 items-center cursor-pointer", i),
                                    children: [(0, t.jsx)(l.X, {
                                        id: a.value,
                                        variant: "monochrome",
                                        checked: null === (r = o.value) || void 0 === r ? void 0 : r.includes(a.value),
                                        onCheckedChange: e => {
                                            var s;
                                            let t = e ? [...o.value || [], a.value] : (null === (s = o.value) || void 0 === s ? void 0 : s.filter(e => e !== a.value)) || [];
                                            o.onChange(t)
                                        }
                                    }), s(a)]
                                })
                            }
                        }, a.value))
                    })
                }
            };
            var o = s(43692),
                d = s(93264);

            function c(e) {
                var a, s, l, r, n, i, d, c, u, m;
                let x = null !== (d = e.sliderProps.min) && void 0 !== d ? d : 0,
                    p = null !== (c = e.sliderProps.max) && void 0 !== c ? c : 1 / 0,
                    f = (null === (a = e.value) || void 0 === a ? void 0 : a[0]) ? Math.min(Math.max(null === (s = e.value) || void 0 === s ? void 0 : s[0], x), p) : x,
                    h = (null === (l = e.value) || void 0 === l ? void 0 : l[1]) ? Math.max(Math.min(null === (r = e.value) || void 0 === r ? void 0 : r[1], p), x) : p;
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-y-2 pt-1",
                    children: [e.label && (0, t.jsx)("span", {
                        children: e.label
                    }), (0, t.jsx)(o.i, {
                        variant: "white",
                        thumb: "white",
                        thumbSize: "xs",
                        trackSize: "sm",
                        ...e.sliderProps,
                        isDual: !0,
                        value: [f, h],
                        onValueChange: e.onChange
                    }), (0, t.jsxs)("div", {
                        className: "flex justify-between text-sm font-semibold",
                        children: [(0, t.jsx)("span", {
                            children: null !== (u = null === (n = e.labelTransformer) || void 0 === n ? void 0 : n.call(e, f)) && void 0 !== u ? u : f
                        }), (0, t.jsx)("span", {
                            children: null !== (m = null === (i = e.labelTransformer) || void 0 === i ? void 0 : i.call(e, h)) && void 0 !== m ? m : h
                        })]
                    })]
                })
            }

            function u(e) {
                var a, s, l, r, n, i, d, c, u, m;
                let x = null !== (d = e.sliderProps.min) && void 0 !== d ? d : 0,
                    p = null !== (c = e.sliderProps.max) && void 0 !== c ? c : 1 / 0,
                    f = (null === (a = e.value) || void 0 === a ? void 0 : a[0]) ? Math.min(Math.max(null === (s = e.value) || void 0 === s ? void 0 : s[0], x), p) : x,
                    h = (null === (l = e.value) || void 0 === l ? void 0 : l[1]) ? Math.max(Math.min(null === (r = e.value) || void 0 === r ? void 0 : r[1], p), x) : p;
                return (0, t.jsxs)("div", {
                    className: "flex flex-col",
                    children: [e.label && (0, t.jsx)("span", {
                        className: "text-xs text-foreground-secondary",
                        children: e.label
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-row min-w-[242px] gap-2 font-semibold text-xs",
                        children: [(0, t.jsx)("span", {
                            children: null !== (u = null === (n = e.labelTransformer) || void 0 === n ? void 0 : n.call(e, f)) && void 0 !== u ? u : f
                        }), (0, t.jsx)(o.i, {
                            variant: "white",
                            thumb: "white",
                            thumbSize: "xs",
                            trackSize: "sm",
                            ...e.sliderProps,
                            isDual: !0,
                            value: [f, h],
                            onValueChange: e.onChange
                        }), (0, t.jsx)("span", {
                            children: null !== (m = null === (i = e.labelTransformer) || void 0 === i ? void 0 : i.call(e, h)) && void 0 !== m ? m : h
                        })]
                    })]
                })
            }
            let m = e => {
                let {
                    sliderProps: a,
                    label: s,
                    labelTransformer: l,
                    asChild: n,
                    ...i
                } = e;
                return { ...i,
                    ...n ? {} : {
                        label: s
                    },
                    render: e => (0, t.jsx)(r.Qr, {
                        control: e,
                        name: i.name,
                        render: e => {
                            let {
                                field: r
                            } = e;
                            return (0, t.jsx)(c, {
                                value: r.value,
                                onChange: r.onChange,
                                sliderProps: a,
                                label: n ? s : null,
                                labelTransformer: l
                            })
                        }
                    })
                }
            };
            var x = s(48842),
                p = s(52467),
                f = s(6185);
            let h = e => {
                let {
                    options: a,
                    multiple: s = !0,
                    ...l
                } = e;
                return { ...l,
                    render: e => (0, t.jsx)(r.Qr, {
                        name: l.name,
                        control: e,
                        render: e => {
                            let {
                                field: l
                            } = e, r = (0, d.useMemo)(() => {
                                var e, a;
                                return s ? {
                                    onValueChange: l.onChange,
                                    type: "multiple",
                                    value: null !== (e = l.value) && void 0 !== e ? e : []
                                } : {
                                    onValueChange: l.onChange,
                                    type: "single",
                                    value: null !== (a = l.value) && void 0 !== a ? a : ""
                                }
                            }, [l.onChange, l.value]), {
                                t: n
                            } = (0, f.$G)(), i = a.some(e => e.secondary), [o, c] = (0, d.useState)(!!i && a.some(e => {
                                var a;
                                return e.secondary && (s ? null === (a = l.value) || void 0 === a ? void 0 : a.includes(e.value) : l.value === e.value)
                            }));
                            return (0, t.jsx)(x.t, { ...r,
                                className: "justify-start",
                                children: (0, t.jsxs)("div", {
                                    className: "flex flex-wrap gap-2",
                                    children: [null == a ? void 0 : a.filter(e => !!o || !e.secondary).map(e => {
                                        let {
                                            label: a,
                                            value: s
                                        } = e;
                                        return (0, t.jsx)(x.G, {
                                            value: s,
                                            size: "xs",
                                            variant: "filterPill",
                                            children: (0, t.jsx)("p", {
                                                children: a
                                            })
                                        }, s)
                                    }), i && !o && (0, t.jsx)("button", {
                                        className: (0, p.E)({
                                            size: "xs",
                                            className: "text-primary-theme"
                                        }),
                                        onClick: () => c(!0),
                                        "aria-label": n("Show more filter options"),
                                        "aria-expanded": o,
                                        children: n("Show More")
                                    })]
                                })
                            })
                        }
                    })
                }
            };
            var v = s(2691),
                g = s(40850),
                j = s(92006),
                b = s(35022),
                y = s(95772),
                N = s(79859);

            function w(e) {
                let a = (0, r.cI)({
                    resolver: (0, N.F)(e.filters.schema),
                    defaultValues: e.filtersState
                });
                return a.watch(), (0, d.useEffect)(() => {
                    if (!e.setFiltersState) return;
                    let s = a.watch(e.setFiltersState);
                    return () => s.unsubscribe()
                }, [a, e.setFiltersState]), (0, d.useEffect)(() => {
                    JSON.stringify(a.getValues()) !== JSON.stringify(e.filtersState) && a.reset(e.filtersState, {
                        keepDefaultValues: !0
                    })
                }, [e.filtersState]), a
            }
            var S = s(44538),
                C = s(25845);
            let z = y.z.boolean().optional(),
                k = y.z.array(y.z.string()).optional(),
                R = () => {
                    let [e, a] = (0, b.v1)("extendedFilters", (0, b.WJ)(z.parse).withDefault(!1)), [s, t] = (0, b.v1)("filtersShown", (0, b.WJ)(k.parse).withDefault([]));
                    return {
                        isExtendedFiltersOpen: e,
                        setExtendedFiltersOpen: a,
                        accordionValues: s,
                        setAccordionValues: t
                    }
                },
                P = e => {
                    let {
                        value: a,
                        label: s,
                        children: l,
                        className: r
                    } = e;
                    return (0, t.jsxs)(v.Qd, {
                        value: a,
                        children: [s && (0, t.jsx)(v.o4, {
                            className: (0, n.cn)("md:px-1 font-semibold hover:no-underline md:text-base text-sm", r),
                            chevronClassName: "stroke-foreground-secondary md:size-4 size-3.5",
                            children: s
                        }), (0, t.jsx)(v.vF, {
                            className: (0, n.cn)("px-1 pt-1", !s && "pt-4"),
                            children: l
                        })]
                    })
                };

            function T(e) {
                let {
                    filterOptions: a,
                    className: s,
                    isResetButton: l = !0
                } = e, {
                    t: r
                } = (0, f.$G)(), {
                    filters: i,
                    setFiltersState: o
                } = a, d = w(a), {
                    accordionValues: c,
                    setAccordionValues: u,
                    setExtendedFiltersOpen: m
                } = R();
                return (0, t.jsxs)(j.l0, { ...d,
                    children: [(0, t.jsx)("form", {
                        className: (0, n.cn)(s),
                        children: (0, t.jsx)(v.UQ, {
                            defaultValue: i.options.filter(e => {
                                let {
                                    name: a,
                                    label: s
                                } = e;
                                return c.includes(a) || !s
                            }).map(e => {
                                let {
                                    name: a
                                } = e;
                                return a
                            }),
                            onValueChange: u,
                            type: "multiple",
                            className: "w-full",
                            children: i.options.map(e => (0, t.jsx)(P, {
                                value: e.name,
                                label: e.label,
                                className: e.labelClassName,
                                children: e.render(d.control)
                            }, e.name))
                        })
                    }), (0, t.jsx)("div", {
                        className: "flex items-center md:justify-center justify-between md:mt-2 mt-5 md:px-0 px-2 md:gap-0 gap-4",
                        children: l && (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)(g.zx, {
                                type: "button",
                                variant: "pfmLink",
                                className: "md:inline-block hidden",
                                onClick: () => {
                                    o({}), d.reset({})
                                },
                                children: r("Reset filter")
                            }), (0, t.jsx)(g.zx, {
                                type: "button",
                                variant: "darkOutline",
                                className: "md:hidden inline-block rounded-full flex-1",
                                onClick: () => {
                                    o({}), d.reset({})
                                },
                                children: r("Reset filter")
                            }), (0, t.jsx)(g.zx, {
                                type: "button",
                                variant: "pfmGradient",
                                className: "md:hidden inline-block rounded-full flex-1",
                                onClick: () => {
                                    m(!1)
                                },
                                children: r("Apply")
                            })]
                        })
                    })]
                })
            }

            function F(e) {
                let {
                    children: a,
                    ...s
                } = e, {
                    t: l
                } = (0, f.$G)();
                return (0, t.jsx)(S.dy, {
                    open: s.open,
                    onOpenChange: s.onOpenChange,
                    children: (0, t.jsxs)(S.sc, {
                        className: "px-4 py-5 [&>div:first-child]:hidden",
                        children: [(0, t.jsxs)(S.OX, {
                            className: "flex items-center justify-between px-2 pt-0 pb-2 text-lg [&>h2]:leading-[27px]",
                            children: [(0, t.jsx)(S.iI, {
                                children: l("Filters")
                            }), (0, t.jsx)(S.u6, {
                                className: "sr-only",
                                children: l("Apply filters")
                            }), (0, t.jsx)(S.uh, {
                                children: (0, t.jsx)(C.Z, {
                                    className: "size-5"
                                })
                            })]
                        }), a]
                    })
                })
            }

            function A(e) {
                let {
                    filtersHookResult: a,
                    isResetButton: s = !0,
                    classNameWrapper: l,
                    className: r,
                    children: i
                } = e, {
                    isExtendedFiltersOpen: o,
                    setExtendedFiltersOpen: c
                } = R(), [u, m] = (0, d.useState)(window.innerWidth < 768);
                return (0, d.useEffect)(() => {
                    let e = () => {
                        m(!!window && window.innerWidth < 768)
                    };
                    return window && window.addEventListener("resize", e), () => {
                        window && window.removeEventListener("resize", e)
                    }
                }, []), (0, t.jsx)("div", {
                    className: "flex flex-col gap-12",
                    children: (0, t.jsxs)("div", {
                        className: (0, n.cn)("flex", l),
                        children: [a && (!u && o ? (0, t.jsx)("div", {
                            className: "md:w-80 border-r pr-5 mr-3",
                            children: (0, t.jsx)(T, {
                                filterOptions: a,
                                isResetButton: s
                            })
                        }) : (0, t.jsx)(F, {
                            onOpenChange: c,
                            open: !!(o && a),
                            children: (0, t.jsx)(T, {
                                className: "overflow-y-auto max-h-[70vh]",
                                filterOptions: a,
                                isResetButton: s
                            })
                        })), (0, t.jsx)("div", {
                            className: (0, n.cn)("flex-1 overflow-x-auto", r),
                            children: i
                        })]
                    })
                })
            }
            var O = s(69615),
                M = s(85473),
                E = s(83352);

            function L(e) {
                var a, s;
                let [l] = M.trpc.firm.listAll.useSuspenseQuery({
                    limit: 100
                });
                return i({
                    name: e.name,
                    label: e.label,
                    options: null !== (s = null === (a = l.data || []) || void 0 === a ? void 0 : a.map(e => ({
                        value: e.id,
                        ...e
                    }))) && void 0 !== s ? s : [],
                    renderItem: e => (0, t.jsxs)("div", {
                        className: "flex space-x-2.5 items-center",
                        children: [(0, t.jsx)(O.wK, {
                            firm: e,
                            className: "w-8 h-8"
                        }), (0, t.jsx)("div", {
                            className: "space-y-1.5",
                            children: (0, t.jsx)("div", {
                                className: "flex space-x-1.5",
                                children: (0, t.jsx)(E.o3, {
                                    maxWidth: "2xs",
                                    children: (0, t.jsx)("p", {
                                        className: "text-base font-semibold",
                                        children: e.name
                                    })
                                })
                            })
                        })]
                    })
                })
            }
            var I = s(6536);
            let D = e => {
                let {
                    options: a,
                    ...s
                } = e;
                return { ...s,
                    render: e => (0, t.jsx)(r.Qr, {
                        name: s.name,
                        control: e,
                        render: e => {
                            var s;
                            let {
                                field: l
                            } = e;
                            return (0, t.jsxs)(I.Select, {
                                value: null !== (s = l.value) && void 0 !== s ? s : "",
                                onValueChange: e => l.onChange(e),
                                children: [(0, t.jsx)(I.SelectTrigger, {
                                    children: (0, t.jsx)(I.SelectValue, {})
                                }), (0, t.jsx)(I.SelectContent, {
                                    children: a.map(e => (0, t.jsx)(I.SelectItem, {
                                        value: e.value,
                                        children: e.label
                                    }, e.value))
                                })]
                            })
                        }
                    })
                }
            };
            var _ = s(7986),
                G = s(20533),
                B = s(31434),
                U = s(41868),
                V = s(13920),
                $ = s(24080),
                W = s(30455),
                Z = s(43220);

            function H(e) {
                var a;
                let {
                    columns: s,
                    data: l,
                    noDataPlaceholder: r,
                    sorting: i,
                    setSorting: o = () => {},
                    rowCount: c,
                    pagination: u,
                    setPagination: m = () => {},
                    expanded: x,
                    setExpanded: p = () => {},
                    columnVisibility: h = {},
                    setColumnVisibility: v = () => {},
                    enableHiding: j = !1,
                    enableColumnPinning: b = !0,
                    columnPinning: y = {},
                    pinFirstColumn: N = !1,
                    pinLastColumn: w = !1,
                    enableMultiSort: S = !1,
                    withCellSeparators: C = !0,
                    headerClassName: z
                } = e, k = (0, d.useRef)(null), P = (0, d.useRef)(null), T = (0, d.useRef)(null), F = (0, d.useRef)(null), [A, O] = (0, d.useState)(!1), [M, E] = (0, d.useState)(!1), {
                    isExtendedFiltersOpen: L
                } = R(), I = (0, d.useCallback)(() => {
                    if (N && k.current && P.current) {
                        let [e, a] = [k.current.getBoundingClientRect(), P.current.getBoundingClientRect()];
                        O(e.right - 1 > a.left)
                    }
                    if (w && F.current && T.current) {
                        let [e, a] = [F.current.getBoundingClientRect(), T.current.getBoundingClientRect()];
                        E(a.left + 1 < e.right)
                    }
                }, [L, N, w]);
                (0, d.useEffect)(() => {
                    I()
                }, [I]);
                let D = (0, d.useCallback)(() => {
                        I()
                    }, [I]),
                    G = (e, a) => {
                        switch (e) {
                            case 0:
                                return k;
                            case 1:
                                return P;
                            case a - 2:
                                return F;
                            case a - 1:
                                return T;
                            default:
                                return null
                        }
                    },
                    H = (0, U.b7)({
                        data: l,
                        columns: s,
                        rowCount: c,
                        getCoreRowModel: (0, V.sC)(),
                        getExpandedRowModel: (0, V.rV)(),
                        manualSorting: !0,
                        onSortingChange: e => {
                            o(e instanceof Function && i ? e(i) : e)
                        },
                        manualPagination: !0,
                        sortDescFirst: !1,
                        onPaginationChange: e => {
                            m(e instanceof Function && u ? e(u) : e)
                        },
                        onColumnVisibilityChange: v,
                        onExpandedChange: p,
                        isMultiSortEvent: () => S,
                        enableHiding: j,
                        state: {
                            sorting: i,
                            pagination: u,
                            columnVisibility: h,
                            expanded: x,
                            columnPinning: y
                        },
                        enableColumnPinning: b
                    }),
                    {
                        t: K
                    } = (0, f.$G)();
                w || (w = L);
                let X = !(null === (a = H.getRowModel().rows) || void 0 === a ? void 0 : a.length);
                return (0, t.jsxs)("div", {
                    className: (0, n.cn)("flex flex-col gap-12", X && "h-full"),
                    children: [X ? r || K("No results.") : (0, t.jsxs)(B.iA, {
                        wrapperDivProps: {
                            onScroll: D
                        },
                        children: [(0, t.jsx)(B.xD, {
                            className: (0, n.cn)("bg-secondary-focus", z),
                            children: H.getHeaderGroups().map(e => (0, t.jsx)(B.SC, {
                                children: e.headers.map((e, a, s) => {
                                    var l, r;
                                    let {
                                        length: i
                                    } = s, d = N && 0 === a, c = w && a === i - 1, u = e.column.getIsSorted();
                                    return (0, t.jsxs)(B.ss, {
                                        ref: G(a, i),
                                        className: (0, n.cn)("px-3 py-4 uppercase text-[8px] md:text-[10px] font-semibold relative", (A && d || M && c) && "bg-background", d && "sticky z-10 left-0", c && "sticky z-10 right-0", null === (l = e.column.columnDef.meta) || void 0 === l ? void 0 : l.headContainerClassName),
                                        children: [(0, t.jsx)("div", {
                                            className: (0, n.cn)("flex", 0 !== a && "justify-center", null === (r = e.column.columnDef.meta) || void 0 === r ? void 0 : r.headClassName),
                                            children: e.isPlaceholder ? null : e.column.columnDef.enableSorting ? (0, t.jsxs)("div", {
                                                className: (0, n.cn)("flex items-center leading-none", 0 !== a && "text-center"),
                                                children: [(0, U.ie)(e.column.columnDef.header, e.getContext()), (0, t.jsxs)(g.zx, {
                                                    size: "iconXs",
                                                    variant: "ghost",
                                                    className: "ml-1.5 px-0 w-3",
                                                    onClick: () => {
                                                        let a;
                                                        let s = e.column.getIsSorted(),
                                                            t = e.column.columnDef.sortDescFirst,
                                                            l = void 0 !== t ? t : H.options.sortDescFirst;
                                                        a = !1 === s ? l ? "desc" : "asc" : "asc" === s ? "desc" : "asc", o([{
                                                            id: e.column.id,
                                                            desc: "desc" === a
                                                        }])
                                                    },
                                                    children: ["asc" === u && (0, t.jsx)($.Z, {
                                                        className: "w-3"
                                                    }), "desc" === u && (0, t.jsx)(W.Z, {
                                                        className: "w-3"
                                                    }), !1 === u && (0, t.jsx)(Z.Z, {
                                                        className: "w-3"
                                                    })]
                                                })]
                                            }) : (0, U.ie)(e.column.columnDef.header, e.getContext())
                                        }), C && a < i - 1 && (0, t.jsx)(Y, {})]
                                    }, e.id)
                                })
                            }, e.id))
                        }), (0, t.jsx)(B.RM, {
                            children: H.getRowModel().rows.map(e => (0, t.jsx)(B.SC, {
                                "data-state": e.getIsSelected() && "selected",
                                children: e.getVisibleCells().map((e, a, s) => {
                                    var l;
                                    let {
                                        length: r
                                    } = s, i = N && 0 === a, o = w && a === r - 1;
                                    return (0, t.jsxs)(B.pj, {
                                        className: (0, n.cn)("px-3 py-4 relative", (A && i || M && o) && "bg-background group-hover:bg-muted", i && "sticky z-10 left-0", o && "sticky z-10 right-0", null === (l = e.column.columnDef.meta) || void 0 === l ? void 0 : l.cellClassName),
                                        children: [(0, U.ie)(e.column.columnDef.cell, e.getContext()), C && a < r - 1 && (0, t.jsx)(Y, {})]
                                    }, e.id)
                                })
                            }, e.id))
                        })]
                    }), u && c ? (0, t.jsx)(_.h, {
                        totalCount: c,
                        pageSize: null == u ? void 0 : u.pageSize,
                        page: null == u ? void 0 : u.pageIndex,
                        onPageChange: H.setPageIndex
                    }) : null]
                })
            }
            let Y = e => (0, t.jsx)("div", {
                className: (0, n.cn)("absolute right-0 top-1/4 h-1/2 w-px bg-border", e.className)
            });

            function K(e) {
                return (0, t.jsx)("div", {
                    className: (0, n.cn)("flex justify-center font-semibold text-[10px] md:text-sm", e.className),
                    children: e.children
                })
            }

            function X(e) {
                let a = (0, d.useMemo)(() => Array.from({
                        length: e.columns
                    }).map((e, a) => a), [e.columns]),
                    s = (0, d.useMemo)(() => Array.from({
                        length: e.rows
                    }).map((e, a) => a), [e.rows]);
                return (0, t.jsxs)(B.iA, {
                    children: [(0, t.jsx)(B.xD, {
                        children: (0, t.jsx)(B.SC, {
                            children: a.map((e, s) => (0, t.jsxs)(B.ss, {
                                className: "relative",
                                children: [(0, t.jsx)(G.O, {
                                    className: "h-4 w-full bg-background-tertiary"
                                }), s < a.length - 1 && (0, t.jsx)(Y, {})]
                            }, e))
                        })
                    }), (0, t.jsx)(B.RM, {
                        children: s.map(e => (0, t.jsx)(B.SC, {
                            children: a.map((e, s) => (0, t.jsxs)(B.pj, {
                                className: "relative",
                                children: [(0, t.jsx)(G.O, {
                                    className: "h-4 w-full"
                                }), s < a.length - 1 && (0, t.jsx)(Y, {})]
                            }, e))
                        }, e))
                    })]
                })
            }
            var J = s(30245),
                Q = s(59957),
                q = s(97385),
                ee = s(66453),
                ea = s(75024),
                es = s(18167);
            let et = e => {
                    let {
                        onSearch: a,
                        placeholder: s,
                        defaultValue: l,
                        size: r = "sm"
                    } = e, {
                        t: n
                    } = (0, f.$G)();
                    return (0, t.jsx)(Q.I, {
                        leftIcon: (0, t.jsx)(ee.Z, {}),
                        type: "text",
                        size: r,
                        defaultValue: l,
                        placeholder: null != s ? s : n("Search"),
                        onChange: e => null == a ? void 0 : a(e.target.value),
                        className: "w-full pl-10 rounded-full md:max-w-none md:min-w-80",
                        wrapperClassName: "w-full md:w-auto"
                    })
                },
                el = (0, d.forwardRef)((e, a) => {
                    var s;
                    let {
                        active: l,
                        className: r,
                        ...i
                    } = e;
                    return (0, t.jsx)(g.zx, {
                        rounded: "full",
                        size: null !== (s = i.size) && void 0 !== s ? s : "xs",
                        className: (0, n.cn)("md:[&_svg]:h-4 md:[&_svg]:w-4", l && "[&_svg]:fill-primary-theme [&_svg]:text-primary-theme focus:bg-background focus:border-foreground focus:text-foreground", r),
                        variant: l ? "alternativeOutline" : "dark",
                        ref: a,
                        ...i,
                        children: i.children
                    })
                });

            function er(e) {
                let {
                    items: a,
                    onQuickFilterChange: s,
                    defaultValue: l,
                    size: r
                } = e, [n, i] = (0, d.useState)(l);
                return a.map(e => (0, t.jsxs)(el, {
                    active: n === e.value,
                    onClick: () => {
                        null == s || s(e.value), i(e.value)
                    },
                    size: r,
                    children: [e.icon && (0, t.jsx)(g.uv, {
                        children: e.icon
                    }), e.label]
                }, e.label))
            }

            function en(e) {
                let {
                    extendedFilter: a,
                    otherFilters: s,
                    quickFilters: l,
                    search: r,
                    selectFilters: i,
                    sorting: o
                } = e, {
                    t: d
                } = (0, f.$G)(), {
                    isExtendedFiltersOpen: c,
                    setExtendedFiltersOpen: u
                } = R();
                return (0, t.jsxs)("div", {
                    className: "justify-between grid xs:grid-cols-1 gap-4 md:flex flex-wrap",
                    children: [(a || i || s || l) && (0, t.jsxs)("div", {
                        className: "flex items-center gap-2 md:gap-2.5 overflow-auto",
                        children: [a && (0, t.jsxs)(g.zx, {
                            rounded: "full",
                            size: "xs",
                            className: (0, n.cn)("[&_svg]:h-4 [&_svg]:w-4"),
                            variant: c ? "darkActive" : "dark",
                            onClick: () => {
                                var e;
                                let s = !c;
                                null == a || null === (e = a.onOpenChange) || void 0 === e || e.call(a, s), u(s)
                            },
                            children: [(0, t.jsx)(g.uv, {
                                className: "mr-0 md:mr-2",
                                children: c ? (0, t.jsx)(ea.Z, {}) : (0, t.jsx)(es.Z, {})
                            }), (0, t.jsx)("span", {
                                className: "hidden md:block",
                                children: d("Filter")
                            })]
                        }), i && (0, t.jsxs)(t.Fragment, {
                            children: [a && (0, t.jsx)(q.Separator, {
                                orientation: "vertical",
                                className: "h-6 min-h-6 mx-px align-middle"
                            }), i]
                        }), s && (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)(q.Separator, {
                                orientation: "vertical",
                                className: "h-6 min-h-6 mx-px align-middle"
                            }), s]
                        }), l && (0, t.jsxs)(t.Fragment, {
                            children: [(a || i || s) && (0, t.jsx)(q.Separator, {
                                orientation: "vertical",
                                className: "h-6 min-h-6 mx-px align-middle"
                            }), (0, t.jsx)(er, { ...l
                            })]
                        })]
                    }), (o || r) && (0, t.jsxs)("div", {
                        className: "flex items-center gap-2 sm:gap-4 flex-wrap",
                        children: [o && (0, t.jsx)(J.h, { ...o
                        }), r && (0, t.jsx)(et, { ...r
                        })]
                    })]
                })
            }
            el.displayName = "PfmDataTableFilterItem";
            var ei = s(5455);

            function eo(e) {
                let {
                    placeholderText: a,
                    className: s
                } = e;
                return (0, t.jsxs)("div", {
                    className: (0, n.cn)("flex flex-col items-center justify-center h-full gap-1 min-h-[248px]", s),
                    children: [(0, t.jsx)(ei.Z, {
                        className: "size-5 text-muted-foreground"
                    }), (0, t.jsx)("span", {
                        className: "text-muted-foreground text-[12px]",
                        children: a
                    })]
                })
            }

            function ed(e) {
                let {
                    placeholderText: a
                } = e, {
                    t: s
                } = (0, f.$G)();
                return (0, t.jsxs)("div", {
                    className: "flex flex-col items-center justify-center h-full gap-5",
                    children: [(0, t.jsx)("img", {
                        src: "/no-results-placeholder.png",
                        alt: "No Results",
                        className: "h-[220px] w-[250px]"
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col items-center gap-2 justify-center text-center",
                        children: [(0, t.jsx)("span", {
                            className: "text-[20px] leading-[30px] font-semibold",
                            children: s("No results")
                        }), (0, t.jsx)("span", {
                            className: "text-foreground-secondary text-lg font-normal",
                            children: null != a ? a : s("Adjust the filters to discover additional options")
                        })]
                    })]
                })
            }

            function ec(e) {
                let {
                    filtersHookResult: a,
                    className: s
                } = e, {
                    filters: l
                } = a, i = w(a);
                return (0, t.jsx)(r.RV, { ...i,
                    children: (0, t.jsx)("form", {
                        className: (0, n.cn)("flex items-center space-x-2.5", s),
                        children: l.options.map(e => (0, t.jsx)("div", {
                            children: e.render(i.control)
                        }, e.name))
                    })
                })
            }
        },
        94062: (e, a, s) => {
            s.d(a, {
                g: () => t
            });

            function t(e, a) {
                return {
                    schema: e,
                    options: a
                }
            }
        },
        68373: (e, a, s) => {
            s.d(a, {
                Y: () => l
            });
            var t = s(12428);

            function l(e) {
                return (0, t.jsx)("div", {
                    className: "flex justify-center",
                    children: (0, t.jsx)("div", {
                        className: "flex px-1 w-full flex-col md:flex-row justify-center gap-6 lg:gap-[60px]",
                        children: e.children
                    })
                })
            }
        },
        43441: (e, a, s) => {
            s.d(a, {
                T: () => i,
                r: () => n
            });
            var t = s(6185),
                l = s(64093),
                r = s(93264);

            function n() {
                let {
                    t: e
                } = (0, t.$G)();
                return (0, r.useMemo)(() => (0, l.ar)(e), [e])
            }

            function i() {
                let {
                    t: e
                } = (0, t.$G)();
                return (0, r.useMemo)(() => (0, l.ce)(e), [e])
            }
        },
        21880: (e, a, s) => {
            s.d(a, {
                lo: () => eC,
                oJ: () => eA,
                xX: () => ew
            });
            var t = s(12428),
                l = s(6185),
                r = s(85473),
                n = s(17322),
                i = s(93264),
                o = s(70935),
                d = s(64093),
                c = s(95772);
            let u = (0, o.u)(d.Ue.extend({
                    termsAccepted: c.z.boolean()
                }), ["firm", "details", "rating", "reporting"], {
                    firm: e => d.Ue.pick({
                        firm: !0
                    }).safeParse(e).success,
                    details: e => d.Ue.pick({
                        accountSize: !0,
                        programType: !0
                    }).safeParse(e).success,
                    rating: e => d.Ue.pick({
                        overallRating: !0,
                        dashboardRating: !0,
                        customerCareRating: !0,
                        credentialsRating: !0,
                        tradingConditionsRating: !0,
                        overallSummary: !0
                    }).safeParse(e).success,
                    reporting: e => d.Ue.pick({
                        orderConfirmationFile: !0,
                        likedMostAboutFirm: !0,
                        likedLeastAboutFirm: !0,
                        reporting: !0
                    }).safeParse(e).success && !!e.termsAccepted
                }),
                m = d.Ue.omit({
                    firm: !0
                }).extend({
                    termsAccepted: c.z.boolean()
                }),
                x = (0, o.u)(m, ["details", "rating", "reporting"], {
                    details: e => d.Ue.pick({
                        accountSize: !0,
                        programType: !0
                    }).safeParse(e).success,
                    rating: e => d.Ue.pick({
                        overallRating: !0,
                        dashboardRating: !0,
                        customerCareRating: !0,
                        credentialsRating: !0,
                        tradingConditionsRating: !0,
                        overallSummary: !0
                    }).safeParse(e).success,
                    reporting: e => d.Ue.pick({
                        orderConfirmationFile: !0,
                        likedMostAboutFirm: !0,
                        likedLeastAboutFirm: !0,
                        reporting: !0
                    }).safeParse(e).success && !!e.termsAccepted
                }),
                p = (0, i.createContext)({
                    useFormContext: void 0
                });

            function f() {
                let {
                    useFormContext: e
                } = (0, i.useContext)(p);
                if (!e) throw Error("no useReviewContext");
                return {
                    useFormContext: e
                }
            }

            function h(e) {
                return (0, t.jsx)(p.Provider, {
                    value: {
                        useFormContext: e.useFormContext
                    },
                    children: e.children
                })
            }
            var v = s(1798),
                g = s(49433),
                j = s(40850),
                b = s(92006),
                y = s(33656),
                N = s(59957),
                w = s(57207),
                S = s(43692),
                C = s(62993),
                z = s(32029),
                k = s(70073),
                R = s(87071),
                P = s(68373),
                T = s(93125),
                F = s(37672),
                A = s(12351);

            function O(e) {
                let {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsxs)("div", {
                    className: "space-y-4 md:w-[300px]",
                    children: [(0, t.jsx)(F.Zb, {
                        variant: "pfmPale",
                        children: (0, t.jsxs)(F.aY, {
                            className: "text-xs space-y-4 p-4",
                            children: [(0, t.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, t.jsx)(A.Z, {
                                    className: "text-primary-theme",
                                    size: "16"
                                }), (0, t.jsx)("p", {
                                    className: "text-primary-theme font-normal text-xs",
                                    children: a("Important Notes:")
                                })]
                            }), (0, t.jsx)("p", {
                                children: a("You must have traded with the firm for at least 2-weeks before leaving a review. As of April 18, 2024 we are no longer awarding points for reviews. Giveaway winners cannot leave a review if still in the challenge phase.")
                            }), (0, t.jsx)("div", {
                                className: "px-4 py-2.5 bg-background-primary rounded-md text-muted-foreground",
                                children: (0, t.jsx)("p", {
                                    children: a("Editing Review. If you are editing a previous review, your new review will replace the original once it has been verified.")
                                })
                            }), e.children]
                        })
                    }), (0, t.jsx)("p", {
                        className: "text-sm font-semibold text-center",
                        children: (0, t.jsx)(l.cC, {
                            i18nKey: "Need help? Reach out to our <support>support</support>",
                            components: {
                                support: e => (0, t.jsx)("button", {
                                    type: "button",
                                    onClick: () => (0, T.show)(),
                                    className: "text-primary-theme font-semibold hover:underline",
                                    children: e.children
                                })
                            }
                        })
                    })]
                })
            }

            function M(e) {
                let {
                    form: a,
                    completedSteps: s,
                    setNextStep: r,
                    setPreviousStep: i
                } = f().useFormContext(), {
                    t: o
                } = (0, l.$G)(), {
                    user: c
                } = (0, g.aF)(), u = (0, v.x)();
                return (0, t.jsxs)(P.Y, {
                    children: [(0, t.jsx)(b.l0, { ...a,
                        children: (0, t.jsxs)("div", {
                            className: "space-y-10 md:w-[400px]",
                            children: [(0, t.jsxs)("div", {
                                className: "space-y-5",
                                children: [(0, t.jsx)(y.P, {
                                    name: "name",
                                    label: o("Full Name"),
                                    render: () => {
                                        var e;
                                        return (0, t.jsx)(N.I, {
                                            type: "text",
                                            placeholder: o("Full Name"),
                                            disabled: !0,
                                            value: null !== (e = null == c ? void 0 : c.fullName) && void 0 !== e ? e : ""
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    name: "email",
                                    label: o("Email"),
                                    render: () => {
                                        var e, a;
                                        return (0, t.jsx)(N.I, {
                                            type: "text",
                                            placeholder: o("Enter your email"),
                                            disabled: !0,
                                            value: null !== (a = null == c ? void 0 : null === (e = c.primaryEmailAddress) || void 0 === e ? void 0 : e.emailAddress) && void 0 !== a ? a : ""
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: a.control,
                                    name: "accountSize",
                                    label: o("Account size"),
                                    render: e => {
                                        var a, s;
                                        let {
                                            field: l
                                        } = e;
                                        return (0, t.jsxs)("div", {
                                            className: "flex flex-col gap-y-2 pt-1",
                                            children: [(0, t.jsxs)("div", {
                                                className: "flex justify-between font-semibold",
                                                children: [(0, t.jsx)("span", {
                                                    children: "$0"
                                                }), (0, t.jsx)("span", {
                                                    children: (0, z.uf)({
                                                        value: null !== (a = l.value) && void 0 !== a ? a : 0,
                                                        currency: z.Mf.USD,
                                                        maximumFractionDigits: 2,
                                                        notation: "compact"
                                                    })
                                                })]
                                            }), (0, t.jsx)(S.i, {
                                                variant: "white",
                                                thumb: "white",
                                                thumbSize: "xs",
                                                trackSize: "sm",
                                                ...l,
                                                value: [null !== (s = l.value) && void 0 !== s ? s : 0],
                                                onChange: () => {},
                                                onValueChange: e => {
                                                    l.onChange(e[0])
                                                },
                                                steps: d.kK
                                            })]
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: a.control,
                                    name: "programType",
                                    label: o("Steps"),
                                    render: e => {
                                        var a;
                                        let {
                                            field: s
                                        } = e;
                                        return (0, t.jsx)(k.Ee, {
                                            defaultValue: null !== (a = s.value) && void 0 !== a ? a : "",
                                            onValueChange: s.onChange,
                                            children: (0, t.jsx)("div", {
                                                className: "grid grid-cols-1 sm:grid-cols-4 gap-2",
                                                children: [n.oi.Instant, n.oi.OneStep, n.oi.TwoSteps, n.oi.ThreeSteps, n.oi.FourSteps].map(e => (0, t.jsx)(w.$, {
                                                    value: e,
                                                    variant: "pfmCheckbox",
                                                    className: (0, C.cn)("col-span-1"),
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        children: u[e]
                                                    })
                                                }, e))
                                            })
                                        }, s.value)
                                    }
                                })]
                            }), (0, t.jsx)("div", {
                                className: "flex flex-col space-y-10",
                                children: (0, t.jsxs)("div", {
                                    className: "flex w-full items-center space-x-4",
                                    children: [!e.hideBackButton && (0, t.jsx)(j.zx, {
                                        variant: "darkOutline",
                                        rounded: "full",
                                        size: "iconLg",
                                        type: "button",
                                        asChild: !0,
                                        onClick: i,
                                        children: (0, t.jsx)(R.Z, {})
                                    }), (0, t.jsx)("div", {
                                        className: "flex-1 flex flex-col",
                                        children: (0, t.jsx)(j.zx, {
                                            variant: "pfmGradient",
                                            rounded: "full",
                                            type: "button",
                                            onClick: r,
                                            disabled: !s.details,
                                            children: o("Next")
                                        })
                                    })]
                                })
                            })]
                        })
                    }), (0, t.jsx)(O, {})]
                })
            }
            var E = s(69615),
                L = s(27708),
                I = s(24040);

            function D(e) {
                let a = (0, I.lA)();
                return "object" == typeof e.image ? (0, t.jsx)("img", {
                    className: e.className,
                    src: a.getFileReadUrl(e.image),
                    alt: e.image.name
                }) : (0, t.jsx)("img", {
                    className: e.className,
                    src: e.image,
                    alt: "Image"
                })
            }
            s(31077), s(1456), s(20842), s(77815);
            var _ = s(33617),
                G = s(42619),
                B = s(83352),
                U = s(71999),
                V = s(35022),
                $ = s(64608);

            function W(e) {
                var a;
                return (0, t.jsxs)("div", {
                    className: "flex items-center justify-start relative space-x-2.5 text-sm w-full",
                    children: [(0, t.jsxs)("div", {
                        className: "flex items-center space-x-2",
                        children: [e.item.logo ? (0, t.jsx)(D, {
                            image: e.item.logo,
                            className: "size-4"
                        }) : null, (0, t.jsx)(B.o3, {
                            maxWidth: "2xs",
                            tooltipContentSize: "sm",
                            children: null !== (a = e.item.name) && void 0 !== a ? a : "n/a"
                        })]
                    }), e.selected && (0, t.jsx)("div", {
                        className: "text-foreground-primary absolute right-0 top-1/2 transform -translate-y-1/2",
                        children: (0, t.jsx)(U.Z, {
                            className: "size-3"
                        })
                    })]
                })
            }

            function Z(e) {
                var a;
                let {
                    t: s
                } = (0, l.$G)(), [o, d] = (0, i.useState)(""), [u, m] = (0, i.useState)(!1), [x, p] = (0, V.v1)("firmName", c.z.string().optional()), [f] = (0, $.Nr)(o, 400), [h] = r.trpc.unlistedFirm.listUnlisted.useSuspenseQuery({
                    limit: 100,
                    search: f || void 0
                }), v = (null !== (a = h.data) && void 0 !== a ? a : []).find(a => a.id === e.value);
                return (0, t.jsxs)(G.J2, {
                    open: u,
                    onOpenChange: m,
                    children: [(0, t.jsx)(G.xo, {
                        asChild: !0,
                        children: e.trigger((null == v ? void 0 : v.name) || x || e.value)
                    }), (0, t.jsx)(G.yk, {
                        align: "start",
                        children: (0, t.jsxs)(_.mY, {
                            children: [(0, t.jsx)(_.sZ, {
                                hideIcon: !0,
                                wrapperClassname: "px-0",
                                placeholder: s("Search"),
                                value: o,
                                onValueChange: d
                            }), (0, t.jsx)(_.e8, {
                                className: "pt-1",
                                children: (0, t.jsxs)(_.fu, {
                                    children: [h.data.map(a => (0, t.jsx)(_.di, {
                                        className: "cursor-pointer",
                                        value: a.name,
                                        onSelect: () => {
                                            p(a.name), e.onChange({
                                                value: a.id,
                                                listingStatus: a.listingStatus
                                            })
                                        },
                                        children: (0, t.jsx)(W, {
                                            item: a,
                                            selected: a.id === e.value
                                        })
                                    }, a.id)), e.type === n.Nf.unknown && (0, t.jsx)(_.di, {
                                        className: "cursor-pointer",
                                        value: e.value,
                                        onSelect: () => {
                                            p(null), e.onChange({
                                                firmName: e.value
                                            })
                                        },
                                        children: (0, t.jsxs)("div", {
                                            className: "flex items-center justify-start relative space-x-2.5 text-sm w-full",
                                            children: [(0, t.jsx)(B.o3, {
                                                maxWidth: "2xs",
                                                tooltipContentSize: "sm",
                                                children: e.value
                                            }), (0, t.jsx)("div", {
                                                className: "text-foreground-primary absolute right-0 top-1/2 transform -translate-y-1/2",
                                                children: (0, t.jsx)(U.Z, {
                                                    className: "size-3"
                                                })
                                            })]
                                        })
                                    }), !!o && o !== e.value && (0, t.jsx)(_.di, {
                                        className: "cursor-pointer",
                                        value: o,
                                        onSelect: () => {
                                            p(null), e.onChange({
                                                firmName: o
                                            })
                                        },
                                        children: (0, t.jsxs)("div", {
                                            className: "flex items-center justify-start relative space-x-2.5 text-sm w-full",
                                            children: [(0, t.jsx)(B.o3, {
                                                maxWidth: "2xs",
                                                tooltipContentSize: "sm",
                                                children: o
                                            }), e.value === o && (0, t.jsx)("div", {
                                                className: "text-foreground-primary absolute right-0 top-1/2 transform -translate-y-1/2",
                                                children: (0, t.jsx)(U.Z, {
                                                    className: "size-3"
                                                })
                                            })]
                                        })
                                    })]
                                })
                            })]
                        })
                    })]
                })
            }
            var H = s(88785);

            function Y() {
                let {
                    completedSteps: e,
                    form: a,
                    setNextStep: s
                } = u.useMultiStepContext(), {
                    t: r
                } = (0, l.$G)(), i = a.watch("firm.listingStatus"), o = i !== n.Xt.Listed;
                return (0, t.jsxs)(P.Y, {
                    children: [(0, t.jsxs)("div", {
                        className: "space-y-6 md:w-[400px]",
                        children: [(0, t.jsxs)("div", {
                            className: "space-y-6 sm:space-y-10",
                            children: [(0, t.jsx)(y.P, {
                                control: a.control,
                                name: "firm",
                                label: r("Search Firm"),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(E.ou, {
                                        value: a.value.type === n.Nf.known && a.value.listingStatus === n.Xt.Listed ? a.value.firmId : "",
                                        onChange: e => {
                                            a.onChange({
                                                type: n.Nf.known,
                                                firmId: e,
                                                listingStatus: n.Xt.Listed
                                            })
                                        }
                                    })
                                }
                            }), (0, t.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, t.jsx)(y.P, {
                                    control: a.control,
                                    name: "firm",
                                    label: "",
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsxs)("div", {
                                            className: "flex items-center space-x-2",
                                            children: [(0, t.jsx)(H.X, {
                                                id: "firmType",
                                                checked: o,
                                                onCheckedChange: e => {
                                                    e ? a.onChange({
                                                        firmId: "",
                                                        listingStatus: n.Xt.Unlisted
                                                    }) : a.onChange({
                                                        firmId: "",
                                                        type: n.Nf.known,
                                                        listingStatus: n.Xt.Listed
                                                    })
                                                }
                                            }), (0, t.jsx)("label", {
                                                htmlFor: "firmType",
                                                className: "text-xs",
                                                children: r("Other Firm Not Listed")
                                            })]
                                        })
                                    }
                                }), o && (0, t.jsx)(y.P, {
                                    control: a.control,
                                    name: "firm",
                                    label: "Name Of Other Firm",
                                    description: r("If your firm is not listed, we'll do our best to auto-fill the one you're looking for. If we can't autofill it, you can still type it manually."),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(Z, { ...a,
                                            value: a.value.type === n.Nf.known && a.value.listingStatus !== n.Xt.Listed ? a.value.firmId : a.value.type === n.Nf.unknown ? a.value.firmName : "",
                                            type: a.value.type,
                                            onChange: e => {
                                                let {
                                                    value: s,
                                                    listingStatus: t,
                                                    firmName: l
                                                } = e;
                                                l && a.onChange({
                                                    type: n.Nf.unknown,
                                                    firmName: l
                                                }), s && t && a.onChange({
                                                    type: n.Nf.known,
                                                    firmId: s,
                                                    listingStatus: t
                                                })
                                            },
                                            trigger: e => (0, t.jsx)(j.zx, {
                                                disabled: a.disabled,
                                                className: (0, C.cn)("w-full justify-start", !a.value && "text-foreground-secondary"),
                                                variant: "outline",
                                                children: e || r("Other Firm")
                                            })
                                        })
                                    }
                                })]
                            }, i)]
                        }), (0, t.jsx)("div", {
                            className: "flex flex-col space-y-10",
                            children: (0, t.jsx)("div", {
                                className: "flex w-full items-center space-x-4",
                                children: (0, t.jsx)("div", {
                                    className: "flex-1 flex flex-col",
                                    children: (0, t.jsx)(j.zx, {
                                        variant: "pfmGradient",
                                        rounded: "full",
                                        type: "button",
                                        onClick: s,
                                        disabled: !e.firm,
                                        children: r("Next")
                                    })
                                })
                            })
                        })]
                    }), (0, t.jsx)(O, {})]
                })
            }
            var K = s(54852),
                X = s(97385),
                J = s(5689);

            function Q(e) {
                return (0, t.jsxs)("div", {
                    className: "flex gap-1",
                    children: [(0, t.jsxs)("p", {
                        children: [e.index, "."]
                    }), (0, t.jsx)("p", {
                        className: "text-wrap",
                        children: e.label
                    })]
                })
            }

            function q() {
                let {
                    form: e,
                    completedSteps: a,
                    setNextStep: s,
                    setPreviousStep: r
                } = f().useFormContext(), {
                    t: n
                } = (0, l.$G)();
                return (0, t.jsxs)(P.Y, {
                    children: [(0, t.jsxs)("div", {
                        className: "space-y-10 md:w-[400px]",
                        children: [(0, t.jsxs)("div", {
                            className: "space-y-5",
                            children: [(0, t.jsxs)("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
                                children: [(0, t.jsx)(y.P, {
                                    control: e.control,
                                    name: "customerCareRating",
                                    label: (0, t.jsx)(Q, {
                                        index: 1,
                                        label: n("Customer Care")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(K.FirmStarsRank, {
                                            readOnly: !1,
                                            size: "lg",
                                            ...a,
                                            rank: a.value
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: e.control,
                                    name: "tradingConditionsRating",
                                    label: (0, t.jsx)(Q, {
                                        index: 2,
                                        label: n("Trading conditions (Spread, slippage, execution")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(K.FirmStarsRank, {
                                            readOnly: !1,
                                            size: "lg",
                                            ...a,
                                            rank: a.value
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: e.control,
                                    name: "dashboardRating",
                                    label: (0, t.jsx)(Q, {
                                        index: 3,
                                        label: n("Dashboard / User Friendliness")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(K.FirmStarsRank, {
                                            readOnly: !1,
                                            size: "lg",
                                            ...a,
                                            rank: a.value
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: e.control,
                                    name: "credentialsRating",
                                    label: (0, t.jsx)(Q, {
                                        index: 4,
                                        label: n("Credentials / Payout Times / Process")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(K.FirmStarsRank, {
                                            readOnly: !1,
                                            size: "lg",
                                            ...a,
                                            rank: a.value
                                        })
                                    }
                                })]
                            }), (0, t.jsx)(X.Separator, {}), (0, t.jsx)(y.P, {
                                control: e.control,
                                name: "overallRating",
                                label: "Overall Rating",
                                className: "pb-5",
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(K.FirmStarsRank, {
                                        readOnly: !1,
                                        size: "2xl",
                                        ...a,
                                        rank: a.value
                                    })
                                }
                            }), (0, t.jsx)(y.P, {
                                control: e.control,
                                name: "overallSummary",
                                label: (0, t.jsx)("p", {
                                    className: "text-wrap",
                                    children: (0, t.jsx)(l.cC, {
                                        i18nKey: "Detailed summary of the firm overall <muted>(150 characters minimum)</muted>",
                                        components: {
                                            muted: e => (0, t.jsx)("span", {
                                                className: "text-muted-foreground",
                                                children: e.children
                                            })
                                        }
                                    })
                                }),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(J.g, {
                                        rows: 7,
                                        ...a,
                                        placeholder: n("Share your real experience with the firm. For example, you can share about the trading conditions, customer service, payout process, or any other key details that made an impression on you, for better or worse.")
                                    })
                                }
                            })]
                        }), (0, t.jsx)("div", {
                            className: "flex flex-col space-y-10",
                            children: (0, t.jsxs)("div", {
                                className: "flex w-full items-center space-x-4",
                                children: [(0, t.jsx)(j.zx, {
                                    variant: "darkOutline",
                                    rounded: "full",
                                    size: "iconLg",
                                    type: "button",
                                    asChild: !0,
                                    onClick: r,
                                    children: (0, t.jsx)(R.Z, {})
                                }), (0, t.jsx)("div", {
                                    className: "flex-1 flex flex-col",
                                    children: (0, t.jsx)(j.zx, {
                                        variant: "pfmGradient",
                                        rounded: "full",
                                        type: "button",
                                        onClick: s,
                                        disabled: !a.rating,
                                        children: n("Next")
                                    })
                                })]
                            })
                        })]
                    }), (0, t.jsx)(O, {})]
                })
            }
            var ee = s(95289),
                ea = s(81786);
            let es = (0, i.forwardRef)((e, a) => {
                let [s, l] = (0, i.useState)(!1);
                return (0, t.jsx)(N.I, {
                    ref: a,
                    type: "file",
                    ...e,
                    className: (0, C.cn)("relative p-0 bg-background-primary file:h-full file:bg-background-secondary file:border-0 file:text-foreground file:border-solid file:border-r file:border-border file:px-5 file:mr-4 focus:border-blue-theme leading-tight text-xs", s ? "text-foreground" : "text-foreground-tertiary", e.className),
                    onChange: a => {
                        var s, t;
                        (null === (s = a.target.files) || void 0 === s ? void 0 : s.length) ? l(!0): l(!1), null == e || null === (t = e.onChange) || void 0 === t || t.call(e, a)
                    }
                })
            });

            function et(e) {
                var a;
                let s = (0, i.useRef)(null),
                    {
                        setError: l,
                        clearErrors: r
                    } = (0, ee.Gc)(),
                    {
                        storageServiceUrl: n,
                        getFileUploadUrl: o
                    } = (0, I.lA)(),
                    d = (0, I.FL)({
                        onChange(a) {
                            r(e.name), e.onChange(a)
                        },
                        getFileUploadUrl: async a => {
                            let t, {
                                accessType: l
                            } = a;
                            return e.recaptchaSiteKey && (t = await new Promise(e => {
                                if (!s.current) {
                                    e(null);
                                    return
                                }
                                s.current.executeAsync().then(e)
                            })), "".concat(n).concat(await o({
                                accessType: l,
                                recaptchaToken: t
                            }))
                        },
                        onError(a) {
                            l(e.name, {
                                type: "manual",
                                message: null == a ? void 0 : a.message
                            })
                        },
                        allowedExtensions: e.allowedExtensions || Object.values(L.V9),
                        maxSizeKB: 1e4,
                        accessType: null !== (a = e.accessType) && void 0 !== a ? a : L.M1.PUBLIC,
                        resetAfterUpload: !1
                    });
                return (0, t.jsxs)(t.Fragment, {
                    children: [e.recaptchaSiteKey && (0, t.jsx)(ea.Z, {
                        sitekey: e.recaptchaSiteKey,
                        size: "invisible",
                        ref: s,
                        theme: "dark"
                    }), (0, t.jsxs)("div", {
                        className: "space-y-2",
                        children: [(0, t.jsx)(es, { ...d.inputProps,
                            loading: d.loading,
                            disabled: e.disabled || d.loading
                        }), e.value && (0, t.jsx)("p", {
                            className: "text-xs text-foreground-secondary font-semibold line-clamp-1",
                            children: e.value.name
                        })]
                    })]
                })
            }
            es.displayName = "FileInput";
            var el = s(35449),
                er = s(3934);

            function en() {
                let e = (0, ee.Gc)();
                return (0, t.jsx)(y.P, {
                    control: e.control,
                    name: "termsAccepted",
                    render: e => {
                        let {
                            field: a
                        } = e;
                        return (0, t.jsxs)("div", {
                            className: "flex items-center space-x-2",
                            children: [(0, t.jsx)(H.X, {
                                id: "terms",
                                checked: a.value,
                                onCheckedChange: e => a.onChange(!!e)
                            }), (0, t.jsx)("label", {
                                htmlFor: "terms",
                                className: "text-xs",
                                children: (0, t.jsx)(l.cC, {
                                    i18nKey: "I accept the <link>Terms and Conditions</link>",
                                    components: {
                                        link: e => (0, t.jsx)(er.default, {
                                            href: "/terms-and-conditions",
                                            className: "text-primary-theme hover:underline",
                                            children: e.children
                                        })
                                    }
                                })
                            })]
                        })
                    }
                })
            }
            var ei = s(25845);

            function eo() {
                let {
                    form: e
                } = f().useFormContext(), [a, s] = (0, i.useState)(1), {
                    t: r
                } = (0, l.$G)(), {
                    remove: n
                } = (0, ee.Dq)({
                    control: e.control,
                    name: "reporting.firmCorrespondenceFiles"
                });
                return (0, t.jsxs)("div", {
                    children: [(0, t.jsx)("div", {
                        className: "space-y-3",
                        children: Array.from({
                            length: a
                        }).map((l, i) => (0, t.jsxs)("div", {
                            className: "relative flex",
                            children: [(0, t.jsx)(y.P, {
                                control: e.control,
                                className: "flex-1",
                                name: "reporting.firmCorrespondenceFiles.".concat(i),
                                label: 0 === i ? (0, t.jsx)(Q, {
                                    index: 3,
                                    label: r("Share Documentation of correspondence with Firm")
                                }) : null,
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(et, { ...a,
                                        accessType: L.M1.PRIVATE
                                    })
                                }
                            }), i === a - 1 && 0 !== i && (0, t.jsx)(j.zx, {
                                variant: "ghost",
                                size: "icon",
                                className: "absolute -right-8.5 top-0.5 text-foreground-secondary",
                                type: "button",
                                onClick: () => {
                                    n(i), s(e => e - 1)
                                },
                                children: (0, t.jsx)(ei.Z, {})
                            })]
                        }, i))
                    }), a < 10 && (0, t.jsx)(j.zx, {
                        variant: "link",
                        className: "p-0",
                        asChild: !0,
                        onClick: () => {
                            s(e => e + 1)
                        },
                        children: (0, t.jsx)("p", {
                            className: "text-xs text-primary-theme cursor-pointer",
                            children: r("Add More +")
                        })
                    })]
                })
            }

            function ed() {
                let {
                    form: e
                } = f().useFormContext(), {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsxs)("div", {
                    className: "space-y-4",
                    children: [(0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.fundingCertificateFile",
                        label: (0, t.jsx)(Q, {
                            index: 2.1,
                            label: (0, t.jsx)(l.cC, {
                                i18nKey: "Upload Funding Certificate <muted>(Required)</muted>",
                                components: {
                                    muted: e => (0, t.jsx)("span", {
                                        className: "text-muted-foreground",
                                        children: e.children
                                    })
                                }
                            })
                        }),
                        render: e => {
                            let {
                                field: a
                            } = e;
                            return (0, t.jsx)(et, { ...a,
                                accessType: L.M1.PRIVATE
                            })
                        }
                    }), (0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.deniedAmount",
                        label: (0, t.jsx)(Q, {
                            index: 2.2,
                            label: a("Denied Amount")
                        }),
                        render: e => {
                            var s;
                            let {
                                field: l
                            } = e;
                            return (0, t.jsx)(N.I, {
                                maxLength: 1e3,
                                placeholder: a("Denied amount"),
                                ...l,
                                value: null !== (s = l.value) && void 0 !== s ? s : ""
                            })
                        }
                    }), (0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.denialReason",
                        label: (0, t.jsx)(Q, {
                            index: 2.3,
                            label: a("The firm's stated reason for denial")
                        }),
                        render: e => {
                            var s;
                            let {
                                field: l
                            } = e;
                            return (0, t.jsx)(N.I, {
                                maxLength: 100,
                                placeholder: a("Short phrase"),
                                ...l,
                                value: null !== (s = l.value) && void 0 !== s ? s : ""
                            })
                        }
                    }), (0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.denialSummary",
                        label: (0, t.jsx)(Q, {
                            index: 2.4,
                            label: a("Describe denial in more detail")
                        }),
                        render: e => {
                            let {
                                field: s
                            } = e;
                            return (0, t.jsx)(J.g, {
                                maxLength: 1e3,
                                rows: 6,
                                ...s,
                                placeholder: a("Summary of denial")
                            })
                        }
                    }), (0, t.jsx)(eo, {})]
                })
            }

            function ec() {
                let {
                    form: e
                } = f().useFormContext(), {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsxs)("div", {
                    className: "space-y-4",
                    children: [(0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.breachReason",
                        label: (0, t.jsx)(Q, {
                            index: 2.1,
                            label: a("The firm's stated reason for breach")
                        }),
                        render: e => {
                            var s;
                            let {
                                field: l
                            } = e;
                            return (0, t.jsx)(N.I, {
                                placeholder: a("Short phrase"),
                                ...l,
                                value: null !== (s = l.value) && void 0 !== s ? s : ""
                            })
                        }
                    }), (0, t.jsx)(y.P, {
                        control: e.control,
                        name: "reporting.breachSummary",
                        label: (0, t.jsx)(Q, {
                            index: 2.2,
                            label: a("Describe the breach in more detail")
                        }),
                        render: e => {
                            let {
                                field: s
                            } = e;
                            return (0, t.jsx)(J.g, {
                                rows: 6,
                                ...s,
                                placeholder: a("Summary of breach")
                            })
                        }
                    }), (0, t.jsx)(eo, {})]
                })
            }

            function eu(e) {
                let {
                    form: a,
                    completedSteps: s,
                    setPreviousStep: r
                } = f().useFormContext(), {
                    t: o
                } = (0, l.$G)(), d = (0, i.useMemo)(() => ({
                    [n.AB.No]: o("No"),
                    [n.AB.PayoutDenial]: o("Payout Denial"),
                    [n.AB.UnjustifiedBreach]: o("Unjustified Breach")
                }), [o]), c = a.watch("reporting.type");
                return (0, t.jsxs)(P.Y, {
                    children: [(0, t.jsxs)("div", {
                        className: "space-y-10 md:w-[400px]",
                        children: [(0, t.jsxs)("div", {
                            className: "space-y-5",
                            children: [(0, t.jsx)(y.P, {
                                control: a.control,
                                name: "orderConfirmationFile",
                                label: (0, t.jsx)(Q, {
                                    index: 1,
                                    label: (0, t.jsx)(l.cC, {
                                        i18nKey: "Upload Order Confirmation <muted>(Required)</muted>",
                                        components: {
                                            muted: e => (0, t.jsx)("span", {
                                                className: "text-muted-foreground",
                                                children: e.children
                                            })
                                        }
                                    })
                                }),
                                description: o("Note: Verification requires matching emails in both account and uploaded confirmation."),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(et, { ...a,
                                        accessType: L.M1.PRIVATE
                                    })
                                }
                            }), (0, t.jsx)(y.P, {
                                control: a.control,
                                name: "reporting.type",
                                label: (0, t.jsx)(Q, {
                                    index: 2,
                                    label: o("Have you experienced a payout denial or unjustified breach with this firm?")
                                }),
                                description: o("If yes, must upload at least 1 funding certificate to be verified"),
                                render: e => {
                                    var a;
                                    let {
                                        field: s
                                    } = e;
                                    return (0, t.jsx)(k.Ee, {
                                        defaultValue: null !== (a = s.value) && void 0 !== a ? a : "",
                                        onValueChange: s.onChange,
                                        children: (0, t.jsx)("div", {
                                            className: "flex gap-2.5",
                                            children: Object.entries(d).map(e => {
                                                let [a, s] = e;
                                                return (0, t.jsx)(w.$, {
                                                    value: a,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "text-nowrap",
                                                        children: s
                                                    })
                                                }, a)
                                            })
                                        })
                                    }, s.value)
                                }
                            }), c === n.AB.PayoutDenial && (0, t.jsx)(ed, {}), c === n.AB.UnjustifiedBreach && (0, t.jsx)(ec, {}), (0, t.jsx)(y.P, {
                                control: a.control,
                                name: "likedMostAboutFirm",
                                label: (0, t.jsx)(Q, {
                                    index: c === n.AB.No ? 3 : 4,
                                    label: o("What do/did you like the most about the firm?")
                                }),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(J.g, {
                                        rows: 7,
                                        ...a,
                                        placeholder: o("Summary here...")
                                    })
                                }
                            }), (0, t.jsx)(y.P, {
                                control: a.control,
                                name: "likedLeastAboutFirm",
                                label: (0, t.jsx)(Q, {
                                    index: c === n.AB.No ? 4 : 5,
                                    label: o("What do/did you like the least about the firm?")
                                }),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(J.g, {
                                        rows: 7,
                                        ...a,
                                        placeholder: o("Summary here...")
                                    })
                                }
                            }), (0, t.jsx)(en, {})]
                        }), (0, t.jsxs)("div", {
                            className: "space-y-4",
                            children: [e.alreadySubmitted && (0, t.jsxs)("div", {
                                className: "text-red-theme text-sm",
                                children: [(0, t.jsx)("p", {
                                    children: o("You have already submitted a review for this firm.")
                                }), (0, t.jsx)("p", {
                                    children: o("Please wait until it will be reviewed.")
                                })]
                            }), (0, t.jsx)("div", {
                                className: "flex flex-col space-y-10",
                                children: (0, t.jsxs)("div", {
                                    className: "flex w-full items-center space-x-4",
                                    children: [(0, t.jsx)(j.zx, {
                                        variant: "darkOutline",
                                        rounded: "full",
                                        size: "iconLg",
                                        type: "button",
                                        asChild: !0,
                                        onClick: () => {
                                            var a;
                                            null === (a = e.setAlreadySubmitted) || void 0 === a || a.call(e, !1), r()
                                        },
                                        children: (0, t.jsx)(R.Z, {})
                                    }), (0, t.jsx)("div", {
                                        className: "flex-1 flex flex-col",
                                        children: (0, t.jsx)(j.zx, {
                                            variant: "pfmGradient",
                                            rounded: "full",
                                            type: "submit",
                                            disabled: !s.reporting || e.isSubmitting || e.isSuccess,
                                            children: (0, t.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [e.isSubmitting && (0, t.jsx)(el.Z, {
                                                    className: "w-4 h-4 animate-spin mr-2"
                                                }), e.isSuccess ? o("Redirecting...") : o("Submit")]
                                            })
                                        })
                                    })]
                                })
                            })]
                        })]
                    }), (0, t.jsx)(O, {
                        children: (0, t.jsx)("div", {
                            className: "px-4 py-2.5 rounded-md bg-[image:var(--pfm-gradient-10)]",
                            children: (0, t.jsx)("p", {
                                children: (0, t.jsx)(l.cC, {
                                    i18nKey: "Ensure you have read our <link>Submission Guidelines</link> to make your review process smooth.",
                                    components: {
                                        link: e => (0, t.jsx)(er.default, {
                                            href: "/guidelines",
                                            className: "text-primary-theme font-semibold hover:underline",
                                            children: e.children
                                        })
                                    }
                                })
                            })
                        })
                    })]
                })
            }
            let em = (0, s(51699).j)("relative w-full rounded-lg border px-3 py-2.5 [&>svg~*]:pl-6 [&>svg]:absolute [&>svg]:top-2.5 [&>svg]:text-foreground", {
                    variants: {
                        variant: {
                            default: "bg-background text-foreground",
                            destructive: "border-red-theme/50 text-red-theme dark:border-red-theme [&>svg]:text-red-theme",
                            pfmGradient: 'bg-transparent text-foreground-secondary relative border-transparent overflow-hidden before:content-[""] before:absolute before:inset-0 before:w-full before:h-full before:-z-10 before:opacity-10 before:bg-[image:var(--pfm-gradient)] [&>svg]:text-primary-theme',
                            pfmGradientLight: 'bg-transparent text-foreground-secondary relative border-transparent overflow-hidden before:content-[""] before:absolute before:inset-0 before:w-full before:h-full before:opacity-15 before:bg-[image:var(--pfm-gradient)] [&>svg]:text-primary-theme',
                            pfmBlueGradient: 'bg-transparent text-foreground-secondary relative border-transparent overflow-hidden before:content-[""] before:absolute before:inset-0 before:w-full before:h-full before:-z-10 before:opacity-10 before:bg-[image:var(--pfm-blue-gradient)] [&>svg]:text-purple-theme'
                        }
                    },
                    defaultVariants: {
                        variant: "default"
                    }
                }),
                ex = i.forwardRef((e, a) => {
                    let {
                        className: s,
                        variant: l,
                        ...r
                    } = e;
                    return (0, t.jsx)("div", {
                        ref: a,
                        role: "alert",
                        className: (0, C.cn)(em({
                            variant: l
                        }), s),
                        ...r
                    })
                });
            ex.displayName = "Alert", i.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("h5", {
                    ref: a,
                    className: (0, C.cn)("leading-tight text-sm font-normal tracking-normal", s),
                    ...l
                })
            }).displayName = "AlertTitle";
            let ep = i.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    ref: a,
                    className: (0, C.cn)("text-xs [&_p]:leading-relaxed mt-1", s),
                    ...l
                })
            });
            ep.displayName = "AlertDescription";
            var ef = s(47953),
                eh = s(43748),
                ev = s(5313),
                eg = s(35389),
                ej = s(6767),
                eb = s(90738),
                ey = s(47576);

            function eN(e) {
                let {
                    reviewId: a
                } = e, {
                    t: s
                } = (0, l.$G)(), r = (0, ey.useRouter)(), [o, d] = (0, i.useState)(n.P4.No), [c, u] = (0, i.useState)(!1);
                return a ? (0, t.jsx)(ef.c, {
                    className: "w-full mb-auto pt-20 px-0 md:px-8",
                    children: (0, t.jsxs)("div", {
                        className: "space-y-10 flex flex-col items-center w-full",
                        children: [(0, t.jsx)("div", {
                            className: "flex flex-col items-center",
                            children: (0, t.jsx)(ev.iM, {
                                className: "w-20 h-20"
                            })
                        }), (0, t.jsxs)("div", {
                            className: "flex flex-col text-center items-center space-y-2 w-full",
                            children: [(0, t.jsx)(ej.S, {
                                className: "md:px-10",
                                children: s("Your Review Has Been Submitted")
                            }), (0, t.jsx)(eb.C, {
                                className: "text-foreground-secondary text-center",
                                children: s("We will verify your review, and as long as it meets the guidelines, it will be published within 48 hours.")
                            })]
                        }), (0, t.jsx)(eh.G7, {
                            variant: "pfmPaleOutline",
                            rounded: "lg",
                            className: "font-medium w-full",
                            children: (0, t.jsxs)(eh.MB, {
                                className: "flex flex-col gap-3 p-5",
                                children: [(0, t.jsxs)("div", {
                                    className: "space-y-2 w-full",
                                    children: [(0, t.jsx)("p", {
                                        className: "text-xs font-medium",
                                        children: s("Did you pass the challenge?")
                                    }), (0, t.jsx)(eg.E, {
                                        defaultValue: o,
                                        onValueChange: e => d(e),
                                        children: (0, t.jsxs)("div", {
                                            className: "grid grid-cols-2 gap-2.5",
                                            children: [(0, t.jsx)(w.$, {
                                                value: n.P4.No,
                                                variant: "pfmCheckbox",
                                                className: "flex-1",
                                                contentClassname: "py-2.5 text-xs",
                                                children: (0, t.jsx)("p", {
                                                    className: "capitalize",
                                                    children: n.P4.No
                                                })
                                            }), (0, t.jsx)(w.$, {
                                                value: n.P4.Yes,
                                                variant: "pfmCheckbox",
                                                className: "flex-1",
                                                contentClassname: "py-2.5 text-xs",
                                                children: (0, t.jsx)("p", {
                                                    className: "capitalize",
                                                    children: n.P4.Yes
                                                })
                                            })]
                                        })
                                    })]
                                }), (0, t.jsxs)(ex, {
                                    variant: "pfmGradientLight",
                                    className: "border-0",
                                    children: [(0, t.jsx)(A.Z, {
                                        size: "16",
                                        className: "text-primary-theme"
                                    }), (0, t.jsx)(ep, {
                                        className: "mt-0",
                                        children: (0, t.jsx)("div", {
                                            className: "text-foreground-secondary",
                                            children: s('Note: Selecting "Yes" will take you to the funding details form where you can provide additional information about your successful challenge.')
                                        })
                                    })]
                                })]
                            })
                        }), (0, t.jsx)("div", {
                            className: "flex flex-col w-full max-w-[400px]",
                            children: (0, t.jsx)(j.zx, {
                                variant: "pfmGradient",
                                rounded: "full",
                                type: "button",
                                onClick: () => {
                                    c || (u(!0), o === n.P4.Yes ? r.push("/reviews/edit/".concat(a, "/funding-details")) : r.push("/reviews"))
                                },
                                disabled: c,
                                children: s(c ? "Redirecting..." : "Confirm")
                            })
                        })]
                    })
                }) : (r.push("/reviews"), null)
            }

            function ew() {
                let [e, a] = (0, i.useState)(!1), [s, o] = (0, i.useState)(""), d = r.trpc.protected.reviewActions.create.useMutation({
                    onSuccess(e) {
                        o(e.id)
                    },
                    onError(e) {
                        var s;
                        (null === (s = e.data) || void 0 === s ? void 0 : s.code) === "CONFLICT" && a(!0)
                    }
                }), {
                    t: c
                } = (0, l.$G)();
                return d.isSuccess && s ? (0, t.jsx)(eN, {
                    reviewId: s
                }) : (0, t.jsxs)(u.FormWrapper, {
                    defaultStep: "firm",
                    onSubmit: e => {
                        let {
                            termsAccepted: a,
                            ...s
                        } = e;
                        a && d.mutate(s)
                    },
                    defaultValue: {
                        firm: {
                            firmId: "",
                            type: n.Nf.known,
                            listingStatus: n.Xt.Listed
                        },
                        accountSize: 0,
                        reporting: {
                            type: n.AB.No
                        }
                    },
                    children: [(0, t.jsx)("div", {
                        className: "mx-auto max-w-[466px] mb-10 pt-4",
                        children: (0, t.jsx)(u.Progress, {})
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col items-center space-y-2 w-full mb-8",
                        children: [(0, t.jsx)("p", {
                            className: "leading-tight text-4xl font-semibold capitalize",
                            children: c("Submit A Review")
                        }), (0, t.jsx)(u.StepsWrapper, {
                            children: (0, t.jsxs)("div", {
                                className: "text-foreground-secondary font-semibold",
                                children: [(0, t.jsx)(u.Step, {
                                    name: "firm",
                                    children: c("Firm")
                                }), (0, t.jsx)(u.Step, {
                                    name: "details",
                                    children: c("Details")
                                }), (0, t.jsx)(u.Step, {
                                    name: "rating",
                                    children: c("Rate Firm")
                                }), (0, t.jsx)(u.Step, {
                                    name: "reporting",
                                    children: c("Additional Details")
                                })]
                            })
                        })]
                    }), (0, t.jsx)(h, {
                        useFormContext: u.useMultiStepContext,
                        children: (0, t.jsxs)(u.StepsWrapper, {
                            children: [(0, t.jsx)(u.Step, {
                                name: "firm",
                                children: (0, t.jsx)(Y, {})
                            }), (0, t.jsx)(u.Step, {
                                name: "details",
                                children: (0, t.jsx)(M, {})
                            }), (0, t.jsx)(u.Step, {
                                name: "rating",
                                children: (0, t.jsx)(q, {})
                            }), (0, t.jsx)(u.Step, {
                                name: "reporting",
                                children: (0, t.jsx)(eu, {
                                    isSuccess: d.isSuccess,
                                    isSubmitting: d.isPending,
                                    alreadySubmitted: e,
                                    setAlreadySubmitted: a
                                })
                            })]
                        })
                    })]
                })
            }
            var eS = s(40798);

            function eC() {
                let {
                    toast: e
                } = (0, eS.pm)(), {
                    reviewId: a = ""
                } = (0, ey.useParams)(), [s] = r.trpc.review.getById.useSuspenseQuery({
                    id: a
                }), {
                    reporting: o,
                    orderConfirmationFile: d,
                    ...c
                } = s, u = r.trpc.protected.reviewActions.update.useMutation({
                    onError() {
                        e({
                            title: p("There was an error updating the review.")
                        })
                    }
                }), {
                    t: p
                } = (0, l.$G)(), f = (0, i.useMemo)(() => {
                    let e = m.partial().safeParse({ ...c,
                        orderConfirmationFile: null != d ? d : void 0,
                        reporting: o === n.AB.No ? {
                            type: n.AB.No
                        } : o === n.AB.PayoutDenial ? {
                            type: n.AB.PayoutDenial,
                            fundingCertificateFile: c.fundingCertificateFile,
                            deniedAmount: c.deniedAmount,
                            denialReason: c.denialReason,
                            denialSummary: c.denialSummary,
                            firmCorrespondenceFiles: c.firmCorrespondenceFiles
                        } : {
                            type: n.AB.UnjustifiedBreach,
                            breachReason: c.breachReason,
                            breachSummary: c.breachSummary,
                            firmCorrespondenceFiles: c.firmCorrespondenceFiles
                        }
                    });
                    return e.success ? e.data : {}
                }, [d, o, c]);
                return u.isSuccess ? (0, t.jsx)(eN, {
                    reviewId: a
                }) : (0, t.jsxs)(x.FormWrapper, {
                    defaultStep: "details",
                    onSubmit: e => {
                        let {
                            termsAccepted: s,
                            ...t
                        } = e;
                        s && u.mutate({
                            id: a,
                            data: t
                        })
                    },
                    defaultValue: f,
                    children: [(0, t.jsx)("div", {
                        className: "mx-auto max-w-[466px] mb-10 pt-4",
                        children: (0, t.jsx)(x.Progress, {})
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col items-center space-y-2 w-full mb-8",
                        children: [(0, t.jsx)("p", {
                            className: "leading-tight text-4xl font-semibold capitalize",
                            children: p("Edit A Review")
                        }), (0, t.jsx)(x.StepsWrapper, {
                            children: (0, t.jsxs)("div", {
                                className: "text-foreground-secondary font-semibold",
                                children: [(0, t.jsx)(x.Step, {
                                    name: "details",
                                    children: p("Details")
                                }), (0, t.jsx)(x.Step, {
                                    name: "rating",
                                    children: p("Rate Firm")
                                }), (0, t.jsx)(x.Step, {
                                    name: "reporting",
                                    children: p("Additional Details")
                                })]
                            })
                        })]
                    }), (0, t.jsx)(h, {
                        useFormContext: x.useMultiStepContext,
                        children: (0, t.jsxs)(x.StepsWrapper, {
                            children: [(0, t.jsx)(x.Step, {
                                name: "details",
                                children: (0, t.jsx)(M, {})
                            }), (0, t.jsx)(x.Step, {
                                name: "rating",
                                children: (0, t.jsx)(q, {})
                            }), (0, t.jsx)(x.Step, {
                                name: "reporting",
                                children: (0, t.jsx)(eu, {
                                    isSuccess: u.isSuccess,
                                    isSubmitting: u.isPending
                                })
                            })]
                        })
                    })]
                })
            }
            var ez = s(79859);

            function ek() {
                let e = (0, ee.Gc)(),
                    [a, s] = (0, i.useState)(1),
                    {
                        t: r
                    } = (0, l.$G)(),
                    {
                        remove: n
                    } = (0, ee.Dq)({
                        control: e.control,
                        name: "payouts.payoutsFiles"
                    });
                return (0, t.jsxs)("div", {
                    children: [(0, t.jsx)("div", {
                        className: "space-y-3",
                        children: Array.from({
                            length: a
                        }).map((l, i) => (0, t.jsxs)("div", {
                            className: "relative flex",
                            children: [(0, t.jsx)(y.P, {
                                control: e.control,
                                className: "flex-1",
                                name: "payouts.payoutsFiles.".concat(i),
                                label: 0 === i ? (0, t.jsx)(Q, {
                                    index: 4.2,
                                    label: r("Upload payout documents")
                                }) : null,
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(et, { ...a,
                                        accessType: L.M1.PRIVATE
                                    })
                                }
                            }), i === a - 1 && 0 !== i && (0, t.jsx)(j.zx, {
                                variant: "ghost",
                                size: "icon",
                                className: "absolute -right-8.5 top-0.5 text-foreground-secondary",
                                type: "button",
                                onClick: () => {
                                    n(i), s(e => e - 1)
                                },
                                children: (0, t.jsx)(ei.Z, {})
                            })]
                        }, i))
                    }), a < 10 && (0, t.jsx)(j.zx, {
                        variant: "link",
                        className: "p-0",
                        asChild: !0,
                        onClick: () => {
                            s(e => e + 1)
                        },
                        children: (0, t.jsx)("p", {
                            className: "text-xs text-primary-theme cursor-pointer",
                            children: r("Add More +")
                        })
                    })]
                })
            }

            function eR() {
                let e = (0, ee.Gc)(),
                    a = e.watch("payouts.payoutsReceived"),
                    {
                        t: s
                    } = (0, l.$G)();
                return (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsx)(y.P, {
                        control: e.control,
                        name: "payouts.payoutsReceived",
                        description: s("If yes, must upload at least 1 payout to be verified"),
                        label: (0, t.jsx)(Q, {
                            index: 4,
                            label: s("Have you received any payouts from this firm?")
                        }),
                        render: e => {
                            let {
                                field: a
                            } = e;
                            return (0, t.jsx)(eg.E, {
                                defaultValue: a.value,
                                onValueChange: a.onChange,
                                children: (0, t.jsxs)("div", {
                                    className: "grid grid-cols-2 gap-2.5",
                                    children: [(0, t.jsx)(w.$, {
                                        value: n.P4.Yes,
                                        variant: "pfmCheckbox",
                                        className: "flex-1",
                                        contentClassname: "py-2.5 text-xs",
                                        children: (0, t.jsx)("p", {
                                            className: "capitalize",
                                            children: n.P4.Yes
                                        })
                                    }), (0, t.jsx)(w.$, {
                                        value: n.P4.No,
                                        variant: "pfmCheckbox",
                                        className: "flex-1",
                                        contentClassname: "py-2.5 text-xs",
                                        children: (0, t.jsx)("p", {
                                            className: "capitalize",
                                            children: n.P4.No
                                        })
                                    })]
                                })
                            })
                        }
                    }), a === n.P4.Yes && (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)(y.P, {
                            control: e.control,
                            name: "payouts.payoutsReceivedCount",
                            label: (0, t.jsx)(Q, {
                                index: 4.1,
                                label: s("How many payouts did you receive from this firm?")
                            }),
                            render: e => {
                                var a;
                                let {
                                    field: s
                                } = e;
                                return (0, t.jsx)(eg.E, {
                                    defaultValue: null !== (a = s.value) && void 0 !== a ? a : n.HN.Zero,
                                    onValueChange: s.onChange,
                                    children: (0, t.jsxs)("div", {
                                        className: "grid gap-2.5",
                                        children: [(0, t.jsx)("div", {
                                            className: "grid grid-cols-6 gap-2.5",
                                            children: Object.entries(n.HN).slice(0, 6).map(e => {
                                                let [a, s] = e;
                                                return (0, t.jsx)(w.$, {
                                                    value: s,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: s
                                                    })
                                                }, a)
                                            })
                                        }), (0, t.jsx)("div", {
                                            className: "grid grid-cols-5 gap-2.5",
                                            children: Object.entries(n.HN).slice(6).map(e => {
                                                let [a, s] = e;
                                                return (0, t.jsx)(w.$, {
                                                    value: s,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: s
                                                    })
                                                }, a)
                                            })
                                        })]
                                    })
                                })
                            }
                        }), (0, t.jsx)(ek, {})]
                    })]
                })
            }
            var eP = s(43441);

            function eT() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsx)(ef.c, {
                    className: "w-full mb-auto pt-20 px-0 md:px-6",
                    children: (0, t.jsxs)("div", {
                        className: "space-y-10 flex flex-col items-center w-full",
                        children: [(0, t.jsx)("div", {
                            className: "flex flex-col items-center",
                            children: (0, t.jsx)(ev.iM, {
                                className: "w-20 h-20"
                            })
                        }), (0, t.jsxs)("div", {
                            className: "flex flex-col text-center items-center space-y-2 w-full",
                            children: [(0, t.jsx)(ej.S, {
                                children: e("Submission Successfully Received")
                            }), (0, t.jsx)(eb.C, {
                                className: "text-foreground-secondary text-center",
                                children: e("We will verify your review, and as long as it meets the guidelines, it will be published.")
                            })]
                        }), (0, t.jsx)(j.zx, {
                            variant: "pfmGradient",
                            rounded: "full",
                            type: "button",
                            asChild: !0,
                            children: (0, t.jsx)(er.default, {
                                href: "/reviews",
                                children: e("Return to Content")
                            })
                        })]
                    })
                })
            }
            let eF = d.iX.extend({
                termsAccepted: c.z.boolean()
            });

            function eA() {
                let {
                    t: e
                } = (0, l.$G)(), {
                    reviewId: a = ""
                } = (0, ey.useParams)(), s = (0, eP.r)(), o = (0, eP.T)(), {
                    toast: d
                } = (0, eS.pm)(), [c] = r.trpc.review.getById.useSuspenseQuery({
                    id: a
                }), u = (0, i.useMemo)(() => {
                    var e, s, t, l, r, i, o;
                    let d = eF.partial().safeParse({
                        reviewId: a,
                        fundingCertificateFile: null !== (e = c.fundingCertificateFile) && void 0 !== e ? e : void 0,
                        stillFunded: null !== (s = c.stillFunded) && void 0 !== s ? s : n.P4.Yes,
                        fundedPeriod: null !== (t = c.fundedPeriod) && void 0 !== t ? t : n.x3.LessThanOneMonth,
                        payouts: c.payoutsReceived === n.P4.Yes ? {
                            payoutsReceived: n.P4.Yes,
                            payoutsReceivedCount: c.payoutsReceivedCount,
                            payoutsFiles: c.payoutsFiles
                        } : {
                            payoutsReceived: n.P4.No
                        },
                        payoutStatus: null !== (l = c.payoutStatus) && void 0 !== l ? l : n.fg.Funded,
                        twitterHandle: null !== (r = c.twitterHandle) && void 0 !== r ? r : "",
                        firmsFundedWithCount: null !== (i = c.firmsFundedWithCount) && void 0 !== i ? i : n.HN.Zero,
                        profileImage: null !== (o = c.profileImage) && void 0 !== o ? o : void 0
                    });
                    return d.success ? d.data : {}
                }, [c, a]), m = (0, ee.cI)({
                    resolver: (0, ez.F)(eF),
                    defaultValues: u
                }), x = r.trpc.protected.reviewActions.updateFundingDetails.useMutation({
                    onError() {
                        d({
                            variant: "destructive",
                            title: e("An error has occured. Please try again.")
                        })
                    }
                });
                return x.isSuccess ? (0, t.jsx)(eT, {}) : (0, t.jsxs)("div", {
                    className: "space-y-8",
                    children: [(0, t.jsxs)("header", {
                        className: "text-center mt-10",
                        children: [(0, t.jsx)(ej.S, {
                            className: "mb-1",
                            children: e("Funding Form")
                        }), (0, t.jsx)("p", {
                            className: "text-xs md:text-base text-foreground-secondary",
                            children: e("Funding")
                        })]
                    }), (0, t.jsxs)(P.Y, {
                        children: [(0, t.jsx)(b.l0, { ...m,
                            children: (0, t.jsxs)("form", {
                                onSubmit: m.handleSubmit(e => {
                                    let {
                                        termsAccepted: s,
                                        ...t
                                    } = e;
                                    s && x.mutate({
                                        id: a,
                                        data: t
                                    })
                                }),
                                className: "space-y-5 w-[400px]",
                                children: [(0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "fundingCertificateFile",
                                    label: (0, t.jsx)(Q, {
                                        index: 1,
                                        label: (0, t.jsx)(l.cC, {
                                            i18nKey: "Upload Funding Certificate <muted>(Required)</muted>",
                                            components: {
                                                muted: e => (0, t.jsx)("span", {
                                                    className: "text-muted-foreground",
                                                    children: e.children
                                                })
                                            }
                                        })
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(et, { ...a,
                                            accessType: L.M1.PRIVATE
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "stillFunded",
                                    label: (0, t.jsx)(Q, {
                                        index: 2,
                                        label: e("Are you still funded?")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(eg.E, {
                                            defaultValue: a.value,
                                            onValueChange: a.onChange,
                                            children: (0, t.jsxs)("div", {
                                                className: "grid grid-cols-2 gap-2.5",
                                                children: [(0, t.jsx)(w.$, {
                                                    value: n.P4.Yes,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: n.P4.Yes
                                                    })
                                                }), (0, t.jsx)(w.$, {
                                                    value: n.P4.No,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: n.P4.No
                                                    })
                                                })]
                                            })
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "fundedPeriod",
                                    label: (0, t.jsx)(Q, {
                                        index: 3,
                                        label: e("How long have you been/were you funded with them?")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(eg.E, {
                                            defaultValue: a.value,
                                            onValueChange: a.onChange,
                                            children: (0, t.jsx)("div", {
                                                className: "grid grid-cols-2 md:grid-cols-3 gap-2.5",
                                                children: [n.x3.LessThanOneMonth, n.x3.OneMonthPlus, n.x3.ThreeMonthsPlus, n.x3.SixMonthsPlus, n.x3.OneYearPlus, n.x3.ThreeYearsPlus].map(e => (0, t.jsx)(w.$, {
                                                    value: e,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: s[e]
                                                    })
                                                }, e))
                                            })
                                        })
                                    }
                                }), (0, t.jsx)(eR, {}), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "payoutStatus",
                                    label: (0, t.jsx)(Q, {
                                        index: 5,
                                        label: e("Have you been paid out recently or have a pending payout with this firm?")
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(eg.E, {
                                            defaultValue: a.value,
                                            onValueChange: a.onChange,
                                            children: (0, t.jsx)("div", {
                                                className: "grid md:grid-cols-3 gap-2.5",
                                                children: [n.fg.PaidOut, n.fg.Funded, n.fg.Pending].map(e => (0, t.jsx)(w.$, {
                                                    value: e,
                                                    variant: "pfmCheckbox",
                                                    className: "flex-1",
                                                    contentClassname: "py-2.5 text-xs",
                                                    children: (0, t.jsx)("p", {
                                                        className: "capitalize",
                                                        children: o[e]
                                                    })
                                                }, e))
                                            })
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "twitterHandle",
                                    label: (0, t.jsx)(Q, {
                                        index: 6,
                                        label: (0, t.jsx)(l.cC, {
                                            i18nKey: "Want to connect with other traders? Add your X/Twitter handle <muted>(Optional)</muted>",
                                            components: {
                                                muted: e => (0, t.jsx)("span", {
                                                    className: "text-muted-foreground",
                                                    children: e.children
                                                })
                                            }
                                        })
                                    }),
                                    render: a => {
                                        var s;
                                        let {
                                            field: l
                                        } = a;
                                        return (0, t.jsx)(N.I, { ...l,
                                            value: null !== (s = l.value) && void 0 !== s ? s : "",
                                            type: "text",
                                            placeholder: e("@handle")
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "firmsFundedWithCount",
                                    label: (0, t.jsx)(Q, {
                                        index: 7,
                                        label: e("How many firms have you been funded with?")
                                    }),
                                    render: e => {
                                        var a;
                                        let {
                                            field: s
                                        } = e;
                                        return (0, t.jsx)(eg.E, {
                                            defaultValue: null !== (a = s.value) && void 0 !== a ? a : n.HN.Zero,
                                            onValueChange: s.onChange,
                                            children: (0, t.jsxs)("div", {
                                                className: "grid gap-2.5",
                                                children: [(0, t.jsx)("div", {
                                                    className: "grid grid-cols-6 gap-2.5",
                                                    children: Object.entries(n.HN).slice(0, 6).map(e => {
                                                        let [a, s] = e;
                                                        return (0, t.jsx)(w.$, {
                                                            value: s,
                                                            variant: "pfmCheckbox",
                                                            className: "flex-1",
                                                            contentClassname: "py-2.5 text-xs",
                                                            children: (0, t.jsx)("p", {
                                                                className: "capitalize",
                                                                children: s
                                                            })
                                                        }, a)
                                                    })
                                                }), (0, t.jsx)("div", {
                                                    className: "grid grid-cols-5 gap-2.5",
                                                    children: Object.entries(n.HN).slice(6).map(e => {
                                                        let [a, s] = e;
                                                        return (0, t.jsx)(w.$, {
                                                            value: s,
                                                            variant: "pfmCheckbox",
                                                            className: "flex-1",
                                                            contentClassname: "py-2.5 text-xs",
                                                            children: (0, t.jsx)("p", {
                                                                className: "capitalize",
                                                                children: s
                                                            })
                                                        }, a)
                                                    })
                                                })]
                                            })
                                        })
                                    }
                                }), (0, t.jsx)(y.P, {
                                    control: m.control,
                                    name: "profileImage",
                                    label: (0, t.jsx)(Q, {
                                        index: 1,
                                        label: (0, t.jsx)(l.cC, {
                                            i18nKey: "Upload a photo of yourself <muted>(Required)</muted>",
                                            components: {
                                                muted: e => (0, t.jsx)("span", {
                                                    className: "text-muted-foreground",
                                                    children: e.children
                                                })
                                            }
                                        })
                                    }),
                                    render: e => {
                                        let {
                                            field: a
                                        } = e;
                                        return (0, t.jsx)(et, { ...a,
                                            accessType: L.M1.PRIVATE
                                        })
                                    }
                                }), (0, t.jsxs)("div", {
                                    className: "pt-5 space-y-6",
                                    children: [(0, t.jsx)(en, {}), (0, t.jsx)(j.zx, {
                                        variant: "pfmGradient",
                                        rounded: "full",
                                        type: "submit",
                                        className: "w-full",
                                        disabled: x.isPending,
                                        children: (0, t.jsxs)("div", {
                                            className: "flex items-center",
                                            children: [x.isPending && (0, t.jsx)(el.Z, {
                                                className: "w-4 h-4 animate-spin mr-2"
                                            }), e("Submit")]
                                        })
                                    })]
                                })]
                            })
                        }), (0, t.jsx)(O, {
                            children: (0, t.jsx)("div", {
                                className: "px-4 py-2.5 rounded-md bg-[image:var(--pfm-gradient-10)]",
                                children: (0, t.jsx)("p", {
                                    children: (0, t.jsx)(l.cC, {
                                        i18nKey: "Ensure you have read our <link>Submission Guidelines</link> to make your review process smooth.",
                                        components: {
                                            link: e => (0, t.jsx)(er.default, {
                                                href: "/guidelines",
                                                className: "text-primary-theme font-semibold hover:underline",
                                                children: e.children
                                            })
                                        }
                                    })
                                })
                            })
                        })]
                    })]
                })
            }
        },
        40045: (e, a, s) => {
            s.d(a, {
                OfferPromo: () => m
            });
            var t = s(12428),
                l = s(6185),
                r = s(93264),
                n = s(17322),
                i = s(43748),
                o = s(36879),
                d = s(51131),
                c = s(62993),
                u = s(32029);

            function m(e) {
                var a, s, m, x, p, f, h;
                let {
                    offer: v
                } = e, {
                    t: g
                } = (0, l.$G)(), j = (0, r.useMemo)(() => (0, o.f)(v), [v]);
                return (0, t.jsx)(i.G7, {
                    className: (0, c.cn)("flex-1 rounded-b-lg rounded-t-[10px] px-0.5 pt-0.5 pb-px", (!v.code || !v.exclusive) && "p-2 rounded-[10px]"),
                    variant: "pfmSolid",
                    children: (0, t.jsxs)("div", {
                        className: "flex flex-col items-center justify-center",
                        children: [(0, t.jsxs)("p", {
                            className: "text-xs font-semibold space-x-0.5",
                            children: [(0, t.jsx)("span", {
                                children: (null == j ? void 0 : j.strategy) === n.Qx.Amount ? (0, u.uf)({
                                    value: null !== (m = null == j ? void 0 : j.amount) && void 0 !== m ? m : 0,
                                    currency: null !== (x = null === (a = v.firm) || void 0 === a ? void 0 : a.currency) && void 0 !== x ? x : u.Mf.USD
                                }) : (null == j ? void 0 : j.strategy) === n.Qx.Percentage ? "".concat(null !== (p = null == j ? void 0 : j.amount) && void 0 !== p ? p : 0, "%") : null == j ? void 0 : j.amount
                            }), (null == j ? void 0 : j.type) === n.LH.Standard && (0, t.jsx)("span", {
                                children: g("OFF")
                            })]
                        }), v.code && v.exclusive ? (0, t.jsx)(d.f, {
                            btnClassName: "pt-[5px] pb-1 space-x-0.5 px-2",
                            className: "md:h-3 md:w-3",
                            iconsClassName: "md:size-3",
                            motionClassName: "md:right-2.5 top-[5px]",
                            size: "lg",
                            value: v.code,
                            firmSlug: null !== (f = null === (s = v.firm) || void 0 === s ? void 0 : s.slug) && void 0 !== f ? f : "",
                            id: null !== (h = v.id) && void 0 !== h ? h : ""
                        }) : null]
                    })
                })
            }
        },
        98682: (e, a, s) => {
            s.r(a), s.d(a, {
                EditReviewButton: () => i
            });
            var t = s(12428),
                l = s(6185),
                r = s(43748),
                n = s(3934);

            function i(e) {
                let {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsx)(n.default, {
                    target: "_blank",
                    href: e.link,
                    children: (0, t.jsx)(r.G7, {
                        variant: "pfmPaleOutline",
                        className: "cursor-pointer",
                        children: (0, t.jsx)(r.MB, {
                            className: "text-xs font-medium px-4 py-2",
                            children: a("Edit")
                        })
                    })
                })
            }
        },
        4060: (e, a, s) => {
            s.r(a), s.d(a, {
                MinReviewsPlaceholder: () => i
            });
            var t = s(12428),
                l = s(6185),
                r = s(43748),
                n = s(23743);

            function i() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsx)(r.G7, {
                    variant: "pfmPaleOutline",
                    className: "w-fit",
                    children: (0, t.jsx)(r.MB, {
                        className: "gradientPillContent px-1 md:px-2 md:py-0.5",
                        children: (0, t.jsxs)("div", {
                            className: "flex items-center gap-1 text-xs font-normal tracking-tight",
                            children: [(0, t.jsx)("p", {
                                className: "whitespace-nowrap",
                                children: e("Less than")
                            }), (0, t.jsx)("p", {
                                className: "text-primary-theme whitespace-nowrap",
                                children: "".concat(n.nu, " reviews")
                            })]
                        })
                    })
                })
            }
        },
        53266: (e, a, s) => {
            s.r(a), s.d(a, {
                NoReviewsPlaceholder: () => n
            });
            var t = s(12428),
                l = s(6185),
                r = s(37672);

            function n() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsx)(r.Zb, {
                    className: "rounded-xl h-40 flex items-center justify-center",
                    children: (0, t.jsx)("p", {
                        className: "text-sm text-foreground-secondary",
                        children: e("No reviews")
                    })
                })
            }
        },
        53023: (e, a, s) => {
            s.r(a), s.d(a, {
                ReplyInput: () => o
            });
            var t = s(12428),
                l = s(6185),
                r = s(40850),
                n = s(59957),
                i = s(23283);
            let o = e => {
                var a, s, o, d;
                let {
                    t: c
                } = (0, l.$G)();
                return (0, t.jsx)(n.I, {
                    value: e.value,
                    className: "pl-12 pr-10 py-7 focus:border-blue-theme",
                    onChange: a => {
                        e.setValue(a.target.value)
                    },
                    disabled: e.disabled,
                    placeholder: null !== (s = e.placeholder) && void 0 !== s ? s : c("Reply message"),
                    leftIcon: (0, t.jsx)("div", {
                        className: "w-8 h-8 bg-background-tertiary border border-border rounded-full flex items-center justify-center",
                        children: (0, t.jsx)(i.Z, {
                            className: "w-5 h-5 text-foreground-tertiary"
                        })
                    }),
                    rightIcon: (0, t.jsx)(r.zx, {
                        className: "py-2 px-3 h-8",
                        variant: null !== (o = null === (a = e.buttonClassNames) || void 0 === a ? void 0 : a.variant) && void 0 !== o ? o : "pfmBlueGradient",
                        rounded: "full",
                        disabled: e.disabled,
                        onClick: e.onSubmit,
                        children: null !== (d = e.buttonText) && void 0 !== d ? d : c("Reply")
                    })
                })
            }
        },
        93536: (e, a, s) => {
            s.d(a, {
                $: () => n
            });
            var t = s(12428),
                l = s(37672),
                r = s(20533);

            function n() {
                return (0, t.jsxs)(l.Zb, {
                    rounded: "2xl",
                    className: "p-5 flex flex-col gap-5",
                    children: [(0, t.jsx)(l.Ol, {
                        className: "p-0 @container",
                        children: (0, t.jsxs)("div", {
                            className: "flex flex-col 2xl:flex-row justify-between gap-5",
                            children: [(0, t.jsxs)("div", {
                                className: "flex justify-between flex-wrap gap-10 items-center",
                                children: [(0, t.jsx)(r.O, {
                                    className: "h-[86px] flex-1 w-auto md:flex-initial md:w-40"
                                }), (0, t.jsx)(r.O, {
                                    className: "h-[86px] flex-1 w-auto md:flex-initial md:w-40"
                                })]
                            }), (0, t.jsxs)("div", {
                                className: "flex justify-end gap-2",
                                children: [(0, t.jsx)(r.O, {
                                    className: "w-[120px] h-[86px]"
                                }), (0, t.jsx)(r.O, {
                                    className: "w-[120px] h-[86px]"
                                }), (0, t.jsx)(r.O, {
                                    className: "w-[120px] h-[86px]"
                                }), (0, t.jsx)(r.O, {
                                    className: "w-[120px] h-[86px]"
                                })]
                            })]
                        })
                    }), (0, t.jsx)(l.aY, {
                        className: "flex flex-col p-0 gap-5",
                        children: (0, t.jsx)(r.O, {
                            className: "w-full h-40"
                        })
                    })]
                })
            }
        },
        13326: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewCardMessage: () => d
            });
            var t = s(12428),
                l = s(6185),
                r = s(56764),
                n = s(5313),
                i = s(30455),
                o = s(93264);
            let d = e => {
                var a;
                let {
                    t: s
                } = (0, l.$G)(), [d, c] = (0, o.useState)(!1), u = null !== (a = e.maxMessageLength) && void 0 !== a ? a : 555, m = e.overallSummary.length > u, x = (0, o.useMemo)(() => m ? d ? e.overallSummary : "".concat(e.overallSummary.slice(0, u), "...") : e.overallSummary, [d, m, u, e.overallSummary]);
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-3",
                    children: [(0, t.jsxs)("div", {
                        className: "flex items-center text-xs text-foreground-secondary gap-1.5",
                        children: [(0, t.jsx)(n.Qu, {
                            className: "size-4"
                        }), (0, t.jsx)("span", {
                            children: (0, t.jsx)(l.cC, {
                                i18nKey: "<date />",
                                components: {
                                    date: () => (0, t.jsx)(r.r, {
                                        date: e.createdAt,
                                        format: "short"
                                    })
                                }
                            })
                        })]
                    }), (0, t.jsx)("p", {
                        className: "text-sm",
                        children: x
                    }), m && (0, t.jsxs)("button", {
                        className: "flex items-center gap-1 text-primary-theme hover:underline cursor-pointer",
                        onClick: () => c(!d),
                        "aria-expanded": d,
                        "aria-controls": "message",
                        children: [(0, t.jsx)("span", {
                            children: s(d ? "Read Less" : "Read More")
                        }), (0, t.jsx)("span", {
                            children: (0, t.jsx)(i.Z, {
                                className: "size-4"
                            })
                        })]
                    })]
                })
            }
        },
        26640: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewCard: () => Q,
                UserReviewCard: () => q
            });
            var t = s(12428),
                l = s(40850),
                r = s(93264);
            let n = (0, r.createContext)(void 0);

            function i(e) {
                let {
                    defaultIsOpen: a = !1,
                    children: s
                } = e, [l, i] = (0, r.useState)(a);
                return (0, t.jsx)(n.Provider, {
                    value: {
                        isOpen: l,
                        setIsOpen: i
                    },
                    children: s
                })
            }

            function o() {
                let e = (0, r.useContext)(n);
                if (!e) throw Error("useCollapsible must be used within a CollapsibleProvider");
                return e
            }
            var d = s(6185),
                c = s(30455);
            let u = () => {
                let {
                    t: e
                } = (0, d.$G)(), {
                    isOpen: a,
                    setIsOpen: s
                } = o();
                return (0, t.jsxs)(l.zx, {
                    variant: "dark",
                    rounded: "full",
                    size: "xs",
                    className: "flex items-center gap-2",
                    onClick: () => s(!a),
                    children: [(0, t.jsx)("p", {
                        className: "text-xs font-medium",
                        children: e(a ? "Hide Details" : "Show Details")
                    }), (0, t.jsx)(c.Z, {
                        size: 16,
                        strokeWidth: 3,
                        className: "transition-transform duration-200 ".concat(a ? "rotate-180" : "")
                    })]
                })
            };
            var m = s(69615),
                x = s(17322),
                p = s(37672),
                f = s(62993),
                h = s(13326),
                v = s(65151),
                g = s(43441),
                j = s(57841);
            let b = j.fC;
            j.wy;
            let y = j.Fw;
            var N = s(5313),
                w = s(51699);
            let S = (0, w.j)("min-w-[120px] min-h-[86px] h-full", {
                    variants: {
                        padding: {
                            md: "p-3",
                            lg: "p-4"
                        }
                    },
                    defaultVariants: {
                        padding: "md"
                    }
                }),
                C = (0, w.j)("flex-1 flex", {
                    variants: {
                        align: {
                            top: "items-start",
                            center: "items-center",
                            bottom: "items-end"
                        }
                    },
                    defaultVariants: {
                        align: "top"
                    }
                }),
                z = e => (0, t.jsx)(p.Zb, {
                    rounded: "md",
                    className: "bg-background-secondary border-none",
                    children: (0, t.jsx)(p.aY, {
                        className: (0, f.cn)(S({
                            padding: e.padding
                        }), e.className),
                        children: (0, t.jsxs)("div", {
                            className: "flex flex-col gap-1 h-full",
                            children: [e.title && (0, t.jsx)("div", {
                                className: "text-xs text-foreground-secondary",
                                children: e.title
                            }), (0, t.jsx)("div", {
                                className: (0, f.cn)("flex-1 flex", C({
                                    align: e.align
                                })),
                                children: (0, t.jsx)("div", {
                                    className: "w-full text-sm",
                                    children: e.children
                                })
                            })]
                        })
                    })
                });
            var k = s(92494);
            let R = e => {
                    let {
                        t: a
                    } = (0, d.$G)();
                    return (0, t.jsxs)("div", {
                        className: "grid grid-cols-[auto_1fr_auto] items-center gap-1.5",
                        children: [(0, t.jsx)(T, {
                            score: e.dashboardRating,
                            title: a("User Friendliness")
                        }), (0, t.jsx)(T, {
                            score: e.credentialsRating,
                            title: a("Payout Process")
                        }), (0, t.jsx)(T, {
                            score: e.customerCareRating,
                            title: a("Customer Care")
                        }), (0, t.jsx)(T, {
                            score: e.tradingConditionsRating,
                            title: a("Trading Conditions")
                        })]
                    })
                },
                P = e => (0, t.jsxs)("div", {
                    className: "flex gap-1",
                    children: [(0, t.jsx)("p", {
                        className: "text-xs",
                        children: e.score.toFixed(1)
                    }), (0, t.jsx)(N.r7, {
                        className: "h-4 w-4"
                    })]
                }),
                T = e => (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsx)(P, { ...e
                    }), (0, t.jsx)(k.P, {
                        size: "xxs",
                        variant: "pfmGradient",
                        minLimit: 1,
                        maxLimit: 5,
                        value: e.score
                    }), (0, t.jsx)("p", {
                        className: "text-xs font-normal max-w-[7rem] overflow-hidden text-ellipsis",
                        children: e.title
                    })]
                }),
                F = e => {
                    let {
                        t: a
                    } = (0, d.$G)(), {
                        isOpen: s
                    } = o(), l = (0, g.r)();
                    return s ? (0, t.jsx)(b, {
                        open: s,
                        children: (0, t.jsx)(y, {
                            children: (0, t.jsxs)("div", {
                                className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
                                children: [(0, t.jsxs)("div", {
                                    className: "contents",
                                    children: [(0, t.jsx)(z, {
                                        padding: "lg",
                                        title: a("Funding Period"),
                                        children: e.fundedPeriod ? (0, t.jsx)(v._, {
                                            variant: "green",
                                            label: l[e.fundedPeriod]
                                        }) : null
                                    }), (0, t.jsx)(z, {
                                        padding: "lg",
                                        title: a("Payout Count"),
                                        children: (0, t.jsx)("p", {
                                            className: "font-semibold",
                                            children: e.payoutsReceivedCount
                                        })
                                    }), (0, t.jsx)(z, {
                                        padding: "lg",
                                        title: a("Firms Count"),
                                        children: (0, t.jsx)("p", {
                                            className: "font-semibold",
                                            children: e.firmsFundedWithCount
                                        })
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "contents",
                                    children: [(0, t.jsx)(z, {
                                        padding: "lg",
                                        title: (0, t.jsxs)("div", {
                                            className: "flex gap-1 items-center",
                                            children: [(0, t.jsx)(N.lb, {
                                                color: "primary",
                                                size: "xxs"
                                            }), a("Top Firm Aspect")]
                                        }),
                                        children: (0, t.jsx)("p", {
                                            children: e.likedMostAboutFirm
                                        })
                                    }), (0, t.jsx)(z, {
                                        padding: "lg",
                                        title: (0, t.jsxs)("div", {
                                            className: "flex gap-1 items-center",
                                            children: [(0, t.jsx)(N.kZ, {
                                                color: "primary",
                                                size: "xxs"
                                            }), a("Least Liked Aspect")]
                                        }),
                                        children: (0, t.jsx)("p", {
                                            children: e.likedLeastAboutFirm
                                        })
                                    }), (0, t.jsx)(z, {
                                        padding: "lg",
                                        children: (0, t.jsx)(R, {
                                            dashboardRating: e.dashboardRating,
                                            credentialsRating: e.credentialsRating,
                                            customerCareRating: e.customerCareRating,
                                            tradingConditionsRating: e.tradingConditionsRating
                                        })
                                    })]
                                })]
                            })
                        })
                    }) : null
                };
            var A = s(24040),
                O = s(31077),
                M = s(1456);
            let E = e => {
                    let {
                        getFileReadUrl: a
                    } = (0, A.lA)();
                    return (0, t.jsxs)("div", {
                        className: "flex gap-2 group",
                        children: [(0, t.jsx)("div", {
                            className: "w-10 h-10 rounded-md bg-background-tertiary",
                            children: (0, t.jsx)("img", {
                                className: "w-10 h-10 rounded-md object-cover",
                                src: a(e.file),
                                alt: "Imageicon"
                            })
                        }), (0, t.jsx)("div", {
                            className: "w-10 h-10 rounded-md bg-background-tertiary group-hover:bg-white group-hover:bg-opacity-5 text-foreground-secondary flex items-center justify-center text-xs transition-all",
                            children: e.imagesLength > 1 ? "+".concat(e.imagesLength - 1) : "1"
                        })]
                    })
                },
                L = e => {
                    let {
                        t: a
                    } = (0, d.$G)(), {
                        getFileReadUrl: s
                    } = (0, A.lA)();
                    return (0, t.jsxs)(M.Vq, {
                        children: [(0, t.jsx)(M.hg, {
                            children: e.children
                        }), (0, t.jsxs)(M.cZ, {
                            className: "w-full max-w-screen-xl mx-auto gap-0 p-0 bg-transparent border-none",
                            children: [(0, t.jsxs)(M.fK, {
                                className: "pb-5 sr-only",
                                children: [(0, t.jsx)(M.$N, {
                                    children: a("Review Images")
                                }), (0, t.jsx)(M.Be, {
                                    className: "sr-only",
                                    children: a("Review Images")
                                })]
                            }), (0, t.jsx)("div", {
                                className: "max-h-screen",
                                children: (0, t.jsxs)(O.lr, {
                                    className: "w-full h-full",
                                    opts: {
                                        align: "start"
                                    },
                                    hideDots: !0,
                                    children: [(0, t.jsx)(O.am, {
                                        className: "bg-transparent border-white disabled:border-white border-opacity-10 disabled:border-opacity-10 disabled:bg-transparent top-1/2 left-0 xl:left-0 z-10 transform -translate-y-1/2 h-8 w-8 xl:h-12 xl:w-12 focus:bg-white focus:border-white focus:bg-opacity-10 hover:bg-white hover:border-white hover:bg-opacity-10"
                                    }), (0, t.jsx)(O.KI, {
                                        containerClassName: "h-full",
                                        className: "h-full py-5",
                                        children: e.images.map((e, a) => e && (0, t.jsx)(O.d$, {
                                            className: "h-full flex justify-center items-center",
                                            children: (0, t.jsx)("img", {
                                                src: s(e),
                                                alt: "Review",
                                                className: "max-h-full"
                                            })
                                        }, a))
                                    }), (0, t.jsx)(O.Pz, {
                                        className: "bg-transparent border-white  disabled:border-white border-opacity-10 disabled:border-opacity-10 disabled:bg-transparent top-1/2 right-0 xl:right-0 transform -translate-y-1/2 h-8 w-8 xl:h-12 xl:w-12 focus:bg-white focus:border-white focus:bg-opacity-10 hover:bg-white hover:border-white hover:bg-opacity-10"
                                    })]
                                })
                            })]
                        })]
                    })
                };
            var I = s(52123),
                D = s(87019);

            function _(e) {
                let {
                    t: a
                } = (0, d.$G)();
                return (0, t.jsxs)("div", {
                    className: (0, f.cn)("flex items-center gap-1", e.truthy && "text-green-theme", !e.truthy && "text-red-theme"),
                    children: [e.truthy ? (0, t.jsx)(I.Z, {
                        className: "fill-green-theme text-foreground-contrast [&>circle]:stroke-none"
                    }) : (0, t.jsx)(D.Z, {
                        className: "fill-red-theme text-foreground-contrast [&>circle]:stroke-none"
                    }), (0, t.jsx)("span", {
                        className: "text-sm font-medium",
                        children: a(e.truthy ? "Yes" : "No")
                    })]
                })
            }
            var G = s(1798),
                B = s(30758),
                U = s(32029),
                V = s(64093);

            function $(e) {
                let {
                    t: a
                } = (0, d.$G)(), s = [e.fundingCertificateFile].filter(Boolean), l = (0, G.x)();
                return (0, t.jsx)("div", {
                    className: "flex-1 @container",
                    children: (0, t.jsxs)("div", {
                        className: "grid grid-cols-2 @xl:grid-cols-4 @xl:w-fit @xl:justify-self-end gap-2",
                        children: [(0, t.jsx)(z, {
                            title: a("Account Size"),
                            align: "center",
                            children: (0, t.jsx)(B.G, {
                                align: "left",
                                label: (0, U.uf)({
                                    value: e.accountSize,
                                    currency: U.Mf.USD,
                                    notation: "compact"
                                }),
                                minLimit: Math.min(...V.kK),
                                maxLimit: Math.max(...V.kK),
                                value: e.accountSize
                            })
                        }), (0, t.jsx)(z, {
                            title: a("Program"),
                            align: "center",
                            children: e.programType && (0, t.jsx)(v._, {
                                label: l[e.programType]
                            })
                        }), (0, t.jsx)(z, {
                            title: a("Reach Payout"),
                            align: "center",
                            children: (0, t.jsx)(_, {
                                truthy: e.payoutStatus === x.fg.PaidOut
                            })
                        }), (0, t.jsx)(z, {
                            title: a("Certificates"),
                            align: "center",
                            children: (0, t.jsx)(L, {
                                images: s,
                                children: s.length && s[0] ? (0, t.jsx)(E, {
                                    file: s[0],
                                    imagesLength: s.length
                                }) : null
                            })
                        })]
                    })
                })
            }
            var W = s(95726),
                Z = s(97385);
            let H = e => {
                    var a;
                    let {
                        t: s
                    } = (0, d.$G)(), l = [...null !== (a = e.firmCorrespondenceFiles) && void 0 !== a ? a : [], e.fundingCertificateFile].filter(Boolean);
                    return (0, t.jsx)(p.Zb, {
                        variant: "red",
                        rounded: "md",
                        className: "p-3",
                        children: (0, t.jsxs)(p.aY, {
                            className: "flex flex-col p-0 gap-3",
                            children: [(0, t.jsxs)("div", {
                                className: "flex justify-between items-center",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, t.jsx)(N.SI, {
                                        color: "red",
                                        size: "sm"
                                    }), (0, t.jsx)("h2", {
                                        className: "text-white font-semibold",
                                        children: s("Report")
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex gap-2 items-center",
                                    children: [e.reporting === x.AB.PayoutDenial ? (0, t.jsxs)(t.Fragment, {
                                        children: [(0, t.jsx)(K, {
                                            title: s("Denied Amount"),
                                            icon: (0, t.jsx)(N.Nb, {
                                                size: "xxs",
                                                className: "text-red-theme"
                                            }),
                                            children: e.deniedAmount || "N/A"
                                        }), (0, t.jsx)(Z.Separator, {
                                            orientation: "vertical",
                                            className: "h-10"
                                        })]
                                    }) : null, (0, t.jsx)(K, {
                                        title: s("Reason"),
                                        icon: (0, t.jsx)(N.AM, {
                                            color: "red",
                                            size: "xxs"
                                        }),
                                        children: s(e.reporting === x.AB.PayoutDenial ? "Payout Denial" : "Unjustified Breach")
                                    })]
                                })]
                            }), (0, t.jsxs)("div", {
                                className: "space-y-2 sm:space-y-0 sm:grid grid-cols-4 grid-rows-[1fr_1fr] gap-3",
                                children: [(0, t.jsx)(Y, {
                                    title: s(e.reporting === x.AB.PayoutDenial ? "Denied Reason" : "Breach Reason"),
                                    icon: (0, t.jsx)(N.AM, {
                                        color: "red",
                                        size: "xxs"
                                    }),
                                    children: (0, t.jsx)("p", {
                                        className: "text-sm",
                                        children: e.reporting === x.AB.PayoutDenial ? e.denialReason : e.breachReason
                                    })
                                }), (0, t.jsx)(Y, {
                                    title: s("Summary"),
                                    className: "col-span-3 row-span-2",
                                    children: (0, t.jsx)("p", {
                                        className: "text-sm",
                                        children: e.reporting === x.AB.PayoutDenial ? e.denialSummary : e.breachSummary
                                    })
                                }), (0, t.jsx)(Y, {
                                    title: s("Images From Reporter"),
                                    icon: (0, t.jsx)(N.XB, {
                                        color: "red",
                                        size: "xxs"
                                    }),
                                    children: (0, t.jsx)(L, {
                                        images: l,
                                        children: l.length && l[0] ? (0, t.jsx)(E, {
                                            file: l[0],
                                            imagesLength: l.length
                                        }) : null
                                    })
                                })]
                            })]
                        })
                    })
                },
                Y = e => {
                    let {
                        title: a,
                        icon: s,
                        children: l,
                        className: r
                    } = e;
                    return (0, t.jsx)(p.Zb, {
                        variant: "darkRed",
                        rounded: "md",
                        className: (0, f.cn)("p-4", r),
                        children: (0, t.jsxs)(p.aY, {
                            className: "flex flex-col p-0 gap-1",
                            children: [(0, t.jsxs)("div", {
                                className: "flex items-center gap-1",
                                children: [s, (0, t.jsx)("p", {
                                    className: "p-0 text-xs text-foreground-secondary",
                                    children: a
                                })]
                            }), l]
                        })
                    })
                },
                K = e => {
                    let {
                        title: a,
                        icon: s,
                        children: l,
                        className: r
                    } = e;
                    return (0, t.jsx)(p.Zb, {
                        variant: "ghost",
                        rounded: "md",
                        className: (0, f.cn)("p-4", r),
                        children: (0, t.jsxs)(p.aY, {
                            className: "flex flex-col p-0 gap-1",
                            children: [(0, t.jsxs)("div", {
                                className: "flex items-center gap-1",
                                children: [s, (0, t.jsx)("p", {
                                    className: "p-0 text-xs text-foreground-secondary",
                                    children: a
                                })]
                            }), (0, t.jsx)("div", {
                                className: "font-semibold",
                                children: l
                            })]
                        })
                    })
                };
            var X = s(72995),
                J = s(3970);
            let Q = e => {
                    var a, s;
                    let {
                        defaultIsOpen: l = !0,
                        ...r
                    } = e;
                    return (0, t.jsxs)(p.Zb, {
                        rounded: "2xl",
                        className: (0, f.cn)(r.className, "p-5 flex flex-col gap-5"),
                        children: [(0, t.jsx)(p.Ol, {
                            className: "p-0 @container",
                            children: (0, t.jsxs)("div", {
                                className: "flex flex-col @2xl:flex-row gap-5",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex justify-between flex-wrap gap-10 items-center",
                                    children: [(0, t.jsx)(J.b, {
                                        user: r.user
                                    }), (0, t.jsx)(X.ReviewTradersSatisfaction, {
                                        reviewScore: r.overallRating
                                    })]
                                }), (0, t.jsx)($, {
                                    accountSize: r.accountSize,
                                    programType: r.programType,
                                    fundingCertificateFile: r.fundingCertificateFile,
                                    payoutStatus: r.payoutStatus
                                })]
                            })
                        }), (0, t.jsxs)(p.aY, {
                            className: "flex flex-col p-0 gap-5",
                            children: [(0, t.jsx)(h.ReviewCardMessage, {
                                createdAt: r.createdAt,
                                overallSummary: r.overallSummary
                            }), (0, t.jsxs)(i, {
                                defaultIsOpen: l,
                                children: [(0, t.jsxs)("div", {
                                    className: "flex justify-between",
                                    children: [(0, t.jsx)(u, {}), (0, t.jsx)("div", {
                                        className: "flex gap-4",
                                        children: null !== (a = r.actions) && void 0 !== a ? a : null
                                    })]
                                }), (0, t.jsx)(F, { ...r
                                })]
                            }), (r.reporting === x.AB.PayoutDenial || r.reporting === x.AB.UnjustifiedBreach) && (0, t.jsx)(H, {
                                denialReason: r.denialReason,
                                deniedAmount: r.deniedAmount,
                                denialSummary: r.denialSummary,
                                reporting: r.reporting,
                                fundingCertificateFile: r.fundingCertificateFile,
                                firmCorrespondenceFiles: r.firmCorrespondenceFiles,
                                breachReason: r.breachReason,
                                breachSummary: r.breachSummary
                            }), r.firmReply ? (0, t.jsx)(W.U, {
                                firmReply: r.firmReply,
                                firm: r.firm
                            }) : null !== (s = r.replyAction) && void 0 !== s ? s : null]
                        })]
                    })
                },
                q = e => {
                    var a;
                    return (0, t.jsxs)(p.Zb, {
                        rounded: "2xl",
                        className: (0, f.cn)(e.className, "p-5 flex flex-col gap-5 border-none bg-background"),
                        children: [(0, t.jsx)(p.Ol, {
                            className: "p-0",
                            children: (0, t.jsxs)("div", {
                                className: "flex flex-col gap-5",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-wrap gap-10 items-center justify-between",
                                    children: [e.firm && (0, t.jsx)(m.mA, {
                                        size: "lg",
                                        firm: e.firm
                                    }), (0, t.jsx)(X.ReviewTradersSatisfaction, {
                                        reviewScore: e.overallRating
                                    })]
                                }), (0, t.jsx)($, {
                                    accountSize: e.accountSize,
                                    programType: e.programType,
                                    fundingCertificateFile: e.fundingCertificateFile,
                                    payoutStatus: e.payoutStatus
                                })]
                            })
                        }), (0, t.jsxs)(p.aY, {
                            className: "flex flex-col p-0 gap-5",
                            children: [(0, t.jsx)(h.ReviewCardMessage, {
                                createdAt: e.createdAt,
                                overallSummary: e.overallSummary
                            }), (0, t.jsxs)(i, {
                                defaultIsOpen: !0,
                                children: [(0, t.jsxs)("div", {
                                    className: "flex justify-between",
                                    children: [(0, t.jsx)(u, {}), (0, t.jsx)("div", {
                                        className: "flex gap-4",
                                        children: null !== (a = e.actions) && void 0 !== a ? a : null
                                    })]
                                }), (0, t.jsx)(F, { ...e
                                })]
                            })]
                        })]
                    })
                }
        },
        31221: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewReplyActionInput: () => u
            });
            var t = s(12428),
                l = s(85473),
                r = s(93264),
                n = s(6185),
                i = s(40850),
                o = s(5689),
                d = s(23283);
            let c = e => {
                    var a, s, l, r;
                    let {
                        t: c
                    } = (0, n.$G)();
                    return (0, t.jsxs)("div", {
                        className: "relative",
                        children: [(0, t.jsx)(o.g, {
                            value: e.value,
                            className: "py-3 pl-12 pr-10 focus:border-blue-theme",
                            onChange: a => {
                                e.setValue(a.target.value)
                            },
                            disabled: e.disabled,
                            placeholder: null !== (s = e.placeholder) && void 0 !== s ? s : c("Reply message")
                        }), (0, t.jsx)("div", {
                            className: "absolute left-3 top-2 flex h-8 w-8 items-center justify-center rounded-full border border-border bg-background-tertiary",
                            children: (0, t.jsx)(d.Z, {
                                className: "h-5 w-5 text-foreground-tertiary"
                            })
                        }), (0, t.jsx)("div", {
                            className: "mt-3 flex flex-row-reverse",
                            children: (0, t.jsx)(i.zx, {
                                className: "h-8 px-3 py-2",
                                variant: null !== (l = null === (a = e.buttonClassNames) || void 0 === a ? void 0 : a.variant) && void 0 !== l ? l : "pfmBlueGradient",
                                rounded: "full",
                                disabled: e.disabled,
                                onClick: e.onSubmit,
                                children: null !== (r = e.buttonText) && void 0 !== r ? r : c("Reply")
                            })
                        })]
                    })
                },
                u = e => {
                    let [a, s] = (0, r.useState)(""), n = l.trpc.useUtils(), i = l.trpc.protected.reviewActions.reply.useMutation({
                        onSuccess() {
                            n.protected.firmDashboard.listReviews.invalidate()
                        },
                        onError() {
                            n.protected.firmDashboard.listReviews.refetch()
                        }
                    }), o = i.isPending || e.disabled;
                    return (0, t.jsx)(c, {
                        disabled: o,
                        placeholder: e.placeholder,
                        buttonText: e.buttonText,
                        buttonClassNames: e.buttonClassNames,
                        onSubmit: () => {
                            i.mutate({
                                reply: a,
                                reviewId: e.reviewId
                            })
                        },
                        value: a,
                        setValue: s
                    })
                }
        },
        95726: (e, a, s) => {
            s.d(a, {
                U: () => d
            });
            var t = s(12428),
                l = s(6185),
                r = s(69615),
                n = s(74777),
                i = s(37672),
                o = s(5313);
            let d = e => {
                let {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsx)("div", {
                    className: "flex flex-col gap-5",
                    children: (0, t.jsx)(i.Zb, {
                        variant: "secondary",
                        rounded: "md",
                        className: "p-6",
                        children: (0, t.jsxs)(i.aY, {
                            className: "flex flex-col p-0 gap-5 text-xs",
                            children: [(0, t.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [e.firm && (0, t.jsx)(r.mA, {
                                    size: "default",
                                    firm: e.firm
                                }), (0, t.jsxs)(n.C, {
                                    variant: "blue",
                                    size: "chipsSm",
                                    rounded: "full",
                                    children: [(0, t.jsx)(o.js, {
                                        className: "h-4 w-4"
                                    }), a("Verified Firm Profile")]
                                })]
                            }), (0, t.jsx)("p", {
                                className: "text-foreground-secondary",
                                children: a("Replied:")
                            }), (0, t.jsx)("pre", {
                                className: "font-sans",
                                children: e.firmReply
                            })]
                        })
                    })
                })
            }
        },
        72995: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewTradersSatisfaction: () => o
            });
            var t = s(12428),
                l = s(6185),
                r = s(40850),
                n = s(45253),
                i = s(7528);
            let o = e => {
                let {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-2 items-center",
                    children: [(0, t.jsx)(n.$, {
                        size: "lg",
                        toFixed: 1,
                        reviewScore: e.reviewScore
                    }), (0, t.jsxs)("p", {
                        className: "text-xs text-foreground-secondary flex items-center gap-1",
                        children: [a("Trader’s Satisfaction"), (0, t.jsx)(r.zx, {
                            variant: "darkOutline",
                            rounded: "full",
                            size: "icon2Xs",
                            children: (0, t.jsx)(i.Z, {
                                className: "size-3.5 text-foreground-secondary"
                            })
                        })]
                    })]
                })
            }
        },
        3970: (e, a, s) => {
            s.d(a, {
                b: () => c
            });
            var t = s(12428),
                l = s(34298),
                r = s(6185),
                n = s(95805),
                i = s(40850),
                o = s(97385),
                d = s(10488);
            let c = e => {
                var a, s, c, u, m, x, p, f, h, v, g, j, b;
                let {
                    showReviews: y = !0,
                    ...N
                } = e, {
                    t: w
                } = (0, r.$G)();
                return (0, t.jsxs)("div", {
                    className: "flex items-center gap-3",
                    children: [(null === (a = N.user) || void 0 === a ? void 0 : a.profileImageUrl) ? (0, t.jsx)(n.Avatar, {
                        className: "size-12",
                        children: (0, t.jsx)(n.AvatarImage, {
                            src: null === (s = N.user) || void 0 === s ? void 0 : s.profileImageUrl
                        })
                    }) : (0, t.jsx)("div", {
                        className: "flex items-center justify-center bg-border leading-none text-xl font-semibold text-foreground-secondary w-12 md:h-12 rounded-full capitalize",
                        children: "".concat(null === (u = N.user) || void 0 === u ? void 0 : null === (c = u.name) || void 0 === c ? void 0 : c.charAt(0))
                    }), (0, t.jsxs)("div", {
                        className: "flex flex-col gap-1",
                        children: [(0, t.jsx)("span", {
                            className: "font-semibold text-foreground",
                            children: null === (m = N.user) || void 0 === m ? void 0 : m.name
                        }), (0, t.jsxs)("div", {
                            className: "flex items-center",
                            children: [(null === (x = N.user) || void 0 === x ? void 0 : x.country) && (0, t.jsx)(l.X, {
                                country: null === (p = N.user) || void 0 === p ? void 0 : p.country
                            }), y && (null === (f = N.user) || void 0 === f ? void 0 : f.id) && (0, t.jsxs)(t.Fragment, {
                                children: [(0, t.jsx)(o.Separator, {
                                    orientation: "vertical",
                                    className: "h-2 mx-2"
                                }), (null === (v = N.user) || void 0 === v ? void 0 : null === (h = v.reviewStats) || void 0 === h ? void 0 : h.total) ? (0, t.jsx)(d.ReviewsSheet, {
                                    user: N.user,
                                    children: (0, t.jsx)(i.zx, {
                                        type: "button",
                                        variant: "pfmLink",
                                        className: "h-auto p-0 text-xs",
                                        children: w("{{itemsCount}} reviews", {
                                            itemsCount: (null !== (b = null === (j = N.user) || void 0 === j ? void 0 : null === (g = j.reviewStats) || void 0 === g ? void 0 : g.total) && void 0 !== b ? b : 0).toString()
                                        })
                                    })
                                }) : (0, t.jsx)("p", {
                                    className: "text-xs text-foreground-secondary",
                                    children: w("0 reviews")
                                })]
                            })]
                        })]
                    })]
                })
            }
        },
        69066: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewsHeader: () => n
            });
            var t = s(12428),
                l = s(6185),
                r = s(6767);

            function n() {
                let {
                    t: e
                } = (0, l.$G)();
                return (0, t.jsxs)("header", {
                    className: "text-center my-10 py-5",
                    children: [(0, t.jsx)(r.S, {
                        className: "mb-1",
                        children: e("Reviews")
                    }), (0, t.jsx)("p", {
                        className: "text-xs md:text-base text-foreground-secondary max-w-2xl mx-auto",
                        children: e("Over 4,500 real reviews from prop firm traders. Every review is manually verified by our team to ensure authenticity.")
                    })]
                })
            }
        },
        69344: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewsList: () => w
            });
            var t = s(12428),
                l = s(36022),
                r = s(89309),
                n = s(6185),
                i = s(99585),
                o = s(85473),
                d = s(47576),
                c = s(93264),
                u = s(53266),
                m = s(26640),
                x = s(93536),
                p = s(55785),
                f = s(43748),
                h = s(5313),
                v = s(35449),
                g = s(64608);
            let j = e => {
                var a, s;
                let {
                    t: l
                } = (0, n.$G)(), r = o.trpc.useUtils(), i = {
                    onSuccess() {
                        r.review.listReviews.invalidate()
                    },
                    onError() {
                        r.review.listReviews.refetch()
                    }
                }, d = o.trpc.protected.reviewActions.likeReview.useMutation(i), c = o.trpc.protected.reviewActions.unlikeReview.useMutation(i), u = null === (a = e.upvoteProps.userLike) || void 0 === a ? void 0 : a.id, m = d.isPending || c.isPending || e.isFetching, x = (0, g.y1)(() => {
                    u ? c.mutate({
                        reviewId: e.upvoteProps.id
                    }) : d.mutate({
                        reviewId: e.upvoteProps.id
                    })
                }, 300);
                return (0, t.jsx)(f.G7, {
                    variant: u ? "pfmPaleOutline" : "dark",
                    asChild: !0,
                    children: (0, t.jsx)("button", {
                        disabled: m,
                        onClick: x,
                        children: (0, t.jsxs)(f.MB, {
                            className: "px-3 py-2 flex gap-1",
                            children: [m && (0, t.jsx)(v.Z, {
                                className: "size-3 animate-spin"
                            }), (0, t.jsx)(h.lb, {
                                color: u ? "pfmGradient" : "white",
                                size: "xxs"
                            }), (0, t.jsx)("p", {
                                className: "text-xs font-medium",
                                children: l(u ? "Upvoted" : "Upvote")
                            }), (0, t.jsx)("p", {
                                className: "text-xs text-foreground-secondary",
                                children: null !== (s = e.upvoteProps.likesCount) && void 0 !== s ? s : 0
                            })]
                        })
                    })
                })
            };
            var b = s(58652),
                y = s(7986);

            function N(e) {
                var a, s;
                let {
                    t: x
                } = (0, n.$G)(), {
                    slug: f
                } = (0, d.useParams)(), {
                    pagination: h,
                    skip: v,
                    take: g
                } = (0, b.h)(), {
                    sorting: N,
                    onSortingChange: w
                } = (0, r.r)(), [S, {
                    isFetching: C
                }] = o.trpc.review.listReviews.useSuspenseQuery({
                    skip: v,
                    take: g,
                    filter: {
                        firmSlug: f
                    },
                    ...(null == N ? void 0 : null === (a = N[0]) || void 0 === a ? void 0 : a.id) ? {
                        order: {
                            by: N[0].id,
                            direction: N[0].desc ? "desc" : "asc"
                        }
                    } : {}
                }), z = (0, c.useMemo)(() => [{
                    value: i.S.createdAt,
                    label: x("Recent"),
                    desc: !0
                }, {
                    value: i.S.overallRating,
                    label: x("Rating"),
                    desc: !0
                }], [x]);
                return (0, t.jsxs)("div", {
                    className: "space-y-8",
                    children: [(0, t.jsxs)("div", {
                        className: "flex flex-col space-y-5",
                        children: [e.children, (0, t.jsx)(l.j, {
                            count: S.count,
                            sorting: {
                                defaultValue: (null == N ? void 0 : null === (s = N[0]) || void 0 === s ? void 0 : s.id) ? {
                                    value: N[0].id,
                                    desc: N[0].desc
                                } : z[0],
                                options: z,
                                onSortingChange: w
                            },
                            itemsLabel: x("Reviews")
                        }), (0, t.jsx)("div", {
                            className: "flex flex-col gap-4",
                            children: S.count ? S.data.map(e => (0, t.jsx)(m.ReviewCard, { ...e,
                                actions: (0, t.jsxs)(t.Fragment, {
                                    children: [(0, t.jsx)(j, {
                                        upvoteProps: {
                                            id: e.id,
                                            likesCount: e.likesCount,
                                            userLike: e.userLike
                                        },
                                        isFetching: C
                                    }), (0, t.jsx)(p._, {
                                        review: e
                                    })]
                                })
                            }, e.id)) : (0, t.jsx)(u.NoReviewsPlaceholder, {})
                        })]
                    }), S.count > 0 ? (0, t.jsx)(y.h, {
                        page: null == h ? void 0 : h.pageIndex,
                        pageSize: null == h ? void 0 : h.pageSize,
                        totalCount: S.count
                    }) : null]
                })
            }

            function w(e) {
                return (0, t.jsx)(c.Suspense, {
                    fallback: (0, t.jsxs)("div", {
                        className: "space-y-4",
                        children: [(0, t.jsx)(x.$, {}), (0, t.jsx)(x.$, {})]
                    }),
                    children: (0, t.jsx)(N, {
                        children: e.children
                    })
                })
            }
        },
        70816: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewsNavigation: () => d
            });
            var t = s(12428),
                l = s(69615),
                r = s(40850),
                n = s(45253),
                i = s(87071),
                o = s(47576);
            let d = e => {
                var a, s;
                let {
                    firm: d
                } = e, c = (0, o.useRouter)();
                return (0, t.jsxs)("div", {
                    className: "flex items-center gap-8 mb-6",
                    children: [(0, t.jsx)(r.zx, {
                        variant: "outline",
                        rounded: "full",
                        size: "iconLg",
                        onClick: () => c.back(),
                        children: (0, t.jsx)(i.Z, {
                            className: "w-4 h-4"
                        })
                    }), (0, t.jsx)(l.mA, {
                        size: "xl",
                        firm: d,
                        children: (0, t.jsx)(n.$, {
                            reviewScore: null !== (a = null == d ? void 0 : d.reviewScore) && void 0 !== a ? a : 0,
                            reviews: null !== (s = null == d ? void 0 : d.reviewsCount) && void 0 !== s ? s : 0
                        })
                    })]
                })
            }
        },
        10488: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewsSheet: () => c
            });
            var t = s(12428),
                l = s(6185),
                r = s(85473),
                n = s(74607),
                i = s(93264),
                o = s(26640),
                d = s(3970);

            function c(e) {
                let {
                    t: a
                } = (0, l.$G)();
                return (0, t.jsxs)(n.yo, {
                    children: [(0, t.jsx)(n.aM, {
                        asChild: !0,
                        children: e.children
                    }), (0, t.jsxs)(n.Tu, {
                        className: "pb-5 sr-only",
                        children: [(0, t.jsx)(n.bC, {
                            children: a("Reviews")
                        }), (0, t.jsx)(n.Ei, {
                            className: "sr-only",
                            children: a("Reviews")
                        })]
                    }), (0, t.jsx)(n.ue, {
                        className: "w-full max-w-full md:max-w-[768px] mx-auto gap-0 p-10 bg-background-primary",
                        showCloseButton: !0,
                        children: (0, t.jsx)(i.Suspense, {
                            fallback: null,
                            children: (0, t.jsx)(u, {
                                user: e.user
                            })
                        })
                    })]
                })
            }

            function u(e) {
                var a, s;
                let {
                    t: n
                } = (0, l.$G)(), [i] = r.trpc.review.listReviews.useSuspenseQuery({
                    filter: {
                        userId: null !== (s = null === (a = e.user) || void 0 === a ? void 0 : a.id) && void 0 !== s ? s : ""
                    }
                });
                return (0, t.jsxs)("div", {
                    className: "flex flex-col gap-5",
                    children: [(0, t.jsx)(d.b, {
                        showReviews: !1,
                        user: e.user
                    }), (0, t.jsx)("p", {
                        className: "text-lg font-semibold",
                        children: n("Reviews:")
                    }), null == i ? void 0 : i.data.map(e => (0, t.jsx)(o.UserReviewCard, { ...e
                    }, e.id))]
                })
            }
        },
        92087: (e, a, s) => {
            s.r(a), s.d(a, {
                ReviewsTableWrapper: () => Z
            });
            var t, l, r = s(12428),
                n = s(6185),
                i = s(28422),
                o = s(17322),
                d = s(40850),
                c = s(3934),
                u = s(35022),
                m = s(93264),
                x = s(64608),
                p = s(95772),
                f = s(51037),
                h = s(94062),
                v = s(64093),
                g = s(97993),
                j = s(32029),
                b = s(95289);
            ! function(e) {
                e.Today = "today", e.Yesterday = "yesterday", e.Last7Days = "last7Days", e.Last30Days = "last30days", e.Last60Days = "last60days", e.LastYear = "LastYear", e.AllTime = "allTime"
            }(t || (t = {}));
            let y = p.z.object({
                    reviewsAmount: p.z.tuple([p.z.number(), p.z.number()]).optional(),
                    minMaxRating: p.z.tuple([p.z.number(), p.z.number()]).optional(),
                    accountSize: p.z.array(p.z.string()).optional(),
                    numberOfSteps: p.z.array(p.z.string()).optional(),
                    assetType: p.z.array(p.z.string()).optional(),
                    nationality: p.z.string().optional(),
                    tradingExperience: p.z.string().optional(),
                    firmsFundedWith: p.z.tuple([p.z.number(), p.z.number()]).optional(),
                    payoutDenials: p.z.string().optional(),
                    date: p.z.nativeEnum(t).optional()
                }),
                N = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                w = {
                    0: o.HN.Zero,
                    1: o.HN.One,
                    2: o.HN.Two,
                    3: o.HN.Three,
                    4: o.HN.Four,
                    5: o.HN.Five,
                    6: o.HN.Six,
                    7: o.HN.Seven,
                    8: o.HN.Eight,
                    9: o.HN.Nine,
                    10: o.HN.TenPlus
                },
                S = {};
            var C = s(89309),
                z = s(77838),
                k = s(85473),
                R = s(1779),
                P = s(24945),
                T = s(70595),
                F = s(78454),
                A = s(83448),
                O = s(39477),
                M = s(69615),
                E = s(68944),
                L = s(73771),
                I = s(30758),
                D = s(88998),
                _ = s(43748),
                G = s(23743);

            function B(e) {
                return (0, r.jsx)("div", {
                    className: "flex justify-center",
                    children: e.children
                })
            }

            function U(e) {
                var a, s, t, l;
                let {
                    t: o
                } = (0, n.$G)(), d = (0, m.useMemo)(() => [{
                    accessorKey: "name",
                    enableSorting: !0,
                    header: () => o("Firm"),
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, r.jsx)(M.mA, {
                            firm: a.original
                        })
                    }
                }, {
                    accessorKey: "count",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("Number of Reviews"),
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(I.G, {
                            value: null !== (a = s.original.stats.count) && void 0 !== a ? a : 0,
                            minLimit: 0,
                            maxLimit: 200
                        })
                    }
                }, {
                    accessorKey: "tradingConditionsRating",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("Trading Conditions"),
                    cell: e => {
                        var a, s;
                        let {
                            row: t
                        } = e;
                        return (0, r.jsx)(B, {
                            children: (0, r.jsx)(L.S, {
                                rank: null !== (s = null === (a = t.original.stats) || void 0 === a ? void 0 : a.tradingConditionsRating) && void 0 !== s ? s : 0,
                                useStatusColors: !0,
                                lowThreshold: G.zg,
                                highThreshold: G.NN
                            })
                        })
                    }
                }, {
                    accessorKey: "customerCareRating",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("Customer Care"),
                    cell: e => {
                        var a, s;
                        let {
                            row: t
                        } = e;
                        return (0, r.jsx)(B, {
                            children: (0, r.jsx)(L.S, {
                                rank: null !== (s = null === (a = t.original.stats) || void 0 === a ? void 0 : a.customerCareRating) && void 0 !== s ? s : 0,
                                useStatusColors: !0,
                                lowThreshold: G.zg,
                                highThreshold: G.NN
                            })
                        })
                    }
                }, {
                    accessorKey: "dashboardRating",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("User Friendliness"),
                    cell: e => {
                        var a, s;
                        let {
                            row: t
                        } = e;
                        return (0, r.jsx)(B, {
                            children: (0, r.jsx)(L.S, {
                                rank: null !== (s = null === (a = t.original.stats) || void 0 === a ? void 0 : a.dashboardRating) && void 0 !== s ? s : 0,
                                useStatusColors: !0,
                                lowThreshold: G.zg,
                                highThreshold: G.NN
                            })
                        })
                    }
                }, {
                    accessorKey: "credentialsRating",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("Payout Process"),
                    cell: e => {
                        var a, s;
                        let {
                            row: t
                        } = e;
                        return (0, r.jsx)(B, {
                            children: (0, r.jsx)(L.S, {
                                rank: null !== (s = null === (a = t.original.stats) || void 0 === a ? void 0 : a.credentialsRating) && void 0 !== s ? s : 0,
                                useStatusColors: !0,
                                lowThreshold: G.zg,
                                highThreshold: G.NN
                            })
                        })
                    }
                }, {
                    accessorKey: "score",
                    sortDescFirst: !0,
                    enableSorting: !0,
                    header: () => o("Rank"),
                    cell: e => {
                        var a;
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(B, {
                            children: (0, r.jsx)(D.O, {
                                rank: null !== (a = s.original.stats.score) && void 0 !== a ? a : 0
                            })
                        })
                    }
                }, {
                    accessorKey: "actions",
                    header: () => o("Actions"),
                    cell: e => {
                        let {
                            row: a
                        } = e;
                        return (0, r.jsx)(_.G7, {
                            variant: "pfmDarkOutline",
                            asChild: !0,
                            children: (0, r.jsx)(c.default, {
                                href: "/prop-firms/".concat(a.original.slug, "?tab=").concat(E.rr.reviews),
                                children: (0, r.jsx)(_.MB, {
                                    className: "py-2 px-3 text-nowrap",
                                    children: o("View Reviews")
                                })
                            })
                        })
                    }
                }], [o]);
                return (0, r.jsx)(i.tf, {
                    columns: d,
                    data: null !== (t = e.result) && void 0 !== t ? t : [],
                    pinFirstColumn: !1,
                    pinLastColumn: !1,
                    sorting: null === (a = e.sortingHookResult) || void 0 === a ? void 0 : a.sorting,
                    setSorting: null === (s = e.sortingHookResult) || void 0 === s ? void 0 : s.onSortingChange,
                    rowCount: null !== (l = null == e ? void 0 : e.result.length) && void 0 !== l ? l : 0,
                    enableMultiSort: !1,
                    noDataPlaceholder: (0, r.jsx)(i.zP, {})
                })
            }

            function V() {
                let {
                    t: e
                } = (0, n.$G)();
                return (0, r.jsxs)("div", {
                    className: "flex justify-end space-x-4",
                    children: [(0, r.jsxs)("div", {
                        className: "flex justify-center items-center space-x-2 text-green-theme",
                        children: [(0, r.jsx)(R.Z, {
                            className: "fill-green-theme rounded-full size-5 p-1.5 bg-green/30"
                        }), (0, r.jsx)("span", {
                            children: e("Excellent")
                        })]
                    }), (0, r.jsxs)("div", {
                        className: "flex justify-center items-center space-x-2 text-yellow-foreground",
                        children: [(0, r.jsx)(R.Z, {
                            className: "fill-yellow-foreground rounded-full size-5 p-1.5 bg-yellow/30"
                        }), (0, r.jsx)("span", {
                            children: e("Average")
                        })]
                    }), (0, r.jsxs)("div", {
                        className: "flex justify-center items-center space-x-2 text-red-theme",
                        children: [(0, r.jsx)(R.Z, {
                            className: "fill-red-theme text-red-theme rounded-full size-5 p-1.5 bg-red/30"
                        }), (0, r.jsx)("span", {
                            children: e("Low")
                        })]
                    })]
                })
            }

            function $(e) {
                var a, s;
                let l = (0, C.r)(),
                    {
                        t: i
                    } = (0, n.$G)(),
                    d = (0, z.k)(y, S),
                    c = (0, m.useMemo)(() => (function(e) {
                        var a, s, l, r, n, i, d;
                        let {
                            payoutStatus: c,
                            filtersState: u
                        } = e, m = {
                            payoutStatus: c,
                            minRating: null === (a = u.minMaxRating) || void 0 === a ? void 0 : a[0],
                            maxRating: null === (s = u.minMaxRating) || void 0 === s ? void 0 : s[1],
                            dateFrom: (() => {
                                let e = u.date;
                                if (e) switch (e) {
                                    case t.AllTime:
                                        return;
                                    case t.Today:
                                        return (0, P.b)(new Date);
                                    case t.Yesterday:
                                        return (0, P.b)((0, T.k)(new Date, 1));
                                    case t.Last7Days:
                                        return (0, P.b)((0, F.t)(new Date, 1));
                                    case t.Last30Days:
                                        return (0, P.b)((0, A.W)(new Date, 1));
                                    case t.Last60Days:
                                        return (0, P.b)((0, A.W)(new Date, 2));
                                    case t.LastYear:
                                        return (0, P.b)((0, O.e)(new Date, 1));
                                    default:
                                        (0, j.vE)(e)
                                }
                            })(),
                            accountSizeMin: u.accountSize ? Number(null === (l = u.accountSize) || void 0 === l ? void 0 : l[0]) : void 0,
                            accountSizeMax: u.accountSize ? Number(null === (r = u.accountSize) || void 0 === r ? void 0 : r[1]) : void 0,
                            reviewsCountMin: u.reviewsAmount ? Number(null === (n = u.reviewsAmount) || void 0 === n ? void 0 : n[0]) : void 0,
                            reviewsCountMax: u.reviewsAmount ? Number(null === (i = u.reviewsAmount) || void 0 === i ? void 0 : i[1]) : void 0,
                            programs: null === (d = u.numberOfSteps) || void 0 === d ? void 0 : d.filter(e => !!e),
                            payoutDenial: u.payoutDenials ? "true" === u.payoutDenials.toLowerCase() : void 0,
                            assets: u.assetType,
                            firmsFundedWithCount: u.firmsFundedWith ? u.firmsFundedWith.map(e => {
                                var a;
                                return e && null !== (a = w[e]) && void 0 !== a ? a : o.HN.Zero
                            }) : void 0,
                            country: "All" === u.nationality ? void 0 : u.nationality,
                            tradingExperience: u.tradingExperience
                        };
                        return (0, j.gH)(m)
                    })({
                        filtersState: d.filtersState,
                        payoutStatus: e.payoutStatus
                    }), [e.payoutStatus, d.filtersState]),
                    [u, {
                        refetch: x
                    }] = k.trpc.firm.listFirmsWithReviews.useSuspenseQuery({ ...(null === (s = l.sorting) || void 0 === s ? void 0 : null === (a = s[0]) || void 0 === a ? void 0 : a.id) ? {
                            order: {
                                by: l.sorting[0].id,
                                direction: l.sorting[0].desc ? "desc" : "asc"
                            }
                        } : {},
                        filter: c
                    }),
                    p = (0, m.useMemo)(() => u ? u.reduce((e, a) => e + (a.stats.count || 0), 0).toString() : "", [u]);
                return (0, r.jsxs)("div", {
                    className: "space-y-5",
                    children: [(0, r.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, r.jsxs)("div", {
                            className: "font-semibold space-x-1",
                            children: [(0, r.jsx)("span", {
                                children: i("Reviews")
                            }), (0, r.jsx)("span", {
                                className: "text-primary-theme",
                                children: p
                            })]
                        }), (0, r.jsx)(V, {})]
                    }), (0, r.jsx)(U, {
                        result: u,
                        refetch: x,
                        sortingHookResult: l
                    })]
                })
            }

            function W() {
                var e;
                let {
                    t: a
                } = (0, n.$G)(), [s, t] = (0, u.v1)("filters", (0, u.WJ)(y.parse).withDefault({})), [l, o] = (0, m.useState)(null !== (e = s.reviewsAmount) && void 0 !== e ? e : [80, 500]), d = (0, m.useCallback)(e => 500 === e ? "500+" : e.toString(), []), c = (0, m.useMemo)(() => ({
                    min: 0,
                    max: 500
                }), []), p = (0, x.y1)(e => {
                    t(a => ({ ...a,
                        reviewsAmount: e
                    }))
                }, 300);
                return (0, r.jsx)(i.Yr, {
                    label: a("Amount of Reviews"),
                    labelTransformer: d,
                    onChange: e => {
                        o(e), p(e)
                    },
                    sliderProps: c,
                    value: l
                })
            }

            function Z(e) {
                let {
                    t: a
                } = (0, n.$G)(), [s, t] = (0, u.v1)("type", p.z.nativeEnum(l).default("all")), x = (0, m.useMemo)(() => [{
                    value: "all",
                    label: a("All Reviews")
                }, {
                    value: "funded",
                    label: a("Funded Only")
                }, {
                    value: "payed-out",
                    label: a("Paid Out Only")
                }], [a]);
                return (0, r.jsxs)("div", {
                    className: "space-y-5 mb-16",
                    children: [(0, r.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, r.jsx)(i.ew, {
                            extendedFilter: {
                                defaultOpen: !1,
                                onOpenChange: () => {}
                            },
                            quickFilters: {
                                items: x,
                                onQuickFilterChange: e => t(e),
                                defaultValue: null != s ? s : "all"
                            },
                            otherFilters: (0, r.jsx)(W, {})
                        }), !e.hidePostButton && (0, r.jsx)(d.zx, {
                            variant: "pfmGradient",
                            rounded: "full",
                            asChild: !0,
                            children: (0, r.jsx)(c.default, {
                                href: "/reviews/submit",
                                children: a("Post a Review")
                            })
                        })]
                    }), (0, r.jsx)(i.F_, {
                        filtersHookResult: function() {
                            let {
                                t: e
                            } = (0, n.$G)(), [a, s] = (0, u.v1)("filters", (0, u.WJ)(y.parse).withDefault({})), t = (0, f.e)();
                            return {
                                filters: (0, m.useMemo)(() => (0, h.g)(y, [(0, i.rV)({
                                    name: "minMaxRating",
                                    label: e("Min/Max Rating"),
                                    sliderProps: {
                                        min: 1,
                                        max: 5
                                    }
                                }), (0, i.rV)({
                                    name: "accountSize",
                                    label: e("Account Size"),
                                    sliderProps: {
                                        min: Math.min(...v.kK),
                                        max: Math.max(...v.kK),
                                        steps: v.kK
                                    },
                                    labelTransformer: e => (0, j.uf)({
                                        value: e,
                                        currency: j.Mf.USD,
                                        notation: "compact"
                                    })
                                }), (0, i.On)({
                                    name: "numberOfSteps",
                                    label: e("Number Of Steps"),
                                    options: [{
                                        value: o.oi.Instant,
                                        label: e("Instant")
                                    }, {
                                        value: o.oi.OneStep,
                                        label: e("1 Step")
                                    }, {
                                        value: o.oi.TwoSteps,
                                        label: e("2 Steps")
                                    }, {
                                        value: o.oi.ThreeSteps,
                                        label: e("3 Steps")
                                    }, {
                                        value: o.oi.FourSteps,
                                        label: e("4 Steps")
                                    }]
                                }), (0, i.On)({
                                    name: "assetType",
                                    label: e("Asset Type"),
                                    options: [o.fo.FX, o.fo.Energy, o.fo.Stocks, o.fo.Crypto, o.fo.Indices, o.fo.Metals, o.fo.OtherCommodities].map(e => ({
                                        value: e,
                                        label: t[e]
                                    }))
                                }), (0, i.i2)({
                                    name: "nationality",
                                    label: e("Nationality"),
                                    options: [{
                                        value: "All",
                                        label: "All"
                                    }, ...j.$Y.map(e => ({
                                        value: e.isoAlpha2,
                                        label: e.name
                                    }))]
                                }), (0, i.On)({
                                    name: "tradingExperience",
                                    label: e("Trading Experience"),
                                    multiple: !1,
                                    options: [o.Kg["0-3M"], o.Kg["4-12M"], o.Kg["1-2Y"], o.Kg["3-5Y"], o.Kg["5Y+"]].map(e => ({
                                        value: e,
                                        label: e
                                    }))
                                }), (0, i.rV)({
                                    name: "firmsFundedWith",
                                    label: e("Amount Of Firms Funded With"),
                                    sliderProps: {
                                        min: Math.min(...N),
                                        max: Math.max(...N)
                                    },
                                    labelTransformer: e => {
                                        var a;
                                        return null !== (a = w[e]) && void 0 !== a ? a : ""
                                    }
                                }), {
                                    name: "payoutDenials",
                                    render: a => (0, r.jsx)(b.Qr, {
                                        name: "payoutDenials",
                                        control: a,
                                        render: a => {
                                            var s;
                                            let {
                                                field: t
                                            } = a;
                                            return (0, r.jsxs)("div", {
                                                className: "flex items-center space-x-3",
                                                children: [(0, r.jsx)(g.r, {
                                                    size: "sm",
                                                    checked: (null === (s = t.value) || void 0 === s ? void 0 : s.toLowerCase()) === "true",
                                                    onCheckedChange: e => {
                                                        t.onChange(e.toString())
                                                    }
                                                }), (0, r.jsx)("label", {
                                                    className: "text-xs font-semibold",
                                                    children: e("Payout Denials")
                                                })]
                                            })
                                        }
                                    })
                                }, (0, i.On)({
                                    name: "date",
                                    label: e("Date"),
                                    multiple: !1,
                                    options: [{
                                        value: "today",
                                        label: e("Today")
                                    }, {
                                        value: "yesterday",
                                        label: e("Yesterday")
                                    }, {
                                        value: "last7Days",
                                        label: e("Last 7 Days")
                                    }, {
                                        value: "last30days",
                                        label: e("Last 30 Days")
                                    }, {
                                        value: "last60days",
                                        label: e("Last 60 Days")
                                    }, {
                                        value: "LastYear",
                                        label: e("365 Days")
                                    }, {
                                        value: "allTime",
                                        label: e("All Time")
                                    }]
                                })]), [t, e]),
                                filtersState: a,
                                setFiltersState: s
                            }
                        }(),
                        children: (0, r.jsx)(m.Suspense, {
                            fallback: null,
                            children: (0, r.jsx)($, {
                                payoutStatus: "funded" === s ? o.fg.Funded : "payed-out" === s ? o.fg.PaidOut : void 0
                            })
                        })
                    })]
                })
            }! function(e) {
                e.All = "all", e.Funded = "funded", e.PayedOut = "payed-out"
            }(l || (l = {}))
        },
        55785: (e, a, s) => {
            s.d(a, {
                _: () => c
            });
            var t = s(12428),
                l = s(6185),
                r = s(49433),
                n = s(17322),
                i = s(40850),
                o = s(5313),
                d = s(8311);

            function c(e) {
                var a, s, c;
                let {
                    user: u
                } = (0, r.aF)(), {
                    t: m
                } = (0, l.$G)();
                return (null === (a = e.review.user) || void 0 === a ? void 0 : a.id) && (null == u ? void 0 : u.id) === (null === (s = e.review.user) || void 0 === s ? void 0 : s.id) && (null === (c = e.review.firm) || void 0 === c ? void 0 : c.listingStatus) === n.Xt.Listed ? (0, t.jsx)(t.Fragment, {
                    children: (0, t.jsx)(d.ShareReviewModal, {
                        review: e.review,
                        children: (0, t.jsxs)(i.zx, {
                            variant: "dark",
                            rounded: "full",
                            size: "sm",
                            className: "py-2 px-3 h-auto",
                            "aria-label": m("Share review"),
                            children: [(0, t.jsx)(o.XR, {
                                className: "w-3 h-3 mr-2"
                            }), (0, t.jsx)("p", {
                                className: "text-xs font-medium",
                                children: m("Share")
                            })]
                        })
                    })
                }) : null
            }
        },
        8311: (e, a, s) => {
            s.d(a, {
                ShareReviewModal: () => F
            });
            var t = s(12428),
                l = s(14892);

            function r(e) {
                return (0, t.jsx)("img", {
                    alt: "facebook-logo",
                    src: "/facebook-logo.svg",
                    className: e.className
                })
            }
            var n = s(45151),
                i = s(54328),
                o = s(6185),
                d = s(79859),
                c = s(96997),
                u = s(40850),
                m = s(92006),
                x = s(33656),
                p = s(59957),
                f = s(32029),
                h = s(95289);
            let v = c.oi.pick({
                handle: !0
            });

            function g(e) {
                var a, s, l;
                let {
                    t: c
                } = (0, o.$G)(), g = (0, h.cI)({
                    resolver: (0, d.F)(v),
                    defaultValues: {
                        handle: ""
                    }
                }), j = a => {
                    let s = g.getValues("handle");
                    if (!s) return;
                    let t = () => {
                        switch (a) {
                            case "twitter":
                                return "https://x.com/intent/post?url=".concat(encodeURIComponent(e.url), "&text=").concat(encodeURIComponent(e.text));
                            case "facebook":
                                return "https://www.facebook.com/sharer/sharer.php?u=".concat(encodeURIComponent(e.url));
                            case "instagram":
                                return "https://instagram.com/";
                            default:
                                (0, f.vE)(a)
                        }
                    };
                    e.onShare(s, a), setTimeout(() => {
                        let e = t();
                        window.open(e, "_blank")
                    }, 100)
                };
                return (0, t.jsx)("div", {
                    className: "space-y-4",
                    children: (0, t.jsx)(m.l0, { ...g,
                        children: (0, t.jsxs)("form", {
                            onSubmit: g.handleSubmit(() => {}),
                            className: "space-y-6",
                            children: [(0, t.jsx)(x.P, {
                                control: g.control,
                                name: "handle",
                                label: c("Social Handle"),
                                render: e => {
                                    let {
                                        field: a
                                    } = e;
                                    return (0, t.jsx)(p.I, { ...a,
                                        type: "text",
                                        placeholder: c("@handle")
                                    })
                                }
                            }), e.children, (0, t.jsxs)("div", {
                                className: "flex flex-col xs:flex-row xs:space-x-4 space-y-2 xs:space-y-0",
                                children: [(!(null === (a = e.platforms) || void 0 === a ? void 0 : a.length) || e.platforms.includes("twitter")) && (0, t.jsxs)(u.zx, {
                                    disabled: e.disabled,
                                    type: "button",
                                    variant: "outline",
                                    rounded: "full",
                                    className: "flex-1",
                                    onClick: () => j("twitter"),
                                    children: [(0, t.jsx)(i.B, {
                                        className: "w-3.5 h-3.5 mr-2 pointer-events-none"
                                    }), c("Twitter")]
                                }), (!(null === (s = e.platforms) || void 0 === s ? void 0 : s.length) || e.platforms.includes("facebook")) && (0, t.jsxs)(u.zx, {
                                    disabled: e.disabled,
                                    type: "button",
                                    variant: "outline",
                                    rounded: "full",
                                    className: "flex-1",
                                    onClick: () => j("facebook"),
                                    children: [(0, t.jsx)(r, {
                                        className: "w-3.5 h-3.5 mr-2 pointer-events-none"
                                    }), c("Facebook")]
                                }), (!(null === (l = e.platforms) || void 0 === l ? void 0 : l.length) || e.platforms.includes("instagram")) && (0, t.jsxs)(u.zx, {
                                    disabled: e.disabled,
                                    type: "button",
                                    variant: "outline",
                                    rounded: "full",
                                    className: "flex-1",
                                    onClick: () => j("instagram"),
                                    children: [(0, t.jsx)(n.K, {
                                        className: "w-3.5 h-3.5 mr-2 pointer-events-none"
                                    }), c("Instagram")]
                                })]
                            })]
                        })
                    })
                })
            }
            var j = s(98661),
                b = s(85473),
                y = s(27708),
                N = s(24040),
                w = s(37672),
                S = s(1456),
                C = s(40798),
                z = s(62993),
                k = s(35449),
                R = s(93264),
                P = s(95772),
                T = s(64677);

            function F(e) {
                var a, s;
                let {
                    t: r
                } = (0, o.$G)(), n = (0, N.lA)(), i = (0, j.mM)(), [d, u] = (0, R.useState)(!1), [m, x] = (0, R.useState)(!1), [p, f] = (0, R.useState)(!0), {
                    toast: h
                } = (0, C.pm)(), v = b.trpc.protected.userLoyaltyPoints.claimShareReview.useMutation({
                    onSuccess() {
                        x(!0)
                    },
                    onError(e) {
                        h({
                            title: r("Share Failed"),
                            description: e.message
                        })
                    }
                }), [F, A] = (0, R.useState)({
                    wide: null,
                    square: null
                });
                (0, R.useEffect)(() => {
                    let a = async () => {
                        try {
                            let a = await fetch("".concat(i.NEXT_PUBLIC_STORAGE_SERVICE_URL, "/review/generate-images/").concat(e.review.id), {
                                    method: "POST"
                                }),
                                s = await a.json(),
                                t = P.z.object({
                                    shareImageSquare: y.AR.nullable(),
                                    shareImageWide: y.AR.nullable()
                                }).safeParse(s);
                            t.success && A({
                                square: t.data.shareImageSquare,
                                wide: t.data.shareImageWide
                            })
                        } catch (e) {
                            console.error(e)
                        } finally {
                            f(!1)
                        }
                    };
                    e.review.id && d && p && a()
                }, [e.review.id, d, p, i.NEXT_PUBLIC_STORAGE_SERVICE_URL]);
                let O = (0, R.useMemo)(() => ({
                    [l.AspectRatioEnum.SQUARE]: F.square,
                    [l.AspectRatioEnum.WIDE]: F.wide
                }), [F]);
                return (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsxs)(S.Vq, {
                        open: d,
                        onOpenChange: e => u(e),
                        children: [(0, t.jsx)(S.hg, {
                            asChild: !0,
                            children: e.children
                        }), (0, t.jsxs)(S.cZ, {
                            className: "w-full max-w-[440px] mx-auto gap-0 p-5",
                            children: [(0, t.jsxs)(S.fK, {
                                className: "pb-5",
                                children: [(0, t.jsx)(S.$N, {
                                    children: r("Share Review")
                                }), (0, t.jsx)(S.Be, {
                                    className: "sr-only",
                                    children: r("Share Review")
                                })]
                            }), (0, t.jsxs)("div", {
                                className: "space-y-5",
                                children: [(0, t.jsx)(w.Zb, {
                                    className: "overflow-hidden flex items-center justify-center h-[250px]",
                                    children: !p && F.wide ? (0, t.jsx)("img", {
                                        alt: r("Review preview"),
                                        className: "h-full w-full",
                                        src: n.getFileReadUrl(F.wide)
                                    }) : (0, t.jsx)(k.Z, {
                                        "aria-label": r("Loading search results"),
                                        className: (0, z.cn)("animate-spin"),
                                        role: "status"
                                    })
                                }), (0, t.jsx)("p", {
                                    className: "text-foreground-secondary text-sm",
                                    children: r("To redeem {{ points }} Loyalty Points on your first shared review, please enter the social handle for the account you will be sharing with. Any subsequently shared reviews for the month will be awarded 50 points.", {
                                        points: c.ww.SHARE_REVIEW
                                    })
                                }), (0, t.jsx)("p", {
                                    className: "text-foreground-secondary text-sm",
                                    children: r("We are unable to verify these submissions of your account is private. Please allow up to 48 hours for your shared review to be verified.")
                                }), (0, t.jsx)(g, {
                                    url: "".concat(i.NEXT_PUBLIC_MAIN_WEBSITE_URL, "/prop-firm-reviews/").concat(e.review.id, "/share"),
                                    text: r("Check out my recent review on @PropFirmMatch for {{ firm }}", {
                                        firm: null !== (s = null === (a = e.review.firm) || void 0 === a ? void 0 : a.name) && void 0 !== s ? s : ""
                                    }),
                                    disabled: p,
                                    onShare: (a, s) => v.mutate({
                                        handle: a,
                                        platform: s,
                                        reviewId: e.review.id
                                    })
                                })]
                            }), (0, t.jsx)(S.cN, {
                                className: "pt-5 w-full",
                                children: (0, t.jsx)(l.D, {
                                    images: O
                                })
                            })]
                        })]
                    }), (0, t.jsx)(T.he, {
                        heading: r("Your Review Has Been Shared"),
                        onOpenChange: x,
                        open: m,
                        subHeading: r("Thank you for your feedback! We appreciate your support."),
                        title: r("Share Review")
                    })]
                })
            }
        },
        23743: (e, a, s) => {
            s.d(a, {
                NN: () => l,
                nu: () => r,
                zg: () => t
            });
            let t = 4,
                l = 4.5,
                r = 20
        },
        34719: (e, a, s) => {
            s.d(a, {
                $m: () => o.$,
                A7: () => n.ReplyInput,
                AI: () => d.ReviewCardMessage,
                Ak: () => r.ReviewCard,
                HA: () => i.NoReviewsPlaceholder,
                YO: () => c.MinReviewsPlaceholder,
                be: () => l.b,
                jK: () => t.ReviewsList,
                nu: () => u.nu
            }), s(69066), s(92087), s(70816);
            var t = s(69344),
                l = s(3970),
                r = s(26640),
                n = s(53023);
            s(10488), s(31221), s(98682);
            var i = s(53266),
                o = s(93536);
            s(55785), s(95726);
            var d = s(13326);
            s(72995);
            var c = s(4060),
                u = s(23743);
            s(14797), s(49046), s(37201)
        },
        37201: (e, a, s) => {
            s.r(a), s.d(a, {
                EditReviewPage: () => n
            });
            var t = s(12428),
                l = s(21880),
                r = s(49433);

            function n() {
                let {
                    user: e
                } = (0, r.aF)();
                return e ? (0, t.jsx)(l.lo, {}) : null
            }
        },
        14797: (e, a, s) => {
            s.r(a), s.d(a, {
                SubmitReviewLayout: () => l
            });
            var t = s(12428);

            function l(e) {
                return (0, t.jsxs)("div", {
                    className: "container px-0 mx-auto py-8",
                    children: [e.children, " "]
                })
            }
        },
        49046: (e, a, s) => {
            s.r(a), s.d(a, {
                SubmitReviewPage: () => n
            });
            var t = s(12428),
                l = s(21880),
                r = s(49433);

            function n() {
                let {
                    user: e
                } = (0, r.aF)();
                return e ? (0, t.jsx)(l.xX, {}) : null
            }
        },
        64677: (e, a, s) => {
            s.d(a, {
                QQ: () => c,
                TX: () => w,
                fz: () => C,
                YC: () => k,
                he: () => A
            });
            var t, l = s(12428),
                r = s(6185),
                n = s(2691),
                i = s(5313),
                o = s(62993),
                d = s(64741);

            function c(e) {
                let {
                    t: a
                } = (0, r.$G)();
                return (0, l.jsx)(n.UQ, {
                    type: "single",
                    collapsible: !0,
                    className: (0, o.cn)("flex text-sm", e.className),
                    children: (0, l.jsxs)(n.Qd, {
                        value: "item-1",
                        className: "flex text-sm border-b-0 text-foreground-secondary w-full",
                        children: [(0, l.jsx)(i.Ab, {
                            className: "text-primary-theme mr-2 size-5"
                        }), (0, l.jsxs)("div", {
                            className: "w-full [&_.prose]:max-w-full",
                            children: [(0, l.jsx)("b", {
                                className: "text-white",
                                children: a("System Warning:")
                            }), (0, l.jsx)(d.$, {
                                markdown: e.visibleText,
                                className: "text-sm text-foreground-secondary"
                            }), e.moreText && (0, l.jsxs)("div", {
                                children: [(0, l.jsx)(n.vF, {
                                    className: "pb-0",
                                    children: (0, l.jsx)(d.$, {
                                        markdown: e.moreText,
                                        className: "text-sm text-foreground-secondary"
                                    })
                                }), (0, l.jsx)(n.o4, {
                                    className: "p-0 flex-none text-primary-theme",
                                    chevronClassName: "text-primary-theme stroke-primary-theme group-data-[state=open]:stroke-primary-theme",
                                    children: a("Read More")
                                })]
                            })]
                        })]
                    })
                })
            }
            var u = s(34719),
                m = s(49433),
                x = s(40850),
                p = s(37672),
                f = s(46354),
                h = s(43748),
                v = s(5689),
                g = s(40798),
                j = s(23029),
                b = s(68698),
                y = s(98541),
                N = s(93264);

            function w(e) {
                var a;
                let {
                    t: s
                } = (0, r.$G)(), [t, n] = (0, N.useState)(e.message), {
                    toast: i
                } = (0, g.pm)(), o = (0, m.aF)(), d = (0, N.useMemo)(() => {
                    if (o.user) {
                        var a;
                        return o.user.id === (null === (a = e.user) || void 0 === a ? void 0 : a.id)
                    }
                    return !1
                }, [o.user, null === (a = e.user) || void 0 === a ? void 0 : a.id]), c = async () => {
                    try {
                        await e.onUpdate(t), e.refetchData(), e.setEditing(!1)
                    } catch (e) {
                        i({
                            variant: "destructive",
                            title: s("There was an error updating the comment.")
                        })
                    }
                };
                return (0, l.jsxs)(p.Zb, {
                    className: "p-5 rounded-2xl space-y-5",
                    children: [(0, l.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, l.jsx)(u.be, {
                            user: e.user,
                            showReviews: !1
                        }), d ? (0, l.jsxs)(f.h_, {
                            children: [(0, l.jsx)(f.$F, {
                                asChild: !0,
                                children: (0, l.jsx)(x.zx, {
                                    variant: "ghost",
                                    size: "icon",
                                    children: (0, l.jsx)(j.Z, {})
                                })
                            }), (0, l.jsxs)(f.AW, {
                                className: "p-1",
                                children: [(0, l.jsxs)(f.Xi, {
                                    onClick: () => e.setEditing(!0),
                                    className: "text-foreground-secondary",
                                    children: [(0, l.jsx)(f.KM, {
                                        className: "ml-0 mr-1.5",
                                        children: (0, l.jsx)(b.Z, {
                                            className: "w-4"
                                        })
                                    }), s("Edit")]
                                }), (0, l.jsxs)(f.Xi, {
                                    onClick: e.onDelete,
                                    className: "text-red-theme",
                                    children: [(0, l.jsx)(f.KM, {
                                        className: "ml-0 mr-1.5",
                                        children: (0, l.jsx)(y.Z, {
                                            className: "w-4"
                                        })
                                    }), s("Delete")]
                                })]
                            })]
                        }) : null, e.deleteDialog]
                    }), e.editing ? (0, l.jsxs)("div", {
                        className: "space-y-3",
                        children: [(0, l.jsx)(h.G7, {
                            variant: "pfm",
                            className: "rounded-md",
                            children: (0, l.jsx)(h.MB, {
                                className: "cursor-pointer bg-background hover:bg-background-secondary",
                                children: (0, l.jsx)(v.g, {
                                    className: "px-6 pt-6 pb-0 min-h-[70px]",
                                    value: t,
                                    onChange: e => n(e.target.value),
                                    placeholder: s("Enter a comment"),
                                    rows: 1
                                })
                            })
                        }), (0, l.jsxs)("div", {
                            className: "flex justify-end gap-4",
                            children: [(0, l.jsx)(x.zx, {
                                className: "py-2 px-3",
                                variant: "darkOutline",
                                onClick: () => e.setEditing(!1),
                                children: s("Cancel")
                            }), (0, l.jsx)(x.zx, {
                                className: "py-2 px-3",
                                variant: "pfmGradient",
                                rounded: "full",
                                onClick: c,
                                children: s("Save")
                            })]
                        })]
                    }) : (0, l.jsx)(u.AI, {
                        createdAt: e.createdAt,
                        overallSummary: e.message
                    })]
                })
            }
            var S = s(35449);

            function C() {
                return (0, l.jsx)("div", {
                    className: "absolute top-0 bg-background-secondary/70 flex items-center justify-center w-full h-full rounded-[inherit]",
                    children: (0, l.jsx)(S.Z, {
                        className: "w-4 h-4 animate-spin text-foreground-secondary"
                    })
                })
            }
            var z = s(58365);

            function k(e) {
                let {
                    section: a,
                    setActiveSection: s,
                    activeSection: t,
                    offset: r = -100,
                    className: n
                } = e;
                return (0, l.jsx)(z.rU, {
                    to: a.id,
                    spy: !0,
                    smooth: !0,
                    offset: r,
                    duration: 300,
                    onSetActive: () => s(a.id),
                    className: (0, o.cn)("cursor-pointer text-sm transition-all whitespace-nowrap pt-2 lg:pt-0", t === a.id ? "border-b-2 lg:border-b-0 lg:border-l-2 border-primary-theme font-semibold pb-2 lg:pl-4 lg:pb-0" : "text-foreground-tertiary", n),
                    children: a.name
                })
            }
            var R = s(1456),
                P = s(45258),
                T = s(25845),
                F = s(12351);

            function A(e) {
                let {
                    heading: a,
                    onOpenChange: s,
                    open: t,
                    sectionImportant: n,
                    subHeading: o,
                    title: d
                } = e, {
                    t: c
                } = (0, r.$G)();
                return (0, l.jsx)(R.Vq, {
                    open: t,
                    onOpenChange: e => s(e),
                    children: (0, l.jsxs)(R.cZ, {
                        hideCloseButton: !0,
                        className: "max-w-[440px] p-5 gap-0 md:rounded-2xl rounded-2xl",
                        children: [(0, l.jsxs)(R.fK, {
                            className: "flex flex-row items-center justify-between pb-5",
                            children: [(0, l.jsx)(P.$N, {
                                className: "text-lg font-semibold",
                                children: d
                            }), (0, l.jsx)(R.GG, {
                                children: (0, l.jsx)(T.Z, {
                                    className: "text-foreground-secondary size-4"
                                })
                            })]
                        }), (0, l.jsxs)(R.a7, {
                            className: "py-10 flex flex-col items-center justify-center space-y-10",
                            children: [(0, l.jsx)(i.iM, {
                                className: "size-20"
                            }), (0, l.jsxs)("div", {
                                className: "text-center px-3",
                                children: [(0, l.jsx)(P.Be, {
                                    className: "leading-[45px] text-4xl font-semibold font-serif mb-2",
                                    children: a
                                }), (0, l.jsx)("p", {
                                    className: "text-foreground-secondary text-base",
                                    children: o
                                }), n ? (0, l.jsxs)("div", {
                                    className: "mt-4 rounded-md bg-[image:var(--pfm-gradient-10)] p-4",
                                    children: [(0, l.jsxs)("div", {
                                        className: "flex items-center justify-start gap-2 text-primary-theme mb-4",
                                        children: [(0, l.jsx)(F.Z, {
                                            className: "size-4"
                                        }), (0, l.jsx)("span", {
                                            className: "text-xs",
                                            children: n.title
                                        })]
                                    }), n.node]
                                }) : null]
                            })]
                        }), (0, l.jsx)(R.cN, {
                            children: (0, l.jsx)(x.zx, {
                                className: "flex-1 mt-5",
                                onClick: () => s(!1),
                                rounded: "full",
                                variant: "pfmGradient",
                                children: c("Close")
                            })
                        })]
                    })
                })
            }! function(e) {
                e.general = "general", e.reviews = "reviews", e.announcements = "announcements", e.challenges = "challenges", e.promos = "promos", e.payouts = "payouts", e.other = "other"
            }(t || (t = {}))
        },
        1798: (e, a, s) => {
            s.d(a, {
                x: () => n
            });
            var t = s(6185),
                l = s(17322),
                r = s(93264);

            function n() {
                let {
                    t: e
                } = (0, t.$G)();
                return (0, r.useMemo)(() => ({
                    [l.oi.Instant]: e("Instant"),
                    [l.oi.OneStep]: e("1 Step"),
                    [l.oi.TwoSteps]: e("2 Steps"),
                    [l.oi.ThreeSteps]: e("3 Steps"),
                    [l.oi.FourSteps]: e("4 Steps")
                }), [e])
            }
        },
        80501: (e, a, s) => {
            s.d(a, {
                z: () => r
            });
            var t = s(6185),
                l = s(17322);

            function r() {
                let {
                    t: e
                } = (0, t.$G)();
                return {
                    [l.wJ.BalanceBased]: e("Balance Based"),
                    [l.wJ.EquityBased]: e("Equity Based"),
                    [l.wJ.BalanceEquityHighestAtEod]: e("Balance/Equity - Highest at EOD"),
                    [l.wJ.TrailingHighestBalanceEquity]: e("Trailing Highest Balance/Equity")
                }
            }
        },
        51131: (e, a, s) => {
            s.d(a, {
                f: () => x
            });
            var t = s(12428),
                l = s(93264),
                r = s(6185),
                n = s(95262),
                i = s(56360),
                o = s(62993),
                d = s(5313);
            let c = {
                default: {
                    initial: -15,
                    animate: 9,
                    exit: -15
                },
                lg: {
                    initial: -30,
                    animate: 0,
                    exit: -30
                },
                xs: {
                    initial: -15,
                    animate: 4,
                    exit: -15
                }
            };

            function u(e) {
                var a, s, l;
                return (0, t.jsxs)("span", {
                    className: (0, o.cn)("inline-flex items-center ml-1 md:w-4 md:h-4 w-3 h-3", e.className),
                    children: [!e.isCopied && (0, t.jsx)(d.TI, {
                        className: (0, o.cn)("md:size-4 size-3 inline text-primary-theme", e.iconsClassName)
                    }), (0, t.jsx)(n.M, {
                        children: e.isCopied && (0, t.jsx)(i.E.div, {
                            initial: {
                                opacity: 0,
                                y: c[null !== (a = e.size) && void 0 !== a ? a : "default"].initial
                            },
                            animate: {
                                opacity: 1,
                                y: c[null !== (s = e.size) && void 0 !== s ? s : "default"].animate
                            },
                            exit: {
                                opacity: 0,
                                y: c[null !== (l = e.size) && void 0 !== l ? l : "default"].exit
                            },
                            transition: {
                                type: "spring",
                                stiffness: 500,
                                damping: 20
                            },
                            className: (0, o.cn)("absolute top-0 md:right-3", e.motionClassName),
                            children: (0, t.jsx)(d.lb, {
                                className: (0, o.cn)("md:size-4 size-3", e.iconsClassName)
                            })
                        }, "thumb-up")
                    })]
                })
            }
            var m = s(47576);

            function x(e) {
                var a, s;
                let {
                    btnClassName: n,
                    children: i,
                    codeClassName: d,
                    value: c,
                    ...x
                } = e, {
                    t: p
                } = (0, r.$G)(), f = (0, m.usePathname)().replace(/^\//, ""), [h, v] = (0, l.useState)(!1);
                return (0, t.jsxs)("button", {
                    "aria-label": p("Copy promo code"),
                    "data-url": f || "/",
                    "data-firm-slug": null !== (a = x.firmSlug) && void 0 !== a ? a : "",
                    "data-id": null !== (s = x.id) && void 0 !== s ? s : "",
                    className: (0, o.cn)("relative flex w-full items-center justify-center rounded-lg bg-background", n),
                    onClick: () => {
                        navigator.clipboard.writeText(c).then(() => {
                            v(!0), setTimeout(() => v(!1), 1e3)
                        }).catch(() => {})
                    },
                    title: p("Copy promo code"),
                    children: [i, (0, t.jsxs)("div", {
                        className: "flex items-center",
                        children: [(0, t.jsx)("span", {
                            className: (0, o.cn)("text-xxs font-semibold", d),
                            children: c || "N/A"
                        }), (0, t.jsx)(u, { ...x,
                            isCopied: h
                        })]
                    })]
                })
            }
        },
        99585: (e, a, s) => {
            s.d(a, {
                S: () => t
            });
            var t, l = s(17322),
                r = s(32029),
                n = s(95772);
            ! function(e) {
                e.id = "id", e.tradingConditionsRating = "tradingConditionsRating", e.dashboardRating = "dashboardRating", e.credentialsRating = "credentialsRating", e.customerCareRating = "customerCareRating", e.overallRating = "overallRating", e.createdAt = "createdAt"
            }(t || (t = {}));
            let i = n.z.object({
                    by: n.z.enum(["id", "tradingConditionsRating", "dashboardRating", "credentialsRating", "customerCareRating", "overallRating", "createdAt"]),
                    direction: n.z.enum(["asc", "desc"])
                }),
                o = n.z.object({
                    firmId: n.z.string().optional(),
                    firmSlug: n.z.string().optional(),
                    userId: n.z.string().optional(),
                    statuses: n.z.nativeEnum(l.ny).array().optional()
                });
            n.z.object({
                search: n.z.string().optional(),
                order: i.optional(),
                filter: o.optional()
            }).merge(r.jq)
        },
        27708: (e, a, s) => {
            s.d(a, {
                Rg: () => r,
                M1: () => i,
                V9: () => l,
                J7: () => t,
                AR: () => c
            });
            let t = "/storage/private";
            ! function(e) {
                e.AVI = "AVI", e.BMP = "BMP", e.CSV = "CSV", e.DOC = "DOC", e.DOCX = "DOCX", e.EPS = "EPS", e.GIF = "GIF", e.HEIC = "HEIC", e.JPG = "JPG", e.JSON = "JSON", e.KEY = "KEY", e.MOV = "MOV", e.MP4 = "MP4", e.MPEG = "MPEG", e.MSG = "MSG", e.ODP = "ODP", e.PDF = "PDF", e.PNG = "PNG", e.PPT = "PPT", e.PPTX = "PPTX", e.RAR = "RAR", e.SVG = "SVG", e.TIFF = "TIFF", e.TXT = "TXT", e.WEBP = "WEBP", e.XLS = "XLS", e.XLSX = "XLSX", e.ZIP = "ZIP"
            }(n || (n = {}));
            let l = {
                    GIF: "GIF",
                    HEIC: "HEIC",
                    JPG: "JPG",
                    PNG: "PNG",
                    SVG: "SVG",
                    TIFF: "TIFF",
                    WEBP: "WEBP"
                },
                r = {
                    AVI: ["video/avi"],
                    BMP: ["image/bmp"],
                    CSV: ["text/csv"],
                    DOC: ["application/msword"],
                    DOCX: ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
                    EPS: ["image/eps", "application/postscript"],
                    GIF: ["image/gif"],
                    HEIC: ["image/heic"],
                    JPG: ["image/jpeg", "image/jpg"],
                    JSON: ["application/json"],
                    KEY: ["application/vnd.apple.keynote"],
                    MOV: ["video/quicktime"],
                    MP4: ["video/mp4"],
                    MPEG: ["video/mpeg"],
                    MSG: ["application/vnd.ms-outlook", ".msg"],
                    ODP: ["application/vnd.oasis.opendocument.presentation"],
                    PDF: ["application/pdf"],
                    PNG: ["image/png"],
                    PPT: ["application/vnd.ms-powerpoint"],
                    PPTX: ["application/vnd.openxmlformats-officedocument.presentationml.presentation"],
                    RAR: ["application/rar", "application/x-rar-compressed"],
                    SVG: ["image/svg+xml"],
                    TIFF: ["image/tiff"],
                    TXT: ["text/plain"],
                    WEBP: ["image/webp"],
                    XLS: ["application/vnd.ms-excel"],
                    XLSX: ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
                    ZIP: ["application/zip", "application/x-zip-compressed"]
                };
            Object.values(l).map(e => r[e]).flat(),
                function(e) {
                    e.PUBLIC = "PUBLIC", e.PRIVATE = "PRIVATE"
                }(i || (i = {}));
            var n, i, o = s(95772);
            let d = {
                accessType: o.ZP.nativeEnum(i),
                name: o.ZP.string(),
                path: o.ZP.string(),
                type: o.ZP.string()
            };
            o.ZP.object({
                userId: o.ZP.string().min(1),
                randomId: o.ZP.string().min(1),
                accessType: o.ZP.nativeEnum(i)
            });
            let c = o.ZP.object(d)
        },
        24040: (e, a, s) => {
            s.d(a, {
                Mw: () => o,
                FL: () => m,
                lA: () => i
            });
            var t = s(12428),
                l = s(93264),
                r = s(27708);
            let n = (0, l.createContext)({
                storageServiceUrl: "",
                mediaServiceUrl: "",
                privateFileToken: "",
                getFileUploadUrl: () => Promise.resolve(""),
                getFileReadUrl: () => ""
            });

            function i() {
                return (0, l.useContext)(n)
            }

            function o(e) {
                return (0, t.jsx)(n.Provider, {
                    value: { ...e,
                        getFileReadUrl: a => a.accessType === r.M1.PUBLIC ? "".concat(e.mediaServiceUrl, "/").concat(a.path) : e.privateFileToken ? "".concat(e.storageServiceUrl).concat(r.J7, "/").concat(a.path, "?token=").concat(e.privateFileToken) : ""
                    },
                    children: e.children
                })
            }
            var d = s(25809),
                c = s(25236),
                u = s(77815);

            function m(e) {
                let a = (0, l.useRef)(null),
                    {
                        t: s
                    } = (0, u.$G)(),
                    [t, n] = (0, l.useState)(!1),
                    i = (0, l.useMemo)(() => e.allowedExtensions.map(e => r.Rg[e]).flat(), [e.allowedExtensions]),
                    o = (0, l.useCallback)(s => {
                        e.onError({
                            message: s
                        }), a.current && (a.current.value = "")
                    }, [e]),
                    m = (0, l.useCallback)(e => {
                        if (i.length && !i.includes(e)) throw s("Unsupported file type")
                    }, [i, s]),
                    x = (0, l.useCallback)(a => {
                        if (e.maxSizeKB && a > 1e3 * e.maxSizeKB) throw s("Maximum file size is {{max}} kb", {
                            max: e.maxSizeKB
                        })
                    }, [e.maxSizeKB, s]),
                    p = (0, l.useCallback)(async t => {
                        try {
                            n(!0);
                            let l = await e.getFileUploadUrl({
                                accessType: e.accessType
                            });
                            if (!l) throw s("Something went wrong");
                            m(t.type), x(t.size);
                            let r = new FormData;
                            r.append("Content-Type", t.type), r.append("file", t);
                            let i = await fetch(l, {
                                method: "POST",
                                body: r,
                                headers: {
                                    Accept: "application/json",
                                    Authorization: c.Z.get("__session")
                                }
                            });
                            if (!i.ok) throw s("Failed to upload file.");
                            let o = {
                                path: (await i.json()).path,
                                type: t.type,
                                name: t.name,
                                accessType: e.accessType
                            };
                            e.onChange(o), e.resetAfterUpload && a.current && (a.current.value = "")
                        } catch (e) {
                            "string" == typeof e ? o(e) : o(s("Something went wrong..."))
                        }
                        n(!1)
                    }, [o, e, s, x, m]),
                    f = (0, l.useCallback)(e => {
                        let a = e.target.files ? e.target.files[0] : null;
                        a && p(a)
                    }, [p]),
                    h = (0, l.useMemo)(() => (0, d.Mc)(), []);
                return {
                    uploadFile: p,
                    loading: t,
                    inputProps: {
                        onChange: f,
                        ref: a,
                        type: "file",
                        accept: i.length ? i.join(",") : "",
                        id: h
                    }
                }
            }
        },
        96997: (e, a, s) => {
            s.d(a, {
                    oi: () => c,
                    MA: () => f,
                    ww: () => p
                }),
                function(e) {
                    e.CREDIT = "CREDIT", e.DEBIT = "DEBIT"
                }(t || (t = {})),
                function(e) {
                    e.INITIAL_SETUP = "INITIAL_SETUP", e.COMPLETE_ONBOARDING = "COMPLETE_ONBOARDING", e.FOLLOW_TWITTER = "FOLLOW_TWITTER", e.FOLLOW_FACEBOOK = "FOLLOW_FACEBOOK", e.FOLLOW_INSTAGRAM = "FOLLOW_INSTAGRAM", e.FOLLOW_YOUTUBE = "FOLLOW_YOUTUBE", e.FOLLOW_TIKTOK = "FOLLOW_TIKTOK", e.FOLLOW_TELEGRAM = "FOLLOW_TELEGRAM", e.JOIN_PROPTALK = "JOIN_PROPTALK", e.SHARE_REVIEW = "SHARE_REVIEW", e.SHARE_ACCOUNT_REDEMPTION = "SHARE_ACCOUNT_REDEMPTION", e.ADMIN_CREDIT_ADJUSTMENT = "ADMIN_CREDIT_ADJUSTMENT", e.DECLINED_ACCOUNT_REDEMPTION = "DECLINED_ACCOUNT_REDEMPTION", e.CLAIM_ACCOUNT_REDEMPTION = "CLAIM_ACCOUNT_REDEMPTION"
                }(l || (l = {})),
                function(e) {
                    e.PURCHASE_ACCOUNT_REDEMPTION = "PURCHASE_ACCOUNT_REDEMPTION", e.ADMIN_DEBIT_ADJUSTMENT = "ADMIN_DEBIT_ADJUSTMENT"
                }(r || (r = {})),
                function(e) {
                    e.ADMIN = "ADMIN", e.SYSTEM = "SYSTEM"
                }(n || (n = {}));
            var t, l, r, n, i = s(95772),
                o = s(27708);
            let d = i.z.object({
                    accountSize: i.z.number(),
                    affiliateCode: i.z.string().optional().nullable(),
                    firmId: i.z.string(),
                    firmReceipt: o.AR,
                    promoCode: i.z.string().optional().nullable(),
                    requestPropFirmOne: i.z.boolean().optional().nullable()
                }),
                c = i.z.object({
                    handle: i.z.string(),
                    reviewId: i.z.string(),
                    platform: i.z.enum(["twitter", "facebook", "instagram"])
                }),
                u = c.pick({
                    handle: !0
                }).merge(i.z.object({
                    accountRedemptionEventId: i.z.string(),
                    platform: i.z.literal("twitter")
                })),
                m = i.z.object({
                    handle: i.z.string().min(1),
                    platform: i.z.enum([l.FOLLOW_TWITTER, l.FOLLOW_FACEBOOK, l.FOLLOW_INSTAGRAM, l.FOLLOW_TELEGRAM, l.FOLLOW_TIKTOK, l.FOLLOW_YOUTUBE, l.JOIN_PROPTALK]),
                    confirmation: o.AR
                }),
                x = i.z.object({
                    accountSize: i.z.number(),
                    challengeId: i.z.string()
                });
            i.z.union([i.z.object({
                type: i.z.literal(l.COMPLETE_ONBOARDING),
                metadata: i.z.object({}).optional().nullable()
            }), i.z.object({
                type: i.z.union([i.z.literal(l.FOLLOW_TWITTER), i.z.literal(l.FOLLOW_FACEBOOK), i.z.literal(l.FOLLOW_INSTAGRAM), i.z.literal(l.FOLLOW_TELEGRAM), i.z.literal(l.FOLLOW_TIKTOK), i.z.literal(l.FOLLOW_YOUTUBE), i.z.literal(l.JOIN_PROPTALK)]),
                metadata: m
            }), i.z.object({
                type: i.z.literal(r.PURCHASE_ACCOUNT_REDEMPTION),
                metadata: x.merge(i.z.object({
                    challengeName: i.z.string(),
                    firmName: i.z.string()
                }))
            }), i.z.object({
                type: i.z.literal(l.CLAIM_ACCOUNT_REDEMPTION),
                metadata: d.merge(i.z.object({
                    firmName: i.z.string()
                }))
            }), i.z.object({
                type: i.z.literal(l.SHARE_REVIEW),
                metadata: c.merge(i.z.object({
                    reviewId: i.z.string().optional()
                }))
            }), i.z.object({
                type: i.z.literal(l.SHARE_ACCOUNT_REDEMPTION),
                metadata: u.omit({
                    platform: !0
                }).merge(c.pick({
                    platform: !0
                }))
            })]);
            let p = {
                [l.ADMIN_CREDIT_ADJUSTMENT]: null,
                [l.INITIAL_SETUP]: null,
                [l.DECLINED_ACCOUNT_REDEMPTION]: null,
                [l.COMPLETE_ONBOARDING]: 200,
                [l.FOLLOW_FACEBOOK]: 100,
                [l.FOLLOW_INSTAGRAM]: 150,
                [l.FOLLOW_TIKTOK]: 100,
                [l.FOLLOW_TWITTER]: 150,
                [l.FOLLOW_YOUTUBE]: 100,
                [l.FOLLOW_TELEGRAM]: 100,
                [l.JOIN_PROPTALK]: 100,
                [l.SHARE_REVIEW]: 200,
                [l.SHARE_ACCOUNT_REDEMPTION]: 500,
                [l.CLAIM_ACCOUNT_REDEMPTION]: null
            };
            l.FOLLOW_TWITTER, l.FOLLOW_INSTAGRAM, l.FOLLOW_YOUTUBE, l.FOLLOW_TIKTOK, l.FOLLOW_FACEBOOK, l.FOLLOW_TELEGRAM, l.JOIN_PROPTALK;
            let f = [{
                cost: 2e3,
                accountSize: 5e3
            }, {
                cost: 4e3,
                accountSize: 1e4
            }, {
                cost: 7e3,
                accountSize: 25e3
            }, {
                cost: 1e4,
                accountSize: 5e4
            }, {
                cost: 16e3,
                accountSize: 1e5
            }, {
                cost: 28e3,
                accountSize: 2e5
            }, {
                cost: 42e3,
                accountSize: 3e5
            }, {
                cost: 56e3,
                accountSize: 4e5
            }, {
                cost: 8e4,
                accountSize: 5e5
            }]
        },
        64093: (e, a, s) => {
            s.d(a, {
                kK: () => l,
                Ue: () => d,
                ce: () => n,
                ar: () => r,
                iX: () => u
            });
            var t = s(17322);
            let l = [0, 1e3, 2e3, 5e3, 6e3, 8e3, 1e4, 12e3, 12500, 15e3, 2e4, 25e3, 3e4, 4e4, 5e4, 6e4, 85e3, 1e5, 12e4, 15e4, 2e5, 24e4, 25e4, 3e5, 4e5, 5e5, 1e6, 2e6],
                r = e => ({
                    [t.x3.LessThanOneMonth]: e("Less 1 Month"),
                    [t.x3.OneMonthPlus]: e("1 Month +"),
                    [t.x3.ThreeMonthsPlus]: e("3 Months +"),
                    [t.x3.SixMonthsPlus]: e("6 Months +"),
                    [t.x3.OneYearPlus]: e("1 Year +"),
                    [t.x3.ThreeYearsPlus]: e("3 Years +")
                }),
                n = e => ({
                    [t.fg.Funded]: e("No"),
                    [t.fg.PaidOut]: e("Yes"),
                    [t.fg.Pending]: e("Pending")
                });
            var i = s(27708),
                o = s(95772);
            let d = o.z.object({
                firm: o.z.discriminatedUnion("type", [o.z.object({
                    type: o.z.literal(t.Nf.known),
                    firmId: o.z.string().min(1),
                    listingStatus: o.z.nativeEnum(t.Xt)
                }), o.z.object({
                    type: o.z.literal(t.Nf.unknown),
                    firmName: o.z.string().min(1)
                })]),
                accountSize: o.z.number().int().nonnegative(),
                programType: o.z.nativeEnum(t.oi),
                customerCareRating: o.z.number().int().min(1).max(5),
                tradingConditionsRating: o.z.number().int().min(1).max(5),
                dashboardRating: o.z.number().int().min(1).max(5),
                credentialsRating: o.z.number().int().min(1).max(5),
                overallRating: o.z.number().int().min(1).max(5),
                overallSummary: o.z.string().min(150),
                orderConfirmationFile: i.AR,
                reporting: o.z.discriminatedUnion("type", [o.z.object({
                    type: o.z.literal(t.AB.No)
                }), o.z.object({
                    type: o.z.literal(t.AB.PayoutDenial),
                    fundingCertificateFile: i.AR,
                    deniedAmount: o.z.string(),
                    denialReason: o.z.string().min(1),
                    denialSummary: o.z.string().min(1),
                    firmCorrespondenceFiles: o.z.array(i.AR).min(1)
                }), o.z.object({
                    type: o.z.literal(t.AB.UnjustifiedBreach),
                    breachReason: o.z.string().min(1),
                    breachSummary: o.z.string().min(1),
                    firmCorrespondenceFiles: o.z.array(i.AR).min(1)
                })]),
                likedMostAboutFirm: o.z.string(),
                likedLeastAboutFirm: o.z.string()
            });
            var c = s(32029);
            o.z.object({
                search: o.z.string().optional(),
                filter: o.z.object({
                    statuses: o.z.nativeEnum(t.ny).array().optional(),
                    firmIds: o.z.string().array().optional(),
                    flagged: o.z.boolean().optional(),
                    funded: o.z.boolean().optional(),
                    reporting: o.z.nativeEnum(t.AB).optional(),
                    payoutStatus: o.z.nativeEnum(t.fg).optional(),
                    advancedQuery: o.z.any()
                }).optional(),
                order: o.z.object({
                    by: o.z.enum(["createdAt", "overallRating"]),
                    direction: o.z.nativeEnum(c.sh)
                }).optional()
            }).merge(c.jq);
            let u = o.z.object({
                reviewId: o.z.string(),
                fundingCertificateFile: i.AR,
                stillFunded: o.z.nativeEnum(t.P4),
                fundedPeriod: o.z.nativeEnum(t.x3),
                payouts: o.z.discriminatedUnion("payoutsReceived", [o.z.object({
                    payoutsReceived: o.z.literal(t.P4.Yes),
                    payoutsReceivedCount: o.z.nativeEnum(t.HN),
                    payoutsFiles: o.z.array(i.AR).min(1)
                }), o.z.object({
                    payoutsReceived: o.z.literal(t.P4.No)
                })]),
                payoutStatus: o.z.nativeEnum(t.fg),
                twitterHandle: o.z.string().optional(),
                firmsFundedWithCount: o.z.nativeEnum(t.HN),
                profileImage: i.AR
            });
            o.z.object({
                id: o.z.string(),
                authorName: o.z.string().optional().nullable(),
                fundingDetails: o.z.discriminatedUnion("pass", [o.z.object({
                    pass: o.z.literal(t.P4.No)
                }), o.z.object({
                    pass: o.z.literal(t.P4.Yes)
                }).merge(u.omit({
                    reviewId: !0
                }))])
            }).merge(d.pick({
                accountSize: !0,
                credentialsRating: !0,
                customerCareRating: !0,
                dashboardRating: !0,
                likedLeastAboutFirm: !0,
                likedMostAboutFirm: !0,
                orderConfirmationFile: !0,
                overallRating: !0,
                overallSummary: !0,
                programType: !0,
                reporting: !0,
                tradingConditionsRating: !0
            }))
        },
        5178: (e, a, s) => {
            s.d(a, {
                Tz: () => l.PropFirmSelectInline,
                _P: () => t.PropFirmSelect
            });
            var t = s(60654),
                l = s(57502);
            s(68448), s(93521)
        },
        33656: (e, a, s) => {
            s.d(a, {
                P: () => n
            });
            var t = s(12428),
                l = s(92006),
                r = s(62993);
            let n = e => {
                let {
                    label: a,
                    rightLabel: s,
                    description: n,
                    render: i,
                    className: o,
                    hideErrorMessage: d,
                    ...c
                } = e;
                return (0, t.jsx)(l.Wi, { ...c,
                    render: e => (0, t.jsxs)(l.xJ, {
                        className: (0, r.cn)("group", o),
                        "data-error": !!e.fieldState.error,
                        "data-success": e.formState.isSubmitSuccessful,
                        children: [(0, t.jsxs)("div", {
                            className: "flex justify-between",
                            children: [a && (0, t.jsx)(l.lX, {
                                className: "text-nowrap",
                                children: a
                            }), s && (0, t.jsx)(l.lX, {
                                className: "text-nowrap",
                                children: s
                            })]
                        }), (0, t.jsx)(l.NI, {
                            children: i(e)
                        }), n && (0, t.jsx)(l.pf, {
                            children: n
                        }), d ? null : (0, t.jsx)(l.zG, {})]
                    })
                })
            }
        },
        56764: (e, a, s) => {
            s.d(a, {
                r: () => x
            });
            var t = s(12428),
                l = s(93745),
                r = s(51581),
                n = s(68586),
                i = s(73951),
                o = s(93264),
                d = s(62993),
                c = s(20842);
            let u = {
                    xs: "MMM d",
                    shortMonth: "MMM d, yyyy",
                    short: "PPP",
                    long: "PPp",
                    relative: "",
                    relativeShort: "",
                    fullDay: "EEEE, d MMMM",
                    full: "yyyy/MM/dd HH:mm:ss"
                },
                m = e => {
                    let a = (0, o.useMemo)(() => "string" == typeof e.date ? new Date(e.date.includes("T") ? e.date.endsWith("Z") ? e.date : e.date + "Z" : e.date) : e.date, [e.date]),
                        s = (0, o.useCallback)(e => {
                            let a = new Date,
                                s = (0, l._)(a, e),
                                t = Math.round(s / 1e3 / 60),
                                r = Math.round(s / 1e3 / 60 / 60),
                                n = Math.round(s / 1e3 / 60 / 60 / 24),
                                i = Math.round(s / 1e3 / 60 / 60 / 24 / 7),
                                o = Math.round(s / 1e3 / 60 / 60 / 24 / 30),
                                d = Math.round(s / 1e3 / 60 / 60 / 24 / 365);
                            return r < 1 ? "".concat(t, "min") : r < 12 ? "".concat(r, "h") : r < 24 ? "today" : n < 7 ? "".concat(n, "d") : i < 4 ? "".concat(i, "w") : o < 12 ? "".concat(n, "d") : "".concat(d, "y")
                        }, []);
                    if (!a) return "-";
                    if ("relativeShort" === e.variant) return s(a);
                    if ("relative" === e.variant) {
                        let s = e.leftDate ? new Date(e.leftDate) : new Date,
                            t = (0, r.j)(s, a);
                        return t > 14 ? (0, n.WU)(a, "PP") : t > 2 ? (0, n.WU)(a, "PPPP") : (0, i.H)(a, s, {
                            addSuffix: !0
                        })
                    }
                    return (0, n.WU)(a, u[e.variant])
                },
                x = e => {
                    let {
                        date: a,
                        leftDate: s,
                        format: l = "short",
                        asString: r,
                        className: i
                    } = e, o = m({
                        date: a,
                        leftDate: s,
                        variant: l
                    });
                    return o ? r ? o : (0, t.jsx)(c.TooltipProvider, {
                        children: (0, t.jsxs)(c.Tooltip, {
                            delayDuration: 300,
                            children: [(0, t.jsx)(c.TooltipTrigger, {
                                asChild: !0,
                                children: (0, t.jsx)("span", {
                                    className: (0, d.cn)("whitespace-nowrap", i),
                                    children: o
                                })
                            }), a && (0, t.jsx)(c.TooltipContent, {
                                children: (0, n.WU)(new Date(a), "PPpp")
                            })]
                        })
                    }) : null
                }
        },
        64741: (e, a, s) => {
            s.d(a, {
                $: () => d
            });
            var t = s(12428),
                l = s(93264),
                r = s(2197),
                n = s(977),
                i = s(62993),
                o = s(20533);

            function d(e) {
                let a = (0, l.useRef)(),
                    [d, c] = (0, l.useState)(!1);
                return ((0, l.useEffect)(() => {
                    (async function() {
                        let e = await s.e(4874).then(s.bind(s, 34874));
                        a.current = e.default, c(!0)
                    })()
                }, []), d && a.current) ? (0, t.jsx)(a.current, {
                    className: (0, i.cn)("prose dark:prose-dark", e.className),
                    remarkPlugins: [r.Z, n.Z],
                    children: e.markdown
                }) : (0, t.jsx)(o.O, {
                    className: "h-8 w-full"
                })
            }
        },
        2691: (e, a, s) => {
            s.d(a, {
                Qd: () => d,
                UQ: () => o,
                o4: () => c,
                vF: () => u
            });
            var t = s(12428),
                l = s(11650),
                r = s(30455),
                n = s(93264),
                i = s(62993);
            let o = l.fC,
                d = n.forwardRef((e, a) => {
                    let {
                        className: s,
                        ...r
                    } = e;
                    return (0, t.jsx)(l.ck, {
                        ref: a,
                        className: (0, i.cn)("border-b", s),
                        ...r
                    })
                });
            d.displayName = "AccordionItem";
            let c = n.forwardRef((e, a) => {
                let {
                    className: s,
                    chevronClassName: n,
                    children: o,
                    ...d
                } = e;
                return (0, t.jsx)(l.h4, {
                    className: "flex",
                    children: (0, t.jsxs)(l.xz, {
                        ref: a,
                        className: (0, i.cn)("flex flex-1 items-center justify-between py-4 font-medium transition-all hover:underline [&[data-state=open]>svg]:rotate-180 group text-left", s),
                        ...d,
                        children: [o, (0, t.jsx)(r.Z, {
                            className: (0, i.cn)("h-4 w-4 shrink-0 transition-transform duration-200 group-data-[state=open]:stroke-foreground stroke-foreground-secondary", n)
                        })]
                    })
                })
            });
            c.displayName = l.xz.displayName;
            let u = n.forwardRef((e, a) => {
                let {
                    className: s,
                    children: r,
                    ...n
                } = e;
                return (0, t.jsx)(l.VY, {
                    ref: a,
                    className: "overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
                    ...n,
                    children: (0, t.jsx)("div", {
                        className: (0, i.cn)("pb-4 pt-0", s),
                        children: r
                    })
                })
            });
            u.displayName = l.VY.displayName
        },
        74777: (e, a, s) => {
            s.d(a, {
                C: () => o
            });
            var t = s(12428),
                l = s(51699),
                r = s(93264),
                n = s(62993);
            let i = (0, l.j)("inline-flex items-center px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
                    variants: {
                        variant: {
                            default: "bg-primary-theme text-foreground hover:bg-primary-hover focus:bg-primary-focus",
                            primary: "bg-primary text-primary-foreground hover:bg-primary/80",
                            secondary: "border-transparent bg-dark text-foreground-secondary hover:bg-dark/80",
                            red: "border-transparent bg-red/30 text-red-foreground hover:bg-red/80",
                            pink: "border-transparent bg-primary hover:bg-primary-focus text-primary-foreground",
                            destructiveDark: "border-transparent bg-red text-red-foreground hover:bg-red/80",
                            destructive: "border-transparent bg-red-theme text-red-foreground hover:bg-red-theme/80",
                            destructiveOutline: "border border-red-theme text-red-theme hover:bg-red-hover hover:text-foreground hover:border-transparent",
                            yellow: "bg-yellow/30 text-yellow-foreground hover:bg-yellow/80",
                            yellowHighlight: "bg-yellow  text-yellow-foreground hover:bg-yellow/30",
                            green: "border-transparent bg-green/30 text-green-foreground hover:bg-green/80",
                            greenDark: "border-transparent bg-green text-green-foreground hover:bg-green/80",
                            indigo: "bg-indigo text-indigo-foreground hover:bg-indigo/80",
                            purple: "bg-purple text-purple-foreground hover:bg-purple/80",
                            blue: "bg-blue text-blue-foreground hover:bg-blue/80",
                            outline: "text-foreground border border-foreground hover:bg-foreground/10"
                        },
                        size: {
                            sm: "h-5 px-3 p-1 [&_svg]:w-3 [&_svg]:h-3",
                            default: "h-6 px-3 py-1 [&_svg]:w-4 [&_svg]:h-4",
                            md: "h-[22px] px-1.5 py-0.5 [&_svg]:w-4 [&_svg]:h-4 leading-normal tracking-[0.5px]",
                            icon: "w-6 h-6 p-1 flex items-center justify-center rounded-full",
                            chipsXxs: "px-2 py-0.5",
                            chipsXs: "px-2.5 py-0.5",
                            chipsSm: "px-3 py-1.5 [&_svg]:size-3 [&_svg]:mr-1.5",
                            chips: "px-4 py-1.5",
                            chipXxs: "px-[6px] py-[2px] [&_svg]:size-2 [&_svg]:mr-1.5"
                        },
                        rounded: {
                            default: "rounded-md",
                            full: "rounded-full"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default",
                        rounded: "default"
                    }
                }),
                o = r.forwardRef((e, a) => {
                    let {
                        className: s,
                        variant: l,
                        size: r,
                        leftIcon: o,
                        rightIcon: d,
                        rounded: c,
                        children: u,
                        ...m
                    } = e;
                    return (0, t.jsx)("div", {
                        className: (0, n.cn)(i({
                            variant: l,
                            size: r,
                            rounded: c,
                            className: s
                        })),
                        ref: a,
                        ...m,
                        children: (0, t.jsxs)(t.Fragment, {
                            children: [o && (0, t.jsx)("span", {
                                className: "mr-2",
                                children: o
                            }), u, d && (0, t.jsx)("span", {
                                className: "ml-2",
                                children: d
                            })]
                        })
                    })
                });
            o.displayName = "Badge"
        },
        37672: (e, a, s) => {
            s.d(a, {
                Ol: () => d,
                SZ: () => u,
                Zb: () => o,
                aY: () => m,
                eW: () => x,
                ll: () => c
            });
            var t = s(12428),
                l = s(51699),
                r = s(93264),
                n = s(62993);
            let i = (0, l.j)("border bg-card text-card-foreground shadow-sm", {
                    variants: {
                        variant: {
                            default: "",
                            red: "border-red/30 bg-red/10",
                            darkRed: "border-none shadow-none bg-red/30",
                            secondary: "border-none bg-background-secondary",
                            ghost: "border-none bg-transparent",
                            pfmPale: "border-none bg-[image:var(--pfm-gradient-10)]",
                            pfmBluePale: "border-none bg-[image:var(--pfm-blue-gradient-10)]"
                        },
                        rounded: {
                            default: "rounded-lg",
                            none: "rounded-none",
                            sm: "rounded-sm",
                            md: "rounded-md",
                            lg: "rounded-lg",
                            xl: "rounded-xl",
                            "2xl": "rounded-2xl",
                            full: "rounded-full"
                        }
                    },
                    defaultVariants: {
                        rounded: "default",
                        variant: "default"
                    }
                }),
                o = r.forwardRef((e, a) => {
                    let {
                        className: s,
                        rounded: l,
                        variant: r,
                        ...o
                    } = e;
                    return (0, t.jsx)("div", {
                        ref: a,
                        className: (0, n.cn)(i({
                            rounded: l,
                            variant: r
                        }), s),
                        ...o
                    })
                });
            o.displayName = "Card";
            let d = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    ref: a,
                    className: (0, n.cn)("flex flex-col space-y-1.5 p-6", s),
                    ...l
                })
            });
            d.displayName = "CardHeader";
            let c = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("h3", {
                    ref: a,
                    className: (0, n.cn)("text-2xl font-semibold leading-none tracking-tight", s),
                    ...l
                })
            });
            c.displayName = "CardTitle";
            let u = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("p", {
                    ref: a,
                    className: (0, n.cn)("text-sm text-muted-foreground", s),
                    ...l
                })
            });
            u.displayName = "CardDescription";
            let m = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    ref: a,
                    className: (0, n.cn)("p-6 pt-0", s),
                    ...l
                })
            });
            m.displayName = "CardContent";
            let x = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    ref: a,
                    className: (0, n.cn)("flex items-center p-6 pt-0", s),
                    ...l
                })
            });
            x.displayName = "CardFooter"
        },
        31077: (e, a, s) => {
            s.d(a, {
                A0: () => v,
                KI: () => p,
                Pz: () => j,
                am: () => g,
                d$: () => f,
                lr: () => x
            });
            var t = s(12428),
                l = s(76930),
                r = s(60105),
                n = s(62312),
                i = s(93264),
                o = s(62993),
                d = s(40850),
                c = s(51699);
            let u = i.createContext(null);

            function m() {
                let e = i.useContext(u);
                if (!e) throw Error("useCarousel must be used within a <Carousel />");
                return e
            }
            let x = i.forwardRef((e, a) => {
                let {
                    orientation: s = "horizontal",
                    opts: r,
                    setApi: n,
                    plugins: d,
                    className: c,
                    children: m,
                    hideDots: x,
                    ...p
                } = e, [f, h] = (0, l.Z)({ ...r,
                    axis: "horizontal" === s ? "x" : "y"
                }, d), [g, j] = i.useState(!1), [b, y] = i.useState(!1), [N, w] = i.useState(0), S = i.useCallback(e => {
                    e && (j(e.canScrollPrev()), y(e.canScrollNext()), w(e.selectedScrollSnap()))
                }, []), C = i.useCallback(() => {
                    null == h || h.scrollPrev()
                }, [h]), z = i.useCallback(() => {
                    null == h || h.scrollNext()
                }, [h]), k = i.useCallback(e => {
                    "ArrowLeft" === e.key ? (e.preventDefault(), C()) : "ArrowRight" === e.key && (e.preventDefault(), z())
                }, [C, z]), R = i.useCallback(e => {
                    null == h || h.scrollTo(e)
                }, [h]);
                return i.useEffect(() => {
                    h && n && n(h)
                }, [h, n]), i.useEffect(() => {
                    if (h) return S(h), h.on("reInit", S), h.on("select", S), () => {
                        null == h || h.off("select", S)
                    }
                }, [h, S]), (0, t.jsxs)(u.Provider, {
                    value: {
                        carouselRef: f,
                        api: h,
                        opts: r,
                        orientation: s || ((null == r ? void 0 : r.axis) === "y" ? "vertical" : "horizontal"),
                        scrollPrev: C,
                        scrollNext: z,
                        canScrollPrev: g,
                        canScrollNext: b,
                        selectedIndex: N,
                        scrollTo: R
                    },
                    children: [(0, t.jsx)("div", {
                        ref: a,
                        onKeyDownCapture: k,
                        className: (0, o.cn)("relative", c),
                        role: "region",
                        "aria-roledescription": "carousel",
                        ...p,
                        children: m
                    }), !x && (0, t.jsx)(v, {})]
                })
            });
            x.displayName = "Carousel";
            let p = i.forwardRef((e, a) => {
                let {
                    className: s,
                    containerClassName: l,
                    ...r
                } = e, {
                    carouselRef: n,
                    orientation: i
                } = m();
                return (0, t.jsx)("div", {
                    ref: n,
                    className: (0, o.cn)("overflow-hidden", l),
                    children: (0, t.jsx)("div", {
                        ref: a,
                        className: (0, o.cn)("flex", "horizontal" === i ? "-ml-4" : "-mt-4 flex-col", s),
                        ...r
                    })
                })
            });
            p.displayName = "CarouselContent";
            let f = i.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e, {
                    orientation: r
                } = m();
                return (0, t.jsx)("div", {
                    ref: a,
                    role: "group",
                    "aria-roledescription": "slide",
                    className: (0, o.cn)("min-w-0 shrink-0 grow-0 basis-full", "horizontal" === r ? "pl-4" : "pt-4", s),
                    ...l
                })
            });
            f.displayName = "CarouselItem";
            let h = (0, c.j)("flex items-center space-x-2 mb-10 ml-10", {
                    variants: {
                        size: {
                            sm: "[&>div]:size-2 space-x-1 m-0",
                            default: ""
                        }
                    },
                    defaultVariants: {
                        size: "default"
                    }
                }),
                v = i.forwardRef((e, a) => {
                    let {
                        className: s,
                        size: l,
                        ...r
                    } = e, {
                        selectedIndex: n,
                        api: i
                    } = m();
                    return (0, t.jsx)("div", {
                        ref: a,
                        className: (0, o.cn)(h({
                            size: l
                        }), s),
                        children: null == i ? void 0 : i.scrollSnapList().map((e, a) => (0, t.jsx)("div", {
                            className: (0, o.cn)("size-3 bg-background-contrast rounded-full cursor-pointer", a === n ? "bg-background-contrast" : "bg-background-contrast/50"),
                            onClick: () => null == i ? void 0 : i.scrollTo(a),
                            ...r
                        }, a))
                    })
                });
            v.displayName = "CarouselDots";
            let g = i.forwardRef((e, a) => {
                let {
                    className: s,
                    variant: l = "outline",
                    size: n = "icon",
                    ...i
                } = e, {
                    orientation: c,
                    scrollPrev: u,
                    canScrollPrev: x
                } = m();
                return (0, t.jsxs)(d.zx, {
                    ref: a,
                    variant: l,
                    size: n,
                    className: (0, o.cn)("absolute rounded-full", "horizontal" === c ? "-left-12 xl:-left-16 top-1/2 -translate-y-1/2" : "-top-12 xl:-top-16 left-1/2 -translate-x-1/2 rotate-90", s),
                    disabled: !x,
                    onClick: u,
                    ...i,
                    children: [(0, t.jsx)(r.Z, {
                        className: "w-4 h-4 xl:h-8 xl:w-8"
                    }), (0, t.jsx)("span", {
                        className: "sr-only",
                        children: "Previous slide"
                    })]
                })
            });
            g.displayName = "CarouselPrevious";
            let j = i.forwardRef((e, a) => {
                let {
                    className: s,
                    variant: l = "outline",
                    size: r = "icon",
                    ...i
                } = e, {
                    orientation: c,
                    scrollNext: u,
                    canScrollNext: x
                } = m();
                return (0, t.jsxs)(d.zx, {
                    ref: a,
                    variant: l,
                    size: r,
                    className: (0, o.cn)("absolute rounded-full", "horizontal" === c ? "-right-12 xl:-right-16 top-1/2 -translate-y-1/2" : "-bottom-12 xl:-bottom-16 left-1/2 -translate-x-1/2 rotate-90", s),
                    disabled: !x,
                    onClick: u,
                    ...i,
                    children: [(0, t.jsx)(n.Z, {
                        className: "w-4 h-4 xl:h-8 xl:w-8"
                    }), (0, t.jsx)("span", {
                        className: "sr-only",
                        children: "Next slide"
                    })]
                })
            });
            j.displayName = "CarouselNext"
        },
        88785: (e, a, s) => {
            s.d(a, {
                X: () => c
            });
            var t = s(12428),
                l = s(62993),
                r = s(16335),
                n = s(51699),
                i = s(71999),
                o = s(93264);
            let d = (0, n.j)((0, l.cn)("peer inline-flex items-center justify-center shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", "h-4 w-4 rounded-sm border"), {
                    variants: {
                        variant: {
                            default: "ring-offset-background bg-background-secondary hover:bg-background-tertiary data-[state=disabled]:border-secondary data-[state=checked]:bg-primary-theme data-[state=checked]:text-white data-[state=checked]:hover:bg-primary-hover",
                            purple: "ring-offset-background bg-background-secondary hover:bg-background-tertiary data-[state=disabled]:border-secondary data-[state=checked]:bg-purple-theme data-[state=checked]:text-white data-[state=checked]:hover:bg-purple-hover",
                            monochrome: "ring-offset-background bg-background-secondary hover:bg-background-tertiary data-[state=disabled]:border-secondary data-[state=checked]:bg-background-contrast data-[state=checked]:text-foreground-contrast data-[state=checked]:hover:bg-background-contrast/80"
                        }
                    },
                    defaultVariants: {
                        variant: "default"
                    }
                }),
                c = o.forwardRef((e, a) => {
                    let {
                        className: s,
                        variant: n,
                        children: o,
                        checked: c,
                        onCheckedChange: u,
                        rightLabel: m,
                        ...x
                    } = e;
                    return (0, t.jsxs)("label", {
                        className: "flex items-start gap-2",
                        children: [(0, t.jsx)(r.fC, {
                            ref: a,
                            className: (0, l.cn)(d({
                                variant: n
                            }), s),
                            checked: c,
                            onCheckedChange: u,
                            ...x,
                            children: (0, t.jsxs)(r.z$, {
                                className: (0, l.cn)("flex items-center justify-center text-current"),
                                children: [(0, t.jsx)(i.Z, {
                                    className: "h-2.5 w-2.5"
                                }), o]
                            })
                        }), m && (0, t.jsx)("span", {
                            className: "text-xs",
                            children: m
                        })]
                    })
                });
            c.displayName = r.fC.displayName
        },
        44538: (e, a, s) => {
            s.d(a, {
                OX: () => m,
                dy: () => i,
                iI: () => x,
                sc: () => u,
                u6: () => p,
                uh: () => d
            });
            var t = s(12428),
                l = s(93264),
                r = s(65048),
                n = s(62993);
            let i = e => {
                let {
                    shouldScaleBackground: a = !0,
                    ...s
                } = e;
                return (0, t.jsx)(r.d.Root, {
                    shouldScaleBackground: a,
                    ...s
                })
            };
            i.displayName = "Drawer", r.d.Trigger;
            let o = r.d.Portal,
                d = r.d.Close,
                c = l.forwardRef((e, a) => {
                    let {
                        className: s,
                        ...l
                    } = e;
                    return (0, t.jsx)(r.d.Overlay, {
                        ref: a,
                        className: (0, n.cn)("fixed inset-0 z-50 bg-black/80", s),
                        ...l
                    })
                });
            c.displayName = r.d.Overlay.displayName;
            let u = l.forwardRef((e, a) => {
                let {
                    className: s,
                    children: l,
                    ...i
                } = e;
                return (0, t.jsxs)(o, {
                    children: [(0, t.jsx)(c, {}), (0, t.jsxs)(r.d.Content, {
                        ref: a,
                        className: (0, n.cn)("fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background", s),
                        ...i,
                        children: [(0, t.jsx)("div", {
                            className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted"
                        }), l]
                    })]
                })
            });
            u.displayName = "DrawerContent";
            let m = e => {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, n.cn)("grid gap-1.5 p-4 text-center sm:text-left", a),
                    ...s
                })
            };
            m.displayName = "DrawerHeader";
            let x = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)(r.d.Title, {
                    ref: a,
                    className: (0, n.cn)("text-lg font-semibold leading-none tracking-tight", s),
                    ...l
                })
            });
            x.displayName = r.d.Title.displayName;
            let p = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)(r.d.Description, {
                    ref: a,
                    className: (0, n.cn)("text-sm text-muted-foreground", s),
                    ...l
                })
            });
            p.displayName = r.d.Description.displayName
        },
        46354: (e, a, s) => {
            s.d(a, {
                $F: () => u,
                AW: () => m,
                Ju: () => p,
                KM: () => h,
                VD: () => f,
                Xi: () => x,
                h_: () => c
            });
            var t = s(12428),
                l = s(62196),
                r = s(62312),
                n = s(71999),
                i = s(1779),
                o = s(93264),
                d = s(62993);
            let c = l.fC,
                u = l.xz;
            l.ZA, l.Uv, l.Tr, l.Ee, o.forwardRef((e, a) => {
                let {
                    className: s,
                    inset: n,
                    children: i,
                    ...o
                } = e;
                return (0, t.jsxs)(l.fF, {
                    ref: a,
                    className: (0, d.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent", n && "pl-8", s),
                    ...o,
                    children: [i, (0, t.jsx)(r.Z, {
                        className: "ml-auto h-4 w-4"
                    })]
                })
            }).displayName = l.fF.displayName, o.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.tu, {
                    ref: a,
                    className: (0, d.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", s),
                    ...r
                })
            }).displayName = l.tu.displayName;
            let m = o.forwardRef((e, a) => {
                let {
                    className: s,
                    sideOffset: r = 4,
                    ...n
                } = e;
                return (0, t.jsx)(l.Uv, {
                    children: (0, t.jsx)(l.VY, {
                        ref: a,
                        sideOffset: r,
                        className: (0, d.cn)("z-50 min-w-[8rem] overflow-hidden rounded-lg bg-popover p-4 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", s),
                        ...n
                    })
                })
            });
            m.displayName = l.VY.displayName;
            let x = o.forwardRef((e, a) => {
                let {
                    className: s,
                    inset: r,
                    ...n
                } = e;
                return (0, t.jsx)(l.ck, {
                    ref: a,
                    className: (0, d.cn)("relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors duration-200 focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 hover:bg-dark", r && "pl-8", s),
                    ...n
                })
            });
            x.displayName = l.ck.displayName, o.forwardRef((e, a) => {
                let {
                    className: s,
                    children: r,
                    checked: i,
                    ...o
                } = e;
                return (0, t.jsxs)(l.oC, {
                    ref: a,
                    className: (0, d.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", s),
                    checked: i,
                    ...o,
                    children: [(0, t.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, t.jsx)(l.wU, {
                            children: (0, t.jsx)(n.Z, {
                                className: "h-4 w-4"
                            })
                        })
                    }), r]
                })
            }).displayName = l.oC.displayName, o.forwardRef((e, a) => {
                let {
                    className: s,
                    children: r,
                    ...n
                } = e;
                return (0, t.jsxs)(l.Rk, {
                    ref: a,
                    className: (0, d.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", s),
                    ...n,
                    children: [(0, t.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, t.jsx)(l.wU, {
                            children: (0, t.jsx)(i.Z, {
                                className: "h-2 w-2 fill-current"
                            })
                        })
                    }), r]
                })
            }).displayName = l.Rk.displayName;
            let p = o.forwardRef((e, a) => {
                let {
                    className: s,
                    inset: r,
                    ...n
                } = e;
                return (0, t.jsx)(l.__, {
                    ref: a,
                    className: (0, d.cn)("px-2 py-1.5 text-sm font-semibold", r && "pl-8", s),
                    ...n
                })
            });
            p.displayName = l.__.displayName;
            let f = o.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.Z0, {
                    ref: a,
                    className: (0, d.cn)("-mx-1 my-1 h-px bg-border", s),
                    ...r
                })
            });
            f.displayName = l.Z0.displayName;
            let h = e => {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsx)("span", {
                    className: (0, d.cn)("ml-auto text-xs tracking-widest opacity-60", a),
                    ...s
                })
            };
            h.displayName = "DropdownMenuShortcut"
        },
        39540: (e, a, s) => {
            s.d(a, {
                _: () => i
            });
            var t = s(12428),
                l = s(93264),
                r = s(62993),
                n = s(5313);

            function i(e) {
                let [a, s] = (0, l.useState)(!1);
                return (0, l.useEffect)(() => {
                    s(e.isFavorite)
                }, [e.isFavorite]), (0, t.jsx)("button", {
                    onClick: e.onToggle,
                    className: "flex items-center justify-center cursor-pointer",
                    suppressHydrationWarning: !0,
                    children: (0, t.jsx)(n.h_, {
                        className: (0, r.cn)("size-4", !a && "stroke-foreground-secondary fill-transparent", e.iconClassName),
                        gradient: a
                    })
                })
            }
        },
        26185: (e, a, s) => {
            s.d(a, {
                l: () => r
            });
            var t = s(12428),
                l = s(32029);

            function r(e) {
                return (0, t.jsxs)("div", {
                    className: "space-x-1 flex items-center",
                    children: [(0, t.jsx)("img", {
                        src: (0, l.mv)(e.countryCode),
                        className: "w-5",
                        alt: "country-flag"
                    }), (0, t.jsx)("p", {
                        className: "text-sm font-semibold pt-px",
                        children: e.countryCode
                    })]
                })
            }
        },
        73771: (e, a, s) => {
            s.d(a, {
                S: () => n
            });
            var t = s(12428),
                l = s(93264),
                r = s(43748);

            function n(e) {
                let {
                    rank: a,
                    useStatusColors: s = !1,
                    lowThreshold: n = 2,
                    highThreshold: i = 4
                } = e, o = a.toFixed(1), d = +o, c = (0, l.useMemo)(() => s ? d <= n ? "red" : d < i ? "yellow" : "green" : "pfmPaleOutline", [d, s, n, i]);
                return (0, t.jsx)(r.G7, {
                    variant: c,
                    className: "font-semibold",
                    children: (0, t.jsx)(r.MB, {
                        className: "px-2 py-0.5",
                        children: o
                    })
                })
            }
        },
        30758: (e, a, s) => {
            s.d(a, {
                G: () => o
            });
            var t = s(12428),
                l = s(51699),
                r = s(62993),
                n = s(92494);
            let i = (0, l.j)("space-y-1 flex flex-col", {
                variants: {
                    align: {
                        left: ["items-start", "text-left"],
                        center: ["items-center", "text-center"],
                        right: ["items-end", "text-right"]
                    }
                },
                defaultVariants: {
                    align: "center"
                }
            });

            function o(e) {
                var a, s, l;
                return (0, t.jsxs)("div", {
                    className: (0, r.cn)(i({
                        align: e.align
                    }), e.className),
                    children: [(0, t.jsx)("p", {
                        className: "text-[10px] md:text-sm font-semibold",
                        children: null !== (a = e.label) && void 0 !== a ? a : e.value
                    }), (0, t.jsx)(n.P, {
                        variant: "pfmGradient",
                        className: "h-1",
                        value: e.value,
                        minLimit: null !== (s = e.minLimit) && void 0 !== s ? s : 1e5,
                        maxLimit: null !== (l = e.maxLimit) && void 0 !== l ? l : 1e6
                    })]
                })
            }
        },
        88998: (e, a, s) => {
            s.d(a, {
                O: () => n
            });
            var t = s(12428),
                l = s(73771),
                r = s(54852);
            let n = e => (0, t.jsxs)("div", {
                className: "space-y-1 flex flex-col items-center w-fit",
                children: [(0, t.jsx)(l.S, {
                    rank: e.rank
                }), (0, t.jsx)(r.FirmStarsRank, {
                    rank: e.rank
                }), e.children]
            })
        },
        45253: (e, a, s) => {
            s.d(a, {
                $: () => c,
                O: () => u
            });
            var t = s(12428),
                l = s(54852),
                r = s(43748),
                n = s(51699),
                i = s(62993);
            let o = (0, n.j)("flex items-center", {
                    variants: {
                        size: {
                            lg: "space-x-1.5",
                            md: "space-x-1",
                            sm: "space-x-1",
                            xs: "space-x-1"
                        }
                    },
                    defaultVariants: {
                        size: "sm"
                    }
                }),
                d = (0, n.j)("font-semibold", {
                    variants: {
                        size: {
                            "2xl": "text-2xl",
                            lg: "text-lg",
                            md: "text-sm leading-[21px]",
                            sm: "text-xxs md:text-sm",
                            xs: "text-xxs leading-[15px]"
                        }
                    },
                    defaultVariants: {
                        size: "sm"
                    }
                }),
                c = e => {
                    var a, s, n, c, u;
                    let m = null !== (a = e.toFixed) && void 0 !== a ? a : 1;
                    return (0, t.jsx)(r.G7, {
                        variant: "pfmPaleOutline",
                        children: (0, t.jsx)(r.MB, {
                            className: (0, i.cn)("gradientPillContent px-1 md:px-2 md:py-0.5", e.wrapperClassName),
                            children: (0, t.jsxs)("div", {
                                className: (0, i.cn)(o({
                                    size: e.size
                                }), e.className),
                                children: [e.hideReviewScoreLabel ? null : (0, t.jsx)("p", {
                                    className: d({
                                        size: null !== (s = e.scoreSize) && void 0 !== s ? s : e.size
                                    }),
                                    children: (null !== (n = e.reviewScore) && void 0 !== n ? n : 0).toFixed(m)
                                }), (0, t.jsx)("div", {
                                    className: (0, i.cn)("md:px-1", e.rankClassName),
                                    children: (0, t.jsx)(l.FirmStarsRank, {
                                        size: null !== (c = e.starIconSize) && void 0 !== c ? c : e.size,
                                        rank: null !== (u = e.reviewScore) && void 0 !== u ? u : 0
                                    })
                                }), !e.hideReviewsCountLabel && void 0 !== e.reviews && (0, t.jsx)("p", {
                                    className: "reviews text-primary-theme text-2xs md:text-xs flex items-center border-l border-primary-theme pl-1",
                                    children: e.reviews
                                })]
                            })
                        })
                    })
                },
                u = e => {
                    var a, s;
                    return (0, t.jsx)(r.G7, {
                        variant: "pfmPaleOutline",
                        children: (0, t.jsx)(r.MB, {
                            className: "gradientPillContent px-1 md:px-2 md:py-0.5",
                            children: (0, t.jsxs)("div", {
                                className: (0, i.cn)(o({
                                    size: e.size
                                }), e.className),
                                children: [(0, t.jsx)("div", {
                                    children: (0, t.jsx)(l.GradientStarRankIcon, {
                                        className: "rankStar",
                                        size: null !== (a = e.starIconSize) && void 0 !== a ? a : e.size
                                    })
                                }), (0, t.jsx)("p", {
                                    className: d({
                                        size: null !== (s = e.scoreSize) && void 0 !== s ? s : e.size
                                    }),
                                    children: e.toFixed ? e.reviewScore.toFixed(e.toFixed) : e.reviewScore
                                })]
                            })
                        })
                    })
                }
        },
        54852: (e, a, s) => {
            s.d(a, {
                FirmStarsRank: () => u,
                GradientStarRankIcon: () => c
            });
            var t = s(12428),
                l = s(51699),
                r = s(93264),
                n = s(62993);
            let i = (0, l.j)("relative flex w-fit", {
                    variants: {
                        size: {
                            xs: "",
                            sm: "",
                            md: "",
                            lg: "",
                            xl: "",
                            "2xl": "",
                            "3xl": ""
                        }
                    },
                    defaultVariants: {
                        size: "sm"
                    }
                }),
                o = (0, l.j)("", {
                    variants: {
                        size: {
                            xs: "w-[10px] h-[9.5px]",
                            sm: "w-3.5 h-3.5",
                            md: "w-4 h-4",
                            lg: "w-[18px] h-[18px]",
                            xl: "h-[23px] w-[23px]",
                            "2xl": "w-8 h-8",
                            "3xl": "h-10 w-[42px]"
                        }
                    },
                    defaultVariants: {
                        size: "sm"
                    }
                }),
                d = e => (0, t.jsx)("svg", {
                    className: (0, n.cn)(o({
                        size: e.size
                    }), e.className),
                    viewBox: "0 0 14 14",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, t.jsx)("path", {
                        d: "M6.64 1.42237C6.7774 1.10853 7.2226 1.10853 7.36 1.42237L8.75682 4.6128C8.8151 4.74592 8.94208 4.83601 9.08698 4.84705L12.675 5.12032C13.0291 5.14728 13.1687 5.59284 12.8932 5.81699L10.1899 8.01693C10.0715 8.11327 10.0196 8.26943 10.0567 8.41746L10.8878 11.7273C10.9725 12.0644 10.61 12.3373 10.3094 12.1629L7.19724 10.357C7.07527 10.2863 6.92473 10.2863 6.80276 10.357L3.69058 12.1629C3.38997 12.3373 3.02754 12.0644 3.11218 11.7273L3.94325 8.41746C3.98042 8.26943 3.92852 8.11327 3.81014 8.01693L1.10677 5.81699C0.831321 5.59284 0.970875 5.14728 1.32497 5.12032L4.91302 4.84705C5.05792 4.83601 5.1849 4.74592 5.24318 4.6128L6.64 1.42237Z",
                        fill: "hsl(var(--foreground-disabled))"
                    })
                }),
                c = e => (0, t.jsxs)("svg", {
                    className: (0, n.cn)(o({
                        size: e.size
                    }), e.className),
                    viewBox: "0 0 14 14",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, t.jsx)("path", {
                        d: "M6.64 1.42237C6.7774 1.10853 7.2226 1.10853 7.36 1.42237L8.75682 4.6128C8.8151 4.74592 8.94208 4.83601 9.08698 4.84705L12.675 5.12032C13.0291 5.14728 13.1687 5.59284 12.8932 5.81699L10.1899 8.01693C10.0715 8.11327 10.0196 8.26943 10.0567 8.41746L10.8878 11.7273C10.9725 12.0644 10.61 12.3373 10.3094 12.1629L7.19724 10.357C7.07527 10.2863 6.92473 10.2863 6.80276 10.357L3.69058 12.1629C3.38997 12.3373 3.02754 12.0644 3.11218 11.7273L3.94325 8.41746C3.98042 8.26943 3.92852 8.11327 3.81014 8.01693L1.10677 5.81699C0.831321 5.59284 0.970875 5.14728 1.32497 5.12032L4.91302 4.84705C5.05792 4.83601 5.1849 4.74592 5.24318 4.6128L6.64 1.42237Z",
                        fill: "url(#paint0_linear_8811_862)"
                    }), (0, t.jsx)("defs", {
                        children: (0, t.jsxs)("linearGradient", {
                            id: "paint0_linear_8811_862",
                            x1: "13.125",
                            y1: "11.8501",
                            x2: "0.875",
                            y2: "-0.399902",
                            gradientUnits: "userSpaceOnUse",
                            children: [(0, t.jsx)("stop", {
                                stopColor: "hsl(var(--color-purple))"
                            }), (0, t.jsx)("stop", {
                                offset: "1",
                                stopColor: "hsl(var(--color-primary))"
                            })]
                        })
                    })]
                }),
                u = e => {
                    let {
                        readOnly: a = !0,
                        ...s
                    } = e, [l, o] = (0, r.useState)(null), u = (0, r.useMemo)(() => {
                        var e;
                        return (null !== (e = null != l ? l : s.rank) && void 0 !== e ? e : 0) / 5 * 100
                    }, [l, s.rank]), m = e => {
                        a || o(e + 1)
                    }, x = e => {
                        var t;
                        a || null === (t = s.onChange) || void 0 === t || t.call(s, e + 1)
                    };
                    return (0, t.jsxs)("div", {
                        className: (0, n.cn)(i({
                            size: s.size
                        }), s.className),
                        onMouseLeave: () => {
                            a || o(null)
                        },
                        children: [(0, t.jsx)("div", {
                            className: "flex",
                            children: Array.from({
                                length: 5
                            }).map((e, l) => (0, t.jsx)("div", {
                                className: (0, n.cn)(!a && "cursor-pointer"),
                                onMouseEnter: () => m(l),
                                onClick: () => x(l),
                                children: (0, t.jsx)(d, {
                                    size: s.size,
                                    className: "rankStar"
                                })
                            }, l))
                        }), (0, t.jsx)("div", {
                            className: "absolute overflow-hidden h-full",
                            style: {
                                width: "".concat(u, "%")
                            },
                            children: (0, t.jsx)("div", {
                                className: "absolute top-0 left-0 flex overflow-hidden",
                                children: Array.from({
                                    length: 5
                                }).map((e, l) => (0, t.jsx)("div", {
                                    className: (0, n.cn)(!a && "cursor-pointer"),
                                    onMouseEnter: () => m(l),
                                    onClick: () => x(l),
                                    children: (0, t.jsx)(c, {
                                        className: "rankStar",
                                        size: s.size
                                    })
                                }, l))
                            })
                        })]
                    })
                }
        },
        92006: (e, a, s) => {
            s.d(a, {
                l0: () => u,
                NI: () => g,
                pf: () => j,
                Wi: () => x,
                xJ: () => h,
                lX: () => v,
                zG: () => b
            });
            var t = s(12428),
                l = s(8190),
                r = s(93264),
                n = s(95289),
                i = s(62993),
                o = s(17492);
            let d = (0, s(51699).j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),
                c = r.forwardRef((e, a) => {
                    let {
                        className: s,
                        ...l
                    } = e;
                    return (0, t.jsx)(o.f, {
                        ref: a,
                        className: (0, i.cn)(d(), s),
                        ...l
                    })
                });
            c.displayName = o.f.displayName;
            let u = n.RV,
                m = r.createContext({}),
                x = e => {
                    let { ...a
                    } = e;
                    return (0, t.jsx)(m.Provider, {
                        value: {
                            name: a.name
                        },
                        children: (0, t.jsx)(n.Qr, { ...a
                        })
                    })
                },
                p = () => {
                    let e = r.useContext(m),
                        a = r.useContext(f),
                        {
                            getFieldState: s,
                            formState: t
                        } = (0, n.Gc)(),
                        l = s(e.name, t);
                    if (!e) throw Error("useFormField should be used within <FormField>");
                    let {
                        id: i
                    } = a;
                    return {
                        id: i,
                        name: e.name,
                        formItemId: "".concat(i, "-form-item"),
                        formDescriptionId: "".concat(i, "-form-item-description"),
                        formMessageId: "".concat(i, "-form-item-message"),
                        ...l
                    }
                },
                f = r.createContext({}),
                h = r.forwardRef((e, a) => {
                    let {
                        className: s,
                        ...l
                    } = e, n = r.useId();
                    return (0, t.jsx)(f.Provider, {
                        value: {
                            id: n
                        },
                        children: (0, t.jsx)("div", {
                            ref: a,
                            className: (0, i.cn)("space-y-2", s),
                            ...l
                        })
                    })
                });
            h.displayName = "FormItem";
            let v = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e, {
                    error: r,
                    formItemId: n
                } = p();
                return (0, t.jsx)(c, {
                    ref: a,
                    className: (0, i.cn)("text-xs transition-colors group-data-[success=true]:text-green-theme group-data-[error=true]:text-red-theme", r && "text-red-theme", s),
                    htmlFor: n,
                    ...l
                })
            });
            v.displayName = "FormLabel";
            let g = r.forwardRef((e, a) => {
                let { ...s
                } = e, {
                    error: r,
                    formItemId: n,
                    formDescriptionId: i,
                    formMessageId: o
                } = p();
                return (0, t.jsx)(l.g7, {
                    ref: a,
                    id: n,
                    "aria-describedby": r ? "".concat(i, " ").concat(o) : "".concat(i),
                    "aria-invalid": !!r,
                    ...s
                })
            });
            g.displayName = "FormControl";
            let j = r.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e, {
                    formDescriptionId: r
                } = p();
                return (0, t.jsx)("p", {
                    ref: a,
                    id: r,
                    className: (0, i.cn)("text-xs transition-colors text-foreground-tertiary group-data-[error=true]:text-red-theme group-data-[success=true]:text-green-theme", s),
                    ...l
                })
            });
            j.displayName = "FormDescription";
            let b = r.forwardRef((e, a) => {
                let {
                    className: s,
                    children: l,
                    ...r
                } = e, {
                    error: n,
                    formMessageId: o
                } = p(), d = n ? String(null == n ? void 0 : n.message) : l;
                return d ? (0, t.jsx)("p", {
                    ref: a,
                    id: o,
                    className: (0, i.cn)("text-xs font-medium text-red-theme", s),
                    ...r,
                    children: d
                }) : null
            });
            b.displayName = "FormMessage"
        },
        59957: (e, a, s) => {
            s.d(a, {
                I: () => m
            });
            var t = s(12428),
                l = s(51699),
                r = s(25845),
                n = s(93264),
                i = s(62993),
                o = s(5313);
            let d = (0, l.j)(["block transition-colors bg-background-secondary w-full border px-3 py-2 focus:outline-none disabled:cursor-not-allowed disabled:opacity-50 dark:[color-scheme:dark]", "border-dark text-foreground focus:border-primary-theme placeholder:text-muted-foreground/50", "group-data-[success=true]:border-green-theme group-data-[success=true]:text-green-theme group-data-[success=true]:focus:border-green-theme group-data-[success=true]:placeholder:text-green-theme/50", "group-data-[error=true]:border-red-theme group-data-[error=true]:text-red-theme group-data-[error=true]:focus:border-red-theme group-data-[error=true]:placeholder:text-red-theme/50"], {
                    variants: {
                        size: {
                            xs: "h-8 text-xs",
                            sm: "h-9 text-sm",
                            37: "h-[37px]",
                            default: "h-10 text-sm",
                            lg: "h-12 text-base"
                        },
                        rounded: {
                            default: "rounded-md",
                            full: "rounded-full"
                        }
                    },
                    defaultVariants: {
                        size: "default",
                        rounded: "default"
                    }
                }),
                c = (0, l.j)("", {
                    variants: {
                        iconSize: {
                            default: "[&_svg]:w-4 [&_svg]:h-4",
                            small: "[&_svg]:w-3 [&_svg]:h-3"
                        }
                    },
                    defaultVariants: {
                        iconSize: "default"
                    }
                }),
                u = "absolute inset-y-0 flex items-center text-foreground-secondary transition-colors group-data-[success=true]:text-green-theme group-data-[error=true]:text-red-theme",
                m = n.forwardRef((e, a) => {
                    let {
                        className: s,
                        wrapperClassName: l,
                        type: m = "text",
                        size: x,
                        iconSize: p,
                        rounded: f,
                        leftInnerContent: h,
                        rightInnerContent: v,
                        leftIcon: g,
                        rightIcon: j,
                        clearable: b = !1,
                        onChange: y,
                        onClear: N,
                        value: w,
                        loading: S,
                        ...C
                    } = e, z = (0, n.useRef)(null), k = (0, n.useRef)(null), [R, P] = (0, n.useState)(0), [T, F] = (0, n.useState)(0);
                    (0, n.useEffect)(() => {
                        if (h) {
                            var e, a;
                            P(null !== (a = null === (e = z.current) || void 0 === e ? void 0 : e.offsetWidth) && void 0 !== a ? a : 0)
                        }
                    }, [h]), (0, n.useEffect)(() => {
                        if (v) {
                            var e, a;
                            F(null !== (a = null === (e = k.current) || void 0 === e ? void 0 : e.offsetWidth) && void 0 !== a ? a : 0)
                        }
                    }, [v]);
                    let A = b && null != w && w.toString().length > 0;
                    return (0, t.jsxs)("div", {
                        className: (0, i.cn)(c({
                            iconSize: p
                        }), "flex relative", l),
                        children: [h && (0, t.jsx)("div", {
                            ref: z,
                            className: "absolute inset-y-0 flex items-center pl-3",
                            children: h
                        }), g && (0, t.jsx)("span", {
                            className: (0, i.cn)("left-0 pl-3 pointer-events-none", u),
                            children: g
                        }), (0, t.jsx)("input", {
                            type: m,
                            className: (0, i.cn)(d({
                                size: x,
                                rounded: f
                            }), g && ("small" === p ? "pl-8" : "pl-10"), (j || A || S) && ("small" === p ? "pr-8" : "pr-10"), s),
                            ref: a,
                            value: w,
                            onChange: y,
                            onKeyDown: e => {
                                b && N && "Escape" === e.key && N()
                            },
                            style: { ...h ? {
                                    paddingLeft: "".concat(R, "px")
                                } : {},
                                ...v ? {
                                    paddingRight: "".concat(T, "px")
                                } : {}
                            },
                            ...C
                        }), (j || A) && (0, t.jsx)("span", {
                            className: (0, i.cn)("right-0 pr-3", u),
                            children: A ? (0, t.jsx)("button", {
                                type: "button",
                                onClick: N,
                                className: "focus:outline-none text-foreground",
                                children: (0, t.jsx)(r.Z, {})
                            }) : j
                        }), v && (0, t.jsx)("div", {
                            ref: k,
                            className: "absolute inset-y-0 right-0 flex items-center pr-3",
                            children: v
                        }), S && (0, t.jsx)(o.Aj, {
                            className: "w-6 absolute right-2 top-3"
                        })]
                    })
                });
            m.displayName = "Input"
        },
        45752: (e, a, s) => {
            s.d(a, {
                L: () => n
            });
            var t = s(12428),
                l = s(44273),
                r = s(58950);

            function n(e) {
                return (0, t.jsxs)("div", {
                    className: (0, l.Z)("flex items-center gap-1", e.className),
                    children: [(0, t.jsx)(r.E, {}), (0, t.jsx)("p", {
                        className: "text-[10px] md:text-sm font-semibold",
                        children: e.points.toLocaleString()
                    })]
                })
            }
        },
        92494: (e, a, s) => {
            s.d(a, {
                P: () => n
            });
            var t = s(12428),
                l = s(32029),
                r = s(73283);

            function n(e) {
                let {
                    value: a,
                    minLimit: s = 0,
                    maxLimit: n,
                    variant: i,
                    size: o,
                    className: d,
                    customStyle: c
                } = e, u = (0, l._G)({
                    minLimit: s,
                    maxLimit: n,
                    value: a
                });
                return (0, t.jsx)(r.Ex, {
                    className: d,
                    value: u,
                    variant: i,
                    size: o,
                    style: c
                })
            }
        },
        73283: (e, a, s) => {
            s.d(a, {
                Ex: () => c
            });
            var t = s(12428),
                l = s(66727),
                r = s(51699),
                n = s(93264),
                i = s(62993);
            let o = (0, r.j)("h-full flex-1 transition-all", {
                    variants: {
                        variant: {
                            default: "bg-primary-theme",
                            pfmGradient: "bg-[image:var(--pfm-gradient)]",
                            orangeToGreenGradient: "bg-[image:var(--orange-to-green-gradient)]",
                            greenToOrangeGradient: "bg-[image:var(--green-to-orange-gradient)]",
                            greenToRedGradient: "bg-[image:var(--green-to-red-gradient)]"
                        },
                        rounded: {
                            default: "rounded-full",
                            none: ""
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        rounded: "default"
                    }
                }),
                d = (0, r.j)("", {
                    variants: {
                        size: {
                            lg: "h-6",
                            default: "h-4",
                            sm: "h-3",
                            xs: "h-2",
                            xxs: "h-1.5",
                            "3xs": "h-1"
                        },
                        rounded: {
                            default: "rounded-full",
                            none: ""
                        }
                    },
                    defaultVariants: {
                        size: "default",
                        rounded: "default"
                    }
                }),
                c = n.forwardRef((e, a) => {
                    let {
                        className: s,
                        value: r,
                        variant: n,
                        size: c,
                        rounded: u,
                        style: m,
                        ...x
                    } = e;
                    return (0, t.jsx)(l.fC, {
                        ref: a,
                        className: (0, i.cn)("relative w-full overflow-hidden bg-dark", d({
                            size: c,
                            rounded: u
                        }), s),
                        ...x,
                        children: (0, t.jsx)(l.z$, {
                            className: (0, i.cn)(o({
                                variant: n,
                                rounded: u
                            })),
                            style: {
                                transform: "translateX(-".concat(100 - (r || 0), "%)"),
                                ...m
                            }
                        })
                    })
                });
            c.displayName = l.fC.displayName
        },
        35389: (e, a, s) => {
            s.d(a, {
                E: () => o
            });
            var t = s(12428),
                l = s(93264),
                r = s(70073),
                n = s(1779),
                i = s(62993);
            let o = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)(r.fC, {
                    className: (0, i.cn)("grid gap-2", s),
                    ...l,
                    ref: a
                })
            });
            o.displayName = r.fC.displayName, l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)(r.ck, {
                    ref: a,
                    className: (0, i.cn)("aspect-square h-4 w-4 rounded-full border border-primary-theme text-primary-theme ring-offset-background focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", s),
                    ...l,
                    children: (0, t.jsx)(r.z$, {
                        className: "flex items-center justify-center",
                        children: (0, t.jsx)(n.Z, {
                            className: "h-2.5 w-2.5 fill-current text-current"
                        })
                    })
                })
            }).displayName = r.ck.displayName
        },
        6536: (e, a, s) => {
            s.d(a, {
                Select: () => f,
                SelectContent: () => N,
                SelectItem: () => y,
                SelectTrigger: () => g,
                SelectValue: () => h
            });
            var t = s(12428),
                l = s(58210),
                r = s(51699),
                n = s(30455),
                i = s(25845),
                o = s(24080),
                d = s(71999),
                c = s(66453),
                u = s(93264),
                m = s(62993),
                x = s(40850),
                p = s(59957);
            let f = l.fC;
            l.ZA;
            let h = l.B4,
                v = (0, r.j)("flex w-full items-center justify-between bg-background-secondary rounded-md border border-input px-3 py-2 text-sm ring-offset-background data-[placeholder]:text-foreground-tertiary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 group-data-[success=true]:border-green-theme group-data-[success=true]:text-green-theme group-data-[success=true]:focus:border-green-theme group-data-[success=true]:placeholder:text-green-theme/50 group-data-[error=true]:border-red-theme group-data-[error=true]:text-red-theme group-data-[error=true]:focus:border-red-theme group-data-[error=true]:placeholder:text-red-theme/50", {
                    variants: {
                        size: {
                            "2xs": "h-6.5 text-xs",
                            xs: "h-7 text-xs",
                            sm: "h-8 text-xs",
                            default: "h-10",
                            37: "h-[37px]",
                            lg: "h-12"
                        },
                        rounded: {
                            default: "rounded-md",
                            full: "rounded-full"
                        }
                    },
                    defaultVariants: {
                        size: "default",
                        rounded: "default"
                    }
                }),
                g = u.forwardRef((e, a) => {
                    let {
                        className: s,
                        children: r,
                        rounded: o,
                        size: d,
                        onClear: c,
                        hideChevron: u,
                        ...p
                    } = e;
                    return (0, t.jsxs)("div", {
                        className: "flex items-center relative",
                        children: [(0, t.jsxs)(l.xz, {
                            ref: a,
                            className: (0, m.cn)(v({
                                size: d,
                                rounded: o
                            }), s),
                            ...p,
                            children: [r, (0, t.jsx)(l.JO, {
                                asChild: !0,
                                children: !u && (0, t.jsx)(n.Z, {
                                    className: "h-4 w-4 ml-2"
                                })
                            })]
                        }), c ? (0, t.jsx)(x.zx, {
                            className: (0, m.cn)("absolute", u ? "right-0" : "right-8"),
                            variant: "ghost",
                            size: "icon",
                            onClick: e => {
                                e.preventDefault(), e.stopPropagation(), c()
                            },
                            type: "button",
                            children: (0, t.jsx)(i.Z, {})
                        }) : null]
                    })
                });
            g.displayName = l.xz.displayName;
            let j = u.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.u_, {
                    ref: a,
                    className: (0, m.cn)("flex cursor-default items-center justify-center py-1", s),
                    ...r,
                    children: (0, t.jsx)(o.Z, {
                        className: "h-4 w-4"
                    })
                })
            });
            j.displayName = l.u_.displayName;
            let b = u.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.$G, {
                    ref: a,
                    className: (0, m.cn)("flex cursor-default items-center justify-center py-1", s),
                    ...r,
                    children: (0, t.jsx)(n.Z, {
                        className: "h-4 w-4"
                    })
                })
            });
            b.displayName = l.$G.displayName, u.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.__, {
                    ref: a,
                    className: (0, m.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", s),
                    ...r
                })
            }).displayName = l.__.displayName;
            let y = u.forwardRef((e, a) => {
                let {
                    className: s,
                    children: r,
                    ...n
                } = e;
                return (0, t.jsxs)(l.ck, {
                    ref: a,
                    className: (0, m.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", s),
                    ...n,
                    children: [(0, t.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, t.jsx)(l.wU, {
                            children: (0, t.jsx)(d.Z, {
                                className: "h-4 w-4"
                            })
                        })
                    }), (0, t.jsx)(l.eT, {
                        children: r
                    })]
                })
            });
            y.displayName = l.ck.displayName, u.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.Z0, {
                    ref: a,
                    className: (0, m.cn)("-mx-1 my-1 h-px bg-muted", s),
                    ...r
                })
            }).displayName = l.Z0.displayName;
            let N = u.forwardRef((e, a) => {
                let {
                    className: s,
                    children: r,
                    position: n = "popper",
                    enableSearch: i = !1,
                    searchPlaceholder: o = "Search...",
                    value: d,
                    open: x,
                    ...f
                } = e, [h, v] = u.useState(""), g = u.useRef(null), N = u.Children.toArray(r), w = i && h ? N.filter(e => {
                    if (u.isValidElement(e) && e.type === y) {
                        let a = e.props.value;
                        if ("string" == typeof a) return a === d || a.toLowerCase().includes(h.toLowerCase())
                    }
                    return !0
                }) : N, S = w.some(e => u.isValidElement(e) && e.type === y);
                return u.useEffect(() => {
                    i && setTimeout(() => {
                        var e;
                        null === (e = g.current) || void 0 === e || e.focus()
                    }, 50)
                }, [i]), u.useEffect(() => {
                    x || v("")
                }, [x]), (0, t.jsx)(l.h_, {
                    children: (0, t.jsxs)(l.VY, {
                        ref: a,
                        className: (0, m.cn)("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", "popper" === n && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", s),
                        position: n,
                        ...f,
                        children: [i ? (0, t.jsx)("div", {
                            className: "flex items-center gap-2",
                            children: (0, t.jsx)(p.I, {
                                onKeyDown: e => {
                                    "ArrowDown" !== e.key && e.stopPropagation()
                                },
                                wrapperClassName: "flex-1",
                                ref: g,
                                value: h,
                                onChange: e => v(e.target.value),
                                placeholder: o,
                                leftIcon: (0, t.jsx)(c.Z, {}),
                                clearable: !0,
                                onClear: () => v("")
                            })
                        }) : (0, t.jsx)(j, {}), (0, t.jsx)(l.l_, {
                            className: (0, m.cn)("p-1", "popper" === n && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                            children: S ? w : (0, t.jsx)("div", {
                                className: "py-2 px-3 text-sm text-foreground-tertiary select-none",
                                children: "No results found"
                            })
                        }), (0, t.jsx)(b, {})]
                    })
                })
            });
            N.displayName = l.VY.displayName
        },
        97385: (e, a, s) => {
            s.d(a, {
                Separator: () => i
            });
            var t = s(12428),
                l = s(93264),
                r = s(79157),
                n = s(62993);
            let i = l.forwardRef((e, a) => {
                let {
                    className: s,
                    orientation: l = "horizontal",
                    decorative: i = !0,
                    ...o
                } = e;
                return (0, t.jsx)(r.f, {
                    ref: a,
                    decorative: i,
                    orientation: l,
                    className: (0, n.cn)("shrink-0 bg-border", "horizontal" === l ? "h-[1px] w-full" : "min-h-full w-[1px]", s),
                    ...o
                })
            });
            i.displayName = r.f.displayName
        },
        74607: (e, a, s) => {
            s.d(a, {
                Ei: () => g,
                Tu: () => h,
                aM: () => c,
                bC: () => v,
                ue: () => f,
                yo: () => d
            });
            var t = s(12428),
                l = s(45258),
                r = s(51699),
                n = s(93264),
                i = s(25845),
                o = s(62993);
            let d = l.fC,
                c = l.xz;
            l.x8;
            let u = l.h_,
                m = n.forwardRef((e, a) => {
                    let {
                        className: s,
                        ...r
                    } = e;
                    return (0, t.jsx)(l.aV, {
                        className: (0, o.cn)("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", s),
                        ...r,
                        ref: a
                    })
                });
            m.displayName = l.aV.displayName;
            let x = (e, a) => {
                    if ("top" === e || "bottom" === e) switch (a) {
                        case "sm":
                            return "h-1/5";
                        case "default":
                            return "h-1/4";
                        case "lg":
                            return "h-1/3";
                        case "xl":
                            return "h-1/2";
                        case "2xl":
                            return "h-2/3";
                        default:
                            return ""
                    }
                    if ("left" === e || "right" === e) switch (a) {
                        case "sm":
                            return "w-1/5";
                        case "default":
                            return "w-1/4";
                        case "lg":
                            return "w-1/3";
                        case "xl":
                            return "w-1/2";
                        case "2xl":
                            return "w-2/3"
                    }
                    return ""
                },
                p = (0, r.j)("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500 overflow-y-auto", {
                    variants: {
                        side: {
                            top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
                            bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
                            left: "inset-y-0 left-0 h-full border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left",
                            right: "inset-y-0 right-0 h-full border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right"
                        }
                    },
                    defaultVariants: {
                        side: "right"
                    }
                }),
                f = n.forwardRef((e, a) => {
                    let {
                        side: s = "right",
                        size: r = "default",
                        showCloseButton: n,
                        className: d,
                        children: c,
                        ...f
                    } = e, h = x(s, r);
                    return (0, t.jsx)(u, {
                        children: (0, t.jsx)(m, {
                            children: (0, t.jsxs)(l.VY, {
                                ref: a,
                                className: (0, o.cn)(p({
                                    side: s
                                }), h, d),
                                ...f,
                                children: [c, n && (0, t.jsxs)(l.x8, {
                                    className: "absolute right-6 top-6 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none",
                                    children: [(0, t.jsx)(i.Z, {
                                        className: "h-4 w-4"
                                    }), (0, t.jsx)("span", {
                                        className: "sr-only",
                                        children: "Close"
                                    })]
                                })]
                            })
                        })
                    })
                });
            f.displayName = l.VY.displayName;
            let h = e => {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, o.cn)("flex flex-col space-y-2 text-left", a),
                    ...s
                })
            };
            h.displayName = "SheetHeader";
            let v = n.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.Dx, {
                    ref: a,
                    className: (0, o.cn)("text-lg font-semibold text-foreground leading-7", s),
                    ...r
                })
            });
            v.displayName = l.Dx.displayName;
            let g = n.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.dk, {
                    ref: a,
                    className: (0, o.cn)("text-sm text-muted-foreground", s),
                    ...r
                })
            });
            g.displayName = l.dk.displayName
        },
        20533: (e, a, s) => {
            s.d(a, {
                O: () => r
            });
            var t = s(12428),
                l = s(62993);

            function r(e) {
                let {
                    className: a,
                    ...s
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, l.cn)("animate-pulse rounded-md bg-muted", a),
                    ...s
                })
            }
        },
        43692: (e, a, s) => {
            s.d(a, {
                i: () => u
            });
            var t = s(12428),
                l = s(6391),
                r = s(51699),
                n = s(93264),
                i = s(62993);
            let o = (0, r.j)("absolute h-full", {
                    variants: {
                        variant: {
                            default: "bg-primary-theme",
                            white: "bg-white"
                        }
                    },
                    defaultVariants: {
                        variant: "default"
                    }
                }),
                d = (0, r.j)("relative w-full grow overflow-hidden rounded-full bg-dark", {
                    variants: {
                        trackSize: {
                            default: "h-2",
                            sm: "h-[5px]"
                        }
                    },
                    defaultVariants: {
                        trackSize: "default"
                    }
                }),
                c = (0, r.j)("block rounded-full ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50", {
                    variants: {
                        thumb: {
                            default: "border-2 border-primary-theme bg-background",
                            white: "bg-white"
                        },
                        thumbSize: {
                            default: "h-5 w-5",
                            sm: "h-4 w-4",
                            xs: "h-3 w-3"
                        }
                    },
                    defaultVariants: {
                        thumb: "default",
                        thumbSize: "default"
                    }
                }),
                u = n.forwardRef((e, a) => {
                    var s, r, n;
                    let {
                        className: u,
                        variant: m,
                        thumb: x,
                        thumbSize: p,
                        trackSize: f,
                        isDual: h,
                        steps: v,
                        ...g
                    } = e;
                    return (0, t.jsxs)(l.fC, {
                        ref: a,
                        className: (0, i.cn)("relative flex w-full touch-none select-none items-center", u),
                        ...g,
                        step: v ? void 0 : null !== (s = g.step) && void 0 !== s ? s : 1,
                        min: v ? Math.min(...v) : null !== (r = g.min) && void 0 !== r ? r : 0,
                        max: v ? Math.max(...v) : null !== (n = g.max) && void 0 !== n ? n : 100,
                        onValueChange: e => {
                            var a, s;
                            if (v) {
                                let s = e.map(e => v.reduce((a, s) => Math.abs(s - e) < Math.abs(a - e) ? s : a));
                                null === (a = g.onValueChange) || void 0 === a || a.call(g, s)
                            } else null === (s = g.onValueChange) || void 0 === s || s.call(g, e)
                        },
                        children: [(0, t.jsx)(l.fQ, {
                            className: (0, i.cn)(d({
                                trackSize: f
                            })),
                            children: (0, t.jsx)(l.e6, {
                                className: (0, i.cn)(o({
                                    variant: m
                                }))
                            })
                        }), (0, t.jsx)(l.bU, {
                            className: (0, i.cn)(c({
                                thumb: x,
                                thumbSize: p
                            }))
                        }), h && (0, t.jsx)(l.bU, {
                            className: (0, i.cn)(c({
                                thumb: x,
                                thumbSize: p
                            }))
                        })]
                    })
                });
            u.displayName = l.fC.displayName
        },
        97993: (e, a, s) => {
            s.d(a, {
                r: () => d
            });
            var t = s(12428),
                l = s(48110),
                r = s(93264),
                n = s(51699),
                i = s(62993);
            let o = (0, n.j)("peer inline-flex shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary-theme data-[state=unchecked]:bg-input", {
                    variants: {
                        size: {
                            default: "h-6 w-11",
                            sm: "h-5 w-8"
                        }
                    },
                    defaultVariants: {
                        size: "default"
                    }
                }),
                d = r.forwardRef((e, a) => {
                    let {
                        className: s,
                        size: r,
                        thumbBg: n,
                        ...d
                    } = e;
                    return (0, t.jsx)(l.fC, {
                        className: o({
                            size: r,
                            className: s
                        }),
                        ...d,
                        ref: a,
                        children: (0, t.jsx)(l.bU, {
                            className: (0, i.cn)("pointer-events-none block rounded-full shadow-lg ring-0 transition-transform data-[state=unchecked]:translate-x-0", n || "bg-foreground", "sm" === r ? "h-4 w-4 data-[state=checked]:translate-x-3" : "h-5 w-5 data-[state=checked]:translate-x-5")
                        })
                    })
                });
            d.displayName = l.fC.displayName
        },
        31434: (e, a, s) => {
            s.d(a, {
                RM: () => o,
                Rn: () => m,
                SC: () => d,
                iA: () => n,
                pj: () => u,
                ss: () => c,
                xD: () => i
            });
            var t = s(12428),
                l = s(93264),
                r = s(62993);
            let n = l.forwardRef((e, a) => {
                let {
                    className: s,
                    wrapperClassName: l,
                    wrapperDivProps: n,
                    ...i
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, r.cn)("relative w-full h-full overflow-auto", l),
                    ...n,
                    children: (0, t.jsx)("table", {
                        ref: a,
                        className: (0, r.cn)("w-full caption-bottom text-sm", s),
                        ...i
                    })
                })
            });
            n.displayName = "Table";
            let i = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("thead", {
                    ref: a,
                    className: (0, r.cn)("[&_tr]:border-b", s),
                    ...l
                })
            });
            i.displayName = "TableHeader";
            let o = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("tbody", {
                    ref: a,
                    className: (0, r.cn)("[&_tr:last-child]:border-0", s),
                    ...l
                })
            });
            o.displayName = "TableBody", l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("tfoot", {
                    ref: a,
                    className: (0, r.cn)("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", s),
                    ...l
                })
            }).displayName = "TableFooter";
            let d = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("tr", {
                    ref: a,
                    className: (0, r.cn)("border-b transition-colors group hover:bg-muted/50 data-[state=selected]:bg-muted", s),
                    ...l
                })
            });
            d.displayName = "TableRow";
            let c = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("th", {
                    ref: a,
                    className: (0, r.cn)("h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0", s),
                    ...l
                })
            });
            c.displayName = "TableHead";
            let u = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("td", {
                    ref: a,
                    className: (0, r.cn)("p-4 align-middle [&:has([role=checkbox])]:pr-0", s),
                    ...l
                })
            });
            u.displayName = "TableCell";
            let m = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("caption", {
                    ref: a,
                    className: (0, r.cn)("mt-4 text-sm text-muted-foreground", s),
                    ...l
                })
            });
            m.displayName = "TableCaption"
        },
        53859: (e, a, s) => {
            s.d(a, {
                Id: () => d,
                SP: () => p,
                dr: () => x,
                mQ: () => m,
                nU: () => f
            });
            var t = s(12428),
                l = s(15911),
                r = s(51699),
                n = s(93264),
                i = s(62993);
            let o = (0, r.j)("flex", {
                    variants: {
                        variant: {
                            underlined: "bg-transparent",
                            filled: "bg-dark-disabled text-foreground-disabled border-0 rounded-sm",
                            outlined: "space-x-2",
                            button: "space-x-2",
                            "button-filled": "bg-dark-disabled text-foreground-disabled border-0 rounded-sm",
                            pill: "w-full space-x-2.5",
                            text: "space-x-2",
                            buttonRounded: "space-x-4",
                            buttonRoundedOutline: "space-x-4"
                        },
                        size: {
                            sm: "text-xs",
                            md: "text-sm",
                            lg: "text-md"
                        }
                    },
                    defaultVariants: {
                        variant: "underlined"
                    }
                }),
                d = (0, r.j)("px-3 py-1.5 text-xs md:text-sm font-medium transition-all duration-200 text-foreground-tertiary data-[state=active]:text-foreground hover:bg-background-secondary", {
                    variants: {
                        size: {
                            sm: "text-xs py-1 [&_svg]:h-3",
                            md: "text-sm py-2 [&_svg]:h-3.5",
                            lg: "text-sm py-3 [&_svg]:h-4"
                        },
                        variant: {
                            underlined: "border-transparent data-[state=active]:border-primary-theme border-b-2 leading-normal",
                            filled: "data-[state=active]:bg-dark-focus",
                            text: "border-transparent",
                            outlined: "border data-[state=active]:border-primary-theme rounded-md",
                            button: "bg-dark-disabled rounded-md data-[state=active]:bg-primary-theme",
                            "button-filled": "rounded-md data-[state=active]:bg-primary-theme",
                            pill: "h-1 rounded-full flex-1 bg-border data-[state=active]:bg-primary-theme p-0",
                            buttonRounded: "px-2.5 md:px-5 py-3 rounded-full bg-background-tertiary text-foreground data-[state=active]:bg-background-contrast data-[state=active]:text-foreground-contrast text-xs md:text-base font-semibold leading-6",
                            buttonRoundedOutline: "px-5 py-3 rounded-full text-foreground border bg-background-tertiary data-[state=active]:bg-transparent data-[state=active]:border data-[state=active]:border-white text-xs font-semibold"
                        }
                    },
                    defaultVariants: {
                        size: "md",
                        variant: "underlined"
                    }
                }),
                c = {
                    size: "md",
                    variant: "underlined"
                },
                u = n.createContext(c),
                m = l.fC,
                x = n.forwardRef((e, a) => {
                    let {
                        className: s,
                        size: r,
                        variant: n,
                        children: d,
                        ...m
                    } = e;
                    return (0, t.jsx)(u.Provider, {
                        value: {
                            size: null != r ? r : c.size,
                            variant: null != n ? n : c.variant
                        },
                        children: (0, t.jsx)(l.aV, {
                            ref: a,
                            className: (0, i.cn)(o({
                                size: r,
                                variant: n
                            }), s),
                            ...m,
                            children: d
                        })
                    })
                });
            x.displayName = l.aV.displayName;
            let p = n.forwardRef((e, a) => {
                let {
                    className: s,
                    icon: r,
                    children: o,
                    ...c
                } = e, {
                    size: m,
                    variant: x
                } = n.useContext(u);
                return (0, t.jsx)(l.xz, {
                    ref: a,
                    className: (0, i.cn)(d({
                        size: m,
                        variant: x
                    }), s),
                    ...c,
                    children: (0, t.jsxs)("span", {
                        className: (0, i.cn)(r && "flex items-center mr-3"),
                        children: [r && (0, t.jsx)("span", {
                            className: "mr-1",
                            children: r
                        }), o]
                    })
                })
            });
            p.displayName = l.xz.displayName;
            let f = n.forwardRef((e, a) => {
                let {
                    className: s,
                    ...r
                } = e;
                return (0, t.jsx)(l.VY, {
                    ref: a,
                    className: (0, i.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", s),
                    ...r
                })
            });
            f.displayName = l.VY.displayName
        },
        83352: (e, a, s) => {
            s.d(a, {
                o3: () => d
            });
            var t = s(12428),
                l = s(51699);
            s(93264);
            var r = s(62993),
                n = s(20842);
            let i = (0, l.j)("break-words inline-flex", {
                    variants: {
                        maxWidth: {
                            "3xs": "max-w-20",
                            "2xs": "max-w-40",
                            xs: "max-w-60 md:max-w-xs",
                            sm: "max-w-60 md:max-w-sm",
                            md: "max-w-60 md:max-w-md",
                            lg: "max-w-60 md:max-w-lg",
                            xl: "max-w-60 md:max-w-xl",
                            "2xl": "max-w-60 md:max-w-2xl",
                            full: "max-w-60 md:max-w-full"
                        },
                        lineClamp: {
                            1: "line-clamp-1",
                            2: "line-clamp-2",
                            3: "line-clamp-3",
                            4: "line-clamp-4",
                            5: "line-clamp-5"
                        }
                    },
                    defaultVariants: {
                        maxWidth: "md",
                        lineClamp: "1"
                    }
                }),
                o = (0, l.j)("max-w-lg break-words", {
                    variants: {
                        tooltipContentSize: {
                            xs: "max-w-40 md:max-w-60",
                            sm: "max-w-60 md:max-w-sm",
                            default: ""
                        }
                    },
                    defaultVariants: {
                        tooltipContentSize: "default"
                    }
                }),
                d = e => {
                    let {
                        maxWidth: a,
                        lineClamp: s,
                        tooltipContentSize: l,
                        className: d,
                        children: c,
                        ...u
                    } = e;
                    return (0, t.jsx)(n.TooltipProvider, {
                        children: (0, t.jsxs)(n.Tooltip, {
                            children: [(0, t.jsx)(n.TooltipTrigger, {
                                asChild: !0,
                                children: (0, t.jsx)("span", {
                                    className: (0, r.cn)(i({
                                        maxWidth: a,
                                        lineClamp: s
                                    }), d),
                                    ...u,
                                    children: c
                                })
                            }), (0, t.jsx)(n.TooltipContent, {
                                className: (0, r.cn)(o({
                                    tooltipContentSize: l
                                })),
                                children: c
                            })]
                        })
                    })
                }
        },
        5689: (e, a, s) => {
            s.d(a, {
                g: () => n
            });
            var t = s(12428),
                l = s(93264),
                r = s(62993);
            let n = l.forwardRef((e, a) => {
                let {
                    className: s,
                    ...l
                } = e;
                return (0, t.jsx)("textarea", {
                    className: (0, r.cn)("flex min-h-[80px] w-full rounded-md border border-input bg-background-secondary px-3 py-2 text-sm ring-offset-background placeholder:text-foreground-tertiary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 group-data-[success=true]:border-green-theme group-data-[success=true]:text-green-theme group-data-[success=true]:focus:border-green-theme group-data-[success=true]:placeholder:text-green-theme/50 group-data-[error=true]:border-red-theme group-data-[error=true]:text-red-theme group-data-[error=true]:focus:border-red-theme group-data-[error=true]:placeholder:text-red-theme/50", s),
                    ref: a,
                    ...l
                })
            });
            n.displayName = "Textarea"
        },
        48842: (e, a, s) => {
            s.d(a, {
                G: () => c,
                t: () => d
            });
            var t = s(12428),
                l = s(93264),
                r = s(32245),
                n = s(62993),
                i = s(52467);
            let o = l.createContext({
                    size: "default",
                    variant: "default"
                }),
                d = l.forwardRef((e, a) => {
                    let {
                        className: s,
                        variant: l,
                        size: i,
                        children: d,
                        ...c
                    } = e;
                    return (0, t.jsx)(r.fC, {
                        ref: a,
                        className: (0, n.cn)("flex items-center justify-center gap-1", s),
                        ...c,
                        children: (0, t.jsx)(o.Provider, {
                            value: {
                                variant: l,
                                size: i
                            },
                            children: d
                        })
                    })
                });
            d.displayName = r.fC.displayName;
            let c = l.forwardRef((e, a) => {
                let {
                    className: s,
                    children: d,
                    variant: c,
                    size: u,
                    ...m
                } = e, x = l.useContext(o);
                return (0, t.jsx)(r.ck, {
                    ref: a,
                    className: (0, n.cn)((0, i.E)({
                        variant: x.variant || c,
                        size: x.size || u
                    }), s),
                    ...m,
                    children: d
                })
            });
            c.displayName = r.ck.displayName
        },
        52467: (e, a, s) => {
            s.d(a, {
                E: () => o
            });
            var t = s(12428),
                l = s(93264),
                r = s(25434),
                n = s(51699),
                i = s(62993);
            let o = (0, n.j)("inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=on]:bg-accent data-[state=on]:text-accent-foreground", {
                variants: {
                    variant: {
                        default: "bg-transparent",
                        filterPill: "rounded-full bg-dark data-[state=on]:bg-background-contrast data-[state=on]:text-foreground-contrast",
                        outline: "border border-input bg-transparent hover:bg-accent hover:text-accent-foreground"
                    },
                    size: {
                        default: "h-10 px-3",
                        sm: "h-9 px-2.5",
                        xs: "py-0.5 px-1.5 text-xs leading-normal",
                        lg: "h-11 px-5"
                    }
                },
                defaultVariants: {
                    variant: "default",
                    size: "default"
                }
            });
            l.forwardRef((e, a) => {
                let {
                    className: s,
                    variant: l,
                    size: n,
                    ...d
                } = e;
                return (0, t.jsx)(r.f, {
                    ref: a,
                    className: (0, i.cn)(o({
                        variant: l,
                        size: n,
                        className: s
                    })),
                    ...d
                })
            }).displayName = r.f.displayName
        },
        20842: (e, a, s) => {
            s.d(a, {
                Tooltip: () => o,
                TooltipContent: () => c,
                TooltipProvider: () => i,
                TooltipTrigger: () => d
            });
            var t = s(12428),
                l = s(93264),
                r = s(36705),
                n = s(62993);
            let i = r.zt,
                o = r.fC,
                d = r.xz,
                c = l.forwardRef((e, a) => {
                    let {
                        className: s,
                        sideOffset: l = 4,
                        ...i
                    } = e;
                    return (0, t.jsx)(r.VY, {
                        ref: a,
                        sideOffset: l,
                        className: (0, n.cn)("z-50 overflow-hidden rounded bg-popover p-3 text-sm tracking-tight text-center text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", s),
                        ...i
                    })
                });
            c.displayName = r.VY.displayName
        },
        40798: (e, a, s) => {
            s.d(a, {
                pm: () => m
            });
            var t = s(93264);
            let l = 0,
                r = new Map,
                n = e => {
                    if (r.has(e)) return;
                    let a = setTimeout(() => {
                        r.delete(e), c({
                            type: "REMOVE_TOAST",
                            toastId: e
                        })
                    }, 1e6);
                    r.set(e, a)
                },
                i = (e, a) => {
                    switch (a.type) {
                        case "ADD_TOAST":
                            return { ...e,
                                toasts: [a.toast, ...e.toasts].slice(0, 1)
                            };
                        case "UPDATE_TOAST":
                            return { ...e,
                                toasts: e.toasts.map(e => e.id === a.toast.id ? { ...e,
                                    ...a.toast
                                } : e)
                            };
                        case "DISMISS_TOAST":
                            {
                                let {
                                    toastId: s
                                } = a;
                                return s ? n(s) : e.toasts.forEach(e => {
                                    n(e.id)
                                }),
                                { ...e,
                                    toasts: e.toasts.map(e => e.id === s || void 0 === s ? { ...e,
                                        open: !1
                                    } : e)
                                }
                            }
                        case "REMOVE_TOAST":
                            if (void 0 === a.toastId) return { ...e,
                                toasts: []
                            };
                            return { ...e,
                                toasts: e.toasts.filter(e => e.id !== a.toastId)
                            }
                    }
                },
                o = [],
                d = {
                    toasts: []
                };

            function c(e) {
                d = i(d, e), o.forEach(e => {
                    e(d)
                })
            }

            function u(e) {
                let { ...a
                } = e, s = (l = (l + 1) % Number.MAX_SAFE_INTEGER).toString(), t = () => c({
                    type: "DISMISS_TOAST",
                    toastId: s
                });
                return c({
                    type: "ADD_TOAST",
                    toast: { ...a,
                        id: s,
                        open: !0,
                        onOpenChange: e => {
                            e || t()
                        }
                    }
                }), {
                    id: s,
                    dismiss: t,
                    update: e => c({
                        type: "UPDATE_TOAST",
                        toast: { ...e,
                            id: s
                        }
                    })
                }
            }

            function m() {
                let [e, a] = t.useState(d);
                return t.useEffect(() => (o.push(a), () => {
                    let e = o.indexOf(a);
                    e > -1 && o.splice(e, 1)
                }), [e]), { ...e,
                    toast: u,
                    dismiss: e => c({
                        type: "DISMISS_TOAST",
                        toastId: e
                    })
                }
            }
        }
    }
]);