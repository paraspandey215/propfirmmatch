(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9660], {
        24683: () => {},
        67345: (e, s, a) => {
            "use strict";
            a.d(s, {
                C: () => i
            });
            var l = a(12428),
                r = a(3934),
                t = a(45151),
                n = a(91169);

            function i(e) {
                return (0, l.jsx)(r.default, {
                    href: n.u.instagram,
                    className: "box-content cursor-pointer",
                    target: "_blank",
                    children: (0, l.jsx)(t.K, {
                        className: e.className
                    })
                })
            }
        },
        57917: (e, s, a) => {
            "use strict";
            a.d(s, {
                PFMLogo: () => i
            });
            var l = a(12428),
                r = a(98661),
                t = a(62993),
                n = a(3934);

            function i(e) {
                let s = (0, r.mM)();
                return (0, l.jsxs)(n.default, {
                    href: s.NEXT_PUBLIC_MAIN_WEBSITE_URL,
                    className: "box-content cursor-pointer",
                    children: [(0, l.jsx)("img", {
                        alt: "pfm-logo-sm",
                        src: "/pfm-logo-symbol.svg",
                        className: (0, t.cn)("block md:hidden w-6", e.className)
                    }), (0, l.jsx)("img", {
                        alt: "pfm-logo-base",
                        src: "/pfm-logo.svg",
                        className: (0, t.cn)("hidden md:block", e.className)
                    })]
                })
            }
        },
        54495: (e, s, a) => {
            "use strict";
            a.d(s, {
                r: () => i
            });
            var l = a(12428),
                r = a(3934);

            function t(e) {
                return (0, l.jsx)("img", {
                    alt: "tiktok-logo",
                    src: "/tiktok-logo.svg",
                    className: e.className
                })
            }
            var n = a(91169);

            function i(e) {
                return (0, l.jsx)(r.default, {
                    href: n.u.tiktok,
                    className: "box-content cursor-pointer",
                    target: "_blank",
                    children: (0, l.jsx)(t, {
                        className: e.className
                    })
                })
            }
        },
        9855: (e, s, a) => {
            "use strict";
            a.d(s, {
                u: () => i
            });
            var l = a(12428),
                r = a(3934),
                t = a(54328),
                n = a(91169);

            function i(e) {
                return (0, l.jsx)(r.default, {
                    href: n.u.twitter,
                    className: "box-content cursor-pointer",
                    target: "_blank",
                    children: (0, l.jsx)(t.B, {
                        className: e.className
                    })
                })
            }
        },
        91023: (e, s, a) => {
            "use strict";
            a.d(s, {
                V: () => i
            });
            var l = a(12428),
                r = a(3934);

            function t(e) {
                return (0, l.jsx)("img", {
                    alt: "youtube-logo",
                    src: "/youtube-logo.svg",
                    className: e.className
                })
            }
            var n = a(91169);

            function i(e) {
                return (0, l.jsx)(r.default, {
                    href: n.u.youtube,
                    className: "box-content cursor-pointer",
                    target: "_blank",
                    children: (0, l.jsx)(t, {
                        className: e.className
                    })
                })
            }
        },
        89729: (e, s, a) => {
            "use strict";
            a.d(s, {
                NavBarRightSection: () => ea
            });
            var l = a(12428),
                r = a(34298),
                t = a(6185),
                n = a(11126),
                i = a(29782),
                o = a(6536),
                c = a(62993),
                d = a(66921),
                m = a(47576);

            function u(e) {
                let s = (0, m.useRouter)(),
                    a = (0, m.usePathname)(),
                    u = (0, d.useCurrentLocale)(i.E),
                    {
                        t: x
                    } = (0, t.$G)(),
                    f = e => {
                        let l = new Date;
                        l.setTime(l.getTime() + 2592e6), document.cookie = "".concat(i.E.localeCookie, "=").concat(e, ";expires=").concat(l.toUTCString(), ";path=/"), u !== i.E.defaultLocale || i.E.prefixDefault ? s.push(a.replace("/".concat(u), "/".concat(e))) : s.push("/" + e + a), s.refresh()
                    };
                return (0, l.jsx)("div", {
                    className: (0, c.cn)("flex items-center justify-end", e.className),
                    children: (0, l.jsxs)(o.Select, {
                        value: u,
                        onValueChange: e => f(e),
                        children: [(0, l.jsx)(o.SelectTrigger, {
                            className: "border-0 focus:ring-0 focus:ring-offset-0 px-2 whitespace-nowrap bg-transparent",
                            children: (0, l.jsx)(o.SelectValue, {})
                        }), (0, l.jsx)(o.SelectContent, {
                            children: (0, l.jsxs)(o.SelectItem, {
                                className: "cursor-pointer",
                                value: n.go.En,
                                children: [(0, l.jsx)(r.L, {
                                    country: "GB"
                                }), (0, l.jsx)("span", {
                                    className: "px-2 font-semibold",
                                    children: x("En")
                                })]
                            })
                        })]
                    })
                })
            }
            var x = a(98661),
                f = a(49433),
                h = a(48411),
                p = a(95805),
                g = a(40850),
                v = a(44538),
                j = a(46354),
                b = a(5313),
                N = a(75014),
                w = a(68019),
                y = a(86384),
                S = a(25845),
                _ = a(2402),
                k = a(88480),
                C = a(3934),
                E = a(93264),
                I = a(44427);

            function B(e) {
                let {
                    t: s
                } = (0, t.$G)();
                return (0, l.jsx)(I.aR, {
                    open: e.open,
                    onOpenChange: e.setOpen,
                    children: (0, l.jsxs)(I._T, {
                        className: "max-w-[440px]",
                        children: [(0, l.jsxs)(I.fY, {
                            children: [(0, l.jsx)(I.f$, {
                                className: "flex items-center",
                                children: s("Sign Out")
                            }), (0, l.jsx)(I.yT, {
                                children: s("Are you sure you want to sign out from your account?")
                            })]
                        }), (0, l.jsxs)(I.xo, {
                            children: [(0, l.jsx)(g.zx, {
                                variant: "outline",
                                rounded: "full",
                                className: "flex-1",
                                onClick: () => e.setOpen(!1),
                                children: s("Cancel")
                            }), (0, l.jsx)(g.zx, {
                                variant: "pfmGradient",
                                className: "flex-1",
                                rounded: "full",
                                onClick: () => e.onConfirm(),
                                children: s("Confirm")
                            })]
                        })]
                    })
                })
            }
            let R = (0, k.default)(() => a.e(3100).then(a.bind(a, 73100)), {
                    loadableGenerated: {
                        webpack: () => [73100]
                    },
                    ssr: !1
                }),
                T = (0, c.cn)("relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 hover:bg-dark", "gap-3 py-2 mb-[1px] hover:font-semibold hover:rounded-full hover:bg-background-secondary focus:bg-background-secondary"),
                U = "group-hover:text-primary-theme";

            function L() {
                let {
                    signOut: e
                } = (0, f.ll)(), {
                    t: s
                } = (0, t.$G)(), [a, r] = (0, E.useState)(!1), [n, i] = (0, E.useState)(!1), o = (0, x.mM)(), d = (0, E.useMemo)(() => [{
                    label: s("My Profile"),
                    icon: (0, l.jsx)(N.Z, {
                        className: (0, c.cn)(U),
                        size: 16
                    }),
                    href: o.NEXT_PUBLIC_DASHBOARD_WEBSITE_URL
                }, {
                    label: s("Account Security"),
                    render: () => (0, l.jsxs)("div", {
                        className: (0, c.cn)(T, "group"),
                        onClick: () => i(!0),
                        children: [(0, l.jsx)(b.lE, {
                            className: (0, c.cn)(U)
                        }), (0, l.jsx)("span", {
                            className: "hover:font-semibold",
                            children: s("Account Security")
                        })]
                    })
                }, {
                    label: s("Affiliate Program"),
                    icon: (0, l.jsx)(b.Vt, {
                        className: (0, c.cn)(U)
                    }),
                    href: o.NEXT_PUBLIC_MAIN_WEBSITE_URL + "/join-affiliate-program"
                }, {
                    label: s("FAQ & Support"),
                    icon: (0, l.jsx)(w.Z, {
                        className: (0, c.cn)(U),
                        size: 16
                    }),
                    href: o.NEXT_PUBLIC_DASHBOARD_WEBSITE_URL + "/support"
                }, {
                    label: s("My Reviews"),
                    icon: (0, l.jsx)(b._z, {
                        className: (0, c.cn)(U)
                    }),
                    href: o.NEXT_PUBLIC_DASHBOARD_WEBSITE_URL + "/reviews"
                }, {
                    label: s("Pending Reviews"),
                    icon: (0, l.jsx)(b.m_, {
                        className: (0, c.cn)(U)
                    }),
                    href: o.NEXT_PUBLIC_DASHBOARD_WEBSITE_URL + "/reviews/pending"
                }, {
                    label: s("Bookmarks"),
                    icon: (0, l.jsx)(y.Z, {
                        className: (0, c.cn)(U),
                        size: 16
                    }),
                    href: o.NEXT_PUBLIC_DASHBOARD_WEBSITE_URL + "/bookmarks"
                }], [s, o]);
                return (0, l.jsxs)("div", {
                    children: [(0, l.jsx)(v.dy, {
                        modal: !1,
                        open: n,
                        onOpenChange: i,
                        children: (0, l.jsxs)(v.sc, {
                            className: "fixed inset-0 w-[fit-fontent] max-w-[100vw] p-0 rounded-none border-none",
                            children: [(0, l.jsx)(v.OX, {
                                className: "sr-only",
                                children: (0, l.jsx)(v.iI, {
                                    children: s("Account Security")
                                })
                            }), (0, l.jsx)("div", {
                                className: "flex justify-center mt-4",
                                children: (0, l.jsx)(v.uh, {
                                    asChild: !0,
                                    children: (0, l.jsxs)(g.zx, {
                                        variant: "outline",
                                        children: [(0, l.jsx)(S.Z, {
                                            className: "w-4 mr-2"
                                        }), s("Close")]
                                    })
                                })
                            }), (0, l.jsx)("div", {
                                className: "h-full w-full flex justify-center my-4 overflow-y-auto",
                                children: (0, l.jsx)(h.UserProfile, {
                                    routing: "virtual",
                                    appearance: {
                                        variables: {
                                            colorBackground: "hsl(330, 6.7%, 5.9%)",
                                            colorText: "white",
                                            colorTextSecondary: "hsl(340, 2.5%, 76.3%)",
                                            colorInputText: "hsl(330, 6.7%, 5.9%)",
                                            colorPrimary: "hsl(330.9, 77%, 59%)",
                                            colorNeutral: "white",
                                            colorWarning: "hsl(0, 84%, 63.1%)",
                                            fontSize: "16px"
                                        }
                                    }
                                })
                            })]
                        })
                    }), (0, l.jsxs)(j.h_, {
                        children: [(0, l.jsx)(j.$F, {
                            className: "rounded-full",
                            children: (0, l.jsx)(z, {})
                        }), (0, l.jsxs)(j.AW, {
                            align: "center",
                            className: "px-4 py-3 min-w-64",
                            children: [(0, l.jsx)(A, {}), d.map(e => {
                                var s;
                                return (0, l.jsx)(j.Xi, {
                                    asChild: !0,
                                    children: "render" in e ? e.render() : (0, l.jsxs)(C.default, {
                                        href: null !== (s = e.href) && void 0 !== s ? s : "/",
                                        className: (0, c.cn)(T, "group"),
                                        children: [e.icon, e.label]
                                    })
                                }, e.label)
                            }), (0, l.jsx)(j.VD, {
                                className: "my-3"
                            }), (0, l.jsxs)(j.Xi, {
                                className: (0, c.cn)(T, "text-red-theme"),
                                onClick: e => {
                                    e.preventDefault(), r(!0)
                                },
                                children: [(0, l.jsx)(_.Z, {
                                    size: 20
                                }), s("Sign out")]
                            }), (0, l.jsx)(B, {
                                onConfirm: () => e(),
                                open: a,
                                setOpen: r
                            })]
                        })]
                    })]
                })
            }
            let z = e => {
                    var s, a;
                    let {
                        className: r
                    } = e, {
                        user: t
                    } = (0, f.aF)();
                    return (0, l.jsxs)(p.Avatar, {
                        className: (0, c.cn)("size-7 md:size-8", r),
                        children: [(null == t ? void 0 : t.hasImage) && (0, l.jsx)(p.AvatarImage, {
                            src: null == t ? void 0 : t.imageUrl
                        }), (0, l.jsxs)(p.Q, {
                            className: "bg-background-tertiary font-medium text-xs leading-[12px]",
                            children: [null == t ? void 0 : null === (s = t.firstName) || void 0 === s ? void 0 : s[0], null == t ? void 0 : null === (a = t.lastName) || void 0 === a ? void 0 : a[0]]
                        })]
                    })
                },
                A = () => {
                    var e;
                    let {
                        user: s
                    } = (0, f.aF)();
                    return (0, l.jsxs)(j.Ju, {
                        className: "px-0",
                        children: [(0, l.jsxs)("div", {
                            className: "flex items-center mb-3 gap-2",
                            children: [(0, l.jsx)(z, {}), (0, l.jsxs)("div", {
                                className: "flex-col max-w-52 pr-2",
                                children: [(0, l.jsx)("div", {
                                    className: "text-base overflow-hidden text-ellipsis",
                                    children: null == s ? void 0 : s.fullName
                                }), (0, l.jsx)("div", {
                                    className: "font-normal text-foreground-tertiary overflow-hidden text-ellipsis",
                                    children: null == s ? void 0 : null === (e = s.primaryEmailAddress) || void 0 === e ? void 0 : e.emailAddress
                                })]
                            })]
                        }), (0, l.jsx)(E.Suspense, {
                            children: (0, l.jsx)(R, {})
                        })]
                    })
                };
            var P = a(1545),
                F = a(97385),
                M = a(67345),
                X = a(54495),
                W = a(9855),
                D = a(91023),
                G = a(74777),
                $ = a(72927),
                O = a(95262),
                Z = a(56360),
                V = a(26268),
                H = a(1481),
                Y = a(39081);

            function J(e) {
                let s = (0, x.mM)();
                return e.disabled ? (0, l.jsxs)("div", {
                    className: "bg-background flex gap-2 h-[60px] items-center justify-start p-4 rounded-md text-sm opacity-70",
                    children: [e.icon, e.label]
                }) : (0, l.jsx)(C.default, {
                    href: "".concat(s.NEXT_PUBLIC_MAIN_WEBSITE_URL).concat(e.href),
                    className: "hover:underline",
                    children: (0, l.jsxs)("div", {
                        className: "bg-background-secondary hover:bg-background-tertiary flex gap-2 h-[60px] items-center justify-start p-4 rounded-md text-sm",
                        children: [e.icon, e.label]
                    })
                })
            }

            function K(e) {
                return (0, l.jsx)("p", {
                    className: (0, c.cn)("text-sm font-semibold uppercase", e.className),
                    children: e.children
                })
            }

            function Q(e) {
                let s = (0, x.mM)();
                return (0, l.jsx)("div", {
                    className: "text-sm text-foreground-secondary",
                    role: "menuitem",
                    children: (0, l.jsx)(C.default, {
                        href: "".concat(s.NEXT_PUBLIC_MAIN_WEBSITE_URL).concat(e.href),
                        className: "hover:underline",
                        children: e.children
                    })
                })
            }
            let q = (0, k.default)(() => a.e(7084).then(a.bind(a, 37084)), {
                loadableGenerated: {
                    webpack: () => [37084]
                },
                ssr: !1
            });

            function ee(e) {
                let {
                    className: s
                } = e, {
                    t: a
                } = (0, t.$G)(), r = (0, E.useRef)(null), [n, i] = (0, E.useState)(!1), o = (0, E.useMemo)(() => [{
                    href: "/",
                    label: a("Firms"),
                    icon: (0, l.jsx)(b.FR, {
                        size: "xs"
                    })
                }, {
                    href: "/prop-firm-challenges",
                    icon: (0, l.jsx)(b.jx, {
                        size: "xs"
                    }),
                    label: a("Challenges")
                }, {
                    href: "/payouts",
                    icon: (0, l.jsx)(b.UX, {
                        size: "xs"
                    }),
                    label: (0, l.jsxs)("div", {
                        className: "flex items-center gap-0.5",
                        children: [(0, l.jsx)("p", {
                            children: a("Payouts")
                        }), (0, l.jsx)(G.C, {
                            rounded: "full",
                            variant: "green",
                            className: "text-[10px] px-2 text-foreground-secondary",
                            children: a("Coming Soon")
                        })]
                    }),
                    disabled: !0
                }, {
                    href: "/reviews",
                    icon: (0, l.jsx)(b.NF, {
                        size: "xs"
                    }),
                    label: a("Reviews")
                }, {
                    href: "/exclusive-offers",
                    icon: (0, l.jsx)(b.EY, {
                        size: "xs"
                    }),
                    label: a("Offers")
                }, {
                    href: "/best-sellers",
                    icon: (0, l.jsx)(b.aB, {
                        size: "xs"
                    }),
                    label: a("Best Sellers")
                }, {
                    href: "/favorite-firms",
                    icon: (0, l.jsx)(b.hp, {
                        size: "xs"
                    }),
                    label: a("Favorite Firms")
                }, {
                    href: "/prop-firm-rules",
                    icon: (0, l.jsx)(b.E2, {
                        size: "xs"
                    }),
                    label: a("Prop Firm Rules")
                }], [a]), d = (0, E.useMemo)(() => [{
                    label: a("Resources"),
                    items: [{
                        label: a("Blog"),
                        href: "/blog"
                    }, {
                        label: a("Prop Firm Lists"),
                        href: "/prop-firm-lists"
                    }, {
                        label: a("Demo Accounts"),
                        href: "/prop-firm-demo-accounts"
                    }, {
                        label: a("How It Works"),
                        href: "/how-it-works"
                    }, {
                        label: a("High Impact News"),
                        href: "/high-impact-news"
                    }, {
                        label: a("Announcements"),
                        href: "/prop-firm-announcements"
                    }]
                }, {
                    label: a("Program"),
                    items: [{
                        label: a("Loyalty Points"),
                        href: "/loyalty-program"
                    }, {
                        label: a("Affiliate Program"),
                        href: "/join-affiliate-program"
                    }]
                }, {
                    label: a("Contact"),
                    items: [{
                        label: a("Contact"),
                        href: "/contact"
                    }, {
                        label: a("About Us"),
                        href: "/about-us"
                    }]
                }], [a]);
                return (0, E.useEffect)(() => {
                    let e = e => {
                        r.current && !r.current.contains(e.target) && i(!1)
                    };
                    return document.addEventListener("mousedown", e), () => {
                        document.removeEventListener("mousedown", e)
                    }
                }, [i]), (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)(g.zx, {
                        variant: "ghost",
                        size: "icon",
                        className: "p-1.5",
                        onClick: () => i(!n),
                        children: n ? (0, l.jsx)(V.Z, {
                            className: "size-5"
                        }) : (0, l.jsx)(H.Z, {
                            className: "size-5"
                        })
                    }), (0, l.jsx)(O.M, {
                        children: n ? (0, l.jsx)(Z.E.div, {
                            animate: {
                                height: "auto"
                            },
                            className: (0, c.cn)("absolute overflow-hidden", s),
                            exit: {
                                height: 0
                            },
                            initial: {
                                height: 0
                            },
                            layout: !0,
                            ref: r,
                            transition: {
                                duration: .2,
                                ease: "linear"
                            },
                            children: (0, l.jsx)($.ScrollArea, {
                                scrollable: !0,
                                className: "md:h-auto h-screen",
                                children: (0, l.jsx)("div", {
                                    className: "bg-background md:bg-background md:w-full relative min-h-screen md:min-h-min z-40",
                                    children: (0, l.jsxs)(Y.W, {
                                        className: "flex flex-col md:flex-row items-stretch gap-6 md:gap-10 py-6 pt-14 md:py-10 md:px-4 px-4",
                                        children: [(0, l.jsx)(g.zx, {
                                            variant: "ghost",
                                            size: "iconXl",
                                            className: "p-1.5 absolute top-3 right-3 md:hidden",
                                            onClick: () => i(!n),
                                            children: (0, l.jsx)(S.Z, {
                                                className: "size-5"
                                            })
                                        }), (0, l.jsxs)("div", {
                                            className: "md:hidden flex items-center justify-center",
                                            children: [(0, l.jsx)("div", {
                                                className: "flex gap-4 basis-1/2",
                                                children: (0, l.jsx)(u, {
                                                    className: "mx-auto"
                                                })
                                            }), (0, l.jsx)(P.CH, {
                                                children: (0, l.jsxs)("div", {
                                                    className: "flex items-center basis-1/2",
                                                    children: [(0, l.jsx)(F.Separator, {
                                                        orientation: "vertical",
                                                        className: "h-5"
                                                    }), (0, l.jsx)("div", {
                                                        className: "mx-auto flex items-center",
                                                        children: (0, l.jsx)(q, {
                                                            className: "min-w-32"
                                                        })
                                                    })]
                                                })
                                            })]
                                        }), (0, l.jsx)("div", {
                                            className: "basis-1/2 lg:basis-1/3",
                                            children: (0, l.jsx)("div", {
                                                className: "gap-1 grid grid-cols-2",
                                                children: o.map((e, s) => (0, l.jsx)(J, {
                                                    href: e.href,
                                                    icon: e.icon,
                                                    label: e.label,
                                                    disabled: e.disabled
                                                }, "".concat(e.label, "-").concat(s)))
                                            })
                                        }), (0, l.jsx)("div", {
                                            className: "border-border-secondary border-r hidden md:block w-px"
                                        }), (0, l.jsxs)("div", {
                                            className: "flex-grow gap-4 gap-y-8 grid grid-cols-2 lg:gap-y-0 lg:grid-cols-3",
                                            children: [d.map((e, s) => (0, l.jsxs)("div", {
                                                className: (0, c.cn)("space-y-4", 0 === s && "col-span-full grid grid-cols-2 gap-x-4 md:col-span-1 md:grid-cols-1"),
                                                children: [(0, l.jsx)(K, {
                                                    className: (0, c.cn)(0 === s && "col-span-full"),
                                                    children: e.label
                                                }), e.items.map((s, a) => (0, l.jsx)(Q, {
                                                    href: s.href,
                                                    children: s.label
                                                }, "".concat(e.label, "-").concat(a)))]
                                            }, e.label)), (0, l.jsxs)("div", {
                                                className: "lg:col-start-3 lg:row-end-2 lg:row-start-2 lg:-mt-16 space-y-4",
                                                children: [(0, l.jsx)(K, {
                                                    children: a("Social")
                                                }), (0, l.jsxs)("div", {
                                                    className: "flex items-center space-x-4 xl:space-x-7",
                                                    children: [(0, l.jsx)(W.u, {}), (0, l.jsx)(M.C, {
                                                        className: "h-6 w-6"
                                                    }), (0, l.jsx)(D.V, {}), (0, l.jsx)(X.r, {})]
                                                })]
                                            })]
                                        })]
                                    })
                                })
                            })
                        }) : null
                    })]
                })
            }
            let es = (0, k.default)(() => a.e(7084).then(a.bind(a, 37084)), {
                    loadableGenerated: {
                        webpack: () => [37084]
                    },
                    ssr: !1
                }),
                ea = () => {
                    let {
                        t: e
                    } = (0, t.$G)(), s = (0, f.ll)();
                    return (0, l.jsxs)("div", {
                        className: "flex items-center",
                        children: [(0, l.jsxs)("div", {
                            className: "flex gap-1 md:gap-4",
                            children: [(0, l.jsxs)(P.tj, {
                                children: [(0, l.jsx)(g.zx, {
                                    variant: "ghost",
                                    className: "px-2 md:px-5",
                                    rounded: "full",
                                    onClick: () => s.redirectToSignIn(),
                                    children: e("Log in")
                                }), (0, l.jsx)(g.zx, {
                                    variant: "pfmGradient",
                                    className: "px-2 md:px-5",
                                    rounded: "full",
                                    onClick: () => s.redirectToSignUp(),
                                    children: e("Sign up")
                                })]
                            }), (0, l.jsxs)(P.CH, {
                                children: [(0, l.jsx)(es, {
                                    className: "hidden md:block min-w-32"
                                }), (0, l.jsx)(L, {})]
                            })]
                        }), (0, l.jsxs)("div", {
                            className: "flex items-center",
                            children: [(0, l.jsx)(F.Separator, {
                                orientation: "vertical",
                                className: "h-5 mx-4 hidden md:block"
                            }), (0, l.jsx)(u, {
                                className: "hidden md:block"
                            }), (0, l.jsx)(F.Separator, {
                                orientation: "vertical",
                                className: "hidden md:block h-5 mx-2.5 md:mx-4"
                            }), (0, l.jsx)(ee, {
                                className: "right-0 md:left-0 md:ml-0 xl:ml-0 h-screen md:h-full top-0 md:top-[100px] w-full xl:w-full"
                            })]
                        })]
                    })
                }
        },
        65318: (e, s, a) => {
            "use strict";
            a.d(s, {
                NavBarSearch: () => C
            });
            var l = a(12428),
                r = a(6185),
                t = a(69615),
                n = a(28422),
                i = a(85473),
                o = a(40850),
                c = a(59957),
                d = a(62993),
                m = a(51699),
                u = a(56360),
                x = a(65747),
                f = a(95262),
                h = a(35449),
                p = a(66453),
                g = a(26268),
                v = a(3934),
                j = a(93264),
                b = a(64608);
            let N = (0, m.j)("", {
                    variants: {
                        variant: {
                            default: "focus:border-primary-theme",
                            blue: "focus:border-blue-theme"
                        }
                    },
                    defaultVariants: {
                        variant: "default"
                    }
                }),
                w = e => {
                    let {
                        loading: s,
                        className: a
                    } = e, {
                        t
                    } = (0, r.$G)();
                    return s ? (0, l.jsx)(h.Z, {
                        "aria-label": t("Loading search results"),
                        className: (0, d.cn)("animate-spin", a),
                        role: "status"
                    }) : (0, l.jsx)(p.Z, {
                        className: a,
                        "aria-label": "Search",
                        role: "img"
                    })
                },
                y = () => {
                    let {
                        t: e
                    } = (0, r.$G)();
                    return (0, l.jsx)(n.Gp, {
                        className: "h-auto min-h-[58px]",
                        placeholderText: e("No firms")
                    })
                },
                S = e => {
                    let {
                        firm: s,
                        onClick: a
                    } = e;
                    return (0, l.jsx)(v.default, {
                        className: "hover:bg-background-secondary hover:cursor-pointer block px-4 py-3",
                        href: "/prop-firms/".concat(s.slug),
                        onClick: a,
                        role: "option",
                        children: (0, l.jsxs)("div", {
                            className: "flex gap-2 items-center",
                            children: [(0, l.jsx)(t.wK, {
                                firm: s,
                                className: "h-[34px] w-[34px]"
                            }), (0, l.jsx)("span", {
                                className: "align-middle inline-block text-sm",
                                children: s.name
                            })]
                        })
                    })
                },
                _ = (0, j.forwardRef)((e, s) => {
                    let {
                        onItemClick: a,
                        searchResults: t
                    } = e, {
                        t: n
                    } = (0, r.$G)();
                    return (0, l.jsx)("div", {
                        "aria-label": n("Search results"),
                        className: "absolute bg-background-primary border border-border font-semibold hidden max-h-36 md:block min-h-auto mt-[2.5px] overflow-y-auto py-5 rounded-lg w-full",
                        ref: s,
                        role: "listbox",
                        children: t.length ? t.map(e => (0, l.jsx)(S, {
                            firm: e,
                            onClick: a
                        }, e.id)) : (0, l.jsx)(y, {})
                    })
                });
            _.displayName = "SearchResultsContainer";
            let k = e => {
                    let {
                        children: s
                    } = e;
                    return (0, l.jsx)(u.E.div, {
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        className: "bg-background fixed font-semibold h-dvh left-0 md:hidden pt-4 top-0 w-screen z-30 flex flex-col gap-3",
                        exit: {
                            opacity: 0,
                            y: 0
                        },
                        initial: {
                            opacity: 0,
                            y: 0
                        },
                        layout: !0,
                        transition: x.S,
                        children: s
                    })
                },
                C = e => {
                    var s, a, t, n, m, u, x;
                    let {
                        t: h
                    } = (0, r.$G)(), p = (0, j.useRef)(null), v = (0, j.useRef)(null), [C, E] = (0, j.useState)(!1), [I, B] = (0, j.useState)(!1), [R, T] = (0, j.useState)(""), [U] = (0, b.Nr)(R, 400), L = (0, j.useCallback)(() => {
                        E(!1), B(!1), T("")
                    }, []), z = i.trpc.firm.listAll.useQuery({
                        limit: 100,
                        search: U
                    }, {
                        enabled: U.length >= 2
                    });
                    (0, j.useEffect)(() => {
                        let e = e => {
                            p.current && !p.current.contains(e.target) && E(!1)
                        };
                        return document.addEventListener("mousedown", e), () => {
                            document.removeEventListener("mousedown", e)
                        }
                    }, [p]), (0, j.useEffect)(() => {
                        var e;
                        (null === (e = z.data) || void 0 === e ? void 0 : e.data) && E(!0)
                    }, [null === (s = z.data) || void 0 === s ? void 0 : s.data]);
                    let A = (0, j.useCallback)(() => {
                        var e;
                        E(!!(null === (e = z.data) || void 0 === e ? void 0 : e.data)), B(!0)
                    }, [null === (a = z.data) || void 0 === a ? void 0 : a.data]);
                    return (0, l.jsxs)("div", {
                        className: "flex-1 max-w-lg mr-2 md:mx-4 relative",
                        children: [(0, l.jsx)(c.I, {
                            className: (0, d.cn)("w-full !pl-[42px] rounded-full py-1.5 h-7 md:py-2 md:h-9 text-xs md:text-sm", N({
                                variant: e.variant
                            })),
                            leftIcon: (0, l.jsx)(w, {
                                loading: z.isLoading
                            }),
                            onChange: e => T(e.target.value),
                            onFocus: A,
                            placeholder: h("Search a Prop Firm"),
                            ref: v,
                            type: "text",
                            value: R,
                            wrapperClassName: "[&_svg]:w-3 [&_svg]:h-3 md:[&_svg]:w-4 md:[&_svg]:h-4 [&>span]:pl-4"
                        }), (null === (t = z.data) || void 0 === t ? void 0 : t.data) && C ? (0, l.jsx)(_, {
                            ref: p,
                            searchResults: null === (n = z.data) || void 0 === n ? void 0 : n.data,
                            onItemClick: L
                        }) : null, (0, l.jsx)(f.M, {
                            children: I && (0, l.jsxs)(k, {
                                children: [(0, l.jsxs)("div", {
                                    className: "absolue top-0 left-0 flex w-full items-center gap-2.5 px-4",
                                    children: [(0, l.jsx)(c.I, {
                                        autoFocus: !0,
                                        className: (0, d.cn)("font-normal h-7 md:h-9 md:py-2 !pl-[42px] py-1.5 rounded-full text-xs md:text-sm w-full z-40", N({
                                            variant: e.variant
                                        })),
                                        leftIcon: (0, l.jsx)(w, {
                                            className: "z-50",
                                            loading: z.isLoading
                                        }),
                                        onChange: e => T(e.target.value),
                                        onFocus: A,
                                        placeholder: h("Search a Prop Firm"),
                                        type: "text",
                                        value: R,
                                        wrapperClassName: "flex-grow [&_svg]:h-3 [&_svg]:w-3 md:[&_svg]:h-4 md:[&_svg]:w-4 [&>span]:pl-4"
                                    }), (0, l.jsx)(o.zx, {
                                        className: "h-auto p-1.5",
                                        onClick: () => B(!1),
                                        size: "icon",
                                        variant: "ghost",
                                        children: (0, l.jsx)(g.Z, {
                                            className: "size-5"
                                        })
                                    })]
                                }), (null === (m = z.data) || void 0 === m ? void 0 : m.data) && I ? (0, l.jsx)("div", {
                                    className: "flex-grow overflow-y-auto",
                                    children: (null === (u = z.data) || void 0 === u ? void 0 : u.data.length) ? null === (x = z.data) || void 0 === x ? void 0 : x.data.map(e => (0, l.jsx)(S, {
                                        firm: e,
                                        onClick: L
                                    }, e.id)) : (0, l.jsx)(y, {})
                                }) : null]
                            })
                        })]
                    })
                }
        },
        28233: (e, s, a) => {
            "use strict";
            a.d(s, {
                NavigationMenu: () => n
            });
            var l = a(12428),
                r = a(6185),
                t = a(86464);

            function n() {
                let {
                    t: e
                } = (0, r.$G)();
                return (0, l.jsxs)("nav", {
                    className: "h-[40px] flex items-center justify-around overflow-y-auto",
                    children: [(0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/",
                        className: "flex-1 text-center text-nowrap",
                        children: e("Home")
                    }), (0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/extra-account-promo",
                        aliases: ["/exclusive-offers", "/offers"],
                        className: "flex-1 text-center text-nowrap",
                        children: e("Offers")
                    }), (0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/best-sellers",
                        className: "flex-1 text-center text-nowrap",
                        children: e("Best Sellers")
                    }), (0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/reviews",
                        className: "flex-1 text-center text-nowrap",
                        children: e("Reviews")
                    }), (0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/favorite-firms",
                        className: "flex-1 text-center text-nowrap",
                        children: e("Favorite Firms")
                    }), (0, l.jsx)(t.f, {
                        variant: "underlined",
                        href: "/prop-firm-rules",
                        className: "flex-1 text-center text-nowrap",
                        children: e("Prop Firm Rules")
                    }), (0, l.jsx)(t.f, {
                        className: "flex-1 text-center text-nowrap",
                        href: "/brokers",
                        new: !0,
                        variant: "underlined",
                        children: e("Brokers")
                    }), (0, l.jsx)(t.f, {
                        className: "flex-1 text-center text-nowrap",
                        new: !0,
                        href: "/prop-firm-spreads",
                        variant: "underlined",
                        children: e("Spreads")
                    }), (0, l.jsx)(t.f, {
                        className: "flex-1 text-center text-nowrap",
                        comingSoon: e("Coming Soon"),
                        disabled: !0,
                        href: "/payouts",
                        variant: "underlined",
                        children: e("Payouts")
                    }), (0, l.jsx)(t.f, {
                        className: "flex-1 text-center text-nowrap",
                        comingSoon: e("Coming Soon"),
                        disabled: !0,
                        href: "/futures",
                        variant: "underlined",
                        children: e("Futures")
                    })]
                })
            }
        },
        47945: (e, s, a) => {
            "use strict";
            a.d(s, {
                ProductCheckout: () => u
            });
            var l = a(12428),
                r = a(6185),
                t = a(98661),
                n = a(49433),
                i = a(46354),
                o = a(62993),
                c = a(30455),
                d = a(3934),
                m = a(93264);
            let u = () => {
                let [e, s] = (0, m.useState)(!1), {
                    user: a
                } = (0, n.aF)(), u = (0, t.mM)(), x = null == a ? void 0 : a.organizationMemberships.find(e => e.organization.slug), {
                    t: f
                } = (0, r.$G)(), h = (0, m.useMemo)(() => window.location.href.includes(u.NEXT_PUBLIC_BUSINESS_WEBSITE_URL) ? {
                    business: !0,
                    main: !1
                } : {
                    business: !1,
                    main: !0
                }, [u.NEXT_PUBLIC_BUSINESS_WEBSITE_URL, u.NEXT_PUBLIC_MAIN_WEBSITE_URL, u.NEXT_PUBLIC_WEBSITE_URL]);
                return (0, l.jsxs)(i.h_, {
                    onOpenChange: e => s(e),
                    children: [(0, l.jsx)(i.$F, {
                        asChild: !0,
                        className: "rounded-full w-6 lg:w-auto h-6 flex items-center justify-center focus:outline-none cursor-pointer",
                        "aria-label": f("Toggle product menu"),
                        children: (0, l.jsxs)("div", {
                            children: [(0, l.jsx)(c.Z, {
                                className: (0, o.cn)("w-4 transition-transform duration-200 lg:hidden", e ? "rotate-180 text-white" : "text-foreground-tertiary")
                            }), (0, l.jsxs)("div", {
                                className: "hidden lg:flex items-center",
                                children: [(0, l.jsx)("p", {
                                    className: "text-sm font-medium",
                                    children: f("Products")
                                }), (0, l.jsx)(c.Z, {
                                    className: (0, o.cn)("w-3 ml-2 transition-transform duration-200", e ? "rotate-180 text-white" : "text-foreground-tertiary")
                                })]
                            })]
                        })
                    }), (0, l.jsx)(i.AW, {
                        align: "center",
                        className: "bg-[hsl(var(--color-gray-800))] border border-background-secondary p-6 min-w-64 md:-ml-12 mt-1 md:mt-2",
                        children: (0, l.jsx)("div", {
                            className: "space-y-2",
                            children: [{
                                itemClass: (0, o.cn)("bg-[url(/pfm-bg.png)] hover:border-primary-theme", h.main && "border-primary-theme"),
                                logo: (0, l.jsx)("img", {
                                    alt: "pfm-logo-base",
                                    src: "/pfm-logo.svg",
                                    className: "block w-36"
                                }),
                                href: u.NEXT_PUBLIC_MAIN_WEBSITE_URL
                            }, {
                                itemClass: (0, o.cn)("bg-[url(/pfb-bg.png)] hover:border-purple-theme", h.business && "border-purple-theme"),
                                logo: (0, l.jsx)("img", {
                                    alt: "pfm-logo-business",
                                    src: "/pfm-logo-blue.svg",
                                    className: "block w-40"
                                }),
                                href: x ? u.NEXT_PUBLIC_BUSINESS_WEBSITE_URL : a ? u.NEXT_PUBLIC_BUSINESS_WEBSITE_URL + "/firm-listing-form" : u.NEXT_PUBLIC_BUSINESS_WEBSITE_URL
                            }, {
                                itemClass: "bg-[url(/pf1-bg.png)] hover:border-purple-theme",
                                logo: (0, l.jsx)("img", {
                                    alt: "pf-one-logo",
                                    src: "/pf-one-logo.svg",
                                    className: "block w-32"
                                }),
                                disabled: !1,
                                comingSoon: !1,
                                href: "https://propfirmone.com/"
                            }].map((e, s) => (0, l.jsx)("div", {
                                className: (0, o.cn)("flex items-end justify-start relative w-80 h-32 overflow-hidden transition duration-200", {
                                    "hover:brightness-150": !e.disabled,
                                    "bg-opacity-30 cursor-not-allowed hover:border-background-secondary": e.disabled
                                }),
                                children: e.disabled ? (0, l.jsxs)("div", {
                                    className: "relative w-full h-full flex items-end p-5 rounded-lg border border-background-secondary",
                                    children: [(0, l.jsx)("div", {
                                        className: (0, o.cn)("absolute top-0 left-0 opacity-50 z-0 w-full h-full bg-cover rounded-lg", e.itemClass)
                                    }), e.comingSoon && (0, l.jsx)("div", {
                                        className: "absolute top-0 right-0 bg-[hsl(var(--color-green-900))] bg-opacity-30 text-[hsl(var(--color-green-400))] text-xxs uppercase px-3 py-1 rounded-bl-2xl rounded-tr-lg font-semibold",
                                        children: f("Coming soon")
                                    }), (0, l.jsx)("span", {
                                        className: "opacity-50",
                                        children: e.logo
                                    })]
                                }) : (0, l.jsx)(d.default, {
                                    href: e.href,
                                    className: (0, o.cn)("w-full h-full flex items-end rounded-lg p-5 bg-cover border border-background-secondary", e.itemClass),
                                    children: e.logo
                                })
                            }, s))
                        })
                    })]
                })
            }
        },
        91169: (e, s, a) => {
            "use strict";
            a.d(s, {
                u: () => l
            });
            let l = {
                instagram: "https://www.instagram.com/propfirmmatch",
                twitter: "https://twitter.com/propfirmmatch",
                facebook: "https://www.facebook.com/PropFirmMatch",
                youtube: "https://www.youtube.com/channel/UCY-imVjtKo8NO4TEEZjh8cw",
                tiktok: "https://www.tiktok.com/@propfirmmatch",
                telegram: "https://t.me/propfirmmatch",
                proptalk: "https://proptalk.propfirmmatch.com/signup"
            }
        },
        66630: (e, s, a) => {
            "use strict";
            a.d(s, {
                J: () => n
            });
            var l = a(6185),
                r = a(47576),
                t = a(93264);

            function n() {
                let e = (0, r.usePathname)(),
                    {
                        locale: s,
                        defaultLocale: a
                    } = (0, l.bU)();
                return (0, t.useMemo)(() => (s === a ? e : e.replace("/".concat(s), "")) || "/", [s, a, e])
            }
        },
        86464: (e, s, a) => {
            "use strict";
            a.d(s, {
                f: () => d
            });
            var l = a(12428),
                r = a(66630),
                t = a(6185),
                n = a(74777),
                i = a(53859),
                o = a(62993),
                c = a(3934);

            function d(e) {
                var s, a;
                let {
                    t: d
                } = (0, t.$G)(), m = (0, r.J)();
                return (0, l.jsxs)(c.default, {
                    href: e.disabled ? "#" : e.href,
                    className: (0, o.cn)((0, i.Id)({
                        variant: null !== (a = e.variant) && void 0 !== a ? a : "buttonRounded",
                        className: "block"
                    }), e.comingSoon && "cursor-default", e.className),
                    "data-state": m === e.href || (null == e ? void 0 : null === (s = e.aliases) || void 0 === s ? void 0 : s.includes(m)) ? "active" : "inactive",
                    children: [e.children, e.comingSoon ? (0, l.jsx)(n.C, {
                        variant: "green",
                        className: "relative bottom-[11px]",
                        size: "chipsXxs",
                        rounded: "full",
                        children: (0, l.jsx)("span", {
                            className: "inline-block text-xxs leading-[15px]",
                            children: e.comingSoon
                        })
                    }) : e.new ? (0, l.jsx)(n.C, {
                        variant: "pink",
                        className: "uppercase relative bottom-[11px]",
                        size: "chipsXxs",
                        rounded: "full",
                        children: (0, l.jsx)("span", {
                            className: "inline-block text-xxs leading-[15px] uppercase",
                            children: d("new")
                        })
                    }) : null]
                })
            }
        },
        44427: (e, s, a) => {
            "use strict";
            a.d(s, {
                _T: () => m,
                aR: () => o,
                f$: () => f,
                fY: () => u,
                le: () => p,
                xo: () => x,
                yT: () => h
            });
            var l = a(12428),
                r = a(93264),
                t = a(32840),
                n = a(62993),
                i = a(40850);
            let o = t.fC;
            t.xz;
            let c = t.h_,
                d = r.forwardRef((e, s) => {
                    let {
                        className: a,
                        ...r
                    } = e;
                    return (0, l.jsx)(t.aV, {
                        className: (0, n.cn)("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", a),
                        ...r,
                        ref: s
                    })
                });
            d.displayName = t.aV.displayName;
            let m = r.forwardRef((e, s) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, l.jsxs)(c, {
                    children: [(0, l.jsx)(d, {}), (0, l.jsx)(t.VY, {
                        ref: s,
                        className: (0, n.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", a),
                        ...r
                    })]
                })
            });
            m.displayName = t.VY.displayName;
            let u = e => {
                let {
                    className: s,
                    ...a
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, n.cn)("flex flex-col space-y-2 text-center sm:text-left", s),
                    ...a
                })
            };
            u.displayName = "AlertDialogHeader";
            let x = e => {
                let {
                    className: s,
                    ...a
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, n.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", s),
                    ...a
                })
            };
            x.displayName = "AlertDialogFooter";
            let f = r.forwardRef((e, s) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, l.jsx)(t.Dx, {
                    ref: s,
                    className: (0, n.cn)("text-lg font-semibold", a),
                    ...r
                })
            });
            f.displayName = t.Dx.displayName;
            let h = r.forwardRef((e, s) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, l.jsx)(t.dk, {
                    ref: s,
                    className: (0, n.cn)("text-sm text-muted-foreground", a),
                    ...r
                })
            });
            h.displayName = t.dk.displayName, r.forwardRef((e, s) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, l.jsx)(t.aU, {
                    ref: s,
                    className: (0, n.cn)((0, i.dc)(), a),
                    ...r
                })
            }).displayName = t.aU.displayName;
            let p = r.forwardRef((e, s) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, l.jsx)(t.$j, {
                    ref: s,
                    className: (0, n.cn)((0, i.dc)({
                        variant: "outline"
                    }), "mt-2 sm:mt-0", a),
                    ...r
                })
            });
            p.displayName = t.$j.displayName
        },
        39081: (e, s, a) => {
            "use strict";
            a.d(s, {
                W: () => o
            });
            var l = a(12428),
                r = a(51699),
                t = a(93264),
                n = a(62993);
            let i = (0, r.j)("px-2 md:px-4 mx-auto xl:px-0", {
                    variants: {
                        size: {
                            default: "max-w-screen-xl",
                            screenMd: "max-w-screen-md",
                            md: "max-w-md",
                            "2xl": "max-w-screen-2xl",
                            full: "max-w-full"
                        }
                    },
                    defaultVariants: {
                        size: "default"
                    }
                }),
                o = t.forwardRef((e, s) => {
                    let {
                        className: a,
                        size: r,
                        ...t
                    } = e;
                    return (0, l.jsx)("div", {
                        className: (0, n.cn)(i({
                            size: r
                        }), a),
                        ref: s,
                        ...t
                    })
                });
            o.displayName = "Container"
        },
        72927: (e, s, a) => {
            "use strict";
            a.d(s, {
                ScrollArea: () => i
            });
            var l = a(12428),
                r = a(93264),
                t = a(93693),
                n = a(62993);
            let i = r.forwardRef((e, s) => {
                let {
                    className: a,
                    children: r,
                    scrollable: i = !0,
                    ...c
                } = e;
                return i ? (0, l.jsxs)(t.fC, {
                    ref: s,
                    className: (0, n.cn)("relative overflow-hidden", a),
                    ...c,
                    children: [(0, l.jsx)(t.l_, {
                        className: "h-full w-full rounded-[inherit]",
                        children: r
                    }), (0, l.jsx)(o, {}), (0, l.jsx)(t.Ns, {})]
                }) : (0, l.jsx)(l.Fragment, {
                    children: r
                })
            });
            i.displayName = t.fC.displayName;
            let o = r.forwardRef((e, s) => {
                let {
                    className: a,
                    orientation: r = "vertical",
                    ...i
                } = e;
                return (0, l.jsx)(t.gb, {
                    ref: s,
                    orientation: r,
                    className: (0, n.cn)("flex touch-none select-none transition-colors", "vertical" === r && "h-full w-2.5 border-l border-l-transparent p-[1px]", "horizontal" === r && "h-2.5 flex-col border-t border-t-transparent p-[1px]", a),
                    ...i,
                    children: (0, l.jsx)(t.q4, {
                        className: "relative flex-1 rounded-full bg-border"
                    })
                })
            });
            o.displayName = t.gb.displayName
        },
        123: (e, s, a) => {
            "use strict";
            a.d(s, {
                T: () => r
            });
            var l = a(39034);
            let r = (0, l.createServerReference)("7f8345394eae042ab106c78750e02b4ccb37d8a4c5", l.callServer, void 0, l.findSourceMapURL, "invalidateCacheAction")
        }
    }
]);