(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6198], {
        80306: (e, s, l) => {
            Promise.resolve().then(l.bind(l, 57917)), Promise.resolve().then(l.bind(l, 89729)), Promise.resolve().then(l.bind(l, 65318)), Promise.resolve().then(l.bind(l, 28233)), Promise.resolve().then(l.bind(l, 47945)), Promise.resolve().then(l.bind(l, 77105)), Promise.resolve().then(l.bind(l, 28561)), Promise.resolve().then(l.bind(l, 6610)), Promise.resolve().then(l.bind(l, 90836)), Promise.resolve().then(l.bind(l, 90731)), Promise.resolve().then(l.bind(l, 91192)), Promise.resolve().then(l.bind(l, 97385))
        },
        28561: (e, s, l) => {
            "use strict";
            l.d(s, {
                HomepageHeader: () => t
            });
            var n = l(12428),
                r = l(6185),
                a = l(6767);

            function t() {
                let {
                    t: e
                } = (0, r.$G)();
                return (0, n.jsxs)("header", {
                    className: "text-center mt-10 mb-6",
                    children: [(0, n.jsx)(a.S, {
                        className: "mb-3 md:mb-1 px-4 md:leading-[54px] leading-[42px]",
                        children: e("Prop Firms Insights and Analytics")
                    }), (0, n.jsx)("p", {
                        className: "text-xs md:text-base text-foreground-secondary",
                        children: e("Across 500+ challenges and 40+ of the best firms.")
                    })]
                })
            }
        },
        6610: (e, s, l) => {
            "use strict";
            l.d(s, {
                HomepageSubscribe: () => g
            });
            var n = l(12428),
                r = l(6185),
                a = l(85473),
                t = l(79859),
                i = l(40850),
                c = l(37672),
                o = l(92006),
                d = l(33656),
                m = l(59957),
                x = l(54258),
                u = l(40798),
                h = l(35449),
                f = l(93264),
                p = l(95289),
                j = l(95772);

            function g() {
                let {
                    t: e
                } = (0, r.$G)(), {
                    toast: s
                } = (0, u.pm)(), [l, g] = (0, f.useState)(!1), N = function() {
                    let {
                        t: e
                    } = (0, r.$G)();
                    return j.z.object({
                        email: j.z.string().email(e("Invalid email address"))
                    })
                }(), b = (0, p.cI)({
                    resolver: (0, t.F)(N),
                    defaultValues: {
                        email: ""
                    }
                }), v = a.trpc.contacts.subscribeNewsletter.useMutation({
                    onSuccess() {
                        g(!0), s({
                            title: e("You have successfully subscribed!"),
                            description: e("Thank you for joining our community. Stay tuned for updates and exclusive content!")
                        })
                    },
                    onError() {
                        s({
                            variant: "destructive",
                            title: e("Something went wrong")
                        })
                    }
                });
                return (0, n.jsx)(o.l0, { ...b,
                    children: (0, n.jsx)("form", {
                        onSubmit: b.handleSubmit(e => {
                            v.mutate({
                                email: e.email
                            })
                        }),
                        className: "space-y-4",
                        children: (0, n.jsx)(c.Zb, {
                            className: "mb-16",
                            children: (0, n.jsx)("div", {
                                className: "bg-contain bg-no-repeat bg-left-bottom bg-[image:url(/gradient/pfm-subscribe-gradient-left.png)]",
                                children: (0, n.jsx)("div", {
                                    className: "bg-contain bg-no-repeat bg-right-bottom bg-[image:url(/gradient/pfm-subscribe-gradient-right.png)]",
                                    children: (0, n.jsx)(c.aY, {
                                        className: "p-4 md:p-20 relative",
                                        children: l ? (0, n.jsxs)("div", {
                                            className: "text-center p-8 h-full flex flex-col justify-center",
                                            children: [(0, n.jsx)(x.Q, {
                                                children: e("Thank you!")
                                            }), (0, n.jsx)("p", {
                                                children: e("Your submission has been received!")
                                            })]
                                        }) : (0, n.jsxs)("div", {
                                            className: "flex flex-col justify-center items-center py-2 overflow-hidden space-y-10",
                                            children: [(0, n.jsxs)("div", {
                                                className: "z-10 space-y-2",
                                                children: [(0, n.jsx)("p", {
                                                    className: "uppercase text-sm font-medium text-primary-foreground text-center",
                                                    children: e("Stay Connected")
                                                }), (0, n.jsx)("p", {
                                                    className: "text-2xl leading-normal font-semibold max-w-sm text-center md:text-3xl md:leading-snug md:max-w-lg lg:text-4xl lg:max-w-2xl lg:leading-normal",
                                                    children: e("Subscribe For The Latest In Prop Trading News And Deals")
                                                })]
                                            }), (0, n.jsx)("div", {
                                                className: "w-full max-w-[350px] mx-auto",
                                                children: (0, n.jsx)(d.P, {
                                                    control: b.control,
                                                    name: "email",
                                                    render: s => {
                                                        let {
                                                            field: l
                                                        } = s;
                                                        return (0, n.jsx)(m.I, {
                                                            className: "z-10 pl-4 pr-1.5 py-6 bg-background-tertiary text-foreground-secondary w-full md:w-[350px]",
                                                            rounded: "full",
                                                            placeholder: e("Enter your email"),
                                                            ...l,
                                                            rightIcon: (0, n.jsx)("div", {
                                                                className: "py-1.5 z-10",
                                                                children: (0, n.jsx)(i.zx, {
                                                                    rounded: "full",
                                                                    size: "sm",
                                                                    variant: "pfmGradient",
                                                                    disabled: v.isPending,
                                                                    className: "w-24 text-center",
                                                                    children: v.isPending ? (0, n.jsx)(h.Z, {
                                                                        className: "w-4 h-4 animate-spin mr-2"
                                                                    }) : e("Subscribe")
                                                                })
                                                            })
                                                        })
                                                    }
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            }
        },
        90836: (e, s, l) => {
            "use strict";
            l.d(s, {
                HomepageTabs: () => t
            });
            var n = l(12428),
                r = l(6185),
                a = l(86464);

            function t() {
                let {
                    t: e
                } = (0, r.$G)();
                return (0, n.jsxs)("div", {
                    className: "flex flex-nowrap justify-center mb-10 space-x-1.5 md:space-x-4",
                    children: [(0, n.jsx)(a.f, {
                        href: "/",
                        children: e("Firms")
                    }), (0, n.jsx)(a.f, {
                        href: "/prop-firm-challenges",
                        children: e("Challenges")
                    }), (0, n.jsx)(a.f, {
                        href: "/extra-account-promo",
                        aliases: ["/exclusive-offers", "/offers"],
                        children: e("Offers")
                    }), (0, n.jsx)(a.f, {
                        href: "/prop-firm-reviews",
                        children: e("Reviews")
                    })]
                })
            }
        },
        90731: (e, s, l) => {
            "use strict";
            l.d(s, {
                default: () => L
            });
            var n = l(12428),
                r = l(93264),
                a = l(31077),
                t = l(32709),
                i = l(20533),
                c = l(6185),
                o = l(37672),
                d = l(54258),
                m = l(3934);
            let x = [{
                image: "propfirmone.jpg",
                link: "https://propfirmone.com/",
                name: "PropFirmOne",
                external: !0
            }, {
                image: "spreads-live.png",
                name: "Spreads",
                link: "/prop-firm-spreads"
            }, {
                image: "payouts.jpg",
                name: "Payouts"
            }, {
                image: "futures.jpg",
                name: "Futures"
            }];

            function u() {
                let {
                    t: e
                } = (0, c.$G)();
                return (0, n.jsxs)(o.Zb, {
                    className: "flex flex-1 flex-col items-start rounded-2xl bg-background aspect-[2.17] p-4 md:p-4 space-y-3",
                    children: [(0, n.jsx)(d.Q, {
                        className: "text-base mx-auto",
                        children: e("Features")
                    }), (0, n.jsx)("div", {
                        className: "h-[85%]",
                        children: (0, n.jsxs)(a.lr, {
                            className: "h-full w-full flex items-center",
                            opts: {
                                align: "start",
                                loop: !0
                            },
                            hideDots: !0,
                            plugins: [(0, t.Z)({
                                delay: 5e3,
                                stopOnInteraction: !1,
                                stopOnMouseEnter: !0
                            })],
                            children: [(0, n.jsx)(a.KI, {
                                containerClassName: "h-full w-full",
                                className: "h-full w-[calc(100%+16px)]",
                                children: x.map(e => {
                                    var s;
                                    return (0, n.jsx)(a.d$, {
                                        className: "w-full overflow-hidden",
                                        children: (0, n.jsx)(m.default, {
                                            href: null !== (s = e.link) && void 0 !== s ? s : "#",
                                            target: e.link && e.external ? "_blank" : void 0,
                                            children: (0, n.jsx)("img", {
                                                alt: e.name,
                                                "aria-label": "Visit ".concat(e.link),
                                                className: "h-full w-full object-cover object-center bg-no-repeat border border-border rounded-md",
                                                rel: "noopener noreferrer",
                                                src: "/homepage-features/".concat(e.image)
                                            })
                                        })
                                    }, e.image)
                                })
                            }), (0, n.jsxs)("div", {
                                className: "absolute -top-9 right-0 m-0 flex items-center gap-1",
                                children: [(0, n.jsx)(a.am, {
                                    className: "bg-background static h-6 w-6 flex translate-y-0 p-0.5"
                                }), (0, n.jsx)(a.A0, {
                                    size: "sm"
                                }), (0, n.jsx)(a.Pz, {
                                    className: "bg-background static h-6 w-6 flex translate-y-0 p-0.5"
                                })]
                            })]
                        })
                    })]
                })
            }
            var h = l(25845),
                f = l(87071),
                p = l(68586),
                j = l(85473),
                g = l(72172),
                N = l(5313),
                b = l(43748),
                v = l(72927),
                w = l(97385),
                y = l(1456),
                k = l(62993),
                C = l(40850),
                P = l(67194),
                M = l(47576),
                z = l(58365),
                S = l(69615),
                O = l(40045),
                G = l(45253),
                I = l(34719);

            function E(e) {
                let {
                    offer: s
                } = e;
                if (!s.firm) return null;
                let l = "/prop-firms/".concat(s.firm.slug);
                return (0, n.jsxs)(o.Zb, {
                    className: "flex items-center justify-between p-2 rounded-xl",
                    children: [(0, n.jsxs)("div", {
                        className: "flex items-center space-x-3",
                        children: [(0, n.jsx)(m.default, {
                            href: l,
                            children: (0, n.jsx)(S.wK, {
                                firm: s.firm
                            })
                        }), (0, n.jsxs)("div", {
                            className: "flex flex-col items-start space-y-1",
                            children: [(0, n.jsx)(m.default, {
                                href: l,
                                className: "text-sm font-semibold",
                                children: s.firm.name
                            }), (0, n.jsx)("div", {
                                className: "inline-block",
                                children: s.firm.reviewsCount < I.nu ? (0, n.jsx)(I.YO, {}) : (0, n.jsx)(G.$, {
                                    className: "space-x-px",
                                    hideReviewsCountLabel: !0,
                                    rankClassName: "md:px-0",
                                    reviews: s.firm.reviewsCount,
                                    reviewScore: s.firm.reviewScore,
                                    size: "xs",
                                    toFixed: 1,
                                    wrapperClassName: "md:px-[2.5px] md:py-0"
                                })
                            })]
                        })]
                    }), (0, n.jsx)("div", {
                        children: (0, n.jsx)(O.OfferPromo, {
                            offer: s
                        })
                    })]
                })
            }

            function A(e) {
                let {
                    setOpen: s
                } = e, {
                    t: l
                } = (0, c.$G)(), a = (0, M.usePathname)(), [t] = j.trpc.promo.listHighlighted.useSuspenseQuery(), i = (0, r.useCallback)(() => {
                    setTimeout(() => {
                        z.OK.scrollTo("offersNavigation", {
                            smooth: !0,
                            duration: 500,
                            offset: -100
                        })
                    }, a.includes("exclusive-offers") ? 0 : 1200)
                }, [a]);
                return (0, n.jsxs)(b.G7, {
                    className: "relative flex-1 aspect-[2.17] rounded-2xl",
                    variant: "pfmPaleOutline40",
                    children: [(0, n.jsx)("div", {
                        className: "absolute inset-0 z-10 cursor-pointer",
                        onClick: () => s(!0)
                    }), (0, n.jsxs)(b.MB, {
                        className: "flex flex-col items-start p-4",
                        children: [(0, n.jsxs)("div", {
                            className: "relative flex w-full justify-center",
                            children: [(0, n.jsxs)("div", {
                                className: "flex items-center justify-center gap-2",
                                children: [(0, n.jsx)(m.default, {
                                    href: "/extra-account-promo#offers-content",
                                    onClick: i,
                                    children: (0, n.jsx)(d.Q, {
                                        className: "text-base",
                                        children: l("Launch Offer")
                                    })
                                }), (0, n.jsx)(N.Yq, {
                                    className: "text-primary-theme size-4"
                                })]
                            }), (0, n.jsx)(b.G7, {
                                variant: "pfmPaleOutline40",
                                className: "absolute right-0",
                                children: (0, n.jsxs)(b.MB, {
                                    className: "px-1.5",
                                    children: [(0, n.jsx)(N.Qu, {
                                        className: "mr-1.5 text-primary-theme"
                                    }), (0, n.jsxs)("span", {
                                        className: "text-xs font-semibold text-foreground",
                                        children: [(0, p.WU)(new Date(2025, 1, 26), "MMM d"), " -", " ", (0, p.WU)(new Date(2025, 2, 31), "MMM d")]
                                    })]
                                })
                            })]
                        }), (0, n.jsxs)("div", {
                            className: "flex items-center justify-center gap-1 mt-2 w-full",
                            children: [(0, n.jsx)(N.XX, {
                                className: "hidden xl:inline shrink-0"
                            }), (0, n.jsx)("p", {
                                className: "text-xs font-semibold text-center",
                                children: (0, n.jsx)(c.cC, {
                                    i18nKey: "Get an <underline>additional free</underline>, same-sized account upon payout by using the <coupon>MATCH</coupon> code.",
                                    components: {
                                        underline: e => (0, n.jsx)("span", {
                                            className: "capitalize underline",
                                            children: e.children
                                        }),
                                        coupon: e => (0, n.jsx)("span", {
                                            className: "text-primary-theme",
                                            children: e.children
                                        })
                                    }
                                })
                            })]
                        }), (0, n.jsx)("p", {
                            className: "text-xs w-full text-center text-foreground-secondary mt-3",
                            children: l("Applies with the following firms:")
                        }), (0, n.jsx)(v.ScrollArea, {
                            className: "flex-1 w-full h-[220px] mt-1 relative z-30 cursor-pointer",
                            onClick: () => s(!0),
                            children: (0, n.jsx)("div", {
                                className: "grid grid-cols-1 gap-[4px] xl:grid-cols-2 pointer-events-none",
                                children: (null == t ? void 0 : t.length) ? t.map(e => (0, n.jsx)(E, {
                                    offer: e
                                }, e.id)) : null
                            })
                        })]
                    })]
                })
            }

            function T(e) {
                let {
                    howItWorksClick: s,
                    moveContent: l
                } = e, {
                    t: r
                } = (0, c.$G)(), [a] = j.trpc.promo.listHighlighted.useSuspenseQuery();
                return (0, n.jsxs)("div", {
                    className: (0, k.cn)("flex flex-col max-w-[980px] h-[800px] overflow-hidden gap-0 px-10 pt-10 pb-0 transition-all duration-300 w-full", l && "-translate-x-full"),
                    children: [(0, n.jsxs)(y.fK, {
                        className: "relative pb-0 text-center",
                        children: [(0, n.jsxs)("div", {
                            className: "flex items-center justify-center py-1.5 space-x-[9px]",
                            children: [(0, n.jsx)(y.$N, {
                                asChild: !0,
                                className: "text-2xl",
                                children: (0, n.jsx)(d.Q, {
                                    children: r("Launch Offer")
                                })
                            }), (0, n.jsx)(N.Yq, {
                                className: "size-6 text-primary-theme"
                            }), (0, n.jsxs)("div", {
                                className: "absolute right-0 flex items-center justify-center gap-4",
                                children: [(0, n.jsx)(b.G7, {
                                    variant: "pfmPaleOutline40",
                                    children: (0, n.jsxs)(b.MB, {
                                        className: "px-2 py-1",
                                        children: [(0, n.jsx)(N.Qu, {
                                            className: "mr-2.5 text-primary-theme"
                                        }), (0, n.jsxs)("span", {
                                            className: "text-xs font-semibold text-foreground",
                                            children: [(0, p.WU)(new Date(2025, 1, 26), "MMM d"), " -", " ", (0, p.WU)(new Date(2025, 2, 31), "MMM d")]
                                        })]
                                    })
                                }), (0, n.jsx)(w.Separator, {
                                    orientation: "vertical",
                                    className: "h-[42px]"
                                }), (0, n.jsx)(y.GG, {
                                    children: (0, n.jsx)(h.Z, {
                                        className: "size-6 text-foreground-secondary"
                                    })
                                })]
                            })]
                        }), (0, n.jsx)("div", {
                            className: "pt-1.5",
                            children: (0, n.jsxs)("div", {
                                className: "flex w-full items-center justify-center gap-1.5",
                                children: [(0, n.jsx)(N.XX, {
                                    className: "shrink-0"
                                }), (0, n.jsx)(y.Be, {
                                    className: "text-xs font-semibold",
                                    children: (0, n.jsx)(c.cC, {
                                        i18nKey: "Get an <underline>additional free</underline>, same-sized account upon payout by using the <coupon>MATCH</coupon> code.",
                                        components: {
                                            underline: e => (0, n.jsx)("span", {
                                                className: "underline capitalize",
                                                children: e.children
                                            }),
                                            coupon: e => (0, n.jsx)("span", {
                                                className: "text-primary-theme",
                                                children: e.children
                                            })
                                        }
                                    })
                                })]
                            })
                        }), (0, n.jsx)("div", {
                            className: "pt-1.5",
                            children: (0, n.jsx)(b.G7, {
                                variant: "pfmDarkOutline",
                                className: "inline-block cursor-pointer",
                                onClick: s,
                                children: (0, n.jsx)(b.MB, {
                                    className: "px-3 py-2",
                                    children: (0, n.jsx)("span", {
                                        className: "text-sm font-medium text-foreground",
                                        children: r("How it works")
                                    })
                                })
                            })
                        }), (0, n.jsx)("span", {
                            className: "pt-1.5 text-xs font-normal text-foreground-secondary",
                            children: r("Applies with the following firms:")
                        })]
                    }), (0, n.jsx)(y.a7, {
                        className: "flex flex-1 flex-col items-center justify-start overflow-y-hidden",
                        children: (0, n.jsx)(v.ScrollArea, {
                            scrollable: !0,
                            className: "mt-3 h-full w-full",
                            children: (0, n.jsx)("div", {
                                className: "space-y-4 pb-3",
                                children: a.map(e => (0, n.jsx)(g.T, {
                                    promo: e,
                                    hideNewBadge: !0
                                }, e.id))
                            })
                        })
                    })]
                })
            }

            function _(e) {
                let {
                    idx: s,
                    children: l
                } = e;
                return (0, n.jsxs)("div", {
                    className: "flex items-center justify-start gap-5 rounded-2xl border border-background-secondary bg-background-primary p-10",
                    children: [(0, n.jsx)(b.G7, {
                        variant: "pfmPaleOutline",
                        className: "inline-block h-12 w-12 shrink-0 cursor-pointer rounded-full",
                        children: (0, n.jsx)(b.MB, {
                            className: "text-base font-semibold",
                            children: s
                        })
                    }), l]
                })
            }

            function B(e) {
                let {
                    clickBack: s,
                    moveContent: l
                } = e, {
                    t: a
                } = (0, c.$G)(), t = (0, P.useCoreContext)(), i = (0, r.useMemo)(() => [(0, n.jsx)(c.cC, {
                    i18nKey: "Make sure to your order through <link>Propfirmmatch.com</link>, or using the MATCH code if applicable.",
                    components: {
                        link: e => (0, n.jsx)(m.default, {
                            className: "text-primary-theme underline",
                            href: t.NEXT_PUBLIC_MAIN_WEBSITE_URL,
                            children: e.children
                        })
                    }
                }, 1), (0, n.jsx)(c.cC, {
                    i18nKey: "After you purchase, upload your order confirmation on your Propfirmmatch member site (<underline>max 2 weeks after purchase</underline>).",
                    components: {
                        underline: e => (0, n.jsx)("span", {
                            className: "underline",
                            children: e.children
                        })
                    }
                }, 2), (0, n.jsx)(c.cC, {
                    i18nKey: "If reaching payout, send us a notice on <link>payout@propfirmmatch.com</link>. We'll confirm with the firm, and you can expect your additional challenge account within 4 working days. <underline>Not applicable to instant accounts</underline>.",
                    components: {
                        link: e => (0, n.jsx)(m.default, {
                            className: "text-primary-theme underline",
                            href: "mailto:payout@propfirmmatch.com",
                            children: e.children
                        }),
                        underline: e => (0, n.jsx)("span", {
                            className: "underline",
                            children: e.children
                        })
                    }
                }, 3), a("You now have both your funded account and a new free challenge account of the same size!")], [t.NEXT_PUBLIC_MAIN_WEBSITE_URL, a]);
                return (0, n.jsxs)("div", {
                    className: (0, k.cn)("absolute inset-0 min-w-full left-full top-0 transition-all duration-300 p-10 flex flex-col", l && "left-0"),
                    children: [(0, n.jsxs)(y.fK, {
                        className: "relative flex flex-row items-center justify-between pb-0",
                        children: [(0, n.jsx)(C.zx, {
                            variant: "darkOutline",
                            className: "rounded-full p-[13px]",
                            onClick: s,
                            children: (0, n.jsx)(f.Z, {
                                className: "size-3.5"
                            })
                        }), (0, n.jsx)(y.$N, {
                            asChild: !0,
                            className: "text-2xl",
                            children: (0, n.jsx)(d.Q, {
                                children: a("How Does It Work?")
                            })
                        }), (0, n.jsx)(y.GG, {
                            children: (0, n.jsx)(h.Z, {
                                className: "text-foreground-secondary size-6"
                            })
                        })]
                    }), (0, n.jsx)(y.a7, {
                        className: "mt-10 w-full flex-1 overflow-y-hidden",
                        children: (0, n.jsx)(v.ScrollArea, {
                            scrollable: !0,
                            className: "h-full",
                            children: (0, n.jsx)("div", {
                                className: "space-y-3",
                                children: i.map((e, s) => (0, n.jsx)(_, {
                                    idx: s + 1,
                                    children: (0, n.jsx)("p", {
                                        className: "text-lg font-semibold",
                                        children: e
                                    })
                                }, s + 1))
                            })
                        })
                    })]
                })
            }

            function $() {
                let [e, s] = (0, r.useState)(!1), [l, a] = (0, r.useState)(!1);
                return (0, r.useEffect)(() => {
                    l || s(!1)
                }, [l]), (0, r.useEffect)(() => {
                    let e = () => {
                        window && window.innerWidth < 768 && l && a(!1)
                    };
                    return window && window.addEventListener("resize", e), () => {
                        window && window.removeEventListener("resize", e)
                    }
                }, [l, a]), (0, n.jsxs)(y.Vq, {
                    open: l,
                    onOpenChange: a,
                    children: [(0, n.jsx)(y.hg, {
                        asChild: !0,
                        children: (0, n.jsx)(A, {
                            setOpen: a
                        })
                    }), (0, n.jsxs)(y.cZ, {
                        className: "relative max-w-max overflow-hidden p-0 bg-background lg:min-w-0 min-w-[90%]",
                        hideCloseButton: !0,
                        children: [(0, n.jsx)(T, {
                            howItWorksClick: () => s(!0),
                            moveContent: e
                        }), (0, n.jsx)(B, {
                            clickBack: () => s(!1),
                            moveContent: e
                        })]
                    })]
                })
            }

            function H() {
                return (0, n.jsx)(i.O, {
                    className: "aspect-[2.17] w-full rounded-2xl"
                })
            }

            function K(e) {
                let {
                    children: s
                } = e;
                return (0, n.jsx)(a.d$, {
                    className: "md:basis-1/2 basis-full [&>*]:md:max-h-[290px]",
                    children: s
                })
            }

            function L() {
                return (0, n.jsx)("div", {
                    className: "md:flex hidden items-center justify-center md:mb-10 mb-[76px]",
                    children: (0, n.jsxs)(a.lr, {
                        className: "gap-4 w-full",
                        opts: {
                            align: "start",
                            loop: !0
                        },
                        hideDots: !0,
                        plugins: [(0, t.Z)({
                            delay: 5e3,
                            stopOnInteraction: !1,
                            stopOnMouseEnter: !0
                        })],
                        children: [(0, n.jsxs)(a.KI, {
                            containerClassName: "w-full h-full",
                            className: "-ml-4 h-auto items-center",
                            children: [(0, n.jsx)(K, {
                                children: (0, n.jsx)(r.Suspense, {
                                    fallback: (0, n.jsx)(H, {}),
                                    children: (0, n.jsx)($, {})
                                })
                            }), (0, n.jsx)(K, {
                                children: (0, n.jsx)(u, {})
                            })]
                        }), (0, n.jsx)(a.A0, {
                            className: "absolute md:hidden flex left-1/2 -translate-x-1/2 top-[calc(100%+32px)]",
                            size: "sm"
                        })]
                    })
                })
            }
        }
    },
    e => {
        var s = s => e(e.s = s);
        e.O(0, [6284, 4647, 6870, 5711, 8315, 8954, 1545, 3693, 4159, 7698, 8525, 4124, 4697, 9365, 9660, 4963, 8752, 5648, 1744], () => s(80306)), _N_E = e.O()
    }
]);