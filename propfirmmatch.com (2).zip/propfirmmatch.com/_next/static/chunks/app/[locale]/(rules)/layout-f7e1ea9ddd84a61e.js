(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1749], {
        75073: (e, s, r) => {
            Promise.resolve().then(r.bind(r, 57917)), Promise.resolve().then(r.bind(r, 89729)), Promise.resolve().then(r.bind(r, 65318)), Promise.resolve().then(r.bind(r, 28233)), Promise.resolve().then(r.bind(r, 47945)), Promise.resolve().then(r.bind(r, 77105)), Promise.resolve().then(r.bind(r, 6610)), Promise.resolve().then(r.bind(r, 74533)), Promise.resolve().then(r.bind(r, 97385))
        },
        77105: (e, s, r) => {
            "use strict";
            r.d(s, {
                HomepageFooter: () => u
            });
            var l = r(12428),
                a = r(67345),
                t = r(57917),
                i = r(54495),
                n = r(9855),
                c = r(91023),
                o = r(6185),
                m = r(98661),
                d = r(97385),
                h = r(3934);

            function x(e) {
                return (0, l.jsx)("p", {
                    className: "text-sm font-semibold uppercase",
                    children: e.children
                })
            }

            function p(e) {
                return (0, l.jsx)("p", {
                    className: "text-sm text-foreground-secondary",
                    children: (0, l.jsx)(h.default, {
                        href: e.href,
                        className: "hover:underline",
                        children: e.children
                    })
                })
            }
            let f = e => (0, l.jsxs)("div", {
                className: "space-y-4 pb-8",
                children: [(0, l.jsx)(x, {
                    children: e.category.label
                }), e.category.items.map((s, r) => (0, l.jsx)(p, {
                    href: s.href,
                    children: s.label
                }, "".concat(e.category.label, "-").concat(r)))]
            });

            function u() {
                let {
                    t: e
                } = (0, o.$G)(), s = (0, m.mM)(), r = [{
                    label: e("Prop Firms"),
                    items: [{
                        label: e("All Prop Firms"),
                        href: "/all-prop-firms"
                    }, {
                        label: e("Compare Challenges"),
                        href: "/prop-firm-challenges"
                    }, {
                        label: e("Best Sellers"),
                        href: "/best-sellers"
                    }, {
                        label: e("Favorite Firms"),
                        href: "/favorite-firms"
                    }, {
                        label: e("Announcements"),
                        href: "/prop-firm-announcements"
                    }, {
                        label: e("Prop Firm Rules"),
                        href: "/prop-firm-rules"
                    }, {
                        label: e("Reviews"),
                        href: "/reviews"
                    }, {
                        label: e("Demo Accounts"),
                        href: "/prop-firm-demo-accounts"
                    }, {
                        label: e("Unlisted Firms"),
                        href: "/unlisted-firms"
                    }]
                }, {
                    label: e("Offers"),
                    items: [{
                        label: e("Exclusive Offers"),
                        href: "/exclusive-offers"
                    }, {
                        label: e("Extra Account Promo"),
                        href: "/extra-account-promo"
                    }, {
                        label: e("All Current Offers"),
                        href: "/offers"
                    }]
                }, {
                    label: e("Resources"),
                    items: [{
                        label: e("High Impact News"),
                        href: "/high-impact-news"
                    }, {
                        label: e("Blog"),
                        href: "/blog"
                    }, {
                        label: e("Prop Firm Features"),
                        href: "/prop-firm-lists"
                    }]
                }, {
                    label: e("Programs"),
                    items: [{
                        label: e("Loyalty Program"),
                        href: "/loyalty-program"
                    }, {
                        label: e("Affiliate Program"),
                        href: "/join-affiliate-program"
                    }]
                }, {
                    label: e("Company"),
                    items: [{
                        label: e("About Us"),
                        href: "/about-us"
                    }, {
                        label: e("Careers"),
                        href: "/"
                    }, {
                        label: e("Prop Firm Business"),
                        href: s.NEXT_PUBLIC_BUSINESS_WEBSITE_URL
                    }, {
                        label: e("Press"),
                        href: "/press"
                    }, {
                        label: e("Sitemap"),
                        href: "/"
                    }]
                }, {
                    label: e("Get Help"),
                    items: [{
                        label: e("Contact Us"),
                        href: "/contact"
                    }, {
                        label: e("How it Works"),
                        href: "/how-it-works"
                    }, {
                        label: e("Status"),
                        href: "/"
                    }]
                }];
                return (0, l.jsxs)("div", {
                    className: "space-y-4",
                    children: [(0, l.jsxs)("div", {
                        className: "relative pl-[76px] md:pl-[230px]",
                        children: [(0, l.jsx)("div", {
                            className: "absolute top-0 left-0",
                            children: (0, l.jsx)(t.PFMLogo, {})
                        }), (0, l.jsxs)("div", {
                            className: "grid gap-4 xs:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
                            children: [(0, l.jsx)("div", {
                                className: "space-y-4",
                                children: r.slice(0, 1).map(e => (0, l.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, l.jsx)("div", {
                                className: "space-y-4",
                                children: r.slice(1, 3).map(e => (0, l.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, l.jsx)("div", {
                                className: "space-y-4",
                                children: r.slice(3, 5).map(e => (0, l.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, l.jsx)("div", {
                                className: "space-y-4",
                                children: r.slice(5, 6).map(e => (0, l.jsx)(f, {
                                    category: e
                                }, e.label))
                            })]
                        })]
                    }), (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(d.Separator, {
                            className: "flex w-full h-px bg-border-disabled"
                        }), (0, l.jsxs)("div", {
                            className: "flex flex-col-reverse space-y-4 md:space-y-0 md:flex-row items-center justify-between text-xs text-foreground-secondary md:px-4 xl:px-0 py-5 md:py-10",
                            children: [(0, l.jsxs)("div", {
                                className: "flex flex-col-reverse md:flex-row",
                                children: [(0, l.jsxs)("p", {
                                    className: "pt-2 md:pt-0",
                                    children: ["\xa9\xa0", new Date().getFullYear(), "\xa0", e("Prop Firm Match. All rights reserved.")]
                                }), (0, l.jsxs)("div", {
                                    className: "flex items-center space-x-8 mt-4 md:mt-0 md:ml-4 md:pl-4 md:border-l",
                                    children: [(0, l.jsx)(h.default, {
                                        href: "/privacy-policy",
                                        className: "box-content cursor-pointer hover:underline",
                                        target: "_blank",
                                        children: e("Privacy Policy")
                                    }), (0, l.jsx)(h.default, {
                                        href: "/terms-and-conditions",
                                        className: "box-content cursor-pointer hover:underline",
                                        target: "_blank",
                                        children: e("Terms & Conditions")
                                    })]
                                })]
                            }), (0, l.jsxs)("div", {
                                className: "flex items-center space-x-4 xl:space-x-7",
                                children: [(0, l.jsx)(n.u, {}), (0, l.jsx)(a.C, {
                                    className: "w-6 h-6"
                                }), (0, l.jsx)(c.V, {}), (0, l.jsx)(i.r, {})]
                            })]
                        })]
                    })]
                })
            }
        },
        6610: (e, s, r) => {
            "use strict";
            r.d(s, {
                HomepageSubscribe: () => g
            });
            var l = r(12428),
                a = r(6185),
                t = r(85473),
                i = r(79859),
                n = r(40850),
                c = r(37672),
                o = r(92006),
                m = r(33656),
                d = r(59957),
                h = r(54258),
                x = r(40798),
                p = r(35449),
                f = r(93264),
                u = r(95289),
                b = r(95772);

            function g() {
                let {
                    t: e
                } = (0, a.$G)(), {
                    toast: s
                } = (0, x.pm)(), [r, g] = (0, f.useState)(!1), v = function() {
                    let {
                        t: e
                    } = (0, a.$G)();
                    return b.z.object({
                        email: b.z.string().email(e("Invalid email address"))
                    })
                }(), j = (0, u.cI)({
                    resolver: (0, i.F)(v),
                    defaultValues: {
                        email: ""
                    }
                }), y = t.trpc.contacts.subscribeNewsletter.useMutation({
                    onSuccess() {
                        g(!0), s({
                            title: e("You have successfully subscribed!"),
                            description: e("Thank you for joining our community. Stay tuned for updates and exclusive content!")
                        })
                    },
                    onError() {
                        s({
                            variant: "destructive",
                            title: e("Something went wrong")
                        })
                    }
                });
                return (0, l.jsx)(o.l0, { ...j,
                    children: (0, l.jsx)("form", {
                        onSubmit: j.handleSubmit(e => {
                            y.mutate({
                                email: e.email
                            })
                        }),
                        className: "space-y-4",
                        children: (0, l.jsx)(c.Zb, {
                            className: "mb-16",
                            children: (0, l.jsx)("div", {
                                className: "bg-contain bg-no-repeat bg-left-bottom bg-[image:url(/gradient/pfm-subscribe-gradient-left.png)]",
                                children: (0, l.jsx)("div", {
                                    className: "bg-contain bg-no-repeat bg-right-bottom bg-[image:url(/gradient/pfm-subscribe-gradient-right.png)]",
                                    children: (0, l.jsx)(c.aY, {
                                        className: "p-4 md:p-20 relative",
                                        children: r ? (0, l.jsxs)("div", {
                                            className: "text-center p-8 h-full flex flex-col justify-center",
                                            children: [(0, l.jsx)(h.Q, {
                                                children: e("Thank you!")
                                            }), (0, l.jsx)("p", {
                                                children: e("Your submission has been received!")
                                            })]
                                        }) : (0, l.jsxs)("div", {
                                            className: "flex flex-col justify-center items-center py-2 overflow-hidden space-y-10",
                                            children: [(0, l.jsxs)("div", {
                                                className: "z-10 space-y-2",
                                                children: [(0, l.jsx)("p", {
                                                    className: "uppercase text-sm font-medium text-primary-foreground text-center",
                                                    children: e("Stay Connected")
                                                }), (0, l.jsx)("p", {
                                                    className: "text-2xl leading-normal font-semibold max-w-sm text-center md:text-3xl md:leading-snug md:max-w-lg lg:text-4xl lg:max-w-2xl lg:leading-normal",
                                                    children: e("Subscribe For The Latest In Prop Trading News And Deals")
                                                })]
                                            }), (0, l.jsx)("div", {
                                                className: "w-full max-w-[350px] mx-auto",
                                                children: (0, l.jsx)(m.P, {
                                                    control: j.control,
                                                    name: "email",
                                                    render: s => {
                                                        let {
                                                            field: r
                                                        } = s;
                                                        return (0, l.jsx)(d.I, {
                                                            className: "z-10 pl-4 pr-1.5 py-6 bg-background-tertiary text-foreground-secondary w-full md:w-[350px]",
                                                            rounded: "full",
                                                            placeholder: e("Enter your email"),
                                                            ...r,
                                                            rightIcon: (0, l.jsx)("div", {
                                                                className: "py-1.5 z-10",
                                                                children: (0, l.jsx)(n.zx, {
                                                                    rounded: "full",
                                                                    size: "sm",
                                                                    variant: "pfmGradient",
                                                                    disabled: y.isPending,
                                                                    className: "w-24 text-center",
                                                                    children: y.isPending ? (0, l.jsx)(p.Z, {
                                                                        className: "w-4 h-4 animate-spin mr-2"
                                                                    }) : e("Subscribe")
                                                                })
                                                            })
                                                        })
                                                    }
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            }
        },
        74533: (e, s, r) => {
            "use strict";
            r.r(s), r.d(s, {
                RulesHeader: () => i
            });
            var l = r(12428),
                a = r(6185),
                t = r(6767);

            function i() {
                let {
                    t: e
                } = (0, a.$G)();
                return (0, l.jsxs)("header", {
                    className: "text-center my-10 py-5",
                    role: "banner",
                    children: [(0, l.jsx)(t.S, {
                        className: "mb-1",
                        "aria-label": e("Prop Firm Rules"),
                        children: e("Prop Firm Rules")
                    }), (0, l.jsx)("p", {
                        className: "text-xs md:text-base text-foreground-secondary max-w-2xl mx-auto",
                        children: e("In the prop trading industry, rules can vary significantly from one firm to another based on their risk management policies. This section provides key rules for each firm and highlights any significant rule changes along with the specific dates of those changes.")
                    })]
                })
            }
        },
        54258: (e, s, r) => {
            "use strict";
            r.d(s, {
                Q: () => l
            });
            let l = (0, r(52231).f)("h3", "text-2xl font-semibold tracking-tight scroll-m-20");
            l.displayName = "TypographyH3"
        }
    },
    e => {
        var s = s => e(e.s = s);
        e.O(0, [6284, 4647, 6870, 5711, 8315, 8954, 1545, 3693, 4159, 7698, 8525, 4124, 4697, 9365, 9660, 8752, 5648, 1744], () => s(75073)), _N_E = e.O()
    }
]);