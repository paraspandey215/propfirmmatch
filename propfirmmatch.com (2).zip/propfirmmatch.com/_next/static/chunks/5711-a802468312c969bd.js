(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5711], {
        87071: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => i
            });
            let i = (0, r(66127).Z)("ArrowLeft", [
                ["path", {
                    d: "m12 19-7-7 7-7",
                    key: "1l729n"
                }],
                ["path", {
                    d: "M19 12H5",
                    key: "x3x0zl"
                }]
            ])
        },
        12351: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => i
            });
            let i = (0, r(66127).Z)("CircleAlert", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "8",
                    y2: "12",
                    key: "1pkeuh"
                }],
                ["line", {
                    x1: "12",
                    x2: "12.01",
                    y1: "16",
                    y2: "16",
                    key: "4dfq90"
                }]
            ])
        },
        3934: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => n.a
            });
            var i = r(76522),
                n = r.n(i)
        },
        12550: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "addLocale", {
                enumerable: !0,
                get: function() {
                    return i
                }
            }), r(83560);
            let i = function(e) {
                for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) r[i - 1] = arguments[i];
                return e
            };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        44808: (e, t, r) => {
            "use strict";

            function i(e, t, r, i) {
                return !1
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "getDomainLocale", {
                enumerable: !0,
                get: function() {
                    return i
                }
            }), r(83560), ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        76522: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return S
                }
            });
            let i = r(81838),
                n = r(12428),
                s = i._(r(93264)),
                o = r(45507),
                a = r(21436),
                l = r(94703),
                u = r(42511),
                h = r(12550),
                d = r(5519),
                c = r(26316),
                f = r(96793),
                p = r(44808),
                m = r(42941),
                g = r(61747),
                v = r(6524),
                y = new Set;

            function x(e, t, r, i, n, s) {
                if ("undefined" != typeof window && (s || (0, a.isLocalURL)(t))) {
                    if (!i.bypassPrefetchedCheck && !s) {
                        let n = t + "%" + r + "%" + (void 0 !== i.locale ? i.locale : "locale" in e ? e.locale : void 0);
                        if (y.has(n)) return;
                        y.add(n)
                    }(async () => s ? e.prefetch(t, n) : e.prefetch(t, r, i))().catch(e => {})
                }
            }

            function b(e) {
                return "string" == typeof e ? e : (0, l.formatUrl)(e)
            }
            let S = s.default.forwardRef(function(e, t) {
                let r, i;
                let {
                    href: l,
                    as: y,
                    children: S,
                    prefetch: P = null,
                    passHref: A,
                    replace: w,
                    shallow: E,
                    scroll: _,
                    locale: T,
                    onClick: R,
                    onMouseEnter: C,
                    onTouchStart: V,
                    legacyBehavior: M = !1,
                    ...k
                } = e;
                r = S, M && ("string" == typeof r || "number" == typeof r) && (r = (0, n.jsx)("a", {
                    children: r
                }));
                let D = s.default.useContext(d.RouterContext),
                    F = s.default.useContext(c.AppRouterContext),
                    j = null != D ? D : F,
                    O = !D,
                    L = !1 !== P,
                    N = null === P ? g.PrefetchKind.AUTO : g.PrefetchKind.FULL,
                    {
                        href: I,
                        as: U
                    } = s.default.useMemo(() => {
                        if (!D) {
                            let e = b(l);
                            return {
                                href: e,
                                as: y ? b(y) : e
                            }
                        }
                        let [e, t] = (0, o.resolveHref)(D, l, !0);
                        return {
                            href: e,
                            as: y ? (0, o.resolveHref)(D, y) : t || e
                        }
                    }, [D, l, y]),
                    B = s.default.useRef(I),
                    W = s.default.useRef(U);
                M && (i = s.default.Children.only(r));
                let $ = M ? i && "object" == typeof i && i.ref : t,
                    [X, H, G] = (0, f.useIntersection)({
                        rootMargin: "200px"
                    }),
                    z = s.default.useCallback(e => {
                        (W.current !== U || B.current !== I) && (G(), W.current = U, B.current = I), X(e)
                    }, [U, I, G, X]),
                    Y = (0, v.useMergedRef)(z, $);
                s.default.useEffect(() => {
                    j && H && L && x(j, I, U, {
                        locale: T
                    }, {
                        kind: N
                    }, O)
                }, [U, I, H, T, L, null == D ? void 0 : D.locale, j, O, N]);
                let K = {
                    ref: Y,
                    onClick(e) {
                        M || "function" != typeof R || R(e), M && i.props && "function" == typeof i.props.onClick && i.props.onClick(e), j && !e.defaultPrevented && function(e, t, r, i, n, o, l, u, h) {
                            let {
                                nodeName: d
                            } = e.currentTarget;
                            if ("A" === d.toUpperCase() && (function(e) {
                                    let t = e.currentTarget.getAttribute("target");
                                    return t && "_self" !== t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                                }(e) || !h && !(0, a.isLocalURL)(r))) return;
                            e.preventDefault();
                            let c = () => {
                                let e = null == l || l;
                                "beforePopState" in t ? t[n ? "replace" : "push"](r, i, {
                                    shallow: o,
                                    locale: u,
                                    scroll: e
                                }) : t[n ? "replace" : "push"](i || r, {
                                    scroll: e
                                })
                            };
                            h ? s.default.startTransition(c) : c()
                        }(e, j, I, U, w, E, _, T, O)
                    },
                    onMouseEnter(e) {
                        M || "function" != typeof C || C(e), M && i.props && "function" == typeof i.props.onMouseEnter && i.props.onMouseEnter(e), j && (L || !O) && x(j, I, U, {
                            locale: T,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: N
                        }, O)
                    },
                    onTouchStart: function(e) {
                        M || "function" != typeof V || V(e), M && i.props && "function" == typeof i.props.onTouchStart && i.props.onTouchStart(e), j && (L || !O) && x(j, I, U, {
                            locale: T,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: N
                        }, O)
                    }
                };
                if ((0, u.isAbsoluteUrl)(U)) K.href = U;
                else if (!M || A || "a" === i.type && !("href" in i.props)) {
                    let e = void 0 !== T ? T : null == D ? void 0 : D.locale,
                        t = (null == D ? void 0 : D.isLocaleDomain) && (0, p.getDomainLocale)(U, e, null == D ? void 0 : D.locales, null == D ? void 0 : D.domainLocales);
                    K.href = t || (0, m.addBasePath)((0, h.addLocale)(U, e, null == D ? void 0 : D.defaultLocale))
                }
                return M ? s.default.cloneElement(i, K) : (0, n.jsx)("a", { ...k,
                    ...K,
                    children: r
                })
            });
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        56214: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    cancelIdleCallback: function() {
                        return i
                    },
                    requestIdleCallback: function() {
                        return r
                    }
                });
            let r = "undefined" != typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(e) {
                    let t = Date.now();
                    return self.setTimeout(function() {
                        e({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - t))
                            }
                        })
                    }, 1)
                },
                i = "undefined" != typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(e) {
                    return clearTimeout(e)
                };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        45507: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "resolveHref", {
                enumerable: !0,
                get: function() {
                    return d
                }
            });
            let i = r(4177),
                n = r(94703),
                s = r(94029),
                o = r(42511),
                a = r(83560),
                l = r(21436),
                u = r(4977),
                h = r(40164);

            function d(e, t, r) {
                let d;
                let c = "string" == typeof t ? t : (0, n.formatWithValidation)(t),
                    f = c.match(/^[a-zA-Z]{1,}:\/\//),
                    p = f ? c.slice(f[0].length) : c;
                if ((p.split("?", 1)[0] || "").match(/(\/\/|\\)/)) {
                    console.error("Invalid href '" + c + "' passed to next/router in page: '" + e.pathname + "'. Repeated forward-slashes (//) or backslashes \\ are not valid in the href.");
                    let t = (0, o.normalizeRepeatedSlashes)(p);
                    c = (f ? f[0] : "") + t
                }
                if (!(0, l.isLocalURL)(c)) return r ? [c] : c;
                try {
                    d = new URL(c.startsWith("#") ? e.asPath : e.pathname, "http://n")
                } catch (e) {
                    d = new URL("/", "http://n")
                }
                try {
                    let e = new URL(c, d);
                    e.pathname = (0, a.normalizePathTrailingSlash)(e.pathname);
                    let t = "";
                    if ((0, u.isDynamicRoute)(e.pathname) && e.searchParams && r) {
                        let r = (0, i.searchParamsToUrlQuery)(e.searchParams),
                            {
                                result: o,
                                params: a
                            } = (0, h.interpolateAs)(e.pathname, e.pathname, r);
                        o && (t = (0, n.formatWithValidation)({
                            pathname: o,
                            hash: e.hash,
                            query: (0, s.omit)(r, a)
                        }))
                    }
                    let o = e.origin === d.origin ? e.href.slice(e.origin.length) : e.href;
                    return r ? [o, t || o] : o
                } catch (e) {
                    return r ? [c] : c
                }
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        96793: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "useIntersection", {
                enumerable: !0,
                get: function() {
                    return l
                }
            });
            let i = r(93264),
                n = r(56214),
                s = "function" == typeof IntersectionObserver,
                o = new Map,
                a = [];

            function l(e) {
                let {
                    rootRef: t,
                    rootMargin: r,
                    disabled: l
                } = e, u = l || !s, [h, d] = (0, i.useState)(!1), c = (0, i.useRef)(null), f = (0, i.useCallback)(e => {
                    c.current = e
                }, []);
                return (0, i.useEffect)(() => {
                    if (s) {
                        if (u || h) return;
                        let e = c.current;
                        if (e && e.tagName) return function(e, t, r) {
                            let {
                                id: i,
                                observer: n,
                                elements: s
                            } = function(e) {
                                let t;
                                let r = {
                                        root: e.root || null,
                                        margin: e.rootMargin || ""
                                    },
                                    i = a.find(e => e.root === r.root && e.margin === r.margin);
                                if (i && (t = o.get(i))) return t;
                                let n = new Map;
                                return t = {
                                    id: r,
                                    observer: new IntersectionObserver(e => {
                                        e.forEach(e => {
                                            let t = n.get(e.target),
                                                r = e.isIntersecting || e.intersectionRatio > 0;
                                            t && r && t(r)
                                        })
                                    }, e),
                                    elements: n
                                }, a.push(r), o.set(r, t), t
                            }(r);
                            return s.set(e, t), n.observe(e),
                                function() {
                                    if (s.delete(e), n.unobserve(e), 0 === s.size) {
                                        n.disconnect(), o.delete(i);
                                        let e = a.findIndex(e => e.root === i.root && e.margin === i.margin);
                                        e > -1 && a.splice(e, 1)
                                    }
                                }
                        }(e, e => e && d(e), {
                            root: null == t ? void 0 : t.current,
                            rootMargin: r
                        })
                    } else if (!h) {
                        let e = (0, n.requestIdleCallback)(() => d(!0));
                        return () => (0, n.cancelIdleCallback)(e)
                    }
                }, [u, r, t, h, c.current]), [f, h, (0, i.useCallback)(() => {
                    d(!1)
                }, [])]
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        6524: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "useMergedRef", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let i = r(93264);

            function n(e, t) {
                let r = (0, i.useRef)(() => {}),
                    n = (0, i.useRef)(() => {});
                return (0, i.useMemo)(() => e && t ? i => {
                    null === i ? (r.current(), n.current()) : (r.current = s(e, i), n.current = s(t, i))
                } : e || t, [e, t])
            }

            function s(e, t) {
                if ("function" != typeof e) return e.current = t, () => {
                    e.current = null
                }; {
                    let r = e(t);
                    return "function" == typeof r ? r : () => e(null)
                }
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        11768: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    ACTION_SUFFIX: function() {
                        return h
                    },
                    APP_DIR_ALIAS: function() {
                        return M
                    },
                    CACHE_ONE_YEAR: function() {
                        return A
                    },
                    DOT_NEXT_ALIAS: function() {
                        return C
                    },
                    ESLINT_DEFAULT_DIRS: function() {
                        return q
                    },
                    GSP_NO_RETURNED_VALUE: function() {
                        return X
                    },
                    GSSP_COMPONENT_MEMBER_ERROR: function() {
                        return z
                    },
                    GSSP_NO_RETURNED_VALUE: function() {
                        return H
                    },
                    INFINITE_CACHE: function() {
                        return w
                    },
                    INSTRUMENTATION_HOOK_FILENAME: function() {
                        return T
                    },
                    MIDDLEWARE_FILENAME: function() {
                        return E
                    },
                    MIDDLEWARE_LOCATION_REGEXP: function() {
                        return _
                    },
                    NEXT_BODY_SUFFIX: function() {
                        return f
                    },
                    NEXT_CACHE_IMPLICIT_TAG_ID: function() {
                        return P
                    },
                    NEXT_CACHE_REVALIDATED_TAGS_HEADER: function() {
                        return g
                    },
                    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: function() {
                        return v
                    },
                    NEXT_CACHE_SOFT_TAGS_HEADER: function() {
                        return m
                    },
                    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: function() {
                        return S
                    },
                    NEXT_CACHE_TAGS_HEADER: function() {
                        return p
                    },
                    NEXT_CACHE_TAG_MAX_ITEMS: function() {
                        return x
                    },
                    NEXT_CACHE_TAG_MAX_LENGTH: function() {
                        return b
                    },
                    NEXT_DATA_SUFFIX: function() {
                        return d
                    },
                    NEXT_INTERCEPTION_MARKER_PREFIX: function() {
                        return i
                    },
                    NEXT_META_SUFFIX: function() {
                        return c
                    },
                    NEXT_QUERY_PARAM_PREFIX: function() {
                        return r
                    },
                    NEXT_RESUME_HEADER: function() {
                        return y
                    },
                    NON_STANDARD_NODE_ENV: function() {
                        return Y
                    },
                    PAGES_DIR_ALIAS: function() {
                        return R
                    },
                    PRERENDER_REVALIDATE_HEADER: function() {
                        return n
                    },
                    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: function() {
                        return s
                    },
                    PUBLIC_DIR_MIDDLEWARE_CONFLICT: function() {
                        return N
                    },
                    ROOT_DIR_ALIAS: function() {
                        return V
                    },
                    RSC_ACTION_CLIENT_WRAPPER_ALIAS: function() {
                        return L
                    },
                    RSC_ACTION_ENCRYPTION_ALIAS: function() {
                        return O
                    },
                    RSC_ACTION_PROXY_ALIAS: function() {
                        return F
                    },
                    RSC_ACTION_VALIDATE_ALIAS: function() {
                        return D
                    },
                    RSC_CACHE_WRAPPER_ALIAS: function() {
                        return j
                    },
                    RSC_MOD_REF_PROXY_ALIAS: function() {
                        return k
                    },
                    RSC_PREFETCH_SUFFIX: function() {
                        return o
                    },
                    RSC_SEGMENTS_DIR_SUFFIX: function() {
                        return a
                    },
                    RSC_SEGMENT_SUFFIX: function() {
                        return l
                    },
                    RSC_SUFFIX: function() {
                        return u
                    },
                    SERVER_PROPS_EXPORT_ERROR: function() {
                        return $
                    },
                    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: function() {
                        return U
                    },
                    SERVER_PROPS_SSG_CONFLICT: function() {
                        return B
                    },
                    SERVER_RUNTIME: function() {
                        return Z
                    },
                    SSG_FALLBACK_EXPORT_ERROR: function() {
                        return K
                    },
                    SSG_GET_INITIAL_PROPS_CONFLICT: function() {
                        return I
                    },
                    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: function() {
                        return W
                    },
                    UNSTABLE_REVALIDATE_RENAME_ERROR: function() {
                        return G
                    },
                    WEBPACK_LAYERS: function() {
                        return J
                    },
                    WEBPACK_RESOURCE_QUERIES: function() {
                        return ee
                    }
                });
            let r = "nxtP",
                i = "nxtI",
                n = "x-prerender-revalidate",
                s = "x-prerender-revalidate-if-generated",
                o = ".prefetch.rsc",
                a = ".segments",
                l = ".segment.rsc",
                u = ".rsc",
                h = ".action",
                d = ".json",
                c = ".meta",
                f = ".body",
                p = "x-next-cache-tags",
                m = "x-next-cache-soft-tags",
                g = "x-next-revalidated-tags",
                v = "x-next-revalidate-tag-token",
                y = "next-resume",
                x = 64,
                b = 256,
                S = 1024,
                P = "_N_T_",
                A = 31536e3,
                w = 0xfffffffe,
                E = "middleware",
                _ = `(?:src/)?${E}`,
                T = "instrumentation",
                R = "private-next-pages",
                C = "private-dot-next",
                V = "private-next-root-dir",
                M = "private-next-app-dir",
                k = "private-next-rsc-mod-ref-proxy",
                D = "private-next-rsc-action-validate",
                F = "private-next-rsc-server-reference",
                j = "private-next-rsc-cache-wrapper",
                O = "private-next-rsc-action-encryption",
                L = "private-next-rsc-action-client-wrapper",
                N = "You can not have a '_next' folder inside of your public folder. This conflicts with the internal '/_next' route. https://nextjs.org/docs/messages/public-next-folder-conflict",
                I = "You can not use getInitialProps with getStaticProps. To use SSG, please remove your getInitialProps",
                U = "You can not use getInitialProps with getServerSideProps. Please remove getInitialProps.",
                B = "You can not use getStaticProps or getStaticPaths with getServerSideProps. To use SSG, please remove getServerSideProps",
                W = "can not have getInitialProps/getServerSideProps, https://nextjs.org/docs/messages/404-get-initial-props",
                $ = "pages with `getServerSideProps` can not be exported. See more info here: https://nextjs.org/docs/messages/gssp-export",
                X = "Your `getStaticProps` function did not return an object. Did you forget to add a `return`?",
                H = "Your `getServerSideProps` function did not return an object. Did you forget to add a `return`?",
                G = "The `unstable_revalidate` property is available for general use.\nPlease use `revalidate` instead.",
                z = "can not be attached to a page's component and must be exported from the page. See more info here: https://nextjs.org/docs/messages/gssp-component-member",
                Y = 'You are using a non-standard "NODE_ENV" value in your environment. This creates inconsistencies in the project and is strongly advised against. Read more: https://nextjs.org/docs/messages/non-standard-node-env',
                K = "Pages with `fallback` enabled in `getStaticPaths` can not be exported. See more info here: https://nextjs.org/docs/messages/ssg-fallback-true-export",
                q = ["app", "pages", "components", "lib", "src"],
                Z = {
                    edge: "edge",
                    experimentalEdge: "experimental-edge",
                    nodejs: "nodejs"
                },
                Q = {
                    shared: "shared",
                    reactServerComponents: "rsc",
                    serverSideRendering: "ssr",
                    actionBrowser: "action-browser",
                    api: "api",
                    middleware: "middleware",
                    instrument: "instrument",
                    edgeAsset: "edge-asset",
                    appPagesBrowser: "app-pages-browser",
                    appMetadataRoute: "app-metadata-route"
                },
                J = { ...Q,
                    GROUP: {
                        builtinReact: [Q.reactServerComponents, Q.actionBrowser, Q.appMetadataRoute],
                        serverOnly: [Q.reactServerComponents, Q.actionBrowser, Q.appMetadataRoute, Q.instrument, Q.middleware],
                        neutralTarget: [Q.api],
                        clientOnly: [Q.serverSideRendering, Q.appPagesBrowser],
                        bundled: [Q.reactServerComponents, Q.actionBrowser, Q.appMetadataRoute, Q.serverSideRendering, Q.appPagesBrowser, Q.shared, Q.instrument],
                        appPages: [Q.reactServerComponents, Q.serverSideRendering, Q.appPagesBrowser, Q.actionBrowser]
                    }
                },
                ee = {
                    edgeSSREntry: "__next_edge_ssr_entry__",
                    metadata: "__next_metadata__",
                    metadataRoute: "__next_metadata_route__",
                    metadataImageMeta: "__next_metadata_image_meta__"
                }
        },
        72841: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "escapeStringRegexp", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let r = /[|\\{}()[\]^$+*?.-]/,
                i = /[|\\{}()[\]^$+*?.-]/g;

            function n(e) {
                return r.test(e) ? e.replace(i, "\\$&") : e
            }
        },
        5519: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "RouterContext", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            let i = r(81838)._(r(93264)).default.createContext(null)
        },
        94703: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    formatUrl: function() {
                        return s
                    },
                    formatWithValidation: function() {
                        return a
                    },
                    urlObjectKeys: function() {
                        return o
                    }
                });
            let i = r(86077)._(r(4177)),
                n = /https?|ftp|gopher|file/;

            function s(e) {
                let {
                    auth: t,
                    hostname: r
                } = e, s = e.protocol || "", o = e.pathname || "", a = e.hash || "", l = e.query || "", u = !1;
                t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? u = t + e.host : r && (u = t + (~r.indexOf(":") ? "[" + r + "]" : r), e.port && (u += ":" + e.port)), l && "object" == typeof l && (l = String(i.urlQueryToSearchParams(l)));
                let h = e.search || l && "?" + l || "";
                return s && !s.endsWith(":") && (s += ":"), e.slashes || (!s || n.test(s)) && !1 !== u ? (u = "//" + (u || ""), o && "/" !== o[0] && (o = "/" + o)) : u || (u = ""), a && "#" !== a[0] && (a = "#" + a), h && "?" !== h[0] && (h = "?" + h), "" + s + u + (o = o.replace(/[?#]/g, encodeURIComponent)) + (h = h.replace("#", "%23")) + a
            }
            let o = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

            function a(e) {
                return s(e)
            }
        },
        4977: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    getSortedRouteObjects: function() {
                        return i.getSortedRouteObjects
                    },
                    getSortedRoutes: function() {
                        return i.getSortedRoutes
                    },
                    isDynamicRoute: function() {
                        return n.isDynamicRoute
                    }
                });
            let i = r(71750),
                n = r(26213)
        },
        40164: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "interpolateAs", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let i = r(69273),
                n = r(20511);

            function s(e, t, r) {
                let s = "",
                    o = (0, n.getRouteRegex)(e),
                    a = o.groups,
                    l = (t !== e ? (0, i.getRouteMatcher)(o)(t) : "") || r;
                s = e;
                let u = Object.keys(a);
                return u.every(e => {
                    let t = l[e] || "",
                        {
                            repeat: r,
                            optional: i
                        } = a[e],
                        n = "[" + (r ? "..." : "") + e + "]";
                    return i && (n = (t ? "" : "/") + "[" + n + "]"), r && !Array.isArray(t) && (t = [t]), (i || e in l) && (s = s.replace(n, r ? t.map(e => encodeURIComponent(e)).join("/") : encodeURIComponent(t)) || "/")
                }) || (s = ""), {
                    params: u,
                    result: s
                }
            }
        },
        26213: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "isDynamicRoute", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let i = r(40394),
                n = /\/\[[^/]+?\](?=\/|$)/;

            function s(e) {
                return (0, i.isInterceptionRouteAppPath)(e) && (e = (0, i.extractInterceptionRouteInformation)(e).interceptedRoute), n.test(e)
            }
        },
        21436: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "isLocalURL", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let i = r(42511),
                n = r(6141);

            function s(e) {
                if (!(0, i.isAbsoluteUrl)(e)) return !0;
                try {
                    let t = (0, i.getLocationOrigin)(),
                        r = new URL(e, t);
                    return r.origin === t && (0, n.hasBasePath)(r.pathname)
                } catch (e) {
                    return !1
                }
            }
        },
        94029: (e, t) => {
            "use strict";

            function r(e, t) {
                let r = {};
                return Object.keys(e).forEach(i => {
                    t.includes(i) || (r[i] = e[i])
                }), r
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "omit", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        4177: (e, t) => {
            "use strict";

            function r(e) {
                let t = {};
                return e.forEach((e, r) => {
                    void 0 === t[r] ? t[r] = e : Array.isArray(t[r]) ? t[r].push(e) : t[r] = [t[r], e]
                }), t
            }

            function i(e) {
                return "string" != typeof e && ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
            }

            function n(e) {
                let t = new URLSearchParams;
                return Object.entries(e).forEach(e => {
                    let [r, n] = e;
                    Array.isArray(n) ? n.forEach(e => t.append(r, i(e))) : t.set(r, i(n))
                }), t
            }

            function s(e) {
                for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) r[i - 1] = arguments[i];
                return r.forEach(t => {
                    Array.from(t.keys()).forEach(t => e.delete(t)), t.forEach((t, r) => e.append(r, t))
                }), e
            }
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    assign: function() {
                        return s
                    },
                    searchParamsToUrlQuery: function() {
                        return r
                    },
                    urlQueryToSearchParams: function() {
                        return n
                    }
                })
        },
        69273: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "getRouteMatcher", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let i = r(42511);

            function n(e) {
                let {
                    re: t,
                    groups: r
                } = e;
                return e => {
                    let n = t.exec(e);
                    if (!n) return !1;
                    let s = e => {
                            try {
                                return decodeURIComponent(e)
                            } catch (e) {
                                throw new i.DecodeError("failed to decode param")
                            }
                        },
                        o = {};
                    return Object.keys(r).forEach(e => {
                        let t = r[e],
                            i = n[t.pos];
                        void 0 !== i && (o[e] = ~i.indexOf("/") ? i.split("/").map(e => s(e)) : t.repeat ? [s(i)] : s(i))
                    }), o
                }
            }
        },
        20511: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    getNamedMiddlewareRegex: function() {
                        return m
                    },
                    getNamedRouteRegex: function() {
                        return p
                    },
                    getRouteRegex: function() {
                        return d
                    },
                    parseParameter: function() {
                        return l
                    }
                });
            let i = r(11768),
                n = r(40394),
                s = r(72841),
                o = r(55559),
                a = /\[((?:\[.*\])|.+)\]/;

            function l(e) {
                let t = e.match(a);
                return t ? u(t[1]) : u(e)
            }

            function u(e) {
                let t = e.startsWith("[") && e.endsWith("]");
                t && (e = e.slice(1, -1));
                let r = e.startsWith("...");
                return r && (e = e.slice(3)), {
                    key: e,
                    repeat: r,
                    optional: t
                }
            }

            function h(e) {
                let t = (0, o.removeTrailingSlash)(e).slice(1).split("/"),
                    r = {},
                    i = 1;
                return {
                    parameterizedRoute: t.map(e => {
                        let t = n.INTERCEPTION_ROUTE_MARKERS.find(t => e.startsWith(t)),
                            o = e.match(a);
                        if (t && o) {
                            let {
                                key: e,
                                optional: n,
                                repeat: a
                            } = u(o[1]);
                            return r[e] = {
                                pos: i++,
                                repeat: a,
                                optional: n
                            }, "/" + (0, s.escapeStringRegexp)(t) + "([^/]+?)"
                        }
                        if (!o) return "/" + (0, s.escapeStringRegexp)(e); {
                            let {
                                key: e,
                                repeat: t,
                                optional: n
                            } = u(o[1]);
                            return r[e] = {
                                pos: i++,
                                repeat: t,
                                optional: n
                            }, t ? n ? "(?:/(.+?))?" : "/(.+?)" : "/([^/]+?)"
                        }
                    }).join(""),
                    groups: r
                }
            }

            function d(e) {
                let {
                    parameterizedRoute: t,
                    groups: r
                } = h(e);
                return {
                    re: RegExp("^" + t + "(?:/)?$"),
                    groups: r
                }
            }

            function c(e) {
                let {
                    interceptionMarker: t,
                    getSafeRouteKey: r,
                    segment: i,
                    routeKeys: n,
                    keyPrefix: o
                } = e, {
                    key: a,
                    optional: l,
                    repeat: h
                } = u(i), d = a.replace(/\W/g, "");
                o && (d = "" + o + d);
                let c = !1;
                (0 === d.length || d.length > 30) && (c = !0), isNaN(parseInt(d.slice(0, 1))) || (c = !0), c && (d = r()), o ? n[d] = "" + o + a : n[d] = a;
                let f = t ? (0, s.escapeStringRegexp)(t) : "";
                return h ? l ? "(?:/" + f + "(?<" + d + ">.+?))?" : "/" + f + "(?<" + d + ">.+?)" : "/" + f + "(?<" + d + ">[^/]+?)"
            }

            function f(e, t) {
                let r;
                let a = (0, o.removeTrailingSlash)(e).slice(1).split("/"),
                    l = (r = 0, () => {
                        let e = "",
                            t = ++r;
                        for (; t > 0;) e += String.fromCharCode(97 + (t - 1) % 26), t = Math.floor((t - 1) / 26);
                        return e
                    }),
                    u = {};
                return {
                    namedParameterizedRoute: a.map(e => {
                        let r = n.INTERCEPTION_ROUTE_MARKERS.some(t => e.startsWith(t)),
                            o = e.match(/\[((?:\[.*\])|.+)\]/);
                        if (r && o) {
                            let [r] = e.split(o[0]);
                            return c({
                                getSafeRouteKey: l,
                                interceptionMarker: r,
                                segment: o[1],
                                routeKeys: u,
                                keyPrefix: t ? i.NEXT_INTERCEPTION_MARKER_PREFIX : void 0
                            })
                        }
                        return o ? c({
                            getSafeRouteKey: l,
                            segment: o[1],
                            routeKeys: u,
                            keyPrefix: t ? i.NEXT_QUERY_PARAM_PREFIX : void 0
                        }) : "/" + (0, s.escapeStringRegexp)(e)
                    }).join(""),
                    routeKeys: u
                }
            }

            function p(e, t) {
                let r = f(e, t);
                return { ...d(e),
                    namedRegex: "^" + r.namedParameterizedRoute + "(?:/)?$",
                    routeKeys: r.routeKeys
                }
            }

            function m(e, t) {
                let {
                    parameterizedRoute: r
                } = h(e), {
                    catchAll: i = !0
                } = t;
                if ("/" === r) return {
                    namedRegex: "^/" + (i ? ".*" : "") + "$"
                };
                let {
                    namedParameterizedRoute: n
                } = f(e, !1);
                return {
                    namedRegex: "^" + n + (i ? "(?:(/.*)?)" : "") + "$"
                }
            }
        },
        71750: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    getSortedRouteObjects: function() {
                        return n
                    },
                    getSortedRoutes: function() {
                        return i
                    }
                });
            class r {
                insert(e) {
                    this._insert(e.split("/").filter(Boolean), [], !1)
                }
                smoosh() {
                    return this._smoosh()
                }
                _smoosh(e) {
                    void 0 === e && (e = "/");
                    let t = [...this.children.keys()].sort();
                    null !== this.slugName && t.splice(t.indexOf("[]"), 1), null !== this.restSlugName && t.splice(t.indexOf("[...]"), 1), null !== this.optionalRestSlugName && t.splice(t.indexOf("[[...]]"), 1);
                    let r = t.map(t => this.children.get(t)._smoosh("" + e + t + "/")).reduce((e, t) => [...e, ...t], []);
                    if (null !== this.slugName && r.push(...this.children.get("[]")._smoosh(e + "[" + this.slugName + "]/")), !this.placeholder) {
                        let t = "/" === e ? "/" : e.slice(0, -1);
                        if (null != this.optionalRestSlugName) throw Error('You cannot define a route with the same specificity as a optional catch-all route ("' + t + '" and "' + t + "[[..." + this.optionalRestSlugName + ']]").');
                        r.unshift(t)
                    }
                    return null !== this.restSlugName && r.push(...this.children.get("[...]")._smoosh(e + "[..." + this.restSlugName + "]/")), null !== this.optionalRestSlugName && r.push(...this.children.get("[[...]]")._smoosh(e + "[[..." + this.optionalRestSlugName + "]]/")), r
                }
                _insert(e, t, i) {
                    if (0 === e.length) {
                        this.placeholder = !1;
                        return
                    }
                    if (i) throw Error("Catch-all must be the last part of the URL.");
                    let n = e[0];
                    if (n.startsWith("[") && n.endsWith("]")) {
                        let r = n.slice(1, -1),
                            o = !1;
                        if (r.startsWith("[") && r.endsWith("]") && (r = r.slice(1, -1), o = !0), r.startsWith("…")) throw Error("Detected a three-dot character ('…') at ('" + r + "'). Did you mean ('...')?");
                        if (r.startsWith("...") && (r = r.substring(3), i = !0), r.startsWith("[") || r.endsWith("]")) throw Error("Segment names may not start or end with extra brackets ('" + r + "').");
                        if (r.startsWith(".")) throw Error("Segment names may not start with erroneous periods ('" + r + "').");

                        function s(e, r) {
                            if (null !== e && e !== r) throw Error("You cannot use different slug names for the same dynamic path ('" + e + "' !== '" + r + "').");
                            t.forEach(e => {
                                if (e === r) throw Error('You cannot have the same slug name "' + r + '" repeat within a single dynamic path');
                                if (e.replace(/\W/g, "") === n.replace(/\W/g, "")) throw Error('You cannot have the slug names "' + e + '" and "' + r + '" differ only by non-word symbols within a single dynamic path')
                            }), t.push(r)
                        }
                        if (i) {
                            if (o) {
                                if (null != this.restSlugName) throw Error('You cannot use both an required and optional catch-all route at the same level ("[...' + this.restSlugName + ']" and "' + e[0] + '" ).');
                                s(this.optionalRestSlugName, r), this.optionalRestSlugName = r, n = "[[...]]"
                            } else {
                                if (null != this.optionalRestSlugName) throw Error('You cannot use both an optional and required catch-all route at the same level ("[[...' + this.optionalRestSlugName + ']]" and "' + e[0] + '").');
                                s(this.restSlugName, r), this.restSlugName = r, n = "[...]"
                            }
                        } else {
                            if (o) throw Error('Optional route parameters are not yet supported ("' + e[0] + '").');
                            s(this.slugName, r), this.slugName = r, n = "[]"
                        }
                    }
                    this.children.has(n) || this.children.set(n, new r), this.children.get(n)._insert(e.slice(1), t, i)
                }
                constructor() {
                    this.placeholder = !0, this.children = new Map, this.slugName = null, this.restSlugName = null, this.optionalRestSlugName = null
                }
            }

            function i(e) {
                let t = new r;
                return e.forEach(e => t.insert(e)), t.smoosh()
            }

            function n(e, t) {
                let r = {},
                    n = [];
                for (let i = 0; i < e.length; i++) {
                    let s = t(e[i]);
                    r[s] = i, n[i] = s
                }
                return i(n).map(t => e[r[t]])
            }
        },
        42511: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    DecodeError: function() {
                        return p
                    },
                    MiddlewareNotFoundError: function() {
                        return y
                    },
                    MissingStaticPage: function() {
                        return v
                    },
                    NormalizeError: function() {
                        return m
                    },
                    PageNotFoundError: function() {
                        return g
                    },
                    SP: function() {
                        return c
                    },
                    ST: function() {
                        return f
                    },
                    WEB_VITALS: function() {
                        return r
                    },
                    execOnce: function() {
                        return i
                    },
                    getDisplayName: function() {
                        return l
                    },
                    getLocationOrigin: function() {
                        return o
                    },
                    getURL: function() {
                        return a
                    },
                    isAbsoluteUrl: function() {
                        return s
                    },
                    isResSent: function() {
                        return u
                    },
                    loadGetInitialProps: function() {
                        return d
                    },
                    normalizeRepeatedSlashes: function() {
                        return h
                    },
                    stringifyError: function() {
                        return x
                    }
                });
            let r = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

            function i(e) {
                let t, r = !1;
                return function() {
                    for (var i = arguments.length, n = Array(i), s = 0; s < i; s++) n[s] = arguments[s];
                    return r || (r = !0, t = e(...n)), t
                }
            }
            let n = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
                s = e => n.test(e);

            function o() {
                let {
                    protocol: e,
                    hostname: t,
                    port: r
                } = window.location;
                return e + "//" + t + (r ? ":" + r : "")
            }

            function a() {
                let {
                    href: e
                } = window.location, t = o();
                return e.substring(t.length)
            }

            function l(e) {
                return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
            }

            function u(e) {
                return e.finished || e.headersSent
            }

            function h(e) {
                let t = e.split("?");
                return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? "?" + t.slice(1).join("?") : "")
            }
            async function d(e, t) {
                let r = t.res || t.ctx && t.ctx.res;
                if (!e.getInitialProps) return t.ctx && t.Component ? {
                    pageProps: await d(t.Component, t.ctx)
                } : {};
                let i = await e.getInitialProps(t);
                if (r && u(r)) return i;
                if (!i) throw Error('"' + l(e) + '.getInitialProps()" should resolve to an object. But found "' + i + '" instead.');
                return i
            }
            let c = "undefined" != typeof performance,
                f = c && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
            class p extends Error {}
            class m extends Error {}
            class g extends Error {
                constructor(e) {
                    super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = "Cannot find module for page: " + e
                }
            }
            class v extends Error {
                constructor(e, t) {
                    super(), this.message = "Failed to load static file for page: " + e + " " + t
                }
            }
            class y extends Error {
                constructor() {
                    super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
                }
            }

            function x(e) {
                return JSON.stringify({
                    message: e.message,
                    stack: e.stack
                })
            }
        },
        58263: e => {
            e.exports = {
                area: !0,
                base: !0,
                br: !0,
                col: !0,
                embed: !0,
                hr: !0,
                img: !0,
                input: !0,
                link: !0,
                meta: !0,
                param: !0,
                source: !0,
                track: !0,
                wbr: !0
            }
        },
        79859: (e, t, r) => {
            "use strict";
            r.d(t, {
                F: () => u
            });
            var i = r(95289);
            let n = (e, t, r) => {
                    if (e && "reportValidity" in e) {
                        let n = (0, i.U2)(r, t);
                        e.setCustomValidity(n && n.message || ""), e.reportValidity()
                    }
                },
                s = (e, t) => {
                    for (let r in t.fields) {
                        let i = t.fields[r];
                        i && i.ref && "reportValidity" in i.ref ? n(i.ref, r, e) : i.refs && i.refs.forEach(t => n(t, r, e))
                    }
                },
                o = (e, t) => {
                    t.shouldUseNativeValidation && s(e, t);
                    let r = {};
                    for (let n in e) {
                        let s = (0, i.U2)(t.fields, n),
                            o = Object.assign(e[n] || {}, {
                                ref: s && s.ref
                            });
                        if (a(t.names || Object.keys(e), n)) {
                            let e = Object.assign({}, (0, i.U2)(r, n));
                            (0, i.t8)(e, "root", o), (0, i.t8)(r, n, e)
                        } else(0, i.t8)(r, n, o)
                    }
                    return r
                },
                a = (e, t) => e.some(e => e.startsWith(t + "."));
            var l = function(e, t) {
                    for (var r = {}; e.length;) {
                        var n = e[0],
                            s = n.code,
                            o = n.message,
                            a = n.path.join(".");
                        if (!r[a]) {
                            if ("unionErrors" in n) {
                                var l = n.unionErrors[0].errors[0];
                                r[a] = {
                                    message: l.message,
                                    type: l.code
                                }
                            } else r[a] = {
                                message: o,
                                type: s
                            }
                        }
                        if ("unionErrors" in n && n.unionErrors.forEach(function(t) {
                                return t.errors.forEach(function(t) {
                                    return e.push(t)
                                })
                            }), t) {
                            var u = r[a].types,
                                h = u && u[n.code];
                            r[a] = (0, i.KN)(a, t, r, s, h ? [].concat(h, n.message) : n.message)
                        }
                        e.shift()
                    }
                    return r
                },
                u = function(e, t, r) {
                    return void 0 === r && (r = {}),
                        function(i, n, a) {
                            try {
                                return Promise.resolve(function(n, o) {
                                    try {
                                        var l = Promise.resolve(e["sync" === r.mode ? "parse" : "parseAsync"](i, t)).then(function(e) {
                                            return a.shouldUseNativeValidation && s({}, a), {
                                                errors: {},
                                                values: r.raw ? i : e
                                            }
                                        })
                                    } catch (e) {
                                        return o(e)
                                    }
                                    return l && l.then ? l.then(void 0, o) : l
                                }(0, function(e) {
                                    if (Array.isArray(null == e ? void 0 : e.errors)) return {
                                        values: {},
                                        errors: o(l(e.errors, !a.shouldUseNativeValidation && "all" === a.criteriaMode), a)
                                    };
                                    throw e
                                }))
                            } catch (e) {
                                return Promise.reject(e)
                            }
                        }
                }
        },
        17492: (e, t, r) => {
            "use strict";
            r.d(t, {
                f: () => a
            });
            var i = r(93264),
                n = r(95641),
                s = r(12428),
                o = i.forwardRef((e, t) => (0, s.jsx)(n.WV.label, { ...e,
                    ref: t,
                    onMouseDown: t => {
                        var r;
                        t.target.closest("button, input, select, textarea") || (null === (r = e.onMouseDown) || void 0 === r || r.call(e, t), !t.defaultPrevented && t.detail > 1 && t.preventDefault())
                    }
                }));
            o.displayName = "Label";
            var a = o
        },
        65747: (e, t, r) => {
            "use strict";
            r.d(t, {
                S: () => d
            });
            var i = r(17393),
                n = r(37453),
                s = r(35047),
                o = r(27017);

            function a(e, t) {
                return e * Math.sqrt(1 - t * t)
            }
            let l = ["duration", "bounce"],
                u = ["stiffness", "damping", "mass"];

            function h(e, t) {
                return t.some(t => void 0 !== e[t])
            }

            function d({
                keyframes: e,
                restDelta: t,
                restSpeed: r,
                ...d
            }) {
                let c;
                let f = e[0],
                    p = e[e.length - 1],
                    m = {
                        done: !1,
                        value: f
                    },
                    {
                        stiffness: g,
                        damping: v,
                        mass: y,
                        duration: x,
                        velocity: b,
                        isResolvedFromDuration: S
                    } = function(e) {
                        let t = {
                            velocity: 0,
                            stiffness: 100,
                            damping: 10,
                            mass: 1,
                            isResolvedFromDuration: !1,
                            ...e
                        };
                        if (!h(e, u) && h(e, l)) {
                            let r = function({
                                duration: e = 800,
                                bounce: t = .25,
                                velocity: r = 0,
                                mass: n = 1
                            }) {
                                let l, u;
                                (0, s.K)(e <= (0, i.w)(10), "Spring duration must be 10 seconds or less");
                                let h = 1 - t;
                                h = (0, o.u)(.05, 1, h), e = (0, o.u)(.01, 10, (0, i.X)(e)), h < 1 ? (l = t => {
                                    let i = t * h,
                                        n = i * e;
                                    return .001 - (i - r) / a(t, h) * Math.exp(-n)
                                }, u = t => {
                                    let i = t * h * e,
                                        n = Math.pow(h, 2) * Math.pow(t, 2) * e,
                                        s = Math.exp(-i),
                                        o = a(Math.pow(t, 2), h);
                                    return (i * r + r - n) * s * (-l(t) + .001 > 0 ? -1 : 1) / o
                                }) : (l = t => -.001 + Math.exp(-t * e) * ((t - r) * e + 1), u = t => e * e * (r - t) * Math.exp(-t * e));
                                let d = function(e, t, r) {
                                    let i = r;
                                    for (let r = 1; r < 12; r++) i -= e(i) / t(i);
                                    return i
                                }(l, u, 5 / e);
                                if (e = (0, i.w)(e), isNaN(d)) return {
                                    stiffness: 100,
                                    damping: 10,
                                    duration: e
                                }; {
                                    let t = Math.pow(d, 2) * n;
                                    return {
                                        stiffness: t,
                                        damping: 2 * h * Math.sqrt(n * t),
                                        duration: e
                                    }
                                }
                            }(e);
                            (t = { ...t,
                                ...r,
                                mass: 1
                            }).isResolvedFromDuration = !0
                        }
                        return t
                    }({ ...d,
                        velocity: -(0, i.X)(d.velocity || 0)
                    }),
                    P = b || 0,
                    A = v / (2 * Math.sqrt(g * y)),
                    w = p - f,
                    E = (0, i.X)(Math.sqrt(g / y)),
                    _ = 5 > Math.abs(w);
                if (r || (r = _ ? .01 : 2), t || (t = _ ? .005 : .5), A < 1) {
                    let e = a(E, A);
                    c = t => p - Math.exp(-A * E * t) * ((P + A * E * w) / e * Math.sin(e * t) + w * Math.cos(e * t))
                } else if (1 === A) c = e => p - Math.exp(-E * e) * (w + (P + E * w) * e);
                else {
                    let e = E * Math.sqrt(A * A - 1);
                    c = t => {
                        let r = Math.exp(-A * E * t),
                            i = Math.min(e * t, 300);
                        return p - r * ((P + A * E * w) * Math.sinh(i) + e * w * Math.cosh(i)) / e
                    }
                }
                return {
                    calculatedDuration: S && x || null,
                    next: e => {
                        let s = c(e);
                        if (S) m.done = e >= x;
                        else {
                            let o = 0;
                            A < 1 && (o = 0 === e ? (0, i.w)(P) : (0, n.P)(c, e, s));
                            let a = Math.abs(o) <= r,
                                l = Math.abs(p - s) <= t;
                            m.done = a && l
                        }
                        return m.value = m.done ? p : s, m
                    }
                }
            }
        },
        37453: (e, t, r) => {
            "use strict";
            r.d(t, {
                P: () => n
            });
            var i = r(20389);

            function n(e, t, r) {
                let n = Math.max(t - 5, 0);
                return (0, i.R)(r - e(n), t - n)
            }
        },
        95262: (e, t, r) => {
            "use strict";
            r.d(t, {
                M: () => v
            });
            var i = r(12428),
                n = r(93264),
                s = r(25479),
                o = r(44276),
                a = r(85714);
            class l extends n.Component {
                getSnapshotBeforeUpdate(e) {
                    let t = this.props.childRef.current;
                    if (t && e.isPresent && !this.props.isPresent) {
                        let e = this.props.sizeRef.current;
                        e.height = t.offsetHeight || 0, e.width = t.offsetWidth || 0, e.top = t.offsetTop, e.left = t.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function u(e) {
                let {
                    children: t,
                    isPresent: r
                } = e, s = (0, n.useId)(), o = (0, n.useRef)(null), u = (0, n.useRef)({
                    width: 0,
                    height: 0,
                    top: 0,
                    left: 0
                }), {
                    nonce: h
                } = (0, n.useContext)(a._);
                return (0, n.useInsertionEffect)(() => {
                    let {
                        width: e,
                        height: t,
                        top: i,
                        left: n
                    } = u.current;
                    if (r || !o.current || !e || !t) return;
                    o.current.dataset.motionPopId = s;
                    let a = document.createElement("style");
                    return h && (a.nonce = h), document.head.appendChild(a), a.sheet && a.sheet.insertRule('\n          [data-motion-pop-id="'.concat(s, '"] {\n            position: absolute !important;\n            width: ').concat(e, "px !important;\n            height: ").concat(t, "px !important;\n            top: ").concat(i, "px !important;\n            left: ").concat(n, "px !important;\n          }\n        ")), () => {
                        document.head.removeChild(a)
                    }
                }, [r]), (0, i.jsx)(l, {
                    isPresent: r,
                    childRef: o,
                    sizeRef: u,
                    children: n.cloneElement(t, {
                        ref: o
                    })
                })
            }
            let h = e => {
                let {
                    children: t,
                    initial: r,
                    isPresent: a,
                    onExitComplete: l,
                    custom: h,
                    presenceAffectsLayout: c,
                    mode: f
                } = e, p = (0, o.h)(d), m = (0, n.useId)(), g = (0, n.useMemo)(() => ({
                    id: m,
                    initial: r,
                    isPresent: a,
                    custom: h,
                    onExitComplete: e => {
                        for (let t of (p.set(e, !0), p.values()))
                            if (!t) return;
                        l && l()
                    },
                    register: e => (p.set(e, !1), () => p.delete(e))
                }), c ? [Math.random()] : [a]);
                return (0, n.useMemo)(() => {
                    p.forEach((e, t) => p.set(t, !1))
                }, [a]), n.useEffect(() => {
                    a || p.size || !l || l()
                }, [a]), "popLayout" === f && (t = (0, i.jsx)(u, {
                    isPresent: a,
                    children: t
                })), (0, i.jsx)(s.O.Provider, {
                    value: g,
                    children: t
                })
            };

            function d() {
                return new Map
            }
            var c = r(59901),
                f = r(35047);
            let p = e => e.key || "";

            function m(e) {
                let t = [];
                return n.Children.forEach(e, e => {
                    (0, n.isValidElement)(e) && t.push(e)
                }), t
            }
            var g = r(82821);
            let v = e => {
                let {
                    children: t,
                    exitBeforeEnter: r,
                    custom: s,
                    initial: a = !0,
                    onExitComplete: l,
                    presenceAffectsLayout: u = !0,
                    mode: d = "sync"
                } = e;
                (0, f.k)(!r, "Replace exitBeforeEnter with mode='wait'");
                let v = (0, n.useMemo)(() => m(t), [t]),
                    y = v.map(p),
                    x = (0, n.useRef)(!0),
                    b = (0, n.useRef)(v),
                    S = (0, o.h)(() => new Map),
                    [P, A] = (0, n.useState)(v),
                    [w, E] = (0, n.useState)(v);
                (0, g.L)(() => {
                    x.current = !1, b.current = v;
                    for (let e = 0; e < w.length; e++) {
                        let t = p(w[e]);
                        y.includes(t) ? S.delete(t) : !0 !== S.get(t) && S.set(t, !1)
                    }
                }, [w, y.length, y.join("-")]);
                let _ = [];
                if (v !== P) {
                    let e = [...v];
                    for (let t = 0; t < w.length; t++) {
                        let r = w[t],
                            i = p(r);
                        y.includes(i) || (e.splice(t, 0, r), _.push(r))
                    }
                    "wait" === d && _.length && (e = _), E(m(e)), A(v);
                    return
                }
                let {
                    forceRender: T
                } = (0, n.useContext)(c.p);
                return (0, i.jsx)(i.Fragment, {
                    children: w.map(e => {
                        let t = p(e),
                            r = v === w || y.includes(t);
                        return (0, i.jsx)(h, {
                            isPresent: r,
                            initial: (!x.current || !!a) && void 0,
                            custom: r ? void 0 : s,
                            presenceAffectsLayout: u,
                            mode: d,
                            onExitComplete: r ? void 0 : () => {
                                if (!S.has(t)) return;
                                S.set(t, !0);
                                let e = !0;
                                S.forEach(t => {
                                    t || (e = !1)
                                }), e && (null == T || T(), E(b.current), l && l())
                            },
                            children: e
                        }, t)
                    })
                })
            }
        },
        59901: (e, t, r) => {
            "use strict";
            r.d(t, {
                p: () => i
            });
            let i = (0, r(93264).createContext)({})
        },
        85714: (e, t, r) => {
            "use strict";
            r.d(t, {
                _: () => i
            });
            let i = (0, r(93264).createContext)({
                transformPagePoint: e => e,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        25479: (e, t, r) => {
            "use strict";
            r.d(t, {
                O: () => i
            });
            let i = (0, r(93264).createContext)(null)
        },
        56360: (e, t, r) => {
            "use strict";
            let i;

            function n(e) {
                return null !== e && "object" == typeof e && "function" == typeof e.start
            }
            r.d(t, {
                E: () => si
            });
            let s = e => Array.isArray(e);

            function o(e, t) {
                if (!Array.isArray(t)) return !1;
                let r = t.length;
                if (r !== e.length) return !1;
                for (let i = 0; i < r; i++)
                    if (t[i] !== e[i]) return !1;
                return !0
            }

            function a(e) {
                return "string" == typeof e || Array.isArray(e)
            }

            function l(e, t, r, i) {
                if ("function" == typeof t || ("string" == typeof t && (t = e.variants && e.variants[t]), "function" == typeof t)) {
                    let [n, s] = function(e) {
                        let t = [{}, {}];
                        return null == e || e.values.forEach((e, r) => {
                            t[0][r] = e.get(), t[1][r] = e.getVelocity()
                        }), t
                    }(i);
                    t = t(void 0 !== r ? r : e.custom, n, s)
                }
                return t
            }

            function u(e, t, r) {
                let i = e.getProps();
                return l(i, t, void 0 !== r ? r : i.custom, e)
            }
            let h = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                d = ["initial", ...h],
                c = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                f = new Set(c);
            var p, m, g = r(17393);
            let v = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                y = e => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === e ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                x = {
                    type: "keyframes",
                    duration: .8
                },
                b = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                S = (e, {
                    keyframes: t
                }) => t.length > 2 ? x : f.has(e) ? e.startsWith("scale") ? y(t[1]) : v : b;

            function P(e, t) {
                return e[t] || e.default || e
            }
            let A = {
                    skipAnimations: !1,
                    useManualTiming: !1
                },
                w = {
                    current: !1
                },
                E = e => null !== e;

            function _(e, {
                repeat: t,
                repeatType: r = "loop"
            }, i) {
                let n = e.filter(E),
                    s = t && "loop" !== r && t % 2 == 1 ? 0 : n.length - 1;
                return s && void 0 !== i ? i : n[s]
            }
            var T = r(94537);
            let R = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function C(e, t) {
                let r = !1,
                    i = !0,
                    n = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    s = () => r = !0,
                    o = R.reduce((e, t) => (e[t] = function(e) {
                        let t = new Set,
                            r = new Set,
                            i = !1,
                            n = !1,
                            s = new WeakSet,
                            o = {
                                delta: 0,
                                timestamp: 0,
                                isProcessing: !1
                            };

                        function a(t) {
                            s.has(t) && (l.schedule(t), e()), t(o)
                        }
                        let l = {
                            schedule: (e, n = !1, o = !1) => {
                                let a = o && i ? t : r;
                                return n && s.add(e), a.has(e) || a.add(e), e
                            },
                            cancel: e => {
                                r.delete(e), s.delete(e)
                            },
                            process: e => {
                                if (o = e, i) {
                                    n = !0;
                                    return
                                }
                                i = !0, [t, r] = [r, t], r.clear(), t.forEach(a), i = !1, n && (n = !1, l.process(e))
                            }
                        };
                        return l
                    }(s), e), {}),
                    {
                        read: a,
                        resolveKeyframes: l,
                        update: u,
                        preRender: h,
                        render: d,
                        postRender: c
                    } = o,
                    f = () => {
                        let s = A.useManualTiming ? n.timestamp : performance.now();
                        r = !1, n.delta = i ? 1e3 / 60 : Math.max(Math.min(s - n.timestamp, 40), 1), n.timestamp = s, n.isProcessing = !0, a.process(n), l.process(n), u.process(n), h.process(n), d.process(n), c.process(n), n.isProcessing = !1, r && t && (i = !1, e(f))
                    },
                    p = () => {
                        r = !0, i = !0, n.isProcessing || e(f)
                    };
                return {
                    schedule: R.reduce((e, t) => {
                        let i = o[t];
                        return e[t] = (e, t = !1, n = !1) => (r || p(), i.schedule(e, t, n)), e
                    }, {}),
                    cancel: e => {
                        for (let t = 0; t < R.length; t++) o[R[t]].cancel(e)
                    },
                    state: n,
                    steps: o
                }
            }
            let {
                schedule: V,
                cancel: M,
                state: k,
                steps: D
            } = C("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : T.Z, !0), F = e => /^0[^.\s]+$/u.test(e);
            var j = r(35047);
            let O = e => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),
                L = e => t => "string" == typeof t && t.startsWith(e),
                N = L("--"),
                I = L("var(--"),
                U = e => !!I(e) && B.test(e.split("/*")[0].trim()),
                B = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
                W = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
            var $ = r(27017);
            let X = {
                    test: e => "number" == typeof e,
                    parse: parseFloat,
                    transform: e => e
                },
                H = { ...X,
                    transform: e => (0, $.u)(0, 1, e)
                },
                G = { ...X,
                    default: 1
                },
                z = e => Math.round(1e5 * e) / 1e5,
                Y = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
                K = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
                q = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;

            function Z(e) {
                return "string" == typeof e
            }
            let Q = e => ({
                    test: t => Z(t) && t.endsWith(e) && 1 === t.split(" ").length,
                    parse: parseFloat,
                    transform: t => `${t}${e}`
                }),
                J = Q("deg"),
                ee = Q("%"),
                et = Q("px"),
                er = Q("vh"),
                ei = Q("vw"),
                en = { ...ee,
                    parse: e => ee.parse(e) / 100,
                    transform: e => ee.transform(100 * e)
                },
                es = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                eo = e => e === X || e === et,
                ea = (e, t) => parseFloat(e.split(", ")[t]),
                el = (e, t) => (r, {
                    transform: i
                }) => {
                    if ("none" === i || !i) return 0;
                    let n = i.match(/^matrix3d\((.+)\)$/u);
                    if (n) return ea(n[1], t); {
                        let t = i.match(/^matrix\((.+)\)$/u);
                        return t ? ea(t[1], e) : 0
                    }
                },
                eu = new Set(["x", "y", "z"]),
                eh = c.filter(e => !eu.has(e)),
                ed = {
                    width: ({
                        x: e
                    }, {
                        paddingLeft: t = "0",
                        paddingRight: r = "0"
                    }) => e.max - e.min - parseFloat(t) - parseFloat(r),
                    height: ({
                        y: e
                    }, {
                        paddingTop: t = "0",
                        paddingBottom: r = "0"
                    }) => e.max - e.min - parseFloat(t) - parseFloat(r),
                    top: (e, {
                        top: t
                    }) => parseFloat(t),
                    left: (e, {
                        left: t
                    }) => parseFloat(t),
                    bottom: ({
                        y: e
                    }, {
                        top: t
                    }) => parseFloat(t) + (e.max - e.min),
                    right: ({
                        x: e
                    }, {
                        left: t
                    }) => parseFloat(t) + (e.max - e.min),
                    x: el(4, 13),
                    y: el(5, 14)
                };
            ed.translateX = ed.x, ed.translateY = ed.y;
            let ec = e => t => t.test(e),
                ef = [X, et, ee, J, ei, er, {
                    test: e => "auto" === e,
                    parse: e => e
                }],
                ep = e => ef.find(ec(e)),
                em = new Set,
                eg = !1,
                ev = !1;

            function ey() {
                if (ev) {
                    let e = Array.from(em).filter(e => e.needsMeasurement),
                        t = new Set(e.map(e => e.element)),
                        r = new Map;
                    t.forEach(e => {
                        let t = function(e) {
                            let t = [];
                            return eh.forEach(r => {
                                let i = e.getValue(r);
                                void 0 !== i && (t.push([r, i.get()]), i.set(r.startsWith("scale") ? 1 : 0))
                            }), t
                        }(e);
                        t.length && (r.set(e, t), e.render())
                    }), e.forEach(e => e.measureInitialState()), t.forEach(e => {
                        e.render();
                        let t = r.get(e);
                        t && t.forEach(([t, r]) => {
                            var i;
                            null === (i = e.getValue(t)) || void 0 === i || i.set(r)
                        })
                    }), e.forEach(e => e.measureEndState()), e.forEach(e => {
                        void 0 !== e.suspendedScrollY && window.scrollTo(0, e.suspendedScrollY)
                    })
                }
                ev = !1, eg = !1, em.forEach(e => e.complete()), em.clear()
            }

            function ex() {
                em.forEach(e => {
                    e.readKeyframes(), e.needsMeasurement && (ev = !0)
                })
            }
            class eb {
                constructor(e, t, r, i, n, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = r, this.motionValue = i, this.element = n, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (em.add(this), eg || (eg = !0, V.read(ex), V.resolveKeyframes(ey))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: e,
                        name: t,
                        element: r,
                        motionValue: i
                    } = this;
                    for (let n = 0; n < e.length; n++)
                        if (null === e[n]) {
                            if (0 === n) {
                                let n = null == i ? void 0 : i.get(),
                                    s = e[e.length - 1];
                                if (void 0 !== n) e[0] = n;
                                else if (r && t) {
                                    let i = r.readValue(t, s);
                                    null != i && (e[0] = i)
                                }
                                void 0 === e[0] && (e[0] = s), i && void 0 === n && i.set(e[0])
                            } else e[n] = e[n - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), em.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, em.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
            let eS = (e, t) => r => !!(Z(r) && q.test(r) && r.startsWith(e) || t && null != r && Object.prototype.hasOwnProperty.call(r, t)),
                eP = (e, t, r) => i => {
                    if (!Z(i)) return i;
                    let [n, s, o, a] = i.match(Y);
                    return {
                        [e]: parseFloat(n),
                        [t]: parseFloat(s),
                        [r]: parseFloat(o),
                        alpha: void 0 !== a ? parseFloat(a) : 1
                    }
                },
                eA = e => (0, $.u)(0, 255, e),
                ew = { ...X,
                    transform: e => Math.round(eA(e))
                },
                eE = {
                    test: eS("rgb", "red"),
                    parse: eP("red", "green", "blue"),
                    transform: ({
                        red: e,
                        green: t,
                        blue: r,
                        alpha: i = 1
                    }) => "rgba(" + ew.transform(e) + ", " + ew.transform(t) + ", " + ew.transform(r) + ", " + z(H.transform(i)) + ")"
                },
                e_ = {
                    test: eS("#"),
                    parse: function(e) {
                        let t = "",
                            r = "",
                            i = "",
                            n = "";
                        return e.length > 5 ? (t = e.substring(1, 3), r = e.substring(3, 5), i = e.substring(5, 7), n = e.substring(7, 9)) : (t = e.substring(1, 2), r = e.substring(2, 3), i = e.substring(3, 4), n = e.substring(4, 5), t += t, r += r, i += i, n += n), {
                            red: parseInt(t, 16),
                            green: parseInt(r, 16),
                            blue: parseInt(i, 16),
                            alpha: n ? parseInt(n, 16) / 255 : 1
                        }
                    },
                    transform: eE.transform
                },
                eT = {
                    test: eS("hsl", "hue"),
                    parse: eP("hue", "saturation", "lightness"),
                    transform: ({
                        hue: e,
                        saturation: t,
                        lightness: r,
                        alpha: i = 1
                    }) => "hsla(" + Math.round(e) + ", " + ee.transform(z(t)) + ", " + ee.transform(z(r)) + ", " + z(H.transform(i)) + ")"
                },
                eR = {
                    test: e => eE.test(e) || e_.test(e) || eT.test(e),
                    parse: e => eE.test(e) ? eE.parse(e) : eT.test(e) ? eT.parse(e) : e_.parse(e),
                    transform: e => Z(e) ? e : e.hasOwnProperty("red") ? eE.transform(e) : eT.transform(e)
                },
                eC = "number",
                eV = "color",
                eM = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function ek(e) {
                let t = e.toString(),
                    r = [],
                    i = {
                        color: [],
                        number: [],
                        var: []
                    },
                    n = [],
                    s = 0,
                    o = t.replace(eM, e => (eR.test(e) ? (i.color.push(s), n.push(eV), r.push(eR.parse(e))) : e.startsWith("var(") ? (i.var.push(s), n.push("var"), r.push(e)) : (i.number.push(s), n.push(eC), r.push(parseFloat(e))), ++s, "${}")).split("${}");
                return {
                    values: r,
                    split: o,
                    indexes: i,
                    types: n
                }
            }

            function eD(e) {
                return ek(e).values
            }

            function eF(e) {
                let {
                    split: t,
                    types: r
                } = ek(e), i = t.length;
                return e => {
                    let n = "";
                    for (let s = 0; s < i; s++)
                        if (n += t[s], void 0 !== e[s]) {
                            let t = r[s];
                            t === eC ? n += z(e[s]) : t === eV ? n += eR.transform(e[s]) : n += e[s]
                        }
                    return n
                }
            }
            let ej = e => "number" == typeof e ? 0 : e,
                eO = {
                    test: function(e) {
                        var t, r;
                        return isNaN(e) && Z(e) && ((null === (t = e.match(Y)) || void 0 === t ? void 0 : t.length) || 0) + ((null === (r = e.match(K)) || void 0 === r ? void 0 : r.length) || 0) > 0
                    },
                    parse: eD,
                    createTransformer: eF,
                    getAnimatableNone: function(e) {
                        let t = eD(e);
                        return eF(e)(t.map(ej))
                    }
                },
                eL = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function eN(e) {
                let [t, r] = e.slice(0, -1).split("(");
                if ("drop-shadow" === t) return e;
                let [i] = r.match(Y) || [];
                if (!i) return e;
                let n = r.replace(i, ""),
                    s = eL.has(t) ? 1 : 0;
                return i !== r && (s *= 100), t + "(" + s + n + ")"
            }
            let eI = /\b([a-z-]*)\(.*?\)/gu,
                eU = { ...eO,
                    getAnimatableNone: e => {
                        let t = e.match(eI);
                        return t ? t.map(eN).join(" ") : e
                    }
                },
                eB = { ...X,
                    transform: Math.round
                },
                eW = {
                    borderWidth: et,
                    borderTopWidth: et,
                    borderRightWidth: et,
                    borderBottomWidth: et,
                    borderLeftWidth: et,
                    borderRadius: et,
                    radius: et,
                    borderTopLeftRadius: et,
                    borderTopRightRadius: et,
                    borderBottomRightRadius: et,
                    borderBottomLeftRadius: et,
                    width: et,
                    maxWidth: et,
                    height: et,
                    maxHeight: et,
                    size: et,
                    top: et,
                    right: et,
                    bottom: et,
                    left: et,
                    padding: et,
                    paddingTop: et,
                    paddingRight: et,
                    paddingBottom: et,
                    paddingLeft: et,
                    margin: et,
                    marginTop: et,
                    marginRight: et,
                    marginBottom: et,
                    marginLeft: et,
                    rotate: J,
                    rotateX: J,
                    rotateY: J,
                    rotateZ: J,
                    scale: G,
                    scaleX: G,
                    scaleY: G,
                    scaleZ: G,
                    skew: J,
                    skewX: J,
                    skewY: J,
                    distance: et,
                    translateX: et,
                    translateY: et,
                    translateZ: et,
                    x: et,
                    y: et,
                    z: et,
                    perspective: et,
                    transformPerspective: et,
                    opacity: H,
                    originX: en,
                    originY: en,
                    originZ: et,
                    zIndex: eB,
                    backgroundPositionX: et,
                    backgroundPositionY: et,
                    fillOpacity: H,
                    strokeOpacity: H,
                    numOctaves: eB
                },
                e$ = { ...eW,
                    color: eR,
                    backgroundColor: eR,
                    outlineColor: eR,
                    fill: eR,
                    stroke: eR,
                    borderColor: eR,
                    borderTopColor: eR,
                    borderRightColor: eR,
                    borderBottomColor: eR,
                    borderLeftColor: eR,
                    filter: eU,
                    WebkitFilter: eU
                },
                eX = e => e$[e];

            function eH(e, t) {
                let r = eX(e);
                return r !== eU && (r = eO), r.getAnimatableNone ? r.getAnimatableNone(t) : void 0
            }
            let eG = new Set(["auto", "none", "0"]);
            class ez extends eb {
                constructor(e, t, r, i, n) {
                    super(e, t, r, i, n, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: e,
                        element: t,
                        name: r
                    } = this;
                    if (!t || !t.current) return;
                    super.readKeyframes();
                    for (let r = 0; r < e.length; r++) {
                        let i = e[r];
                        if ("string" == typeof i && U(i = i.trim())) {
                            let n = function e(t, r, i = 1) {
                                (0, j.k)(i <= 4, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`);
                                let [n, s] = function(e) {
                                    let t = W.exec(e);
                                    if (!t) return [, ];
                                    let [, r, i, n] = t;
                                    return [`--${null!=r?r:i}`, n]
                                }(t);
                                if (!n) return;
                                let o = window.getComputedStyle(r).getPropertyValue(n);
                                if (o) {
                                    let e = o.trim();
                                    return O(e) ? parseFloat(e) : e
                                }
                                return U(s) ? e(s, r, i + 1) : s
                            }(i, t.current);
                            void 0 !== n && (e[r] = n), r === e.length - 1 && (this.finalKeyframe = i)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !es.has(r) || 2 !== e.length) return;
                    let [i, n] = e, s = ep(i), o = ep(n);
                    if (s !== o) {
                        if (eo(s) && eo(o))
                            for (let t = 0; t < e.length; t++) {
                                let r = e[t];
                                "string" == typeof r && (e[t] = parseFloat(r))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: e,
                        name: t
                    } = this, r = [];
                    for (let t = 0; t < e.length; t++) {
                        var i;
                        ("number" == typeof(i = e[t]) ? 0 === i : null === i || "none" === i || "0" === i || F(i)) && r.push(t)
                    }
                    r.length && function(e, t, r) {
                        let i, n = 0;
                        for (; n < e.length && !i;) {
                            let t = e[n];
                            "string" == typeof t && !eG.has(t) && ek(t).values.length && (i = e[n]), n++
                        }
                        if (i && r)
                            for (let n of t) e[n] = eH(r, i)
                    }(e, r, t)
                }
                measureInitialState() {
                    let {
                        element: e,
                        unresolvedKeyframes: t,
                        name: r
                    } = this;
                    if (!e || !e.current) return;
                    "height" === r && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = ed[r](e.measureViewportBox(), window.getComputedStyle(e.current)), t[0] = this.measuredOrigin;
                    let i = t[t.length - 1];
                    void 0 !== i && e.getValue(r, i).jump(i, !1)
                }
                measureEndState() {
                    var e;
                    let {
                        element: t,
                        name: r,
                        unresolvedKeyframes: i
                    } = this;
                    if (!t || !t.current) return;
                    let n = t.getValue(r);
                    n && n.jump(this.measuredOrigin, !1);
                    let s = i.length - 1,
                        o = i[s];
                    i[s] = ed[r](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (e = this.removedTransforms) || void 0 === e ? void 0 : e.length) && this.removedTransforms.forEach(([e, r]) => {
                        t.getValue(e).set(r)
                    }), this.resolveNoneKeyframes()
                }
            }

            function eY(e) {
                let t;
                return () => (void 0 === t && (t = e()), t)
            }

            function eK() {
                i = void 0
            }
            let eq = {
                    now: () => (void 0 === i && eq.set(k.isProcessing || A.useManualTiming ? k.timestamp : performance.now()), i),
                    set: e => {
                        i = e, queueMicrotask(eK)
                    }
                },
                eZ = (e, t) => "zIndex" !== t && !!("number" == typeof e || Array.isArray(e) || "string" == typeof e && (eO.test(e) || "0" === e) && !e.startsWith("url("));
            class eQ {
                constructor({
                    autoplay: e = !0,
                    delay: t = 0,
                    type: r = "keyframes",
                    repeat: i = 0,
                    repeatDelay: n = 0,
                    repeatType: s = "loop",
                    ...o
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = eq.now(), this.options = {
                        autoplay: e,
                        delay: t,
                        type: r,
                        repeat: i,
                        repeatDelay: n,
                        repeatType: s,
                        ...o
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (ex(), ey()), this._resolved
                }
                onKeyframesResolved(e, t) {
                    this.resolvedAt = eq.now(), this.hasAttemptedResolve = !0;
                    let {
                        name: r,
                        type: i,
                        velocity: n,
                        delay: s,
                        onComplete: o,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && ! function(e, t, r, i) {
                            let n = e[0];
                            if (null === n) return !1;
                            if ("display" === t || "visibility" === t) return !0;
                            let s = e[e.length - 1],
                                o = eZ(n, t),
                                a = eZ(s, t);
                            return (0, j.K)(o === a, `You are trying to animate ${t} from "${n}" to "${s}". ${n} is not an animatable value - to enable this animation set ${n} to a value animatable to ${s} via the \`style\` property.`), !!o && !!a && (function(e) {
                                let t = e[0];
                                if (1 === e.length) return !0;
                                for (let r = 0; r < e.length; r++)
                                    if (e[r] !== t) return !0
                            }(e) || "spring" === r && i)
                        }(e, r, i, n)) {
                        if (w.current || !s) {
                            null == a || a(_(e, this.options, t)), null == o || o(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let u = this.initPlayback(e, t);
                    !1 !== u && (this._resolved = {
                        keyframes: e,
                        finalKeyframe: t,
                        ...u
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(e, t) {
                    return this.currentFinishedPromise.then(e, t)
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(e => {
                        this.resolveFinishedPromise = e
                    })
                }
            }
            var eJ = r(65747),
                e0 = r(37453);

            function e1({
                keyframes: e,
                velocity: t = 0,
                power: r = .8,
                timeConstant: i = 325,
                bounceDamping: n = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: a,
                max: l,
                restDelta: u = .5,
                restSpeed: h
            }) {
                let d, c;
                let f = e[0],
                    p = {
                        done: !1,
                        value: f
                    },
                    m = e => void 0 !== a && e < a || void 0 !== l && e > l,
                    g = e => void 0 === a ? l : void 0 === l ? a : Math.abs(a - e) < Math.abs(l - e) ? a : l,
                    v = r * t,
                    y = f + v,
                    x = void 0 === o ? y : o(y);
                x !== y && (v = x - f);
                let b = e => -v * Math.exp(-e / i),
                    S = e => x + b(e),
                    P = e => {
                        let t = b(e),
                            r = S(e);
                        p.done = Math.abs(t) <= u, p.value = p.done ? x : r
                    },
                    A = e => {
                        m(p.value) && (d = e, c = (0, eJ.S)({
                            keyframes: [p.value, g(p.value)],
                            velocity: (0, e0.P)(S, e, p.value),
                            damping: n,
                            stiffness: s,
                            restDelta: u,
                            restSpeed: h
                        }))
                    };
                return A(0), {
                    calculatedDuration: null,
                    next: e => {
                        let t = !1;
                        return (c || void 0 !== d || (t = !0, P(e), A(e)), void 0 !== d && e >= d) ? c.next(e - d) : (t || P(e), p)
                    }
                }
            }
            let e2 = (e, t, r) => (((1 - 3 * r + 3 * t) * e + (3 * r - 6 * t)) * e + 3 * t) * e;

            function e5(e, t, r, i) {
                if (e === t && r === i) return T.Z;
                let n = t => (function(e, t, r, i, n) {
                    let s, o;
                    let a = 0;
                    do(s = e2(o = t + (r - t) / 2, i, n) - e) > 0 ? r = o : t = o; while (Math.abs(s) > 1e-7 && ++a < 12);
                    return o
                })(t, 0, 1, e, r);
                return e => 0 === e || 1 === e ? e : e2(n(e), t, i)
            }
            let e3 = e5(.42, 0, 1, 1),
                e4 = e5(0, 0, .58, 1),
                e9 = e5(.42, 0, .58, 1),
                e7 = e => Array.isArray(e) && "number" != typeof e[0],
                e6 = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
                e8 = e => t => 1 - e(1 - t),
                te = e => 1 - Math.sin(Math.acos(e)),
                tt = e8(te),
                tr = e6(te),
                ti = e5(.33, 1.53, .69, .99),
                tn = e8(ti),
                ts = e6(tn),
                to = {
                    linear: T.Z,
                    easeIn: e3,
                    easeInOut: e9,
                    easeOut: e4,
                    circIn: te,
                    circInOut: tr,
                    circOut: tt,
                    backIn: tn,
                    backInOut: ts,
                    backOut: ti,
                    anticipate: e => (e *= 2) < 1 ? .5 * tn(e) : .5 * (2 - Math.pow(2, -10 * (e - 1)))
                },
                ta = e => {
                    if (Array.isArray(e)) {
                        (0, j.k)(4 === e.length, "Cubic bezier arrays must contain four numerical values.");
                        let [t, r, i, n] = e;
                        return e5(t, r, i, n)
                    }
                    return "string" == typeof e ? ((0, j.k)(void 0 !== to[e], `Invalid easing type '${e}'`), to[e]) : e
                },
                tl = (e, t) => r => t(e(r)),
                tu = (...e) => e.reduce(tl),
                th = (e, t, r) => {
                    let i = t - e;
                    return 0 === i ? 1 : (r - e) / i
                },
                td = (e, t, r) => e + (t - e) * r;

            function tc(e, t, r) {
                return (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6) ? e + (t - e) * 6 * r : r < .5 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e
            }

            function tf(e, t) {
                return r => r > 0 ? t : e
            }
            let tp = (e, t, r) => {
                    let i = e * e,
                        n = r * (t * t - i) + i;
                    return n < 0 ? 0 : Math.sqrt(n)
                },
                tm = [e_, eE, eT],
                tg = e => tm.find(t => t.test(e));

            function tv(e) {
                let t = tg(e);
                if ((0, j.K)(!!t, `'${e}' is not an animatable color. Use the equivalent color code instead.`), !t) return !1;
                let r = t.parse(e);
                return t === eT && (r = function({
                    hue: e,
                    saturation: t,
                    lightness: r,
                    alpha: i
                }) {
                    e /= 360, r /= 100;
                    let n = 0,
                        s = 0,
                        o = 0;
                    if (t /= 100) {
                        let i = r < .5 ? r * (1 + t) : r + t - r * t,
                            a = 2 * r - i;
                        n = tc(a, i, e + 1 / 3), s = tc(a, i, e), o = tc(a, i, e - 1 / 3)
                    } else n = s = o = r;
                    return {
                        red: Math.round(255 * n),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * o),
                        alpha: i
                    }
                }(r)), r
            }
            let ty = (e, t) => {
                    let r = tv(e),
                        i = tv(t);
                    if (!r || !i) return tf(e, t);
                    let n = { ...r
                    };
                    return e => (n.red = tp(r.red, i.red, e), n.green = tp(r.green, i.green, e), n.blue = tp(r.blue, i.blue, e), n.alpha = td(r.alpha, i.alpha, e), eE.transform(n))
                },
                tx = new Set(["none", "hidden"]);

            function tb(e, t) {
                return r => td(e, t, r)
            }

            function tS(e) {
                return "number" == typeof e ? tb : "string" == typeof e ? U(e) ? tf : eR.test(e) ? ty : tw : Array.isArray(e) ? tP : "object" == typeof e ? eR.test(e) ? ty : tA : tf
            }

            function tP(e, t) {
                let r = [...e],
                    i = r.length,
                    n = e.map((e, r) => tS(e)(e, t[r]));
                return e => {
                    for (let t = 0; t < i; t++) r[t] = n[t](e);
                    return r
                }
            }

            function tA(e, t) {
                let r = { ...e,
                        ...t
                    },
                    i = {};
                for (let n in r) void 0 !== e[n] && void 0 !== t[n] && (i[n] = tS(e[n])(e[n], t[n]));
                return e => {
                    for (let t in i) r[t] = i[t](e);
                    return r
                }
            }
            let tw = (e, t) => {
                let r = eO.createTransformer(t),
                    i = ek(e),
                    n = ek(t);
                return i.indexes.var.length === n.indexes.var.length && i.indexes.color.length === n.indexes.color.length && i.indexes.number.length >= n.indexes.number.length ? tx.has(e) && !n.values.length || tx.has(t) && !i.values.length ? function(e, t) {
                    return tx.has(e) ? r => r <= 0 ? e : t : r => r >= 1 ? t : e
                }(e, t) : tu(tP(function(e, t) {
                    var r;
                    let i = [],
                        n = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < t.values.length; s++) {
                        let o = t.types[s],
                            a = e.indexes[o][n[o]],
                            l = null !== (r = e.values[a]) && void 0 !== r ? r : 0;
                        i[s] = l, n[o]++
                    }
                    return i
                }(i, n), n.values), r) : ((0, j.K)(!0, `Complex values '${e}' and '${t}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), tf(e, t))
            };

            function tE(e, t, r) {
                return "number" == typeof e && "number" == typeof t && "number" == typeof r ? td(e, t, r) : tS(e)(e, t)
            }

            function t_({
                duration: e = 300,
                keyframes: t,
                times: r,
                ease: i = "easeInOut"
            }) {
                let n = e7(i) ? i.map(ta) : ta(i),
                    s = {
                        done: !1,
                        value: t[0]
                    },
                    o = function(e, t, {
                        clamp: r = !0,
                        ease: i,
                        mixer: n
                    } = {}) {
                        let s = e.length;
                        if ((0, j.k)(s === t.length, "Both input and output ranges must be the same length"), 1 === s) return () => t[0];
                        if (2 === s && e[0] === e[1]) return () => t[1];
                        e[0] > e[s - 1] && (e = [...e].reverse(), t = [...t].reverse());
                        let o = function(e, t, r) {
                                let i = [],
                                    n = r || tE,
                                    s = e.length - 1;
                                for (let r = 0; r < s; r++) {
                                    let s = n(e[r], e[r + 1]);
                                    t && (s = tu(Array.isArray(t) ? t[r] || T.Z : t, s)), i.push(s)
                                }
                                return i
                            }(t, i, n),
                            a = o.length,
                            l = t => {
                                let r = 0;
                                if (a > 1)
                                    for (; r < e.length - 2 && !(t < e[r + 1]); r++);
                                let i = th(e[r], e[r + 1], t);
                                return o[r](i)
                            };
                        return r ? t => l((0, $.u)(e[0], e[s - 1], t)) : l
                    }((r && r.length === t.length ? r : function(e) {
                        let t = [0];
                        return function(e, t) {
                            let r = e[e.length - 1];
                            for (let i = 1; i <= t; i++) {
                                let n = th(0, t, i);
                                e.push(td(r, 1, n))
                            }
                        }(t, e.length - 1), t
                    }(t)).map(t => t * e), t, {
                        ease: Array.isArray(n) ? n : t.map(() => n || e9).splice(0, t.length - 1)
                    });
                return {
                    calculatedDuration: e,
                    next: t => (s.value = o(t), s.done = t >= e, s)
                }
            }
            let tT = e => {
                    let t = ({
                        timestamp: t
                    }) => e(t);
                    return {
                        start: () => V.update(t, !0),
                        stop: () => M(t),
                        now: () => k.isProcessing ? k.timestamp : eq.now()
                    }
                },
                tR = {
                    decay: e1,
                    inertia: e1,
                    tween: t_,
                    keyframes: t_,
                    spring: eJ.S
                },
                tC = e => e / 100;
            class tV extends eQ {
                constructor(e) {
                    super(e), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: e
                        } = this.options;
                        e && e()
                    };
                    let {
                        name: t,
                        motionValue: r,
                        element: i,
                        keyframes: n
                    } = this.options, s = (null == i ? void 0 : i.KeyframeResolver) || eb;
                    this.resolver = new s(n, (e, t) => this.onKeyframesResolved(e, t), t, r, i), this.resolver.scheduleResolve()
                }
                initPlayback(e) {
                    let t, r;
                    let {
                        type: i = "keyframes",
                        repeat: n = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = tR[i] || t_;
                    l !== t_ && "number" != typeof e[0] && (t = tu(tC, tE(e[0], e[1])), e = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: e
                    });
                    "mirror" === o && (r = l({ ...this.options,
                        keyframes: [...e].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = function(e) {
                        let t = 0,
                            r = e.next(t);
                        for (; !r.done && t < 2e4;) t += 50, r = e.next(t);
                        return t >= 2e4 ? 1 / 0 : t
                    }(u));
                    let {
                        calculatedDuration: h
                    } = u, d = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: r,
                        mapPercentToKeyframes: t,
                        calculatedDuration: h,
                        resolvedDuration: d,
                        totalDuration: d * (n + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: e = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && e ? this.state = this.pendingPlayState : this.pause()
                }
                tick(e, t = !1) {
                    let {
                        resolved: r
                    } = this;
                    if (!r) {
                        let {
                            keyframes: e
                        } = this.options;
                        return {
                            done: !0,
                            value: e[e.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: i,
                        generator: n,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: u,
                        resolvedDuration: h
                    } = r;
                    if (null === this.startTime) return n.next(0);
                    let {
                        delay: d,
                        repeat: c,
                        repeatType: f,
                        repeatDelay: p,
                        onUpdate: m
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - u / this.speed, this.startTime)), t ? this.currentTime = e : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(e - this.startTime) * this.speed;
                    let g = this.currentTime - d * (this.speed >= 0 ? 1 : -1),
                        v = this.speed >= 0 ? g < 0 : g > u;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = u);
                    let y = this.currentTime,
                        x = n;
                    if (c) {
                        let e = Math.min(this.currentTime, u) / h,
                            t = Math.floor(e),
                            r = e % 1;
                        !r && e >= 1 && (r = 1), 1 === r && t--, (t = Math.min(t, c + 1)) % 2 && ("reverse" === f ? (r = 1 - r, p && (r -= p / h)) : "mirror" === f && (x = s)), y = (0, $.u)(0, 1, r) * h
                    }
                    let b = v ? {
                        done: !1,
                        value: a[0]
                    } : x.next(y);
                    o && (b.value = o(b.value));
                    let {
                        done: S
                    } = b;
                    v || null === l || (S = this.speed >= 0 ? this.currentTime >= u : this.currentTime <= 0);
                    let P = null === this.holdTime && ("finished" === this.state || "running" === this.state && S);
                    return P && void 0 !== i && (b.value = _(a, this.options, i)), m && m(b.value), P && this.finish(), b
                }
                get duration() {
                    let {
                        resolved: e
                    } = this;
                    return e ? (0, g.X)(e.calculatedDuration) : 0
                }
                get time() {
                    return (0, g.X)(this.currentTime)
                }
                set time(e) {
                    e = (0, g.w)(e), this.currentTime = e, null !== this.holdTime || 0 === this.speed ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(e) {
                    let t = this.playbackSpeed !== e;
                    this.playbackSpeed = e, t && (this.time = (0, g.X)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: e = tT,
                        onPlay: t,
                        startTime: r
                    } = this.options;
                    this.driver || (this.driver = e(e => this.tick(e))), t && t();
                    let i = this.driver.now();
                    null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = i) : this.startTime = null != r ? r : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var e;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (e = this.currentTime) && void 0 !== e ? e : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: e
                    } = this.options;
                    e && e()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(e) {
                    return this.startTime = 0, this.tick(e, !0)
                }
            }
            let tM = new Set(["opacity", "clipPath", "filter", "transform"]),
                tk = e => Array.isArray(e) && "number" == typeof e[0],
                tD = ([e, t, r, i]) => `cubic-bezier(${e}, ${t}, ${r}, ${i})`,
                tF = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: tD([0, .65, .55, 1]),
                    circOut: tD([.55, 0, 1, .45]),
                    backIn: tD([.31, .01, .66, -.59]),
                    backOut: tD([.33, 1.53, .69, .99])
                };

            function tj(e) {
                return tO(e) || tF.easeOut
            }

            function tO(e) {
                if (e) return tk(e) ? tD(e) : Array.isArray(e) ? e.map(tj) : tF[e]
            }
            let tL = eY(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
            class tN extends eQ {
                constructor(e) {
                    super(e);
                    let {
                        name: t,
                        motionValue: r,
                        element: i,
                        keyframes: n
                    } = this.options;
                    this.resolver = new ez(n, (e, t) => this.onKeyframesResolved(e, t), t, r, i), this.resolver.scheduleResolve()
                }
                initPlayback(e, t) {
                    var r, i;
                    let {
                        duration: n = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u,
                        startTime: h
                    } = this.options;
                    if (!(null === (r = l.owner) || void 0 === r ? void 0 : r.current)) return !1;
                    if ("spring" === (i = this.options).type || ! function e(t) {
                            return !!(!t || "string" == typeof t && t in tF || tk(t) || Array.isArray(t) && t.every(e))
                        }(i.ease)) {
                        let {
                            onComplete: t,
                            onUpdate: r,
                            motionValue: i,
                            element: l,
                            ...u
                        } = this.options, h = function(e, t) {
                            let r = new tV({ ...t,
                                    keyframes: e,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                i = {
                                    done: !1,
                                    value: e[0]
                                },
                                n = [],
                                s = 0;
                            for (; !i.done && s < 2e4;) n.push((i = r.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: n,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(e, u);
                        1 === (e = h.keyframes).length && (e[1] = e[0]), n = h.duration, s = h.times, o = h.ease, a = "keyframes"
                    }
                    let d = function(e, t, r, {
                        delay: i = 0,
                        duration: n = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a,
                        times: l
                    } = {}) {
                        let u = {
                            [t]: r
                        };
                        l && (u.offset = l);
                        let h = tO(a);
                        return Array.isArray(h) && (u.easing = h), e.animate(u, {
                            delay: i,
                            duration: n,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, e, { ...this.options,
                        duration: n,
                        times: s,
                        ease: o
                    });
                    return d.startTime = null != h ? h : this.calcStartTime(), this.pendingTimeline ? (d.timeline = this.pendingTimeline, this.pendingTimeline = void 0) : d.onfinish = () => {
                        let {
                            onComplete: r
                        } = this.options;
                        l.set(_(e, this.options, t)), r && r(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: d,
                        duration: n,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: e
                    }
                }
                get duration() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return 0;
                    let {
                        duration: t
                    } = e;
                    return (0, g.X)(t)
                }
                get time() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return 0;
                    let {
                        animation: t
                    } = e;
                    return (0, g.X)(t.currentTime || 0)
                }
                set time(e) {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: r
                    } = t;
                    r.currentTime = (0, g.w)(e)
                }
                get speed() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return 1;
                    let {
                        animation: t
                    } = e;
                    return t.playbackRate
                }
                set speed(e) {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: r
                    } = t;
                    r.playbackRate = e
                }
                get state() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return "idle";
                    let {
                        animation: t
                    } = e;
                    return t.playState
                }
                get startTime() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return null;
                    let {
                        animation: t
                    } = e;
                    return t.startTime
                }
                attachTimeline(e) {
                    if (this._resolved) {
                        let {
                            resolved: t
                        } = this;
                        if (!t) return T.Z;
                        let {
                            animation: r
                        } = t;
                        r.timeline = e, r.onfinish = null
                    } else this.pendingTimeline = e;
                    return T.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: t
                    } = e;
                    "finished" === t.playState && this.updateFinishedPromise(), t.play()
                }
                pause() {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: t
                    } = e;
                    t.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: t,
                        keyframes: r,
                        duration: i,
                        type: n,
                        ease: s,
                        times: o
                    } = e;
                    if ("idle" === t.playState || "finished" === t.playState) return;
                    if (this.time) {
                        let {
                            motionValue: e,
                            onUpdate: t,
                            onComplete: a,
                            element: l,
                            ...u
                        } = this.options, h = new tV({ ...u,
                            keyframes: r,
                            duration: i,
                            type: n,
                            ease: s,
                            times: o,
                            isGenerator: !0
                        }), d = (0, g.w)(this.time);
                        e.setWithVelocity(h.sample(d - 10).value, h.sample(d).value, 10)
                    }
                    let {
                        onStop: a
                    } = this.options;
                    a && a(), this.cancel()
                }
                complete() {
                    let {
                        resolved: e
                    } = this;
                    e && e.animation.finish()
                }
                cancel() {
                    let {
                        resolved: e
                    } = this;
                    e && e.animation.cancel()
                }
                static supports(e) {
                    let {
                        motionValue: t,
                        name: r,
                        repeatDelay: i,
                        repeatType: n,
                        damping: s,
                        type: o
                    } = e;
                    return tL() && r && tM.has(r) && t && t.owner && t.owner.current instanceof HTMLElement && !t.owner.getProps().onUpdate && !i && "mirror" !== n && 0 !== s && "inertia" !== o
                }
            }
            let tI = eY(() => void 0 !== window.ScrollTimeline);
            class tU {
                constructor(e) {
                    this.stop = () => this.runAll("stop"), this.animations = e.filter(Boolean)
                }
                then(e, t) {
                    return Promise.all(this.animations).then(e).catch(t)
                }
                getAll(e) {
                    return this.animations[0][e]
                }
                setAll(e, t) {
                    for (let r = 0; r < this.animations.length; r++) this.animations[r][e] = t
                }
                attachTimeline(e) {
                    let t = this.animations.map(t => {
                        if (!tI() || !t.attachTimeline) return t.pause(),
                            function(e, t) {
                                let r;
                                let i = () => {
                                    let {
                                        currentTime: i
                                    } = t, n = (null === i ? 0 : i.value) / 100;
                                    r !== n && e(n), r = n
                                };
                                return V.update(i, !0), () => M(i)
                            }(e => {
                                t.time = t.duration * e
                            }, e);
                        t.attachTimeline(e)
                    });
                    return () => {
                        t.forEach((e, t) => {
                            e && e(), this.animations[t].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(e) {
                    this.setAll("time", e)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(e) {
                    this.setAll("speed", e)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let e = 0;
                    for (let t = 0; t < this.animations.length; t++) e = Math.max(e, this.animations[t].duration);
                    return e
                }
                runAll(e) {
                    this.animations.forEach(t => t[e]())
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            let tB = (e, t, r, i = {}, n, s, o) => a => {
                    let l = P(i, e) || {},
                        u = l.delay || i.delay || 0,
                        {
                            elapsed: h = 0
                        } = i;
                    h -= (0, g.w)(u);
                    let d = {
                        keyframes: Array.isArray(r) ? r : [null, r],
                        ease: "easeOut",
                        velocity: t.getVelocity(),
                        ...l,
                        delay: -h,
                        onUpdate: e => {
                            t.set(e), l.onUpdate && l.onUpdate(e)
                        },
                        onComplete: () => {
                            a(), l.onComplete && l.onComplete(), o && o()
                        },
                        onStop: o,
                        name: e,
                        motionValue: t,
                        element: s ? void 0 : n
                    };
                    ! function({
                        when: e,
                        delay: t,
                        delayChildren: r,
                        staggerChildren: i,
                        staggerDirection: n,
                        repeat: s,
                        repeatType: o,
                        repeatDelay: a,
                        from: l,
                        elapsed: u,
                        ...h
                    }) {
                        return !!Object.keys(h).length
                    }(l) && (d = { ...d,
                        ...S(e, d)
                    }), d.duration && (d.duration = (0, g.w)(d.duration)), d.repeatDelay && (d.repeatDelay = (0, g.w)(d.repeatDelay)), void 0 !== d.from && (d.keyframes[0] = d.from);
                    let c = !1;
                    if (!1 !== d.type && (0 !== d.duration || d.repeatDelay) || (d.duration = 0, 0 !== d.delay || (c = !0)), (w.current || A.skipAnimations) && (c = !0, d.duration = 0, d.delay = 0), c && !s && void 0 !== t.get()) {
                        let e = _(d.keyframes, l);
                        if (void 0 !== e) return V.update(() => {
                            d.onUpdate(e), d.onComplete()
                        }), new tU([])
                    }
                    return !s && tN.supports(d) ? new tN(d) : new tV(d)
                },
                tW = e => !!(e && "object" == typeof e && e.mix && e.toValue),
                t$ = e => s(e) ? e[e.length - 1] || 0 : e;

            function tX(e, t) {
                -1 === e.indexOf(t) && e.push(t)
            }

            function tH(e, t) {
                let r = e.indexOf(t);
                r > -1 && e.splice(r, 1)
            }
            class tG {
                constructor() {
                    this.subscriptions = []
                }
                add(e) {
                    return tX(this.subscriptions, e), () => tH(this.subscriptions, e)
                }
                notify(e, t, r) {
                    let i = this.subscriptions.length;
                    if (i) {
                        if (1 === i) this.subscriptions[0](e, t, r);
                        else
                            for (let n = 0; n < i; n++) {
                                let i = this.subscriptions[n];
                                i && i(e, t, r)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
            var tz = r(20389);
            let tY = e => !isNaN(parseFloat(e)),
                tK = {
                    current: void 0
                };
            class tq {
                constructor(e, t = {}) {
                    this.version = "11.5.4", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (e, t = !0) => {
                        let r = eq.now();
                        this.updatedAt !== r && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), t && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner
                }
                setCurrent(e) {
                    this.current = e, this.updatedAt = eq.now(), null === this.canTrackVelocity && void 0 !== e && (this.canTrackVelocity = tY(this.current))
                }
                setPrevFrameValue(e = this.current) {
                    this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt
                }
                onChange(e) {
                    return this.on("change", e)
                }
                on(e, t) {
                    this.events[e] || (this.events[e] = new tG);
                    let r = this.events[e].add(t);
                    return "change" === e ? () => {
                        r(), V.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : r
                }
                clearListeners() {
                    for (let e in this.events) this.events[e].clear()
                }
                attach(e, t) {
                    this.passiveEffect = e, this.stopPassiveEffect = t
                }
                set(e, t = !0) {
                    t && this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e, t)
                }
                setWithVelocity(e, t, r) {
                    this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - r
                }
                jump(e, t = !0) {
                    this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, t && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return tK.current && tK.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    let e = eq.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
                    let t = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return (0, tz.R)(parseFloat(this.current) - parseFloat(this.prevFrameValue), t)
                }
                start(e) {
                    return this.stop(), new Promise(t => {
                        this.hasAnimated = !0, this.animation = e(t), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function tZ(e, t) {
                return new tq(e, t)
            }
            let tQ = e => e.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
                tJ = "data-" + tQ("framerAppearId");

            function t0(e) {
                return f.has(e) ? "transform" : tM.has(e) ? tQ(e) : void 0
            }
            class t1 extends tq {
                constructor() {
                    super(...arguments), this.output = [], this.counts = new Map
                }
                add(e) {
                    let t = t0(e);
                    if (!t) return;
                    let r = this.counts.get(t) || 0;
                    this.counts.set(t, r + 1), 0 === r && (this.output.push(t), this.update());
                    let i = !1;
                    return () => {
                        if (i) return;
                        i = !0;
                        let e = this.counts.get(t) - 1;
                        this.counts.set(t, e), 0 === e && (tH(this.output, t), this.update())
                    }
                }
                update() {
                    this.set(this.output.length ? this.output.join(", ") : "auto")
                }
            }
            let t2 = e => !!(e && e.getVelocity);

            function t5(e, t) {
                var r, i;
                if (!e.applyWillChange) return;
                let n = e.getValue("willChange");
                if (n || (null === (r = e.props.style) || void 0 === r ? void 0 : r.willChange) || (n = new t1("auto"), e.addValue("willChange", n)), t2(i = n) && i.add) return n.add(t)
            }

            function t3(e, t, {
                delay: r = 0,
                transitionOverride: i,
                type: n
            } = {}) {
                var s;
                let {
                    transition: o = e.getDefaultTransition(),
                    transitionEnd: a,
                    ...l
                } = t;
                i && (o = i);
                let h = [],
                    d = n && e.animationState && e.animationState.getState()[n];
                for (let t in l) {
                    let i = e.getValue(t, null !== (s = e.latestValues[t]) && void 0 !== s ? s : null),
                        n = l[t];
                    if (void 0 === n || d && function({
                            protectedKeys: e,
                            needsAnimating: t
                        }, r) {
                            let i = e.hasOwnProperty(r) && !0 !== t[r];
                            return t[r] = !1, i
                        }(d, t)) continue;
                    let a = {
                            delay: r,
                            ...P(o || {}, t)
                        },
                        u = !1;
                    if (window.MotionHandoffAnimation) {
                        let r = e.props[tJ];
                        if (r) {
                            let e = window.MotionHandoffAnimation(r, t, V);
                            null !== e && (a.startTime = e, u = !0)
                        }
                    }
                    i.start(tB(t, i, n, e.shouldReduceMotion && f.has(t) ? {
                        type: !1
                    } : a, e, u, t5(e, t)));
                    let c = i.animation;
                    c && h.push(c)
                }
                return a && Promise.all(h).then(() => {
                    V.update(() => {
                        a && function(e, t) {
                            let {
                                transitionEnd: r = {},
                                transition: i = {},
                                ...n
                            } = u(e, t) || {};
                            for (let t in n = { ...n,
                                    ...r
                                }) {
                                let r = t$(n[t]);
                                e.hasValue(t) ? e.getValue(t).set(r) : e.addValue(t, tZ(r))
                            }
                        }(e, a)
                    })
                }), h
            }

            function t4(e, t, r = {}) {
                var i;
                let n = u(e, t, "exit" === r.type ? null === (i = e.presenceContext) || void 0 === i ? void 0 : i.custom : void 0),
                    {
                        transition: s = e.getDefaultTransition() || {}
                    } = n || {};
                r.transitionOverride && (s = r.transitionOverride);
                let o = n ? () => Promise.all(t3(e, n, r)) : () => Promise.resolve(),
                    a = e.variantChildren && e.variantChildren.size ? (i = 0) => {
                        let {
                            delayChildren: n = 0,
                            staggerChildren: o,
                            staggerDirection: a
                        } = s;
                        return function(e, t, r = 0, i = 0, n = 1, s) {
                            let o = [],
                                a = (e.variantChildren.size - 1) * i,
                                l = 1 === n ? (e = 0) => e * i : (e = 0) => a - e * i;
                            return Array.from(e.variantChildren).sort(t9).forEach((e, i) => {
                                e.notify("AnimationStart", t), o.push(t4(e, t, { ...s,
                                    delay: r + l(i)
                                }).then(() => e.notify("AnimationComplete", t)))
                            }), Promise.all(o)
                        }(e, t, n + i, o, a, r)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = s;
                if (!l) return Promise.all([o(), a(r.delay)]); {
                    let [e, t] = "beforeChildren" === l ? [o, a] : [a, o];
                    return e().then(() => t())
                }
            }

            function t9(e, t) {
                return e.sortNodePosition(t)
            }
            let t7 = [...h].reverse(),
                t6 = h.length;

            function t8(e = !1) {
                return {
                    isActive: e,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function re() {
                return {
                    animate: t8(!0),
                    whileInView: t8(),
                    whileHover: t8(),
                    whileTap: t8(),
                    whileDrag: t8(),
                    whileFocus: t8(),
                    exit: t8()
                }
            }
            class rt {
                constructor(e) {
                    this.isMounted = !1, this.node = e
                }
                update() {}
            }
            class rr extends rt {
                constructor(e) {
                    super(e), e.animationState || (e.animationState = function(e) {
                        let t = t => Promise.all(t.map(({
                                animation: t,
                                options: r
                            }) => (function(e, t, r = {}) {
                                let i;
                                if (e.notify("AnimationStart", t), Array.isArray(t)) i = Promise.all(t.map(t => t4(e, t, r)));
                                else if ("string" == typeof t) i = t4(e, t, r);
                                else {
                                    let n = "function" == typeof t ? u(e, t, r.custom) : t;
                                    i = Promise.all(t3(e, n, r))
                                }
                                return i.then(() => {
                                    e.notify("AnimationComplete", t)
                                })
                            })(e, t, r))),
                            r = re(),
                            i = !0,
                            l = t => (r, i) => {
                                var n;
                                let s = u(e, i, "exit" === t ? null === (n = e.presenceContext) || void 0 === n ? void 0 : n.custom : void 0);
                                if (s) {
                                    let {
                                        transition: e,
                                        transitionEnd: t,
                                        ...i
                                    } = s;
                                    r = { ...r,
                                        ...i,
                                        ...t
                                    }
                                }
                                return r
                            };

                        function h(u) {
                            let h = e.getProps(),
                                d = e.getVariantContext(!0) || {},
                                c = [],
                                f = new Set,
                                p = {},
                                m = 1 / 0;
                            for (let t = 0; t < t6; t++) {
                                var g;
                                let v = t7[t],
                                    y = r[v],
                                    x = void 0 !== h[v] ? h[v] : d[v],
                                    b = a(x),
                                    S = v === u ? y.isActive : null;
                                !1 === S && (m = t);
                                let P = x === d[v] && x !== h[v] && b;
                                if (P && i && e.manuallyAnimateOnMount && (P = !1), y.protectedKeys = { ...p
                                    }, !y.isActive && null === S || !x && !y.prevProp || n(x) || "boolean" == typeof x) continue;
                                let A = (g = y.prevProp, ("string" == typeof x ? x !== g : !!Array.isArray(x) && !o(x, g)) || v === u && y.isActive && !P && b || t > m && b),
                                    w = !1,
                                    E = Array.isArray(x) ? x : [x],
                                    _ = E.reduce(l(v), {});
                                !1 === S && (_ = {});
                                let {
                                    prevResolvedValues: T = {}
                                } = y, R = { ...T,
                                    ..._
                                }, C = t => {
                                    A = !0, f.has(t) && (w = !0, f.delete(t)), y.needsAnimating[t] = !0;
                                    let r = e.getValue(t);
                                    r && (r.liveStyle = !1)
                                };
                                for (let e in R) {
                                    let t = _[e],
                                        r = T[e];
                                    if (!p.hasOwnProperty(e))(s(t) && s(r) ? o(t, r) : t === r) ? void 0 !== t && f.has(e) ? C(e) : y.protectedKeys[e] = !0 : null != t ? C(e) : f.add(e)
                                }
                                y.prevProp = x, y.prevResolvedValues = _, y.isActive && (p = { ...p,
                                    ..._
                                }), i && e.blockInitialAnimation && (A = !1), A && (!P || w) && c.push(...E.map(e => ({
                                    animation: e,
                                    options: {
                                        type: v
                                    }
                                })))
                            }
                            if (f.size) {
                                let t = {};
                                f.forEach(r => {
                                    let i = e.getBaseTarget(r),
                                        n = e.getValue(r);
                                    n && (n.liveStyle = !0), t[r] = null != i ? i : null
                                }), c.push({
                                    animation: t
                                })
                            }
                            let v = !!c.length;
                            return i && (!1 === h.initial || h.initial === h.animate) && !e.manuallyAnimateOnMount && (v = !1), i = !1, v ? t(c) : Promise.resolve()
                        }
                        return {
                            animateChanges: h,
                            setActive: function(t, i) {
                                var n;
                                if (r[t].isActive === i) return Promise.resolve();
                                null === (n = e.variantChildren) || void 0 === n || n.forEach(e => {
                                    var r;
                                    return null === (r = e.animationState) || void 0 === r ? void 0 : r.setActive(t, i)
                                }), r[t].isActive = i;
                                let s = h(t);
                                for (let e in r) r[e].protectedKeys = {};
                                return s
                            },
                            setAnimateFunction: function(r) {
                                t = r(e)
                            },
                            getState: () => r,
                            reset: () => {
                                r = re(), i = !0
                            }
                        }
                    }(e))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: e
                    } = this.node.getProps();
                    n(e) && (this.unmountControls = e.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: e
                    } = this.node.getProps(), {
                        animate: t
                    } = this.node.prevProps || {};
                    e !== t && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    var e;
                    this.node.animationState.reset(), null === (e = this.unmountControls) || void 0 === e || e.call(this)
                }
            }
            let ri = 0;
            class rn extends rt {
                constructor() {
                    super(...arguments), this.id = ri++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: e,
                        onExitComplete: t
                    } = this.node.presenceContext, {
                        isPresent: r
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || e === r) return;
                    let i = this.node.animationState.setActive("exit", !e);
                    t && !e && i.then(() => t(this.id))
                }
                mount() {
                    let {
                        register: e
                    } = this.node.presenceContext || {};
                    e && (this.unmount = e(this.id))
                }
                unmount() {}
            }
            let rs = e => "mouse" === e.pointerType ? "number" != typeof e.button || e.button <= 0 : !1 !== e.isPrimary;

            function ro(e, t = "page") {
                return {
                    point: {
                        x: e[`${t}X`],
                        y: e[`${t}Y`]
                    }
                }
            }
            let ra = e => t => rs(t) && e(t, ro(t));

            function rl(e, t, r, i = {
                passive: !0
            }) {
                return e.addEventListener(t, r, i), () => e.removeEventListener(t, r)
            }

            function ru(e, t, r, i) {
                return rl(e, t, ra(r), i)
            }
            let rh = (e, t) => Math.abs(e - t);
            class rd {
                constructor(e, t, {
                    transformPagePoint: r,
                    contextWindow: i,
                    dragSnapToOrigin: n = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let e = rp(this.lastMoveEventInfo, this.history),
                                t = null !== this.startEvent,
                                r = function(e, t) {
                                    return Math.sqrt(rh(e.x, t.x) ** 2 + rh(e.y, t.y) ** 2)
                                }(e.offset, {
                                    x: 0,
                                    y: 0
                                }) >= 3;
                            if (!t && !r) return;
                            let {
                                point: i
                            } = e, {
                                timestamp: n
                            } = k;
                            this.history.push({ ...i,
                                timestamp: n
                            });
                            let {
                                onStart: s,
                                onMove: o
                            } = this.handlers;
                            t || (s && s(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, e)
                        }, this.handlePointerMove = (e, t) => {
                            this.lastMoveEvent = e, this.lastMoveEventInfo = rc(t, this.transformPagePoint), V.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (e, t) => {
                            this.end();
                            let {
                                onEnd: r,
                                onSessionEnd: i,
                                resumeAnimation: n
                            } = this.handlers;
                            if (this.dragSnapToOrigin && n && n(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = rp("pointercancel" === e.type ? this.lastMoveEventInfo : rc(t, this.transformPagePoint), this.history);
                            this.startEvent && r && r(e, s), i && i(e, s)
                        }, !rs(e)) return;
                    this.dragSnapToOrigin = n, this.handlers = t, this.transformPagePoint = r, this.contextWindow = i || window;
                    let s = rc(ro(e), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = k;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = t;
                    l && l(e, rp(s, this.history)), this.removeListeners = tu(ru(this.contextWindow, "pointermove", this.handlePointerMove), ru(this.contextWindow, "pointerup", this.handlePointerUp), ru(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(e) {
                    this.handlers = e
                }
                end() {
                    this.removeListeners && this.removeListeners(), M(this.updatePoint)
                }
            }

            function rc(e, t) {
                return t ? {
                    point: t(e.point)
                } : e
            }

            function rf(e, t) {
                return {
                    x: e.x - t.x,
                    y: e.y - t.y
                }
            }

            function rp({
                point: e
            }, t) {
                return {
                    point: e,
                    delta: rf(e, rm(t)),
                    offset: rf(e, t[0]),
                    velocity: function(e, t) {
                        if (e.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let r = e.length - 1,
                            i = null,
                            n = rm(e);
                        for (; r >= 0 && (i = e[r], !(n.timestamp - i.timestamp > (0, g.w)(.1)));) r--;
                        if (!i) return {
                            x: 0,
                            y: 0
                        };
                        let s = (0, g.X)(n.timestamp - i.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (n.x - i.x) / s,
                            y: (n.y - i.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(t, 0)
                }
            }

            function rm(e) {
                return e[e.length - 1]
            }

            function rg(e) {
                let t = null;
                return () => null === t && (t = e, () => {
                    t = null
                })
            }
            let rv = rg("dragHorizontal"),
                ry = rg("dragVertical");

            function rx(e) {
                let t = !1;
                if ("y" === e) t = ry();
                else if ("x" === e) t = rv();
                else {
                    let e = rv(),
                        r = ry();
                    e && r ? t = () => {
                        e(), r()
                    } : (e && e(), r && r())
                }
                return t
            }

            function rb() {
                let e = rx(!0);
                return !e || (e(), !1)
            }

            function rS(e) {
                return e && "object" == typeof e && Object.prototype.hasOwnProperty.call(e, "current")
            }

            function rP(e) {
                return e.max - e.min
            }

            function rA(e, t, r, i = .5) {
                e.origin = i, e.originPoint = td(t.min, t.max, e.origin), e.scale = rP(r) / rP(t), e.translate = td(r.min, r.max, e.origin) - e.originPoint, (e.scale >= .9999 && e.scale <= 1.0001 || isNaN(e.scale)) && (e.scale = 1), (e.translate >= -.01 && e.translate <= .01 || isNaN(e.translate)) && (e.translate = 0)
            }

            function rw(e, t, r, i) {
                rA(e.x, t.x, r.x, i ? i.originX : void 0), rA(e.y, t.y, r.y, i ? i.originY : void 0)
            }

            function rE(e, t, r) {
                e.min = r.min + t.min, e.max = e.min + rP(t)
            }

            function r_(e, t, r) {
                e.min = t.min - r.min, e.max = e.min + rP(t)
            }

            function rT(e, t, r) {
                r_(e.x, t.x, r.x), r_(e.y, t.y, r.y)
            }

            function rR(e, t, r) {
                return {
                    min: void 0 !== t ? e.min + t : void 0,
                    max: void 0 !== r ? e.max + r - (e.max - e.min) : void 0
                }
            }

            function rC(e, t) {
                let r = t.min - e.min,
                    i = t.max - e.max;
                return t.max - t.min < e.max - e.min && ([r, i] = [i, r]), {
                    min: r,
                    max: i
                }
            }

            function rV(e, t, r) {
                return {
                    min: rM(e, t),
                    max: rM(e, r)
                }
            }

            function rM(e, t) {
                return "number" == typeof e ? e : e[t] || 0
            }
            let rk = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                rD = () => ({
                    x: rk(),
                    y: rk()
                }),
                rF = () => ({
                    min: 0,
                    max: 0
                }),
                rj = () => ({
                    x: rF(),
                    y: rF()
                });

            function rO(e) {
                return [e("x"), e("y")]
            }

            function rL({
                top: e,
                left: t,
                right: r,
                bottom: i
            }) {
                return {
                    x: {
                        min: t,
                        max: r
                    },
                    y: {
                        min: e,
                        max: i
                    }
                }
            }

            function rN(e) {
                return void 0 === e || 1 === e
            }

            function rI({
                scale: e,
                scaleX: t,
                scaleY: r
            }) {
                return !rN(e) || !rN(t) || !rN(r)
            }

            function rU(e) {
                return rI(e) || rB(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY
            }

            function rB(e) {
                var t, r;
                return (t = e.x) && "0%" !== t || (r = e.y) && "0%" !== r
            }

            function rW(e, t, r, i, n) {
                return void 0 !== n && (e = i + n * (e - i)), i + r * (e - i) + t
            }

            function r$(e, t = 0, r = 1, i, n) {
                e.min = rW(e.min, t, r, i, n), e.max = rW(e.max, t, r, i, n)
            }

            function rX(e, {
                x: t,
                y: r
            }) {
                r$(e.x, t.translate, t.scale, t.originPoint), r$(e.y, r.translate, r.scale, r.originPoint)
            }

            function rH(e, t) {
                e.min = e.min + t, e.max = e.max + t
            }

            function rG(e, t, r, i, n = .5) {
                let s = td(e.min, e.max, n);
                r$(e, t, r, s, i)
            }

            function rz(e, t) {
                rG(e.x, t.x, t.scaleX, t.scale, t.originX), rG(e.y, t.y, t.scaleY, t.scale, t.originY)
            }

            function rY(e, t) {
                return rL(function(e, t) {
                    if (!t) return e;
                    let r = t({
                            x: e.left,
                            y: e.top
                        }),
                        i = t({
                            x: e.right,
                            y: e.bottom
                        });
                    return {
                        top: r.y,
                        left: r.x,
                        bottom: i.y,
                        right: i.x
                    }
                }(e.getBoundingClientRect(), t))
            }
            let rK = ({
                    current: e
                }) => e ? e.ownerDocument.defaultView : null,
                rq = new WeakMap;
            class rZ {
                constructor(e) {
                    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = rj(), this.visualElement = e
                }
                start(e, {
                    snapToCursor: t = !1
                } = {}) {
                    let {
                        presenceContext: r
                    } = this.visualElement;
                    if (r && !1 === r.isPresent) return;
                    let {
                        dragSnapToOrigin: i
                    } = this.getProps();
                    this.panSession = new rd(e, {
                        onSessionStart: e => {
                            let {
                                dragSnapToOrigin: r
                            } = this.getProps();
                            r ? this.pauseAnimation() : this.stopAnimation(), t && this.snapToCursor(ro(e, "page").point)
                        },
                        onStart: (e, t) => {
                            var r;
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: s
                            } = this.getProps();
                            if (i && !n && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = rx(i), !this.openGlobalLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), rO(e => {
                                let t = this.getAxisMotionValue(e).get() || 0;
                                if (ee.test(t)) {
                                    let {
                                        projection: r
                                    } = this.visualElement;
                                    if (r && r.layout) {
                                        let i = r.layout.layoutBox[e];
                                        i && (t = rP(i) * (parseFloat(t) / 100))
                                    }
                                }
                                this.originPoint[e] = t
                            }), s && V.postRender(() => s(e, t)), null === (r = this.removeWillChange) || void 0 === r || r.call(this), this.removeWillChange = t5(this.visualElement, "transform");
                            let {
                                animationState: o
                            } = this.visualElement;
                            o && o.setActive("whileDrag", !0)
                        },
                        onMove: (e, t) => {
                            let {
                                dragPropagation: r,
                                dragDirectionLock: i,
                                onDirectionLock: n,
                                onDrag: s
                            } = this.getProps();
                            if (!r && !this.openGlobalLock) return;
                            let {
                                offset: o
                            } = t;
                            if (i && null === this.currentDirection) {
                                this.currentDirection = function(e, t = 10) {
                                    let r = null;
                                    return Math.abs(e.y) > t ? r = "y" : Math.abs(e.x) > t && (r = "x"), r
                                }(o), null !== this.currentDirection && n && n(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", t.point, o), this.updateAxis("y", t.point, o), this.visualElement.render(), s && s(e, t)
                        },
                        onSessionEnd: (e, t) => this.stop(e, t),
                        resumeAnimation: () => rO(e => {
                            var t;
                            return "paused" === this.getAnimationState(e) && (null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: i,
                        contextWindow: rK(this.visualElement)
                    })
                }
                stop(e, t) {
                    var r;
                    null === (r = this.removeWillChange) || void 0 === r || r.call(this);
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = t;
                    this.startAnimation(n);
                    let {
                        onDragEnd: s
                    } = this.getProps();
                    s && V.postRender(() => s(e, t))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: e,
                        animationState: t
                    } = this.visualElement;
                    e && (e.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: r
                    } = this.getProps();
                    !r && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), t && t.setActive("whileDrag", !1)
                }
                updateAxis(e, t, r) {
                    let {
                        drag: i
                    } = this.getProps();
                    if (!r || !rQ(e, i, this.currentDirection)) return;
                    let n = this.getAxisMotionValue(e),
                        s = this.originPoint[e] + r[e];
                    this.constraints && this.constraints[e] && (s = function(e, {
                        min: t,
                        max: r
                    }, i) {
                        return void 0 !== t && e < t ? e = i ? td(t, e, i.min) : Math.max(e, t) : void 0 !== r && e > r && (e = i ? td(r, e, i.max) : Math.min(e, r)), e
                    }(s, this.constraints[e], this.elastic[e])), n.set(s)
                }
                resolveConstraints() {
                    var e;
                    let {
                        dragConstraints: t,
                        dragElastic: r
                    } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (e = this.visualElement.projection) || void 0 === e ? void 0 : e.layout, n = this.constraints;
                    t && rS(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && i ? this.constraints = function(e, {
                        top: t,
                        left: r,
                        bottom: i,
                        right: n
                    }) {
                        return {
                            x: rR(e.x, r, n),
                            y: rR(e.y, t, i)
                        }
                    }(i.layoutBox, t) : this.constraints = !1, this.elastic = function(e = .35) {
                        return !1 === e ? e = 0 : !0 === e && (e = .35), {
                            x: rV(e, "left", "right"),
                            y: rV(e, "top", "bottom")
                        }
                    }(r), n !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && rO(e => {
                        !1 !== this.constraints && this.getAxisMotionValue(e) && (this.constraints[e] = function(e, t) {
                            let r = {};
                            return void 0 !== t.min && (r.min = t.min - e.min), void 0 !== t.max && (r.max = t.max - e.min), r
                        }(i.layoutBox[e], this.constraints[e]))
                    })
                }
                resolveRefConstraints() {
                    var e;
                    let {
                        dragConstraints: t,
                        onMeasureDragConstraints: r
                    } = this.getProps();
                    if (!t || !rS(t)) return !1;
                    let i = t.current;
                    (0, j.k)(null !== i, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: n
                    } = this.visualElement;
                    if (!n || !n.layout) return !1;
                    let s = function(e, t, r) {
                            let i = rY(e, r),
                                {
                                    scroll: n
                                } = t;
                            return n && (rH(i.x, n.offset.x), rH(i.y, n.offset.y)), i
                        }(i, n.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: rC((e = n.layout.layoutBox).x, s.x),
                            y: rC(e.y, s.y)
                        };
                    if (r) {
                        let e = r(function({
                            x: e,
                            y: t
                        }) {
                            return {
                                top: t.min,
                                right: e.max,
                                bottom: t.max,
                                left: e.min
                            }
                        }(o));
                        this.hasMutatedConstraints = !!e, e && (o = rL(e))
                    }
                    return o
                }
                startAnimation(e) {
                    let {
                        drag: t,
                        dragMomentum: r,
                        dragElastic: i,
                        dragTransition: n,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(rO(o => {
                        if (!rQ(o, t, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: r ? e[o] : 0,
                            bounceStiffness: i ? 200 : 1e6,
                            bounceDamping: i ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...n,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(e, t) {
                    let r = this.getAxisMotionValue(e);
                    return r.start(tB(e, r, 0, t, this.visualElement, !1, t5(this.visualElement, e)))
                }
                stopAnimation() {
                    rO(e => this.getAxisMotionValue(e).stop())
                }
                pauseAnimation() {
                    rO(e => {
                        var t;
                        return null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.pause()
                    })
                }
                getAnimationState(e) {
                    var t;
                    return null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.state
                }
                getAxisMotionValue(e) {
                    let t = `_drag${e.toUpperCase()}`,
                        r = this.visualElement.getProps();
                    return r[t] || this.visualElement.getValue(e, (r.initial ? r.initial[e] : void 0) || 0)
                }
                snapToCursor(e) {
                    rO(t => {
                        let {
                            drag: r
                        } = this.getProps();
                        if (!rQ(t, r, this.currentDirection)) return;
                        let {
                            projection: i
                        } = this.visualElement, n = this.getAxisMotionValue(t);
                        if (i && i.layout) {
                            let {
                                min: r,
                                max: s
                            } = i.layout.layoutBox[t];
                            n.set(e[t] - td(r, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: e,
                        dragConstraints: t
                    } = this.getProps(), {
                        projection: r
                    } = this.visualElement;
                    if (!rS(t) || !r || !this.constraints) return;
                    this.stopAnimation();
                    let i = {
                        x: 0,
                        y: 0
                    };
                    rO(e => {
                        let t = this.getAxisMotionValue(e);
                        if (t && !1 !== this.constraints) {
                            let r = t.get();
                            i[e] = function(e, t) {
                                let r = .5,
                                    i = rP(e),
                                    n = rP(t);
                                return n > i ? r = th(t.min, t.max - i, e.min) : i > n && (r = th(e.min, e.max - n, t.min)), (0, $.u)(0, 1, r)
                            }({
                                min: r,
                                max: r
                            }, this.constraints[e])
                        }
                    });
                    let {
                        transformTemplate: n
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = n ? n({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), rO(t => {
                        if (!rQ(t, e, null)) return;
                        let r = this.getAxisMotionValue(t),
                            {
                                min: n,
                                max: s
                            } = this.constraints[t];
                        r.set(td(n, s, i[t]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    rq.set(this.visualElement, this);
                    let e = ru(this.visualElement.current, "pointerdown", e => {
                            let {
                                drag: t,
                                dragListener: r = !0
                            } = this.getProps();
                            t && r && this.start(e)
                        }),
                        t = () => {
                            let {
                                dragConstraints: e
                            } = this.getProps();
                            rS(e) && e.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: r
                        } = this.visualElement,
                        i = r.addEventListener("measure", t);
                    r && !r.layout && (r.root && r.root.updateScroll(), r.updateLayout()), V.read(t);
                    let n = rl(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = r.addEventListener("didUpdate", ({
                            delta: e,
                            hasLayoutChanged: t
                        }) => {
                            this.isDragging && t && (rO(t => {
                                let r = this.getAxisMotionValue(t);
                                r && (this.originPoint[t] += e[t].translate, r.set(r.get() + e[t].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        n(), e(), i(), s && s()
                    }
                }
                getProps() {
                    let e = this.visualElement.getProps(),
                        {
                            drag: t = !1,
                            dragDirectionLock: r = !1,
                            dragPropagation: i = !1,
                            dragConstraints: n = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = e;
                    return { ...e,
                        drag: t,
                        dragDirectionLock: r,
                        dragPropagation: i,
                        dragConstraints: n,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function rQ(e, t, r) {
                return (!0 === t || t === e) && (null === r || r === e)
            }
            class rJ extends rt {
                constructor(e) {
                    super(e), this.removeGroupControls = T.Z, this.removeListeners = T.Z, this.controls = new rZ(e)
                }
                mount() {
                    let {
                        dragControls: e
                    } = this.node.getProps();
                    e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || T.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let r0 = e => (t, r) => {
                e && V.postRender(() => e(t, r))
            };
            class r1 extends rt {
                constructor() {
                    super(...arguments), this.removePointerDownListener = T.Z
                }
                onPointerDown(e) {
                    this.session = new rd(e, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: rK(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: e,
                        onPanStart: t,
                        onPan: r,
                        onPanEnd: i
                    } = this.node.getProps();
                    return {
                        onSessionStart: r0(e),
                        onStart: r0(t),
                        onMove: r,
                        onEnd: (e, t) => {
                            delete this.session, i && V.postRender(() => i(e, t))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = ru(this.node.current, "pointerdown", e => this.onPointerDown(e))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            var r2 = r(12428),
                r5 = r(93264),
                r3 = r(25479),
                r4 = r(59901);
            let r9 = (0, r5.createContext)({}),
                r7 = {
                    hasAnimatedSinceResize: !0,
                    hasEverUpdated: !1
                };

            function r6(e, t) {
                return t.max === t.min ? 0 : e / (t.max - t.min) * 100
            }
            let r8 = {
                    correct: (e, t) => {
                        if (!t.target) return e;
                        if ("string" == typeof e) {
                            if (!et.test(e)) return e;
                            e = parseFloat(e)
                        }
                        let r = r6(e, t.target.x),
                            i = r6(e, t.target.y);
                        return `${r}% ${i}%`
                    }
                },
                ie = {},
                {
                    schedule: it,
                    cancel: ir
                } = C(queueMicrotask, !1);
            class ii extends r5.Component {
                componentDidMount() {
                    let {
                        visualElement: e,
                        layoutGroup: t,
                        switchLayoutGroup: r,
                        layoutId: i
                    } = this.props, {
                        projection: n
                    } = e;
                    Object.assign(ie, io), n && (t.group && t.group.add(n), r && r.register && i && r.register(n), n.root.didUpdate(), n.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), n.setOptions({ ...n.options,
                        onExitComplete: () => this.safeToRemove()
                    })), r7.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(e) {
                    let {
                        layoutDependency: t,
                        visualElement: r,
                        drag: i,
                        isPresent: n
                    } = this.props, s = r.projection;
                    return s && (s.isPresent = n, i || e.layoutDependency !== t || void 0 === t ? s.willUpdate() : this.safeToRemove(), e.isPresent === n || (n ? s.promote() : s.relegate() || V.postRender(() => {
                        let e = s.getStack();
                        e && e.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: e
                    } = this.props.visualElement;
                    e && (e.root.didUpdate(), it.postRender(() => {
                        !e.currentAnimation && e.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: e,
                        layoutGroup: t,
                        switchLayoutGroup: r
                    } = this.props, {
                        projection: i
                    } = e;
                    i && (i.scheduleCheckAfterUnmount(), t && t.group && t.group.remove(i), r && r.deregister && r.deregister(i))
                }
                safeToRemove() {
                    let {
                        safeToRemove: e
                    } = this.props;
                    e && e()
                }
                render() {
                    return null
                }
            }

            function is(e) {
                let [t, r] = function() {
                    let e = (0, r5.useContext)(r3.O);
                    if (null === e) return [!0, null];
                    let {
                        isPresent: t,
                        onExitComplete: r,
                        register: i
                    } = e, n = (0, r5.useId)();
                    (0, r5.useEffect)(() => i(n), []);
                    let s = (0, r5.useCallback)(() => r && r(n), [n, r]);
                    return !t && r ? [!1, s] : [!0]
                }(), i = (0, r5.useContext)(r4.p);
                return (0, r2.jsx)(ii, { ...e,
                    layoutGroup: i,
                    switchLayoutGroup: (0, r5.useContext)(r9),
                    isPresent: t,
                    safeToRemove: r
                })
            }
            let io = {
                    borderRadius: { ...r8,
                        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                    },
                    borderTopLeftRadius: r8,
                    borderTopRightRadius: r8,
                    borderBottomLeftRadius: r8,
                    borderBottomRightRadius: r8,
                    boxShadow: {
                        correct: (e, {
                            treeScale: t,
                            projectionDelta: r
                        }) => {
                            let i = eO.parse(e);
                            if (i.length > 5) return e;
                            let n = eO.createTransformer(e),
                                s = "number" != typeof i[0] ? 1 : 0,
                                o = r.x.scale * t.x,
                                a = r.y.scale * t.y;
                            i[0 + s] /= o, i[1 + s] /= a;
                            let l = td(o, a, .5);
                            return "number" == typeof i[2 + s] && (i[2 + s] /= l), "number" == typeof i[3 + s] && (i[3 + s] /= l), n(i)
                        }
                    }
                },
                ia = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                il = ia.length,
                iu = e => "string" == typeof e ? parseFloat(e) : e,
                ih = e => "number" == typeof e || et.test(e);

            function id(e, t) {
                return void 0 !== e[t] ? e[t] : e.borderRadius
            }
            let ic = im(0, .5, tt),
                ip = im(.5, .95, T.Z);

            function im(e, t, r) {
                return i => i < e ? 0 : i > t ? 1 : r(th(e, t, i))
            }

            function ig(e, t) {
                e.min = t.min, e.max = t.max
            }

            function iv(e, t) {
                ig(e.x, t.x), ig(e.y, t.y)
            }

            function iy(e, t) {
                e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin
            }

            function ix(e, t, r, i, n) {
                return e -= t, e = i + 1 / r * (e - i), void 0 !== n && (e = i + 1 / n * (e - i)), e
            }

            function ib(e, t, [r, i, n], s, o) {
                ! function(e, t = 0, r = 1, i = .5, n, s = e, o = e) {
                    if (ee.test(t) && (t = parseFloat(t), t = td(o.min, o.max, t / 100) - o.min), "number" != typeof t) return;
                    let a = td(s.min, s.max, i);
                    e === s && (a -= t), e.min = ix(e.min, t, r, a, n), e.max = ix(e.max, t, r, a, n)
                }(e, t[r], t[i], t[n], t.scale, s, o)
            }
            let iS = ["x", "scaleX", "originX"],
                iP = ["y", "scaleY", "originY"];

            function iA(e, t, r, i) {
                ib(e.x, t, iS, r ? r.x : void 0, i ? i.x : void 0), ib(e.y, t, iP, r ? r.y : void 0, i ? i.y : void 0)
            }

            function iw(e) {
                return 0 === e.translate && 1 === e.scale
            }

            function iE(e) {
                return iw(e.x) && iw(e.y)
            }

            function i_(e, t) {
                return e.min === t.min && e.max === t.max
            }

            function iT(e, t) {
                return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max)
            }

            function iR(e, t) {
                return iT(e.x, t.x) && iT(e.y, t.y)
            }

            function iC(e) {
                return rP(e.x) / rP(e.y)
            }

            function iV(e, t) {
                return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint
            }
            class iM {
                constructor() {
                    this.members = []
                }
                add(e) {
                    tX(this.members, e), e.scheduleRender()
                }
                remove(e) {
                    if (tH(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
                        let e = this.members[this.members.length - 1];
                        e && this.promote(e)
                    }
                }
                relegate(e) {
                    let t;
                    let r = this.members.findIndex(t => e === t);
                    if (0 === r) return !1;
                    for (let e = r; e >= 0; e--) {
                        let r = this.members[e];
                        if (!1 !== r.isPresent) {
                            t = r;
                            break
                        }
                    }
                    return !!t && (this.promote(t), !0)
                }
                promote(e, t) {
                    let r = this.lead;
                    if (e !== r && (this.prevLead = r, this.lead = e, e.show(), r)) {
                        r.instance && r.scheduleRender(), e.scheduleRender(), e.resumeFrom = r, t && (e.resumeFrom.preserveOpacity = !0), r.snapshot && (e.snapshot = r.snapshot, e.snapshot.latestValues = r.animationValues || r.latestValues), e.root && e.root.isUpdating && (e.isLayoutDirty = !0);
                        let {
                            crossfade: i
                        } = e.options;
                        !1 === i && r.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(e => {
                        let {
                            options: t,
                            resumingFrom: r
                        } = e;
                        t.onExitComplete && t.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(e => {
                        e.instance && e.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            let ik = (e, t) => e.depth - t.depth;
            class iD {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(e) {
                    tX(this.children, e), this.isDirty = !0
                }
                remove(e) {
                    tH(this.children, e), this.isDirty = !0
                }
                forEach(e) {
                    this.isDirty && this.children.sort(ik), this.isDirty = !1, this.children.forEach(e)
                }
            }

            function iF(e) {
                let t = t2(e) ? e.get() : e;
                return tW(t) ? t.toValue() : t
            }
            let ij = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                iO = "undefined" != typeof window && void 0 !== window.MotionDebug,
                iL = ["", "X", "Y", "Z"],
                iN = {
                    visibility: "hidden"
                },
                iI = 0;

            function iU(e, t, r, i) {
                let {
                    latestValues: n
                } = t;
                n[e] && (r[e] = n[e], t.setStaticValue(e, 0), i && (i[e] = 0))
            }

            function iB({
                attachResizeListener: e,
                defaultParent: t,
                measureScroll: r,
                checkIsScrollRoot: i,
                resetTransform: n
            }) {
                return class {
                    constructor(e = {}, r = null == t ? void 0 : t()) {
                        this.id = iI++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, iO && (ij.totalNodes = ij.resolvedTargetDeltas = ij.recalculatedProjection = 0), this.nodes.forEach(iX), this.nodes.forEach(iZ), this.nodes.forEach(iQ), this.nodes.forEach(iH), iO && window.MotionDebug.record(ij)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = e, this.root = r ? r.root || r : this, this.path = r ? [...r.path, r] : [], this.parent = r, this.depth = r ? r.depth + 1 : 0;
                        for (let e = 0; e < this.path.length; e++) this.path[e].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new iD)
                    }
                    addEventListener(e, t) {
                        return this.eventHandlers.has(e) || this.eventHandlers.set(e, new tG), this.eventHandlers.get(e).add(t)
                    }
                    notifyListeners(e, ...t) {
                        let r = this.eventHandlers.get(e);
                        r && r.notify(...t)
                    }
                    hasListeners(e) {
                        return this.eventHandlers.has(e)
                    }
                    mount(t, r = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = t instanceof SVGElement && "svg" !== t.tagName, this.instance = t;
                        let {
                            layoutId: i,
                            layout: n,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(t), this.root.nodes.add(this), this.parent && this.parent.children.add(this), r && (n || i) && (this.isLayoutDirty = !0), e) {
                            let r;
                            let i = () => this.root.updateBlockedByResize = !1;
                            e(t, () => {
                                this.root.updateBlockedByResize = !0, r && r(), r = function(e, t) {
                                    let r = eq.now(),
                                        i = ({
                                            timestamp: t
                                        }) => {
                                            let n = t - r;
                                            n >= 250 && (M(i), e(n - 250))
                                        };
                                    return V.read(i, !0), () => M(i)
                                }(i, 0), r7.hasAnimatedSinceResize && (r7.hasAnimatedSinceResize = !1, this.nodes.forEach(iq))
                            })
                        }
                        i && this.root.registerSharedNode(i, this), !1 !== this.options.animate && s && (i || n) && this.addEventListener("didUpdate", ({
                            delta: e,
                            hasLayoutChanged: t,
                            hasRelativeTargetChanged: r,
                            layout: i
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let n = this.options.transition || s.getDefaultTransition() || i3,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !iR(this.targetLayout, i) || r,
                                u = !t && r;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || t && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(e, u);
                                let t = { ...P(n, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t)
                            } else t || iq(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = i
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let e = this.getStack();
                        e && e.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, M(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(iJ), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: e
                        } = this.options;
                        return e && e.getProps().transformTemplate
                    }
                    willUpdate(e = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function e(t) {
                                if (t.hasCheckedOptimisedAppear = !0, t.root === t) return;
                                let {
                                    visualElement: r
                                } = t.options;
                                if (!r) return;
                                let i = r.props[tJ];
                                if (window.MotionHasOptimisedAnimation(i, "transform")) {
                                    let {
                                        layout: e,
                                        layoutId: r
                                    } = t.options;
                                    window.MotionCancelOptimisedAnimation(i, "transform", V, !(e || r))
                                }
                                let {
                                    parent: n
                                } = t;
                                n && !n.hasCheckedOptimisedAppear && e(n)
                            }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let e = 0; e < this.path.length; e++) {
                            let t = this.path[e];
                            t.shouldResetTransform = !0, t.updateScroll("snapshot"), t.options.layoutRoot && t.willUpdate(!1)
                        }
                        let {
                            layoutId: t,
                            layout: r
                        } = this.options;
                        if (void 0 === t && !r) return;
                        let i = this.getTransformTemplate();
                        this.prevTransformTemplateValue = i ? i(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(iz);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(iY), this.isUpdating = !1, this.nodes.forEach(iK), this.nodes.forEach(iW), this.nodes.forEach(i$), this.clearAllSnapshots();
                        let e = eq.now();
                        k.delta = (0, $.u)(0, 1e3 / 60, e - k.timestamp), k.timestamp = e, k.isProcessing = !0, D.update.process(k), D.preRender.process(k), D.render.process(k), k.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, it.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(iG), this.sharedNodes.forEach(i0)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, V.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        V.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let e = 0; e < this.path.length; e++) this.path[e].updateScroll();
                        let e = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = rj(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: t
                        } = this.options;
                        t && t.notify("LayoutMeasure", this.layout.layoutBox, e ? e.layoutBox : void 0)
                    }
                    updateScroll(e = "measure") {
                        let t = !!(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === e && (t = !1), t) {
                            let t = i(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: e,
                                isRoot: t,
                                offset: r(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : t
                            }
                        }
                    }
                    resetTransform() {
                        if (!n) return;
                        let e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            t = this.projectionDelta && !iE(this.projectionDelta),
                            r = this.getTransformTemplate(),
                            i = r ? r(this.latestValues, "") : void 0,
                            s = i !== this.prevTransformTemplateValue;
                        e && (t || rU(this.latestValues) || s) && (n(this.instance, i), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(e = !0) {
                        var t;
                        let r = this.measurePageBox(),
                            i = this.removeElementScroll(r);
                        return e && (i = this.removeTransform(i)), i7((t = i).x), i7(t.y), {
                            animationId: this.root.animationId,
                            measuredBox: r,
                            layoutBox: i,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var e;
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return rj();
                        let r = t.measureViewportBox();
                        if (!((null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) || this.path.some(i8))) {
                            let {
                                scroll: e
                            } = this.root;
                            e && (rH(r.x, e.offset.x), rH(r.y, e.offset.y))
                        }
                        return r
                    }
                    removeElementScroll(e) {
                        var t;
                        let r = rj();
                        if (iv(r, e), null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) return r;
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t],
                                {
                                    scroll: n,
                                    options: s
                                } = i;
                            i !== this.root && n && s.layoutScroll && (n.wasRoot && iv(r, e), rH(r.x, n.offset.x), rH(r.y, n.offset.y))
                        }
                        return r
                    }
                    applyTransform(e, t = !1) {
                        let r = rj();
                        iv(r, e);
                        for (let e = 0; e < this.path.length; e++) {
                            let i = this.path[e];
                            !t && i.options.layoutScroll && i.scroll && i !== i.root && rz(r, {
                                x: -i.scroll.offset.x,
                                y: -i.scroll.offset.y
                            }), rU(i.latestValues) && rz(r, i.latestValues)
                        }
                        return rU(this.latestValues) && rz(r, this.latestValues), r
                    }
                    removeTransform(e) {
                        let t = rj();
                        iv(t, e);
                        for (let e = 0; e < this.path.length; e++) {
                            let r = this.path[e];
                            if (!r.instance || !rU(r.latestValues)) continue;
                            rI(r.latestValues) && r.updateSnapshot();
                            let i = rj();
                            iv(i, r.measurePageBox()), iA(t, r.latestValues, r.snapshot ? r.snapshot.layoutBox : void 0, i)
                        }
                        return rU(this.latestValues) && iA(t, this.latestValues), t
                    }
                    setTargetDelta(e) {
                        this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(e) {
                        this.options = { ...this.options,
                            ...e,
                            crossfade: void 0 === e.crossfade || e.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== k.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(e = !1) {
                        var t, r, i, n;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(e || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = k.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let e = this.getClosestProjectingParent();
                                e && e.layout && 1 !== this.animationProgress ? (this.relativeParent = e, this.forceRelativeParentToResolveTarget(), this.relativeTarget = rj(), this.relativeTargetOrigin = rj(), rT(this.relativeTargetOrigin, this.layout.layoutBox, e.layout.layoutBox), iv(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = rj(), this.targetWithTransforms = rj()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), r = this.target, i = this.relativeTarget, n = this.relativeParent.target, rE(r.x, i.x, n.x), rE(r.y, i.y, n.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : iv(this.target, this.layout.layoutBox), rX(this.target, this.targetDelta)) : iv(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let e = this.getClosestProjectingParent();
                                    e && !!e.resumingFrom == !!this.resumingFrom && !e.options.layoutScroll && e.target && 1 !== this.animationProgress ? (this.relativeParent = e, this.forceRelativeParentToResolveTarget(), this.relativeTarget = rj(), this.relativeTargetOrigin = rj(), rT(this.relativeTargetOrigin, this.target, e.target), iv(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                iO && ij.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || rI(this.parent.latestValues) || rB(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var e;
                        let t = this.getLead(),
                            r = !!this.resumingFrom || this !== t,
                            i = !0;
                        if ((this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty)) && (i = !1), r && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1), this.resolvedRelativeTargetAt === k.timestamp && (i = !1), i) return;
                        let {
                            layout: n,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(n || s)) return;
                        iv(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        ! function(e, t, r, i = !1) {
                            let n, s;
                            let o = r.length;
                            if (o) {
                                t.x = t.y = 1;
                                for (let a = 0; a < o; a++) {
                                    s = (n = r[a]).projectionDelta;
                                    let {
                                        visualElement: o
                                    } = n.options;
                                    (!o || !o.props.style || "contents" !== o.props.style.display) && (i && n.options.layoutScroll && n.scroll && n !== n.root && rz(e, {
                                        x: -n.scroll.offset.x,
                                        y: -n.scroll.offset.y
                                    }), s && (t.x *= s.x.scale, t.y *= s.y.scale, rX(e, s)), i && rU(n.latestValues) && rz(e, n.latestValues))
                                }
                                t.x < 1.0000000000001 && t.x > .999999999999 && (t.x = 1), t.y < 1.0000000000001 && t.y > .999999999999 && (t.y = 1)
                            }
                        }(this.layoutCorrected, this.treeScale, this.path, r), t.layout && !t.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (t.target = t.layout.layoutBox, t.targetWithTransforms = rj());
                        let {
                            target: l
                        } = t;
                        if (!l) {
                            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                            return
                        }
                        this.projectionDelta && this.prevProjectionDelta ? (iy(this.prevProjectionDelta.x, this.projectionDelta.x), iy(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), rw(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && iV(this.projectionDelta.x, this.prevProjectionDelta.x) && iV(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), iO && ij.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(e = !0) {
                        var t;
                        if (null === (t = this.options.visualElement) || void 0 === t || t.scheduleRender(), e) {
                            let e = this.getStack();
                            e && e.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = rD(), this.projectionDelta = rD(), this.projectionDeltaWithTransform = rD()
                    }
                    setAnimationOrigin(e, t = !1) {
                        let r;
                        let i = this.snapshot,
                            n = i ? i.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = rD();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
                        let a = rj(),
                            l = (i ? i.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            d = !!(l && !h && !0 === this.options.crossfade && !this.path.some(i5));
                        this.animationProgress = 0, this.mixTargetDelta = t => {
                            let i = t / 1e3;
                            if (i1(o.x, e.x, i), i1(o.y, e.y, i), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, c, f, p;
                                rT(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), f = this.relativeTarget, p = this.relativeTargetOrigin, i2(f.x, p.x, a.x, i), i2(f.y, p.y, a.y, i), r && (u = this.relativeTarget, c = r, i_(u.x, c.x) && i_(u.y, c.y)) && (this.isProjectionDirty = !1), r || (r = rj()), iv(r, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(e, t, r, i, n, s) {
                                n ? (e.opacity = td(0, void 0 !== r.opacity ? r.opacity : 1, ic(i)), e.opacityExit = td(void 0 !== t.opacity ? t.opacity : 1, 0, ip(i))) : s && (e.opacity = td(void 0 !== t.opacity ? t.opacity : 1, void 0 !== r.opacity ? r.opacity : 1, i));
                                for (let n = 0; n < il; n++) {
                                    let s = `border${ia[n]}Radius`,
                                        o = id(t, s),
                                        a = id(r, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || ih(o) === ih(a) ? (e[s] = Math.max(td(iu(o), iu(a), i), 0), (ee.test(a) || ee.test(o)) && (e[s] += "%")) : e[s] = a)
                                }(t.rotate || r.rotate) && (e.rotate = td(t.rotate || 0, r.rotate || 0, i))
                            }(s, n, this.latestValues, i, d, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = i
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(e) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (M(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = V.update(() => {
                            r7.hasAnimatedSinceResize = !0, this.currentAnimation = function(e, t, r) {
                                let i = t2(0) ? 0 : tZ(0);
                                return i.start(tB("", i, 1e3, r)), i.animation
                            }(0, 0, { ...e,
                                onUpdate: t => {
                                    this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t)
                                },
                                onComplete: () => {
                                    e.onComplete && e.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let e = this.getStack();
                        e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let e = this.getLead(),
                            {
                                targetWithTransforms: t,
                                target: r,
                                layout: i,
                                latestValues: n
                            } = e;
                        if (t && r && i) {
                            if (this !== e && this.layout && i && i6(this.options.animationType, this.layout.layoutBox, i.layoutBox)) {
                                r = this.target || rj();
                                let t = rP(this.layout.layoutBox.x);
                                r.x.min = e.target.x.min, r.x.max = r.x.min + t;
                                let i = rP(this.layout.layoutBox.y);
                                r.y.min = e.target.y.min, r.y.max = r.y.min + i
                            }
                            iv(t, r), rz(t, n), rw(this.projectionDeltaWithTransform, this.layoutCorrected, t, n)
                        }
                    }
                    registerSharedNode(e, t) {
                        this.sharedNodes.has(e) || this.sharedNodes.set(e, new iM), this.sharedNodes.get(e).add(t);
                        let r = t.options.initialPromotionConfig;
                        t.promote({
                            transition: r ? r.transition : void 0,
                            preserveFollowOpacity: r && r.shouldPreserveFollowOpacity ? r.shouldPreserveFollowOpacity(t) : void 0
                        })
                    }
                    isLead() {
                        let e = this.getStack();
                        return !e || e.lead === this
                    }
                    getLead() {
                        var e;
                        let {
                            layoutId: t
                        } = this.options;
                        return t && (null === (e = this.getStack()) || void 0 === e ? void 0 : e.lead) || this
                    }
                    getPrevLead() {
                        var e;
                        let {
                            layoutId: t
                        } = this.options;
                        return t ? null === (e = this.getStack()) || void 0 === e ? void 0 : e.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: e
                        } = this.options;
                        if (e) return this.root.sharedNodes.get(e)
                    }
                    promote({
                        needsReset: e,
                        transition: t,
                        preserveFollowOpacity: r
                    } = {}) {
                        let i = this.getStack();
                        i && i.promote(this, r), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({
                            transition: t
                        })
                    }
                    relegate() {
                        let e = this.getStack();
                        return !!e && e.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: e
                        } = this.options;
                        if (!e) return;
                        let t = !1,
                            {
                                latestValues: r
                            } = e;
                        if ((r.z || r.rotate || r.rotateX || r.rotateY || r.rotateZ || r.skewX || r.skewY) && (t = !0), !t) return;
                        let i = {};
                        r.z && iU("z", e, i, this.animationValues);
                        for (let t = 0; t < iL.length; t++) iU(`rotate${iL[t]}`, e, i, this.animationValues), iU(`skew${iL[t]}`, e, i, this.animationValues);
                        for (let t in e.render(), i) e.setStaticValue(t, i[t]), this.animationValues && (this.animationValues[t] = i[t]);
                        e.scheduleRender()
                    }
                    getProjectionStyles(e) {
                        var t, r;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return iN;
                        let i = {
                                visibility: ""
                            },
                            n = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, i.opacity = "", i.pointerEvents = iF(null == e ? void 0 : e.pointerEvents) || "", i.transform = n ? n(this.latestValues, "") : "none", i;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let t = {};
                            return this.options.layoutId && (t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, t.pointerEvents = iF(null == e ? void 0 : e.pointerEvents) || ""), this.hasProjected && !rU(this.latestValues) && (t.transform = n ? n({}, "") : "none", this.hasProjected = !1), t
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), i.transform = function(e, t, r) {
                            let i = "",
                                n = e.x.translate / t.x,
                                s = e.y.translate / t.y,
                                o = (null == r ? void 0 : r.z) || 0;
                            if ((n || s || o) && (i = `translate3d(${n}px, ${s}px, ${o}px) `), (1 !== t.x || 1 !== t.y) && (i += `scale(${1/t.x}, ${1/t.y}) `), r) {
                                let {
                                    transformPerspective: e,
                                    rotate: t,
                                    rotateX: n,
                                    rotateY: s,
                                    skewX: o,
                                    skewY: a
                                } = r;
                                e && (i = `perspective(${e}px) ${i}`), t && (i += `rotate(${t}deg) `), n && (i += `rotateX(${n}deg) `), s && (i += `rotateY(${s}deg) `), o && (i += `skewX(${o}deg) `), a && (i += `skewY(${a}deg) `)
                            }
                            let a = e.x.scale * t.x,
                                l = e.y.scale * t.y;
                            return (1 !== a || 1 !== l) && (i += `scale(${a}, ${l})`), i || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, o), n && (i.transform = n(o, i.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let e in i.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? i.opacity = s === this ? null !== (r = null !== (t = o.opacity) && void 0 !== t ? t : this.latestValues.opacity) && void 0 !== r ? r : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : i.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, ie) {
                            if (void 0 === o[e]) continue;
                            let {
                                correct: t,
                                applyTo: r
                            } = ie[e], n = "none" === i.transform ? o[e] : t(o[e], s);
                            if (r) {
                                let e = r.length;
                                for (let t = 0; t < e; t++) i[r[t]] = n
                            } else i[e] = n
                        }
                        return this.options.layoutId && (i.pointerEvents = s === this ? iF(null == e ? void 0 : e.pointerEvents) || "" : "none"), i
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(e => {
                            var t;
                            return null === (t = e.currentAnimation) || void 0 === t ? void 0 : t.stop()
                        }), this.root.nodes.forEach(iz), this.root.sharedNodes.clear()
                    }
                }
            }

            function iW(e) {
                e.updateLayout()
            }

            function i$(e) {
                var t;
                let r = (null === (t = e.resumeFrom) || void 0 === t ? void 0 : t.snapshot) || e.snapshot;
                if (e.isLead() && e.layout && r && e.hasListeners("didUpdate")) {
                    let {
                        layoutBox: t,
                        measuredBox: i
                    } = e.layout, {
                        animationType: n
                    } = e.options, s = r.source !== e.layout.source;
                    "size" === n ? rO(e => {
                        let i = s ? r.measuredBox[e] : r.layoutBox[e],
                            n = rP(i);
                        i.min = t[e].min, i.max = i.min + n
                    }) : i6(n, r.layoutBox, t) && rO(i => {
                        let n = s ? r.measuredBox[i] : r.layoutBox[i],
                            o = rP(t[i]);
                        n.max = n.min + o, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[i].max = e.relativeTarget[i].min + o)
                    });
                    let o = rD();
                    rw(o, t, r.layoutBox);
                    let a = rD();
                    s ? rw(a, e.applyTransform(i, !0), r.measuredBox) : rw(a, t, r.layoutBox);
                    let l = !iE(o),
                        u = !1;
                    if (!e.resumeFrom) {
                        let i = e.getClosestProjectingParent();
                        if (i && !i.resumeFrom) {
                            let {
                                snapshot: n,
                                layout: s
                            } = i;
                            if (n && s) {
                                let o = rj();
                                rT(o, r.layoutBox, n.layoutBox);
                                let a = rj();
                                rT(a, t, s.layoutBox), iR(o, a) || (u = !0), i.options.layoutRoot && (e.relativeTarget = a, e.relativeTargetOrigin = o, e.relativeParent = i)
                            }
                        }
                    }
                    e.notifyListeners("didUpdate", {
                        layout: t,
                        snapshot: r,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (e.isLead()) {
                    let {
                        onExitComplete: t
                    } = e.options;
                    t && t()
                }
                e.options.transition = void 0
            }

            function iX(e) {
                iO && ij.totalNodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty))
            }

            function iH(e) {
                e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1
            }

            function iG(e) {
                e.clearSnapshot()
            }

            function iz(e) {
                e.clearMeasurements()
            }

            function iY(e) {
                e.isLayoutDirty = !1
            }

            function iK(e) {
                let {
                    visualElement: t
                } = e.options;
                t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform()
            }

            function iq(e) {
                e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0
            }

            function iZ(e) {
                e.resolveTargetDelta()
            }

            function iQ(e) {
                e.calcProjection()
            }

            function iJ(e) {
                e.resetSkewAndRotation()
            }

            function i0(e) {
                e.removeLeadSnapshot()
            }

            function i1(e, t, r) {
                e.translate = td(t.translate, 0, r), e.scale = td(t.scale, 1, r), e.origin = t.origin, e.originPoint = t.originPoint
            }

            function i2(e, t, r, i) {
                e.min = td(t.min, r.min, i), e.max = td(t.max, r.max, i)
            }

            function i5(e) {
                return e.animationValues && void 0 !== e.animationValues.opacityExit
            }
            let i3 = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                i4 = e => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e),
                i9 = i4("applewebkit/") && !i4("chrome/") ? Math.round : T.Z;

            function i7(e) {
                e.min = i9(e.min), e.max = i9(e.max)
            }

            function i6(e, t, r) {
                return "position" === e || "preserve-aspect" === e && !(.2 >= Math.abs(iC(t) - iC(r)))
            }

            function i8(e) {
                var t;
                return e !== e.root && (null === (t = e.scroll) || void 0 === t ? void 0 : t.wasRoot)
            }
            let ne = iB({
                    attachResizeListener: (e, t) => rl(e, "resize", t),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                nt = {
                    current: void 0
                },
                nr = iB({
                    measureScroll: e => ({
                        x: e.scrollLeft,
                        y: e.scrollTop
                    }),
                    defaultParent: () => {
                        if (!nt.current) {
                            let e = new ne({});
                            e.mount(window), e.setOptions({
                                layoutScroll: !0
                            }), nt.current = e
                        }
                        return nt.current
                    },
                    resetTransform: (e, t) => {
                        e.style.transform = void 0 !== t ? t : "none"
                    },
                    checkIsScrollRoot: e => "fixed" === window.getComputedStyle(e).position
                });

            function ni(e, t) {
                let r = t ? "onHoverStart" : "onHoverEnd";
                return ru(e.current, t ? "pointerenter" : "pointerleave", (i, n) => {
                    if ("touch" === i.pointerType || rb()) return;
                    let s = e.getProps();
                    e.animationState && s.whileHover && e.animationState.setActive("whileHover", t);
                    let o = s[r];
                    o && V.postRender(() => o(i, n))
                }, {
                    passive: !e.getProps()[r]
                })
            }
            class nn extends rt {
                mount() {
                    this.unmount = tu(ni(this.node, !0), ni(this.node, !1))
                }
                unmount() {}
            }
            class ns extends rt {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let e = !1;
                    try {
                        e = this.node.current.matches(":focus-visible")
                    } catch (t) {
                        e = !0
                    }
                    e && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = tu(rl(this.node.current, "focus", () => this.onFocus()), rl(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            let no = (e, t) => !!t && (e === t || no(e, t.parentElement));

            function na(e, t) {
                if (!t) return;
                let r = new PointerEvent("pointer" + e);
                t(r, ro(r))
            }
            class nl extends rt {
                constructor() {
                    super(...arguments), this.removeStartListeners = T.Z, this.removeEndListeners = T.Z, this.removeAccessibleListeners = T.Z, this.startPointerPress = (e, t) => {
                        if (this.isPressing) return;
                        this.removeEndListeners();
                        let r = this.node.getProps(),
                            i = ru(window, "pointerup", (e, t) => {
                                if (!this.checkPressEnd()) return;
                                let {
                                    onTap: r,
                                    onTapCancel: i,
                                    globalTapTarget: n
                                } = this.node.getProps(), s = n || no(this.node.current, e.target) ? r : i;
                                s && V.update(() => s(e, t))
                            }, {
                                passive: !(r.onTap || r.onPointerUp)
                            }),
                            n = ru(window, "pointercancel", (e, t) => this.cancelPress(e, t), {
                                passive: !(r.onTapCancel || r.onPointerCancel)
                            });
                        this.removeEndListeners = tu(i, n), this.startPress(e, t)
                    }, this.startAccessiblePress = () => {
                        let e = rl(this.node.current, "keydown", e => {
                                "Enter" !== e.key || this.isPressing || (this.removeEndListeners(), this.removeEndListeners = rl(this.node.current, "keyup", e => {
                                    "Enter" === e.key && this.checkPressEnd() && na("up", (e, t) => {
                                        let {
                                            onTap: r
                                        } = this.node.getProps();
                                        r && V.postRender(() => r(e, t))
                                    })
                                }), na("down", (e, t) => {
                                    this.startPress(e, t)
                                }))
                            }),
                            t = rl(this.node.current, "blur", () => {
                                this.isPressing && na("cancel", (e, t) => this.cancelPress(e, t))
                            });
                        this.removeAccessibleListeners = tu(e, t)
                    }
                }
                startPress(e, t) {
                    this.isPressing = !0;
                    let {
                        onTapStart: r,
                        whileTap: i
                    } = this.node.getProps();
                    i && this.node.animationState && this.node.animationState.setActive("whileTap", !0), r && V.postRender(() => r(e, t))
                }
                checkPressEnd() {
                    return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !rb()
                }
                cancelPress(e, t) {
                    if (!this.checkPressEnd()) return;
                    let {
                        onTapCancel: r
                    } = this.node.getProps();
                    r && V.postRender(() => r(e, t))
                }
                mount() {
                    let e = this.node.getProps(),
                        t = ru(e.globalTapTarget ? window : this.node.current, "pointerdown", this.startPointerPress, {
                            passive: !(e.onTapStart || e.onPointerStart)
                        }),
                        r = rl(this.node.current, "focus", this.startAccessiblePress);
                    this.removeStartListeners = tu(t, r)
                }
                unmount() {
                    this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners()
                }
            }
            let nu = new WeakMap,
                nh = new WeakMap,
                nd = e => {
                    let t = nu.get(e.target);
                    t && t(e)
                },
                nc = e => {
                    e.forEach(nd)
                },
                nf = {
                    some: 0,
                    all: 1
                };
            class np extends rt {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: e = {}
                    } = this.node.getProps(), {
                        root: t,
                        margin: r,
                        amount: i = "some",
                        once: n
                    } = e, s = {
                        root: t ? t.current : void 0,
                        rootMargin: r,
                        threshold: "number" == typeof i ? i : nf[i]
                    };
                    return function(e, t, r) {
                        let i = function({
                            root: e,
                            ...t
                        }) {
                            let r = e || document;
                            nh.has(r) || nh.set(r, {});
                            let i = nh.get(r),
                                n = JSON.stringify(t);
                            return i[n] || (i[n] = new IntersectionObserver(nc, {
                                root: e,
                                ...t
                            })), i[n]
                        }(t);
                        return nu.set(e, r), i.observe(e), () => {
                            nu.delete(e), i.unobserve(e)
                        }
                    }(this.node.current, s, e => {
                        let {
                            isIntersecting: t
                        } = e;
                        if (this.isInView === t || (this.isInView = t, n && !t && this.hasEnteredView)) return;
                        t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
                        let {
                            onViewportEnter: r,
                            onViewportLeave: i
                        } = this.node.getProps(), s = t ? r : i;
                        s && s(e)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: e,
                        prevProps: t
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: e = {}
                    }, {
                        viewport: t = {}
                    } = {}) {
                        return r => e[r] !== t[r]
                    }(e, t)) && this.startObserver()
                }
                unmount() {}
            }
            var nm = r(85714);
            let ng = (0, r5.createContext)({});
            var nv = r(82821);
            let ny = (0, r5.createContext)({
                    strict: !1
                }),
                nx = !1;

            function nb() {
                window.MotionHandoffIsComplete = !0
            }

            function nS(e) {
                return n(e.animate) || d.some(t => a(e[t]))
            }

            function nP(e) {
                return !!(nS(e) || e.variants)
            }

            function nA(e) {
                return Array.isArray(e) ? e.join(" ") : e
            }
            let nw = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                nE = {};
            for (let e in nw) nE[e] = {
                isEnabled: t => nw[e].some(e => !!t[e])
            };
            var n_ = r(87314);
            let nT = Symbol.for("motionComponentSymbol"),
                nR = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function nC(e) {
                if ("string" != typeof e || e.includes("-"));
                else if (nR.indexOf(e) > -1 || /[A-Z]/u.test(e)) return !0;
                return !1
            }

            function nV(e, {
                style: t,
                vars: r
            }, i, n) {
                for (let s in Object.assign(e.style, t, n && n.getProjectionStyles(i)), r) e.style.setProperty(s, r[s])
            }
            let nM = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

            function nk(e, t, r, i) {
                for (let r in nV(e, t, void 0, i), t.attrs) e.setAttribute(nM.has(r) ? r : tQ(r), t.attrs[r])
            }

            function nD(e, {
                layout: t,
                layoutId: r
            }) {
                return f.has(e) || e.startsWith("origin") || (t || void 0 !== r) && (!!ie[e] || "opacity" === e)
            }

            function nF(e, t, r) {
                var i;
                let {
                    style: n
                } = e, s = {};
                for (let o in n)(t2(n[o]) || t.style && t2(t.style[o]) || nD(o, e) || (null === (i = null == r ? void 0 : r.getValue(o)) || void 0 === i ? void 0 : i.liveStyle) !== void 0) && (s[o] = n[o]);
                return r && n && "string" == typeof n.willChange && (r.applyWillChange = !1), s
            }

            function nj(e, t, r) {
                let i = nF(e, t, r);
                for (let r in e)(t2(e[r]) || t2(t[r])) && (i[-1 !== c.indexOf(r) ? "attr" + r.charAt(0).toUpperCase() + r.substring(1) : r] = e[r]);
                return i
            }
            var nO = r(44276);
            let nL = e => (t, r) => {
                let i = (0, r5.useContext)(ng),
                    s = (0, r5.useContext)(r3.O),
                    o = () => (function({
                        applyWillChange: e = !1,
                        scrapeMotionValuesFromProps: t,
                        createRenderState: r,
                        onMount: i
                    }, s, o, a, l) {
                        let u = {
                            latestValues: function(e, t, r, i, s) {
                                var o;
                                let a = {},
                                    l = [],
                                    u = i && (null === (o = e.style) || void 0 === o ? void 0 : o.willChange) === void 0,
                                    h = s(e, {});
                                for (let e in h) a[e] = iF(h[e]);
                                let {
                                    initial: d,
                                    animate: c
                                } = e, f = nS(e), p = nP(e);
                                t && p && !f && !1 !== e.inherit && (void 0 === d && (d = t.initial), void 0 === c && (c = t.animate));
                                let m = !!r && !1 === r.initial,
                                    g = (m = m || !1 === d) ? c : d;
                                return g && "boolean" != typeof g && !n(g) && nN(e, g, (e, t) => {
                                    for (let t in e) {
                                        let r = e[t];
                                        if (Array.isArray(r)) {
                                            let e = m ? r.length - 1 : 0;
                                            r = r[e]
                                        }
                                        null !== r && (a[t] = r)
                                    }
                                    for (let e in t) a[e] = t[e]
                                }), u && (c && !1 !== d && !n(c) && nN(e, c, e => {
                                    for (let t in e) ! function(e, t) {
                                        let r = t0(t);
                                        r && tX(e, r)
                                    }(l, t)
                                }), l.length && (a.willChange = l.join(","))), a
                            }(s, o, a, !l && e, t),
                            renderState: r()
                        };
                        return i && (u.mount = e => i(s, e, u)), u
                    })(e, t, i, s, r);
                return r ? o() : (0, nO.h)(o)
            };

            function nN(e, t, r) {
                let i = Array.isArray(t) ? t : [t];
                for (let t = 0; t < i.length; t++) {
                    let n = l(e, i[t]);
                    if (n) {
                        let {
                            transitionEnd: e,
                            transition: t,
                            ...i
                        } = n;
                        r(i, e)
                    }
                }
            }
            let nI = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {}
                }),
                nU = () => ({ ...nI(),
                    attrs: {}
                }),
                nB = (e, t) => t && "number" == typeof e ? t.transform(e) : e,
                nW = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                n$ = c.length;

            function nX(e, t, r) {
                let {
                    style: i,
                    vars: n,
                    transformOrigin: s
                } = e, o = !1, a = !1;
                for (let e in t) {
                    let r = t[e];
                    if (f.has(e)) {
                        o = !0;
                        continue
                    }
                    if (N(e)) {
                        n[e] = r;
                        continue
                    } {
                        let t = nB(r, eW[e]);
                        e.startsWith("origin") ? (a = !0, s[e] = t) : i[e] = t
                    }
                }
                if (!t.transform && (o || r ? i.transform = function(e, t, r) {
                        let i = "",
                            n = !0;
                        for (let s = 0; s < n$; s++) {
                            let o = c[s],
                                a = e[o];
                            if (void 0 === a) continue;
                            let l = !0;
                            if (!(l = "number" == typeof a ? a === (o.startsWith("scale") ? 1 : 0) : 0 === parseFloat(a)) || r) {
                                let e = nB(a, eW[o]);
                                if (!l) {
                                    n = !1;
                                    let t = nW[o] || o;
                                    i += `${t}(${e}) `
                                }
                                r && (t[o] = e)
                            }
                        }
                        return i = i.trim(), r ? i = r(t, n ? "" : i) : n && (i = "none"), i
                    }(t, e.transform, r) : i.transform && (i.transform = "none")), a) {
                    let {
                        originX: e = "50%",
                        originY: t = "50%",
                        originZ: r = 0
                    } = s;
                    i.transformOrigin = `${e} ${t} ${r}`
                }
            }

            function nH(e, t, r) {
                return "string" == typeof e ? e : et.transform(t + r * e)
            }
            let nG = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                nz = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function nY(e, {
                attrX: t,
                attrY: r,
                attrScale: i,
                originX: n,
                originY: s,
                pathLength: o,
                pathSpacing: a = 1,
                pathOffset: l = 0,
                ...u
            }, h, d) {
                if (nX(e, u, d), h) {
                    e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
                    return
                }
                e.attrs = e.style, e.style = {};
                let {
                    attrs: c,
                    style: f,
                    dimensions: p
                } = e;
                c.transform && (p && (f.transform = c.transform), delete c.transform), p && (void 0 !== n || void 0 !== s || f.transform) && (f.transformOrigin = function(e, t, r) {
                    let i = nH(t, e.x, e.width),
                        n = nH(r, e.y, e.height);
                    return `${i} ${n}`
                }(p, void 0 !== n ? n : .5, void 0 !== s ? s : .5)), void 0 !== t && (c.x = t), void 0 !== r && (c.y = r), void 0 !== i && (c.scale = i), void 0 !== o && function(e, t, r = 1, i = 0, n = !0) {
                    e.pathLength = 1;
                    let s = n ? nG : nz;
                    e[s.offset] = et.transform(-i);
                    let o = et.transform(t),
                        a = et.transform(r);
                    e[s.array] = `${o} ${a}`
                }(c, o, a, l, !1)
            }
            let nK = e => "string" == typeof e && "svg" === e.toLowerCase(),
                nq = {
                    useVisualState: nL({
                        scrapeMotionValuesFromProps: nj,
                        createRenderState: nU,
                        onMount: (e, t, {
                            renderState: r,
                            latestValues: i
                        }) => {
                            V.read(() => {
                                try {
                                    r.dimensions = "function" == typeof t.getBBox ? t.getBBox() : t.getBoundingClientRect()
                                } catch (e) {
                                    r.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), V.render(() => {
                                nY(r, i, nK(t.tagName), e.transformTemplate), nk(t, r)
                            })
                        }
                    })
                },
                nZ = {
                    useVisualState: nL({
                        applyWillChange: !0,
                        scrapeMotionValuesFromProps: nF,
                        createRenderState: nI
                    })
                };

            function nQ(e, t, r) {
                for (let i in t) t2(t[i]) || nD(i, r) || (e[i] = t[i])
            }
            let nJ = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function n0(e) {
                return e.startsWith("while") || e.startsWith("drag") && "draggable" !== e || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || nJ.has(e)
            }
            let n1 = e => !n0(e);
            try {
                ! function(e) {
                    e && (n1 = t => t.startsWith("on") ? !n0(t) : e(t))
                }(require("@emotion/is-prop-valid").default)
            } catch (e) {}
            let n2 = {
                    current: null
                },
                n5 = {
                    current: !1
                },
                n3 = new WeakMap,
                n4 = [...ef, eR, eO],
                n9 = e => n4.find(ec(e)),
                n7 = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
                n6 = d.length;
            class n8 {
                scrapeMotionValuesFromProps(e, t, r) {
                    return {}
                }
                constructor({
                    parent: e,
                    props: t,
                    presenceContext: r,
                    reducedMotionConfig: i,
                    blockInitialAnimation: n,
                    visualState: s
                }, o = {}) {
                    this.applyWillChange = !1, this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = eb, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.isRenderScheduled = !1, this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.isRenderScheduled = !1, this.scheduleRender = () => {
                        this.isRenderScheduled || (this.isRenderScheduled = !0, V.render(this.render, !1, !0))
                    };
                    let {
                        latestValues: a,
                        renderState: l
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = t.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = e, this.props = t, this.presenceContext = r, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = i, this.options = o, this.blockInitialAnimation = !!n, this.isControllingVariants = nS(t), this.isVariantNode = nP(t), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(e && e.current);
                    let {
                        willChange: u,
                        ...h
                    } = this.scrapeMotionValuesFromProps(t, {}, this);
                    for (let e in h) {
                        let t = h[e];
                        void 0 !== a[e] && t2(t) && t.set(a[e], !1)
                    }
                }
                mount(e) {
                    this.current = e, n3.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((e, t) => this.bindToMotionValue(t, e)), n5.current || function() {
                        if (n5.current = !0, n_.j) {
                            if (window.matchMedia) {
                                let e = window.matchMedia("(prefers-reduced-motion)"),
                                    t = () => n2.current = e.matches;
                                e.addListener(t), t()
                            } else n2.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || n2.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    for (let e in n3.delete(this.current), this.projection && this.projection.unmount(), M(this.notifyUpdate), M(this.render), this.valueSubscriptions.forEach(e => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[e].clear();
                    for (let e in this.features) {
                        let t = this.features[e];
                        t && (t.unmount(), t.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(e, t) {
                    let r;
                    this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
                    let i = f.has(e),
                        n = t.on("change", t => {
                            this.latestValues[e] = t, this.props.onUpdate && V.preRender(this.notifyUpdate), i && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        s = t.on("renderRequest", this.scheduleRender);
                    window.MotionCheckAppearSync && (r = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, () => {
                        n(), s(), r && r(), t.owner && t.stop()
                    })
                }
                sortNodePosition(e) {
                    return this.current && this.sortInstanceNodePosition && this.type === e.type ? this.sortInstanceNodePosition(this.current, e.current) : 0
                }
                updateFeatures() {
                    let e = "animation";
                    for (e in nE) {
                        let t = nE[e];
                        if (!t) continue;
                        let {
                            isEnabled: r,
                            Feature: i
                        } = t;
                        if (!this.features[e] && i && r(this.props) && (this.features[e] = new i(this)), this.features[e]) {
                            let t = this.features[e];
                            t.isMounted ? t.update() : (t.mount(), t.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : rj()
                }
                getStaticValue(e) {
                    return this.latestValues[e]
                }
                setStaticValue(e, t) {
                    this.latestValues[e] = t
                }
                update(e, t) {
                    (e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
                    for (let t = 0; t < n7.length; t++) {
                        let r = n7[t];
                        this.propEventSubscriptions[r] && (this.propEventSubscriptions[r](), delete this.propEventSubscriptions[r]);
                        let i = e["on" + r];
                        i && (this.propEventSubscriptions[r] = this.on(r, i))
                    }
                    this.prevMotionValues = function(e, t, r) {
                        for (let i in t) {
                            let n = t[i],
                                s = r[i];
                            if (t2(n)) e.addValue(i, n);
                            else if (t2(s)) e.addValue(i, tZ(n, {
                                owner: e
                            }));
                            else if (s !== n) {
                                if (e.hasValue(i)) {
                                    let t = e.getValue(i);
                                    !0 === t.liveStyle ? t.jump(n) : t.hasAnimated || t.set(n)
                                } else {
                                    let t = e.getStaticValue(i);
                                    e.addValue(i, tZ(void 0 !== t ? t : n, {
                                        owner: e
                                    }))
                                }
                            }
                        }
                        for (let i in r) void 0 === t[i] && e.removeValue(i);
                        return t
                    }(this, this.scrapeMotionValuesFromProps(e, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(e) {
                    return this.props.variants ? this.props.variants[e] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                getVariantContext(e = !1) {
                    if (e) return this.parent ? this.parent.getVariantContext() : void 0;
                    if (!this.isControllingVariants) {
                        let e = this.parent && this.parent.getVariantContext() || {};
                        return void 0 !== this.props.initial && (e.initial = this.props.initial), e
                    }
                    let t = {};
                    for (let e = 0; e < n6; e++) {
                        let r = d[e],
                            i = this.props[r];
                        (a(i) || !1 === i) && (t[r] = i)
                    }
                    return t
                }
                addVariantChild(e) {
                    let t = this.getClosestVariantNode();
                    if (t) return t.variantChildren && t.variantChildren.add(e), () => t.variantChildren.delete(e)
                }
                addValue(e, t) {
                    let r = this.values.get(e);
                    t !== r && (r && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t), this.latestValues[e] = t.get())
                }
                removeValue(e) {
                    this.values.delete(e);
                    let t = this.valueSubscriptions.get(e);
                    t && (t(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState)
                }
                hasValue(e) {
                    return this.values.has(e)
                }
                getValue(e, t) {
                    if (this.props.values && this.props.values[e]) return this.props.values[e];
                    let r = this.values.get(e);
                    return void 0 === r && void 0 !== t && (r = tZ(null === t ? void 0 : t, {
                        owner: this
                    }), this.addValue(e, r)), r
                }
                readValue(e, t) {
                    var r;
                    let i = void 0 === this.latestValues[e] && this.current ? null !== (r = this.getBaseTargetFromProps(this.props, e)) && void 0 !== r ? r : this.readValueFromInstance(this.current, e, this.options) : this.latestValues[e];
                    return null != i && ("string" == typeof i && (O(i) || F(i)) ? i = parseFloat(i) : !n9(i) && eO.test(t) && (i = eH(e, t)), this.setBaseTarget(e, t2(i) ? i.get() : i)), t2(i) ? i.get() : i
                }
                setBaseTarget(e, t) {
                    this.baseTarget[e] = t
                }
                getBaseTarget(e) {
                    var t;
                    let r;
                    let {
                        initial: i
                    } = this.props;
                    if ("string" == typeof i || "object" == typeof i) {
                        let n = l(this.props, i, null === (t = this.presenceContext) || void 0 === t ? void 0 : t.custom);
                        n && (r = n[e])
                    }
                    if (i && void 0 !== r) return r;
                    let n = this.getBaseTargetFromProps(this.props, e);
                    return void 0 === n || t2(n) ? void 0 !== this.initialValues[e] && void 0 === r ? void 0 : this.baseTarget[e] : n
                }
                on(e, t) {
                    return this.events[e] || (this.events[e] = new tG), this.events[e].add(t)
                }
                notify(e, ...t) {
                    this.events[e] && this.events[e].notify(...t)
                }
            }
            class se extends n8 {
                constructor() {
                    super(...arguments), this.KeyframeResolver = ez
                }
                sortInstanceNodePosition(e, t) {
                    return 2 & e.compareDocumentPosition(t) ? 1 : -1
                }
                getBaseTargetFromProps(e, t) {
                    return e.style ? e.style[t] : void 0
                }
                removeValueFromRenderState(e, {
                    vars: t,
                    style: r
                }) {
                    delete t[e], delete r[e]
                }
            }
            class st extends se {
                constructor() {
                    super(...arguments), this.type = "html", this.applyWillChange = !0, this.renderInstance = nV
                }
                readValueFromInstance(e, t) {
                    if (f.has(t)) {
                        let e = eX(t);
                        return e && e.default || 0
                    } {
                        let r = window.getComputedStyle(e),
                            i = (N(t) ? r.getPropertyValue(t) : r[t]) || 0;
                        return "string" == typeof i ? i.trim() : i
                    }
                }
                measureInstanceViewportBox(e, {
                    transformPagePoint: t
                }) {
                    return rY(e, t)
                }
                build(e, t, r) {
                    nX(e, t, r.transformTemplate)
                }
                scrapeMotionValuesFromProps(e, t, r) {
                    return nF(e, t, r)
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: e
                    } = this.props;
                    t2(e) && (this.childSubscription = e.on("change", e => {
                        this.current && (this.current.textContent = `${e}`)
                    }))
                }
            }
            class sr extends se {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = rj
                }
                getBaseTargetFromProps(e, t) {
                    return e[t]
                }
                readValueFromInstance(e, t) {
                    if (f.has(t)) {
                        let e = eX(t);
                        return e && e.default || 0
                    }
                    return t = nM.has(t) ? t : tQ(t), e.getAttribute(t)
                }
                scrapeMotionValuesFromProps(e, t, r) {
                    return nj(e, t, r)
                }
                build(e, t, r) {
                    nY(e, t, this.isSVGTag, r.transformTemplate)
                }
                renderInstance(e, t, r, i) {
                    nk(e, t, r, i)
                }
                mount(e) {
                    this.isSVGTag = nK(e.tagName), super.mount(e)
                }
            }
            let si = function(e) {
                if ("undefined" == typeof Proxy) return e;
                let t = new Map;
                return new Proxy((...t) => e(...t), {
                    get: (r, i) => "create" === i ? e : (t.has(i) || t.set(i, e(i)), t.get(i))
                })
            }((p = {
                animation: {
                    Feature: rr
                },
                exit: {
                    Feature: rn
                },
                inView: {
                    Feature: np
                },
                tap: {
                    Feature: nl
                },
                focus: {
                    Feature: ns
                },
                hover: {
                    Feature: nn
                },
                pan: {
                    Feature: r1
                },
                drag: {
                    Feature: rJ,
                    ProjectionNode: nr,
                    MeasureLayout: is
                },
                layout: {
                    ProjectionNode: nr,
                    MeasureLayout: is
                }
            }, m = (e, t) => nC(e) ? new sr(t) : new st(t, {
                allowProjection: e !== r5.Fragment
            }), function(e, {
                forwardMotionProps: t
            } = {
                forwardMotionProps: !1
            }) {
                return function(e) {
                    let {
                        preloadedFeatures: t,
                        createVisualElement: r,
                        useRender: i,
                        useVisualState: n,
                        Component: s
                    } = e;
                    t && function(e) {
                        for (let t in e) nE[t] = { ...nE[t],
                            ...e[t]
                        }
                    }(t);
                    let o = (0, r5.forwardRef)(function(e, t) {
                        var o;
                        let l;
                        let u = { ...(0, r5.useContext)(nm._),
                                ...e,
                                layoutId: function(e) {
                                    let {
                                        layoutId: t
                                    } = e, r = (0, r5.useContext)(r4.p).id;
                                    return r && void 0 !== t ? r + "-" + t : t
                                }(e)
                            },
                            {
                                isStatic: h
                            } = u,
                            d = function(e) {
                                let {
                                    initial: t,
                                    animate: r
                                } = function(e, t) {
                                    if (nS(e)) {
                                        let {
                                            initial: t,
                                            animate: r
                                        } = e;
                                        return {
                                            initial: !1 === t || a(t) ? t : void 0,
                                            animate: a(r) ? r : void 0
                                        }
                                    }
                                    return !1 !== e.inherit ? t : {}
                                }(e, (0, r5.useContext)(ng));
                                return (0, r5.useMemo)(() => ({
                                    initial: t,
                                    animate: r
                                }), [nA(t), nA(r)])
                            }(e),
                            c = n(e, h);
                        if (!h && n_.j) {
                            (0, r5.useContext)(ny).strict;
                            let e = function(e) {
                                let {
                                    drag: t,
                                    layout: r
                                } = nE;
                                if (!t && !r) return {};
                                let i = { ...t,
                                    ...r
                                };
                                return {
                                    MeasureLayout: (null == t ? void 0 : t.isEnabled(e)) || (null == r ? void 0 : r.isEnabled(e)) ? i.MeasureLayout : void 0,
                                    ProjectionNode: i.ProjectionNode
                                }
                            }(u);
                            l = e.MeasureLayout, d.visualElement = function(e, t, r, i, n) {
                                var s;
                                let {
                                    visualElement: o
                                } = (0, r5.useContext)(ng), a = (0, r5.useContext)(ny), l = (0, r5.useContext)(r3.O), u = (0, r5.useContext)(nm._).reducedMotion, h = (0, r5.useRef)();
                                i = i || a.renderer, !h.current && i && (h.current = i(e, {
                                    visualState: t,
                                    parent: o,
                                    props: r,
                                    presenceContext: l,
                                    blockInitialAnimation: !!l && !1 === l.initial,
                                    reducedMotionConfig: u
                                }));
                                let d = h.current,
                                    c = (0, r5.useContext)(r9);
                                d && !d.projection && n && ("html" === d.type || "svg" === d.type) && function(e, t, r, i) {
                                    let {
                                        layoutId: n,
                                        layout: s,
                                        drag: o,
                                        dragConstraints: a,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    } = t;
                                    e.projection = new r(e.latestValues, t["data-framer-portal-id"] ? void 0 : function e(t) {
                                        if (t) return !1 !== t.options.allowProjection ? t.projection : e(t.parent)
                                    }(e.parent)), e.projection.setOptions({
                                        layoutId: n,
                                        layout: s,
                                        alwaysMeasureLayout: !!o || a && rS(a),
                                        visualElement: e,
                                        animationType: "string" == typeof s ? s : "both",
                                        initialPromotionConfig: i,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    })
                                }(h.current, r, n, c), (0, r5.useInsertionEffect)(() => {
                                    d && d.update(r, l)
                                });
                                let f = r[tJ],
                                    p = (0, r5.useRef)(!!f && !window.MotionHandoffIsComplete && (null === (s = window.MotionHasOptimisedAnimation) || void 0 === s ? void 0 : s.call(window, f)));
                                return (0, nv.L)(() => {
                                    d && (d.updateFeatures(), it.render(d.render), p.current && d.animationState && d.animationState.animateChanges())
                                }), (0, r5.useEffect)(() => {
                                    d && (!p.current && d.animationState && d.animationState.animateChanges(), p.current = !1, nx || (nx = !0, queueMicrotask(nb)))
                                }), d
                            }(s, c, u, r, e.ProjectionNode)
                        }
                        return (0, r2.jsxs)(ng.Provider, {
                            value: d,
                            children: [l && d.visualElement ? (0, r2.jsx)(l, {
                                visualElement: d.visualElement,
                                ...u
                            }) : null, i(s, e, (o = d.visualElement, (0, r5.useCallback)(e => {
                                e && c.mount && c.mount(e), o && (e ? o.mount(e) : o.unmount()), t && ("function" == typeof t ? t(e) : rS(t) && (t.current = e))
                            }, [o])), c, h, d.visualElement)]
                        })
                    });
                    return o[nT] = s, o
                }({ ...nC(e) ? nq : nZ,
                    preloadedFeatures: p,
                    useRender: function(e = !1) {
                        return (t, r, i, {
                            latestValues: n
                        }, s) => {
                            let o = (nC(t) ? function(e, t, r, i) {
                                    let n = (0, r5.useMemo)(() => {
                                        let r = nU();
                                        return nY(r, t, nK(i), e.transformTemplate), { ...r.attrs,
                                            style: { ...r.style
                                            }
                                        }
                                    }, [t]);
                                    if (e.style) {
                                        let t = {};
                                        nQ(t, e.style, e), n.style = { ...t,
                                            ...n.style
                                        }
                                    }
                                    return n
                                } : function(e, t) {
                                    let r = {},
                                        i = function(e, t) {
                                            let r = e.style || {},
                                                i = {};
                                            return nQ(i, r, e), Object.assign(i, function({
                                                transformTemplate: e
                                            }, t) {
                                                return (0, r5.useMemo)(() => {
                                                    let r = nI();
                                                    return nX(r, t, e), Object.assign({}, r.vars, r.style)
                                                }, [t])
                                            }(e, t)), i
                                        }(e, t);
                                    return e.drag && !1 !== e.dragListener && (r.draggable = !1, i.userSelect = i.WebkitUserSelect = i.WebkitTouchCallout = "none", i.touchAction = !0 === e.drag ? "none" : `pan-${"x"===e.drag?"y":"x"}`), void 0 === e.tabIndex && (e.onTap || e.onTapStart || e.whileTap) && (r.tabIndex = 0), r.style = i, r
                                })(r, n, s, t),
                                a = function(e, t, r) {
                                    let i = {};
                                    for (let n in e)("values" !== n || "object" != typeof e.values) && (n1(n) || !0 === r && n0(n) || !t && !n0(n) || e.draggable && n.startsWith("onDrag")) && (i[n] = e[n]);
                                    return i
                                }(r, "string" == typeof t, e),
                                l = t !== r5.Fragment ? { ...a,
                                    ...o,
                                    ref: i
                                } : {},
                                {
                                    children: u
                                } = r,
                                h = (0, r5.useMemo)(() => t2(u) ? u.get() : u, [u]);
                            return (0, r5.createElement)(t, { ...l,
                                children: h
                            })
                        }
                    }(t),
                    createVisualElement: m,
                    Component: e
                })
            }))
        },
        27017: (e, t, r) => {
            "use strict";
            r.d(t, {
                u: () => i
            });
            let i = (e, t, r) => r > t ? t : r < e ? e : r
        },
        35047: (e, t, r) => {
            "use strict";
            r.d(t, {
                K: () => n,
                k: () => s
            });
            var i = r(94537);
            let n = i.Z,
                s = i.Z
        },
        87314: (e, t, r) => {
            "use strict";
            r.d(t, {
                j: () => i
            });
            let i = "undefined" != typeof window
        },
        94537: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => i
            });
            let i = e => e
        },
        17393: (e, t, r) => {
            "use strict";
            r.d(t, {
                X: () => n,
                w: () => i
            });
            let i = e => 1e3 * e,
                n = e => e / 1e3
        },
        44276: (e, t, r) => {
            "use strict";
            r.d(t, {
                h: () => n
            });
            var i = r(93264);

            function n(e) {
                let t = (0, i.useRef)(null);
                return null === t.current && (t.current = e()), t.current
            }
        },
        82821: (e, t, r) => {
            "use strict";
            r.d(t, {
                L: () => n
            });
            var i = r(93264);
            let n = r(87314).j ? i.useLayoutEffect : i.useEffect
        },
        20389: (e, t, r) => {
            "use strict";

            function i(e, t) {
                return t ? 1e3 / t * e : 0
            }
            r.d(t, {
                R: () => i
            })
        },
        95289: (e, t, r) => {
            "use strict";
            r.d(t, {
                Dq: () => ef,
                Gc: () => _,
                KN: () => L,
                Qr: () => O,
                RV: () => T,
                U2: () => v,
                cI: () => ek,
                t8: () => S
            });
            var i = r(93264),
                n = e => "checkbox" === e.type,
                s = e => e instanceof Date,
                o = e => null == e;
            let a = e => "object" == typeof e;
            var l = e => !o(e) && !Array.isArray(e) && a(e) && !s(e),
                u = e => l(e) && e.target ? n(e.target) ? e.target.checked : e.target.value : e,
                h = e => e.substring(0, e.search(/\.\d+(\.|$)/)) || e,
                d = (e, t) => e.has(h(t)),
                c = e => {
                    let t = e.constructor && e.constructor.prototype;
                    return l(t) && t.hasOwnProperty("isPrototypeOf")
                },
                f = "undefined" != typeof window && void 0 !== window.HTMLElement && "undefined" != typeof document;

            function p(e) {
                let t;
                let r = Array.isArray(e);
                if (e instanceof Date) t = new Date(e);
                else if (e instanceof Set) t = new Set(e);
                else if (!(!(f && (e instanceof Blob || e instanceof FileList)) && (r || l(e)))) return e;
                else if (t = r ? [] : {}, r || c(e))
                    for (let r in e) e.hasOwnProperty(r) && (t[r] = p(e[r]));
                else t = e;
                return t
            }
            var m = e => Array.isArray(e) ? e.filter(Boolean) : [],
                g = e => void 0 === e,
                v = (e, t, r) => {
                    if (!t || !l(e)) return r;
                    let i = m(t.split(/[,[\].]+?/)).reduce((e, t) => o(e) ? e : e[t], e);
                    return g(i) || i === e ? g(e[t]) ? r : e[t] : i
                },
                y = e => "boolean" == typeof e,
                x = e => /^\w*$/.test(e),
                b = e => m(e.replace(/["|']|\]/g, "").split(/\.|\[/)),
                S = (e, t, r) => {
                    let i = -1,
                        n = x(t) ? [t] : b(t),
                        s = n.length,
                        o = s - 1;
                    for (; ++i < s;) {
                        let t = n[i],
                            s = r;
                        if (i !== o) {
                            let r = e[t];
                            s = l(r) || Array.isArray(r) ? r : isNaN(+n[i + 1]) ? {} : []
                        }
                        if ("__proto__" === t) return;
                        e[t] = s, e = e[t]
                    }
                    return e
                };
            let P = {
                    BLUR: "blur",
                    FOCUS_OUT: "focusout",
                    CHANGE: "change"
                },
                A = {
                    onBlur: "onBlur",
                    onChange: "onChange",
                    onSubmit: "onSubmit",
                    onTouched: "onTouched",
                    all: "all"
                },
                w = {
                    max: "max",
                    min: "min",
                    maxLength: "maxLength",
                    minLength: "minLength",
                    pattern: "pattern",
                    required: "required",
                    validate: "validate"
                },
                E = i.createContext(null),
                _ = () => i.useContext(E),
                T = e => {
                    let {
                        children: t,
                        ...r
                    } = e;
                    return i.createElement(E.Provider, {
                        value: r
                    }, t)
                };
            var R = (e, t, r, i = !0) => {
                    let n = {
                        defaultValues: t._defaultValues
                    };
                    for (let s in e) Object.defineProperty(n, s, {
                        get: () => (t._proxyFormState[s] !== A.all && (t._proxyFormState[s] = !i || A.all), r && (r[s] = !0), e[s])
                    });
                    return n
                },
                C = e => l(e) && !Object.keys(e).length,
                V = (e, t, r, i) => {
                    r(e);
                    let {
                        name: n,
                        ...s
                    } = e;
                    return C(s) || Object.keys(s).length >= Object.keys(t).length || Object.keys(s).find(e => t[e] === (!i || A.all))
                },
                M = e => Array.isArray(e) ? e : [e],
                k = (e, t, r) => !e || !t || e === t || M(e).some(e => e && (r ? e === t : e.startsWith(t) || t.startsWith(e)));

            function D(e) {
                let t = i.useRef(e);
                t.current = e, i.useEffect(() => {
                    let r = !e.disabled && t.current.subject && t.current.subject.subscribe({
                        next: t.current.next
                    });
                    return () => {
                        r && r.unsubscribe()
                    }
                }, [e.disabled])
            }
            var F = e => "string" == typeof e,
                j = (e, t, r, i, n) => F(e) ? (i && t.watch.add(e), v(r, e, n)) : Array.isArray(e) ? e.map(e => (i && t.watch.add(e), v(r, e))) : (i && (t.watchAll = !0), r);
            let O = e => e.render(function(e) {
                let t = _(),
                    {
                        name: r,
                        disabled: n,
                        control: s = t.control,
                        shouldUnregister: o
                    } = e,
                    a = d(s._names.array, r),
                    l = function(e) {
                        let t = _(),
                            {
                                control: r = t.control,
                                name: n,
                                defaultValue: s,
                                disabled: o,
                                exact: a
                            } = e || {},
                            l = i.useRef(n);
                        l.current = n, D({
                            disabled: o,
                            subject: r._subjects.values,
                            next: e => {
                                k(l.current, e.name, a) && h(p(j(l.current, r._names, e.values || r._formValues, !1, s)))
                            }
                        });
                        let [u, h] = i.useState(r._getWatch(n, s));
                        return i.useEffect(() => r._removeUnmounted()), u
                    }({
                        control: s,
                        name: r,
                        defaultValue: v(s._formValues, r, v(s._defaultValues, r, e.defaultValue)),
                        exact: !0
                    }),
                    h = function(e) {
                        let t = _(),
                            {
                                control: r = t.control,
                                disabled: n,
                                name: s,
                                exact: o
                            } = e || {},
                            [a, l] = i.useState(r._formState),
                            u = i.useRef(!0),
                            h = i.useRef({
                                isDirty: !1,
                                isLoading: !1,
                                dirtyFields: !1,
                                touchedFields: !1,
                                validatingFields: !1,
                                isValidating: !1,
                                isValid: !1,
                                errors: !1
                            }),
                            d = i.useRef(s);
                        return d.current = s, D({
                            disabled: n,
                            next: e => u.current && k(d.current, e.name, o) && V(e, h.current, r._updateFormState) && l({ ...r._formState,
                                ...e
                            }),
                            subject: r._subjects.state
                        }), i.useEffect(() => (u.current = !0, h.current.isValid && r._updateValid(!0), () => {
                            u.current = !1
                        }), [r]), R(a, r, h.current, !1)
                    }({
                        control: s,
                        name: r,
                        exact: !0
                    }),
                    c = i.useRef(s.register(r, { ...e.rules,
                        value: l,
                        ...y(e.disabled) ? {
                            disabled: e.disabled
                        } : {}
                    }));
                return i.useEffect(() => {
                    let e = s._options.shouldUnregister || o,
                        t = (e, t) => {
                            let r = v(s._fields, e);
                            r && r._f && (r._f.mount = t)
                        };
                    if (t(r, !0), e) {
                        let e = p(v(s._options.defaultValues, r));
                        S(s._defaultValues, r, e), g(v(s._formValues, r)) && S(s._formValues, r, e)
                    }
                    return () => {
                        (a ? e && !s._state.action : e) ? s.unregister(r): t(r, !1)
                    }
                }, [r, s, a, o]), i.useEffect(() => {
                    v(s._fields, r) && s._updateDisabledField({
                        disabled: n,
                        fields: s._fields,
                        name: r,
                        value: v(s._fields, r)._f.value
                    })
                }, [n, r, s]), {
                    field: {
                        name: r,
                        value: l,
                        ...y(n) || h.disabled ? {
                            disabled: h.disabled || n
                        } : {},
                        onChange: i.useCallback(e => c.current.onChange({
                            target: {
                                value: u(e),
                                name: r
                            },
                            type: P.CHANGE
                        }), [r]),
                        onBlur: i.useCallback(() => c.current.onBlur({
                            target: {
                                value: v(s._formValues, r),
                                name: r
                            },
                            type: P.BLUR
                        }), [r, s]),
                        ref: i.useCallback(e => {
                            let t = v(s._fields, r);
                            t && e && (t._f.ref = {
                                focus: () => e.focus(),
                                select: () => e.select(),
                                setCustomValidity: t => e.setCustomValidity(t),
                                reportValidity: () => e.reportValidity()
                            })
                        }, [s._fields, r])
                    },
                    formState: h,
                    fieldState: Object.defineProperties({}, {
                        invalid: {
                            enumerable: !0,
                            get: () => !!v(h.errors, r)
                        },
                        isDirty: {
                            enumerable: !0,
                            get: () => !!v(h.dirtyFields, r)
                        },
                        isTouched: {
                            enumerable: !0,
                            get: () => !!v(h.touchedFields, r)
                        },
                        isValidating: {
                            enumerable: !0,
                            get: () => !!v(h.validatingFields, r)
                        },
                        error: {
                            enumerable: !0,
                            get: () => v(h.errors, r)
                        }
                    })
                }
            }(e));
            var L = (e, t, r, i, n) => t ? { ...r[e],
                    types: { ...r[e] && r[e].types ? r[e].types : {},
                        [i]: n || !0
                    }
                } : {},
                N = () => {
                    let e = "undefined" == typeof performance ? Date.now() : 1e3 * performance.now();
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, t => {
                        let r = (16 * Math.random() + e) % 16 | 0;
                        return ("x" == t ? r : 3 & r | 8).toString(16)
                    })
                },
                I = (e, t, r = {}) => r.shouldFocus || g(r.shouldFocus) ? r.focusName || `${e}.${g(r.focusIndex)?t:r.focusIndex}.` : "",
                U = e => ({
                    isOnSubmit: !e || e === A.onSubmit,
                    isOnBlur: e === A.onBlur,
                    isOnChange: e === A.onChange,
                    isOnAll: e === A.all,
                    isOnTouch: e === A.onTouched
                }),
                B = (e, t, r) => !r && (t.watchAll || t.watch.has(e) || [...t.watch].some(t => e.startsWith(t) && /^\.\w+/.test(e.slice(t.length))));
            let W = (e, t, r, i) => {
                for (let n of r || Object.keys(e)) {
                    let r = v(e, n);
                    if (r) {
                        let {
                            _f: e,
                            ...s
                        } = r;
                        if (e) {
                            if (e.refs && e.refs[0] && t(e.refs[0], n) && !i || e.ref && t(e.ref, e.name) && !i) break;
                            W(s, t)
                        } else l(s) && W(s, t)
                    }
                }
            };
            var $ = (e, t, r) => {
                    let i = M(v(e, r));
                    return S(i, "root", t[r]), S(e, r, i), e
                },
                X = e => "file" === e.type,
                H = e => "function" == typeof e,
                G = e => {
                    if (!f) return !1;
                    let t = e ? e.ownerDocument : 0;
                    return e instanceof(t && t.defaultView ? t.defaultView.HTMLElement : HTMLElement)
                },
                z = e => F(e),
                Y = e => "radio" === e.type,
                K = e => e instanceof RegExp;
            let q = {
                    value: !1,
                    isValid: !1
                },
                Z = {
                    value: !0,
                    isValid: !0
                };
            var Q = e => {
                if (Array.isArray(e)) {
                    if (e.length > 1) {
                        let t = e.filter(e => e && e.checked && !e.disabled).map(e => e.value);
                        return {
                            value: t,
                            isValid: !!t.length
                        }
                    }
                    return e[0].checked && !e[0].disabled ? e[0].attributes && !g(e[0].attributes.value) ? g(e[0].value) || "" === e[0].value ? Z : {
                        value: e[0].value,
                        isValid: !0
                    } : Z : q
                }
                return q
            };
            let J = {
                isValid: !1,
                value: null
            };
            var ee = e => Array.isArray(e) ? e.reduce((e, t) => t && t.checked && !t.disabled ? {
                isValid: !0,
                value: t.value
            } : e, J) : J;

            function et(e, t, r = "validate") {
                if (z(e) || Array.isArray(e) && e.every(z) || y(e) && !e) return {
                    type: r,
                    message: z(e) ? e : "",
                    ref: t
                }
            }
            var er = e => l(e) && !K(e) ? e : {
                    value: e,
                    message: ""
                },
                ei = async (e, t, r, i, s) => {
                    let {
                        ref: a,
                        refs: u,
                        required: h,
                        maxLength: d,
                        minLength: c,
                        min: f,
                        max: p,
                        pattern: m,
                        validate: x,
                        name: b,
                        valueAsNumber: S,
                        mount: P,
                        disabled: A
                    } = e._f, E = v(t, b);
                    if (!P || A) return {};
                    let _ = u ? u[0] : a,
                        T = e => {
                            i && _.reportValidity && (_.setCustomValidity(y(e) ? "" : e || ""), _.reportValidity())
                        },
                        R = {},
                        V = Y(a),
                        M = n(a),
                        k = (S || X(a)) && g(a.value) && g(E) || G(a) && "" === a.value || "" === E || Array.isArray(E) && !E.length,
                        D = L.bind(null, b, r, R),
                        j = (e, t, r, i = w.maxLength, n = w.minLength) => {
                            let s = e ? t : r;
                            R[b] = {
                                type: e ? i : n,
                                message: s,
                                ref: a,
                                ...D(e ? i : n, s)
                            }
                        };
                    if (s ? !Array.isArray(E) || !E.length : h && (!(V || M) && (k || o(E)) || y(E) && !E || M && !Q(u).isValid || V && !ee(u).isValid)) {
                        let {
                            value: e,
                            message: t
                        } = z(h) ? {
                            value: !!h,
                            message: h
                        } : er(h);
                        if (e && (R[b] = {
                                type: w.required,
                                message: t,
                                ref: _,
                                ...D(w.required, t)
                            }, !r)) return T(t), R
                    }
                    if (!k && (!o(f) || !o(p))) {
                        let e, t;
                        let i = er(p),
                            n = er(f);
                        if (o(E) || isNaN(E)) {
                            let r = a.valueAsDate || new Date(E),
                                s = e => new Date(new Date().toDateString() + " " + e),
                                o = "time" == a.type,
                                l = "week" == a.type;
                            F(i.value) && E && (e = o ? s(E) > s(i.value) : l ? E > i.value : r > new Date(i.value)), F(n.value) && E && (t = o ? s(E) < s(n.value) : l ? E < n.value : r < new Date(n.value))
                        } else {
                            let r = a.valueAsNumber || (E ? +E : E);
                            o(i.value) || (e = r > i.value), o(n.value) || (t = r < n.value)
                        }
                        if ((e || t) && (j(!!e, i.message, n.message, w.max, w.min), !r)) return T(R[b].message), R
                    }
                    if ((d || c) && !k && (F(E) || s && Array.isArray(E))) {
                        let e = er(d),
                            t = er(c),
                            i = !o(e.value) && E.length > +e.value,
                            n = !o(t.value) && E.length < +t.value;
                        if ((i || n) && (j(i, e.message, t.message), !r)) return T(R[b].message), R
                    }
                    if (m && !k && F(E)) {
                        let {
                            value: e,
                            message: t
                        } = er(m);
                        if (K(e) && !E.match(e) && (R[b] = {
                                type: w.pattern,
                                message: t,
                                ref: a,
                                ...D(w.pattern, t)
                            }, !r)) return T(t), R
                    }
                    if (x) {
                        if (H(x)) {
                            let e = et(await x(E, t), _);
                            if (e && (R[b] = { ...e,
                                    ...D(w.validate, e.message)
                                }, !r)) return T(e.message), R
                        } else if (l(x)) {
                            let e = {};
                            for (let i in x) {
                                if (!C(e) && !r) break;
                                let n = et(await x[i](E, t), _, i);
                                n && (e = { ...n,
                                    ...D(i, n.message)
                                }, T(n.message), r && (R[b] = e))
                            }
                            if (!C(e) && (R[b] = {
                                    ref: _,
                                    ...e
                                }, !r)) return R
                        }
                    }
                    return T(!0), R
                },
                en = (e, t) => [...e, ...M(t)],
                es = e => Array.isArray(e) ? e.map(() => void 0) : void 0;

            function eo(e, t, r) {
                return [...e.slice(0, t), ...M(r), ...e.slice(t)]
            }
            var ea = (e, t, r) => Array.isArray(e) ? (g(e[r]) && (e[r] = void 0), e.splice(r, 0, e.splice(t, 1)[0]), e) : [],
                el = (e, t) => [...M(t), ...M(e)],
                eu = (e, t) => g(t) ? [] : function(e, t) {
                    let r = 0,
                        i = [...e];
                    for (let e of t) i.splice(e - r, 1), r++;
                    return m(i).length ? i : []
                }(e, M(t).sort((e, t) => e - t)),
                eh = (e, t, r) => {
                    [e[t], e[r]] = [e[r], e[t]]
                };

            function ed(e, t) {
                let r = Array.isArray(t) ? t : x(t) ? [t] : b(t),
                    i = 1 === r.length ? e : function(e, t) {
                        let r = t.slice(0, -1).length,
                            i = 0;
                        for (; i < r;) e = g(e) ? i++ : e[t[i++]];
                        return e
                    }(e, r),
                    n = r.length - 1,
                    s = r[n];
                return i && delete i[s], 0 !== n && (l(i) && C(i) || Array.isArray(i) && function(e) {
                    for (let t in e)
                        if (e.hasOwnProperty(t) && !g(e[t])) return !1;
                    return !0
                }(i)) && ed(e, r.slice(0, -1)), e
            }
            var ec = (e, t, r) => (e[t] = r, e);

            function ef(e) {
                let t = _(),
                    {
                        control: r = t.control,
                        name: n,
                        keyName: s = "id",
                        shouldUnregister: o
                    } = e,
                    [a, l] = i.useState(r._getFieldArray(n)),
                    u = i.useRef(r._getFieldArray(n).map(N)),
                    h = i.useRef(a),
                    d = i.useRef(n),
                    c = i.useRef(!1);
                d.current = n, h.current = a, r._names.array.add(n), e.rules && r.register(n, e.rules), D({
                    next: ({
                        values: e,
                        name: t
                    }) => {
                        if (t === d.current || !t) {
                            let t = v(e, d.current);
                            Array.isArray(t) && (l(t), u.current = t.map(N))
                        }
                    },
                    subject: r._subjects.array
                });
                let f = i.useCallback(e => {
                    c.current = !0, r._updateFieldArray(n, e)
                }, [r, n]);
                return i.useEffect(() => {
                    if (r._state.action = !1, B(n, r._names) && r._subjects.state.next({ ...r._formState
                        }), c.current && (!U(r._options.mode).isOnSubmit || r._formState.isSubmitted)) {
                        if (r._options.resolver) r._executeSchema([n]).then(e => {
                            let t = v(e.errors, n),
                                i = v(r._formState.errors, n);
                            (i ? !t && i.type || t && (i.type !== t.type || i.message !== t.message) : t && t.type) && (t ? S(r._formState.errors, n, t) : ed(r._formState.errors, n), r._subjects.state.next({
                                errors: r._formState.errors
                            }))
                        });
                        else {
                            let e = v(r._fields, n);
                            e && e._f && !(U(r._options.reValidateMode).isOnSubmit && U(r._options.mode).isOnSubmit) && ei(e, r._formValues, r._options.criteriaMode === A.all, r._options.shouldUseNativeValidation, !0).then(e => !C(e) && r._subjects.state.next({
                                errors: $(r._formState.errors, e, n)
                            }))
                        }
                    }
                    r._subjects.values.next({
                        name: n,
                        values: { ...r._formValues
                        }
                    }), r._names.focus && W(r._fields, (e, t) => {
                        if (r._names.focus && t.startsWith(r._names.focus) && e.focus) return e.focus(), 1
                    }), r._names.focus = "", r._updateValid(), c.current = !1
                }, [a, n, r]), i.useEffect(() => (v(r._formValues, n) || r._updateFieldArray(n), () => {
                    (r._options.shouldUnregister || o) && r.unregister(n)
                }), [n, r, s, o]), {
                    swap: i.useCallback((e, t) => {
                        let i = r._getFieldArray(n);
                        eh(i, e, t), eh(u.current, e, t), f(i), l(i), r._updateFieldArray(n, i, eh, {
                            argA: e,
                            argB: t
                        }, !1)
                    }, [f, n, r]),
                    move: i.useCallback((e, t) => {
                        let i = r._getFieldArray(n);
                        ea(i, e, t), ea(u.current, e, t), f(i), l(i), r._updateFieldArray(n, i, ea, {
                            argA: e,
                            argB: t
                        }, !1)
                    }, [f, n, r]),
                    prepend: i.useCallback((e, t) => {
                        let i = M(p(e)),
                            s = el(r._getFieldArray(n), i);
                        r._names.focus = I(n, 0, t), u.current = el(u.current, i.map(N)), f(s), l(s), r._updateFieldArray(n, s, el, {
                            argA: es(e)
                        })
                    }, [f, n, r]),
                    append: i.useCallback((e, t) => {
                        let i = M(p(e)),
                            s = en(r._getFieldArray(n), i);
                        r._names.focus = I(n, s.length - 1, t), u.current = en(u.current, i.map(N)), f(s), l(s), r._updateFieldArray(n, s, en, {
                            argA: es(e)
                        })
                    }, [f, n, r]),
                    remove: i.useCallback(e => {
                        let t = eu(r._getFieldArray(n), e);
                        u.current = eu(u.current, e), f(t), l(t), r._updateFieldArray(n, t, eu, {
                            argA: e
                        })
                    }, [f, n, r]),
                    insert: i.useCallback((e, t, i) => {
                        let s = M(p(t)),
                            o = eo(r._getFieldArray(n), e, s);
                        r._names.focus = I(n, e, i), u.current = eo(u.current, e, s.map(N)), f(o), l(o), r._updateFieldArray(n, o, eo, {
                            argA: e,
                            argB: es(t)
                        })
                    }, [f, n, r]),
                    update: i.useCallback((e, t) => {
                        let i = p(t),
                            s = ec(r._getFieldArray(n), e, i);
                        u.current = [...s].map((t, r) => t && r !== e ? u.current[r] : N()), f(s), l([...s]), r._updateFieldArray(n, s, ec, {
                            argA: e,
                            argB: i
                        }, !0, !1)
                    }, [f, n, r]),
                    replace: i.useCallback(e => {
                        let t = M(p(e));
                        u.current = t.map(N), f([...t]), l([...t]), r._updateFieldArray(n, [...t], e => e, {}, !0, !1)
                    }, [f, n, r]),
                    fields: i.useMemo(() => a.map((e, t) => ({ ...e,
                        [s]: u.current[t] || N()
                    })), [a, s])
                }
            }
            var ep = () => {
                    let e = [];
                    return {
                        get observers() {
                            return e
                        },
                        next: t => {
                            for (let r of e) r.next && r.next(t)
                        },
                        subscribe: t => (e.push(t), {
                            unsubscribe: () => {
                                e = e.filter(e => e !== t)
                            }
                        }),
                        unsubscribe: () => {
                            e = []
                        }
                    }
                },
                em = e => o(e) || !a(e);

            function eg(e, t) {
                if (em(e) || em(t)) return e === t;
                if (s(e) && s(t)) return e.getTime() === t.getTime();
                let r = Object.keys(e),
                    i = Object.keys(t);
                if (r.length !== i.length) return !1;
                for (let n of r) {
                    let r = e[n];
                    if (!i.includes(n)) return !1;
                    if ("ref" !== n) {
                        let e = t[n];
                        if (s(r) && s(e) || l(r) && l(e) || Array.isArray(r) && Array.isArray(e) ? !eg(r, e) : r !== e) return !1
                    }
                }
                return !0
            }
            var ev = e => "select-multiple" === e.type,
                ey = e => Y(e) || n(e),
                ex = e => G(e) && e.isConnected,
                eb = e => {
                    for (let t in e)
                        if (H(e[t])) return !0;
                    return !1
                };

            function eS(e, t = {}) {
                let r = Array.isArray(e);
                if (l(e) || r)
                    for (let r in e) Array.isArray(e[r]) || l(e[r]) && !eb(e[r]) ? (t[r] = Array.isArray(e[r]) ? [] : {}, eS(e[r], t[r])) : o(e[r]) || (t[r] = !0);
                return t
            }
            var eP = (e, t) => (function e(t, r, i) {
                    let n = Array.isArray(t);
                    if (l(t) || n)
                        for (let n in t) Array.isArray(t[n]) || l(t[n]) && !eb(t[n]) ? g(r) || em(i[n]) ? i[n] = Array.isArray(t[n]) ? eS(t[n], []) : { ...eS(t[n])
                        } : e(t[n], o(r) ? {} : r[n], i[n]) : i[n] = !eg(t[n], r[n]);
                    return i
                })(e, t, eS(t)),
                eA = (e, {
                    valueAsNumber: t,
                    valueAsDate: r,
                    setValueAs: i
                }) => g(e) ? e : t ? "" === e ? NaN : e ? +e : e : r && F(e) ? new Date(e) : i ? i(e) : e;

            function ew(e) {
                let t = e.ref;
                return (e.refs ? e.refs.every(e => e.disabled) : t.disabled) ? void 0 : X(t) ? t.files : Y(t) ? ee(e.refs).value : ev(t) ? [...t.selectedOptions].map(({
                    value: e
                }) => e) : n(t) ? Q(e.refs).value : eA(g(t.value) ? e.ref.value : t.value, e)
            }
            var eE = (e, t, r, i) => {
                    let n = {};
                    for (let r of e) {
                        let e = v(t, r);
                        e && S(n, r, e._f)
                    }
                    return {
                        criteriaMode: r,
                        names: [...e],
                        fields: n,
                        shouldUseNativeValidation: i
                    }
                },
                e_ = e => g(e) ? e : K(e) ? e.source : l(e) ? K(e.value) ? e.value.source : e.value : e,
                eT = e => e.mount && (e.required || e.min || e.max || e.maxLength || e.minLength || e.pattern || e.validate);

            function eR(e, t, r) {
                let i = v(e, r);
                if (i || x(r)) return {
                    error: i,
                    name: r
                };
                let n = r.split(".");
                for (; n.length;) {
                    let i = n.join("."),
                        s = v(t, i),
                        o = v(e, i);
                    if (s && !Array.isArray(s) && r !== i) break;
                    if (o && o.type) return {
                        name: i,
                        error: o
                    };
                    n.pop()
                }
                return {
                    name: r
                }
            }
            var eC = (e, t, r, i, n) => !n.isOnAll && (!r && n.isOnTouch ? !(t || e) : (r ? i.isOnBlur : n.isOnBlur) ? !e : (r ? !i.isOnChange : !n.isOnChange) || e),
                eV = (e, t) => !m(v(e, t)).length && ed(e, t);
            let eM = {
                mode: A.onSubmit,
                reValidateMode: A.onChange,
                shouldFocusError: !0
            };

            function ek(e = {}) {
                let t = i.useRef(),
                    r = i.useRef(),
                    [a, h] = i.useState({
                        isDirty: !1,
                        isValidating: !1,
                        isLoading: H(e.defaultValues),
                        isSubmitted: !1,
                        isSubmitting: !1,
                        isSubmitSuccessful: !1,
                        isValid: !1,
                        submitCount: 0,
                        dirtyFields: {},
                        touchedFields: {},
                        validatingFields: {},
                        errors: e.errors || {},
                        disabled: e.disabled || !1,
                        defaultValues: H(e.defaultValues) ? void 0 : e.defaultValues
                    });
                t.current || (t.current = { ... function(e = {}) {
                        let t, r = { ...eM,
                                ...e
                            },
                            i = {
                                submitCount: 0,
                                isDirty: !1,
                                isLoading: H(r.defaultValues),
                                isValidating: !1,
                                isSubmitted: !1,
                                isSubmitting: !1,
                                isSubmitSuccessful: !1,
                                isValid: !1,
                                touchedFields: {},
                                dirtyFields: {},
                                validatingFields: {},
                                errors: r.errors || {},
                                disabled: r.disabled || !1
                            },
                            a = {},
                            h = (l(r.defaultValues) || l(r.values)) && p(r.defaultValues || r.values) || {},
                            c = r.shouldUnregister ? {} : p(h),
                            x = {
                                action: !1,
                                mount: !1,
                                watch: !1
                            },
                            b = {
                                mount: new Set,
                                unMount: new Set,
                                array: new Set,
                                watch: new Set
                            },
                            w = 0,
                            E = {
                                isDirty: !1,
                                dirtyFields: !1,
                                validatingFields: !1,
                                touchedFields: !1,
                                isValidating: !1,
                                isValid: !1,
                                errors: !1
                            },
                            _ = {
                                values: ep(),
                                array: ep(),
                                state: ep()
                            },
                            T = U(r.mode),
                            R = U(r.reValidateMode),
                            V = r.criteriaMode === A.all,
                            k = e => t => {
                                clearTimeout(w), w = setTimeout(e, t)
                            },
                            D = async e => {
                                if (E.isValid || e) {
                                    let e = r.resolver ? C((await Y()).errors) : await q(a, !0);
                                    e !== i.isValid && _.state.next({
                                        isValid: e
                                    })
                                }
                            },
                            O = (e, t) => {
                                (E.isValidating || E.validatingFields) && ((e || Array.from(b.mount)).forEach(e => {
                                    e && (t ? S(i.validatingFields, e, t) : ed(i.validatingFields, e))
                                }), _.state.next({
                                    validatingFields: i.validatingFields,
                                    isValidating: !C(i.validatingFields)
                                }))
                            },
                            L = (e, t) => {
                                S(i.errors, e, t), _.state.next({
                                    errors: i.errors
                                })
                            },
                            N = (e, t, r, i) => {
                                let n = v(a, e);
                                if (n) {
                                    let s = v(c, e, g(r) ? v(h, e) : r);
                                    g(s) || i && i.defaultChecked || t ? S(c, e, t ? s : ew(n._f)) : J(e, s), x.mount && D()
                                }
                            },
                            I = (e, t, r, n, s) => {
                                let o = !1,
                                    l = !1,
                                    u = {
                                        name: e
                                    },
                                    d = !!(v(a, e) && v(a, e)._f && v(a, e)._f.disabled);
                                if (!r || n) {
                                    E.isDirty && (l = i.isDirty, i.isDirty = u.isDirty = Z(), o = l !== u.isDirty);
                                    let r = d || eg(v(h, e), t);
                                    l = !!(!d && v(i.dirtyFields, e)), r || d ? ed(i.dirtyFields, e) : S(i.dirtyFields, e, !0), u.dirtyFields = i.dirtyFields, o = o || E.dirtyFields && !r !== l
                                }
                                if (r) {
                                    let t = v(i.touchedFields, e);
                                    t || (S(i.touchedFields, e, r), u.touchedFields = i.touchedFields, o = o || E.touchedFields && t !== r)
                                }
                                return o && s && _.state.next(u), o ? u : {}
                            },
                            z = (r, n, s, o) => {
                                let a = v(i.errors, r),
                                    l = E.isValid && y(n) && i.isValid !== n;
                                if (e.delayError && s ? (t = k(() => L(r, s)))(e.delayError) : (clearTimeout(w), t = null, s ? S(i.errors, r, s) : ed(i.errors, r)), (s ? !eg(a, s) : a) || !C(o) || l) {
                                    let e = { ...o,
                                        ...l && y(n) ? {
                                            isValid: n
                                        } : {},
                                        errors: i.errors,
                                        name: r
                                    };
                                    i = { ...i,
                                        ...e
                                    }, _.state.next(e)
                                }
                            },
                            Y = async e => {
                                O(e, !0);
                                let t = await r.resolver(c, r.context, eE(e || b.mount, a, r.criteriaMode, r.shouldUseNativeValidation));
                                return O(e), t
                            },
                            K = async e => {
                                let {
                                    errors: t
                                } = await Y(e);
                                if (e)
                                    for (let r of e) {
                                        let e = v(t, r);
                                        e ? S(i.errors, r, e) : ed(i.errors, r)
                                    } else i.errors = t;
                                return t
                            },
                            q = async (e, t, n = {
                                valid: !0
                            }) => {
                                for (let s in e) {
                                    let o = e[s];
                                    if (o) {
                                        let {
                                            _f: e,
                                            ...a
                                        } = o;
                                        if (e) {
                                            let a = b.array.has(e.name);
                                            O([s], !0);
                                            let l = await ei(o, c, V, r.shouldUseNativeValidation && !t, a);
                                            if (O([s]), l[e.name] && (n.valid = !1, t)) break;
                                            t || (v(l, e.name) ? a ? $(i.errors, l, e.name) : S(i.errors, e.name, l[e.name]) : ed(i.errors, e.name))
                                        }
                                        C(a) || await q(a, t, n)
                                    }
                                }
                                return n.valid
                            },
                            Z = (e, t) => (e && t && S(c, e, t), !eg(eo(), h)),
                            Q = (e, t, r) => j(e, b, { ...x.mount ? c : g(t) ? h : F(e) ? {
                                    [e]: t
                                } : t
                            }, r, t),
                            J = (e, t, r = {}) => {
                                let i = v(a, e),
                                    s = t;
                                if (i) {
                                    let r = i._f;
                                    r && (r.disabled || S(c, e, eA(t, r)), s = G(r.ref) && o(t) ? "" : t, ev(r.ref) ? [...r.ref.options].forEach(e => e.selected = s.includes(e.value)) : r.refs ? n(r.ref) ? r.refs.length > 1 ? r.refs.forEach(e => (!e.defaultChecked || !e.disabled) && (e.checked = Array.isArray(s) ? !!s.find(t => t === e.value) : s === e.value)) : r.refs[0] && (r.refs[0].checked = !!s) : r.refs.forEach(e => e.checked = e.value === s) : X(r.ref) ? r.ref.value = "" : (r.ref.value = s, r.ref.type || _.values.next({
                                        name: e,
                                        values: { ...c
                                        }
                                    })))
                                }(r.shouldDirty || r.shouldTouch) && I(e, s, r.shouldTouch, r.shouldDirty, !0), r.shouldValidate && es(e)
                            },
                            ee = (e, t, r) => {
                                for (let i in t) {
                                    let n = t[i],
                                        o = `${e}.${i}`,
                                        l = v(a, o);
                                    !b.array.has(e) && em(n) && (!l || l._f) || s(n) ? J(o, n, r) : ee(o, n, r)
                                }
                            },
                            et = (e, t, r = {}) => {
                                let n = v(a, e),
                                    s = b.array.has(e),
                                    l = p(t);
                                S(c, e, l), s ? (_.array.next({
                                    name: e,
                                    values: { ...c
                                    }
                                }), (E.isDirty || E.dirtyFields) && r.shouldDirty && _.state.next({
                                    name: e,
                                    dirtyFields: eP(h, c),
                                    isDirty: Z(e, l)
                                })) : !n || n._f || o(l) ? J(e, l, r) : ee(e, l, r), B(e, b) && _.state.next({ ...i
                                }), _.values.next({
                                    name: x.mount ? e : void 0,
                                    values: { ...c
                                    }
                                })
                            },
                            er = async e => {
                                x.mount = !0;
                                let n = e.target,
                                    s = n.name,
                                    o = !0,
                                    l = v(a, s),
                                    h = e => {
                                        o = Number.isNaN(e) || e === v(c, s, e)
                                    };
                                if (l) {
                                    let d, f;
                                    let p = n.type ? ew(l._f) : u(e),
                                        m = e.type === P.BLUR || e.type === P.FOCUS_OUT,
                                        g = !eT(l._f) && !r.resolver && !v(i.errors, s) && !l._f.deps || eC(m, v(i.touchedFields, s), i.isSubmitted, R, T),
                                        y = B(s, b, m);
                                    S(c, s, p), m ? (l._f.onBlur && l._f.onBlur(e), t && t(0)) : l._f.onChange && l._f.onChange(e);
                                    let x = I(s, p, m, !1),
                                        A = !C(x) || y;
                                    if (m || _.values.next({
                                            name: s,
                                            type: e.type,
                                            values: { ...c
                                            }
                                        }), g) return E.isValid && D(), A && _.state.next({
                                        name: s,
                                        ...y ? {} : x
                                    });
                                    if (!m && y && _.state.next({ ...i
                                        }), r.resolver) {
                                        let {
                                            errors: e
                                        } = await Y([s]);
                                        if (h(p), o) {
                                            let t = eR(i.errors, a, s),
                                                r = eR(e, a, t.name || s);
                                            d = r.error, s = r.name, f = C(e)
                                        }
                                    } else O([s], !0), d = (await ei(l, c, V, r.shouldUseNativeValidation))[s], O([s]), h(p), o && (d ? f = !1 : E.isValid && (f = await q(a, !0)));
                                    o && (l._f.deps && es(l._f.deps), z(s, f, d, x))
                                }
                            },
                            en = (e, t) => {
                                if (v(i.errors, t) && e.focus) return e.focus(), 1
                            },
                            es = async (e, t = {}) => {
                                let n, s;
                                let o = M(e);
                                if (r.resolver) {
                                    let t = await K(g(e) ? e : o);
                                    n = C(t), s = e ? !o.some(e => v(t, e)) : n
                                } else e ? ((s = (await Promise.all(o.map(async e => {
                                    let t = v(a, e);
                                    return await q(t && t._f ? {
                                        [e]: t
                                    } : t)
                                }))).every(Boolean)) || i.isValid) && D() : s = n = await q(a);
                                return _.state.next({ ...!F(e) || E.isValid && n !== i.isValid ? {} : {
                                        name: e
                                    },
                                    ...r.resolver || !e ? {
                                        isValid: n
                                    } : {},
                                    errors: i.errors
                                }), t.shouldFocus && !s && W(a, en, e ? o : b.mount), s
                            },
                            eo = e => {
                                let t = { ...x.mount ? c : h
                                };
                                return g(e) ? t : F(e) ? v(t, e) : e.map(e => v(t, e))
                            },
                            ea = (e, t) => ({
                                invalid: !!v((t || i).errors, e),
                                isDirty: !!v((t || i).dirtyFields, e),
                                error: v((t || i).errors, e),
                                isValidating: !!v(i.validatingFields, e),
                                isTouched: !!v((t || i).touchedFields, e)
                            }),
                            el = (e, t, r) => {
                                let n = (v(a, e, {
                                        _f: {}
                                    })._f || {}).ref,
                                    {
                                        ref: s,
                                        message: o,
                                        type: l,
                                        ...u
                                    } = v(i.errors, e) || {};
                                S(i.errors, e, { ...u,
                                    ...t,
                                    ref: n
                                }), _.state.next({
                                    name: e,
                                    errors: i.errors,
                                    isValid: !1
                                }), r && r.shouldFocus && n && n.focus && n.focus()
                            },
                            eu = (e, t = {}) => {
                                for (let n of e ? M(e) : b.mount) b.mount.delete(n), b.array.delete(n), t.keepValue || (ed(a, n), ed(c, n)), t.keepError || ed(i.errors, n), t.keepDirty || ed(i.dirtyFields, n), t.keepTouched || ed(i.touchedFields, n), t.keepIsValidating || ed(i.validatingFields, n), r.shouldUnregister || t.keepDefaultValue || ed(h, n);
                                _.values.next({
                                    values: { ...c
                                    }
                                }), _.state.next({ ...i,
                                    ...t.keepDirty ? {
                                        isDirty: Z()
                                    } : {}
                                }), t.keepIsValid || D()
                            },
                            eh = ({
                                disabled: e,
                                name: t,
                                field: r,
                                fields: i,
                                value: n
                            }) => {
                                if (y(e) && x.mount || e) {
                                    let s = e ? void 0 : g(n) ? ew(r ? r._f : v(i, t)._f) : n;
                                    S(c, t, s), I(t, s, !1, !1, !0)
                                }
                            },
                            ec = (e, t = {}) => {
                                let i = v(a, e),
                                    n = y(t.disabled);
                                return S(a, e, { ...i || {},
                                    _f: { ...i && i._f ? i._f : {
                                            ref: {
                                                name: e
                                            }
                                        },
                                        name: e,
                                        mount: !0,
                                        ...t
                                    }
                                }), b.mount.add(e), i ? eh({
                                    field: i,
                                    disabled: t.disabled,
                                    name: e,
                                    value: t.value
                                }) : N(e, !0, t.value), { ...n ? {
                                        disabled: t.disabled
                                    } : {},
                                    ...r.progressive ? {
                                        required: !!t.required,
                                        min: e_(t.min),
                                        max: e_(t.max),
                                        minLength: e_(t.minLength),
                                        maxLength: e_(t.maxLength),
                                        pattern: e_(t.pattern)
                                    } : {},
                                    name: e,
                                    onChange: er,
                                    onBlur: er,
                                    ref: n => {
                                        if (n) {
                                            ec(e, t), i = v(a, e);
                                            let r = g(n.value) && n.querySelectorAll && n.querySelectorAll("input,select,textarea")[0] || n,
                                                s = ey(r),
                                                o = i._f.refs || [];
                                            (s ? o.find(e => e === r) : r === i._f.ref) || (S(a, e, {
                                                _f: { ...i._f,
                                                    ...s ? {
                                                        refs: [...o.filter(ex), r, ...Array.isArray(v(h, e)) ? [{}] : []],
                                                        ref: {
                                                            type: r.type,
                                                            name: e
                                                        }
                                                    } : {
                                                        ref: r
                                                    }
                                                }
                                            }), N(e, !1, void 0, r))
                                        } else(i = v(a, e, {}))._f && (i._f.mount = !1), (r.shouldUnregister || t.shouldUnregister) && !(d(b.array, e) && x.action) && b.unMount.add(e)
                                    }
                                }
                            },
                            ef = () => r.shouldFocusError && W(a, en, b.mount),
                            eb = (e, t) => async n => {
                                let s;
                                n && (n.preventDefault && n.preventDefault(), n.persist && n.persist());
                                let o = p(c);
                                if (_.state.next({
                                        isSubmitting: !0
                                    }), r.resolver) {
                                    let {
                                        errors: e,
                                        values: t
                                    } = await Y();
                                    i.errors = e, o = t
                                } else await q(a);
                                if (ed(i.errors, "root"), C(i.errors)) {
                                    _.state.next({
                                        errors: {}
                                    });
                                    try {
                                        await e(o, n)
                                    } catch (e) {
                                        s = e
                                    }
                                } else t && await t({ ...i.errors
                                }, n), ef(), setTimeout(ef);
                                if (_.state.next({
                                        isSubmitted: !0,
                                        isSubmitting: !1,
                                        isSubmitSuccessful: C(i.errors) && !s,
                                        submitCount: i.submitCount + 1,
                                        errors: i.errors
                                    }), s) throw s
                            },
                            eS = (t, r = {}) => {
                                let n = t ? p(t) : h,
                                    s = p(n),
                                    o = C(t),
                                    l = o ? h : s;
                                if (r.keepDefaultValues || (h = n), !r.keepValues) {
                                    if (r.keepDirtyValues)
                                        for (let e of b.mount) v(i.dirtyFields, e) ? S(l, e, v(c, e)) : et(e, v(l, e));
                                    else {
                                        if (f && g(t))
                                            for (let e of b.mount) {
                                                let t = v(a, e);
                                                if (t && t._f) {
                                                    let e = Array.isArray(t._f.refs) ? t._f.refs[0] : t._f.ref;
                                                    if (G(e)) {
                                                        let t = e.closest("form");
                                                        if (t) {
                                                            t.reset();
                                                            break
                                                        }
                                                    }
                                                }
                                            }
                                        a = {}
                                    }
                                    c = e.shouldUnregister ? r.keepDefaultValues ? p(h) : {} : p(l), _.array.next({
                                        values: { ...l
                                        }
                                    }), _.values.next({
                                        values: { ...l
                                        }
                                    })
                                }
                                b = {
                                    mount: r.keepDirtyValues ? b.mount : new Set,
                                    unMount: new Set,
                                    array: new Set,
                                    watch: new Set,
                                    watchAll: !1,
                                    focus: ""
                                }, x.mount = !E.isValid || !!r.keepIsValid || !!r.keepDirtyValues, x.watch = !!e.shouldUnregister, _.state.next({
                                    submitCount: r.keepSubmitCount ? i.submitCount : 0,
                                    isDirty: !o && (r.keepDirty ? i.isDirty : !!(r.keepDefaultValues && !eg(t, h))),
                                    isSubmitted: !!r.keepIsSubmitted && i.isSubmitted,
                                    dirtyFields: o ? {} : r.keepDirtyValues ? r.keepDefaultValues && c ? eP(h, c) : i.dirtyFields : r.keepDefaultValues && t ? eP(h, t) : r.keepDirty ? i.dirtyFields : {},
                                    touchedFields: r.keepTouched ? i.touchedFields : {},
                                    errors: r.keepErrors ? i.errors : {},
                                    isSubmitSuccessful: !!r.keepIsSubmitSuccessful && i.isSubmitSuccessful,
                                    isSubmitting: !1
                                })
                            },
                            ek = (e, t) => eS(H(e) ? e(c) : e, t);
                        return {
                            control: {
                                register: ec,
                                unregister: eu,
                                getFieldState: ea,
                                handleSubmit: eb,
                                setError: el,
                                _executeSchema: Y,
                                _getWatch: Q,
                                _getDirty: Z,
                                _updateValid: D,
                                _removeUnmounted: () => {
                                    for (let e of b.unMount) {
                                        let t = v(a, e);
                                        t && (t._f.refs ? t._f.refs.every(e => !ex(e)) : !ex(t._f.ref)) && eu(e)
                                    }
                                    b.unMount = new Set
                                },
                                _updateFieldArray: (e, t = [], r, n, s = !0, o = !0) => {
                                    if (n && r) {
                                        if (x.action = !0, o && Array.isArray(v(a, e))) {
                                            let t = r(v(a, e), n.argA, n.argB);
                                            s && S(a, e, t)
                                        }
                                        if (o && Array.isArray(v(i.errors, e))) {
                                            let t = r(v(i.errors, e), n.argA, n.argB);
                                            s && S(i.errors, e, t), eV(i.errors, e)
                                        }
                                        if (E.touchedFields && o && Array.isArray(v(i.touchedFields, e))) {
                                            let t = r(v(i.touchedFields, e), n.argA, n.argB);
                                            s && S(i.touchedFields, e, t)
                                        }
                                        E.dirtyFields && (i.dirtyFields = eP(h, c)), _.state.next({
                                            name: e,
                                            isDirty: Z(e, t),
                                            dirtyFields: i.dirtyFields,
                                            errors: i.errors,
                                            isValid: i.isValid
                                        })
                                    } else S(c, e, t)
                                },
                                _updateDisabledField: eh,
                                _getFieldArray: t => m(v(x.mount ? c : h, t, e.shouldUnregister ? v(h, t, []) : [])),
                                _reset: eS,
                                _resetDefaultValues: () => H(r.defaultValues) && r.defaultValues().then(e => {
                                    ek(e, r.resetOptions), _.state.next({
                                        isLoading: !1
                                    })
                                }),
                                _updateFormState: e => {
                                    i = { ...i,
                                        ...e
                                    }
                                },
                                _disableForm: e => {
                                    y(e) && (_.state.next({
                                        disabled: e
                                    }), W(a, (t, r) => {
                                        let i = v(a, r);
                                        i && (t.disabled = i._f.disabled || e, Array.isArray(i._f.refs) && i._f.refs.forEach(t => {
                                            t.disabled = i._f.disabled || e
                                        }))
                                    }, 0, !1))
                                },
                                _subjects: _,
                                _proxyFormState: E,
                                _setErrors: e => {
                                    i.errors = e, _.state.next({
                                        errors: i.errors,
                                        isValid: !1
                                    })
                                },
                                get _fields() {
                                    return a
                                },
                                get _formValues() {
                                    return c
                                },
                                get _state() {
                                    return x
                                },
                                set _state(value) {
                                    x = value
                                },
                                get _defaultValues() {
                                    return h
                                },
                                get _names() {
                                    return b
                                },
                                set _names(value) {
                                    b = value
                                },
                                get _formState() {
                                    return i
                                },
                                set _formState(value) {
                                    i = value
                                },
                                get _options() {
                                    return r
                                },
                                set _options(value) {
                                    r = { ...r,
                                        ...value
                                    }
                                }
                            },
                            trigger: es,
                            register: ec,
                            handleSubmit: eb,
                            watch: (e, t) => H(e) ? _.values.subscribe({
                                next: r => e(Q(void 0, t), r)
                            }) : Q(e, t, !0),
                            setValue: et,
                            getValues: eo,
                            reset: ek,
                            resetField: (e, t = {}) => {
                                v(a, e) && (g(t.defaultValue) ? et(e, p(v(h, e))) : (et(e, t.defaultValue), S(h, e, p(t.defaultValue))), t.keepTouched || ed(i.touchedFields, e), t.keepDirty || (ed(i.dirtyFields, e), i.isDirty = t.defaultValue ? Z(e, p(v(h, e))) : Z()), !t.keepError && (ed(i.errors, e), E.isValid && D()), _.state.next({ ...i
                                }))
                            },
                            clearErrors: e => {
                                e && M(e).forEach(e => ed(i.errors, e)), _.state.next({
                                    errors: e ? i.errors : {}
                                })
                            },
                            unregister: eu,
                            setError: el,
                            setFocus: (e, t = {}) => {
                                let r = v(a, e),
                                    i = r && r._f;
                                if (i) {
                                    let e = i.refs ? i.refs[0] : i.ref;
                                    e.focus && (e.focus(), t.shouldSelect && e.select())
                                }
                            },
                            getFieldState: ea
                        }
                    }(e),
                    formState: a
                });
                let c = t.current.control;
                return c._options = e, D({
                    subject: c._subjects.state,
                    next: e => {
                        V(e, c._proxyFormState, c._updateFormState, !0) && h({ ...c._formState
                        })
                    }
                }), i.useEffect(() => c._disableForm(e.disabled), [c, e.disabled]), i.useEffect(() => {
                    if (c._proxyFormState.isDirty) {
                        let e = c._getDirty();
                        e !== a.isDirty && c._subjects.state.next({
                            isDirty: e
                        })
                    }
                }, [c, a.isDirty]), i.useEffect(() => {
                    e.values && !eg(e.values, r.current) ? (c._reset(e.values, c._options.resetOptions), r.current = e.values, h(e => ({ ...e
                    }))) : c._resetDefaultValues()
                }, [e.values, c]), i.useEffect(() => {
                    e.errors && c._setErrors(e.errors)
                }, [e.errors, c]), i.useEffect(() => {
                    c._state.mount || (c._updateValid(), c._state.mount = !0), c._state.watch && (c._state.watch = !1, c._subjects.state.next({ ...c._formState
                    })), c._removeUnmounted()
                }), i.useEffect(() => {
                    e.shouldUnregister && c._subjects.values.next({
                        values: c._getWatch()
                    })
                }, [e.shouldUnregister, c]), t.current.formState = R(a, c), t.current
            }
        },
        77815: (e, t, r) => {
            "use strict";
            let i;
            r.d(t, {
                $G: () => T
            });
            var n = r(93264),
                s = r(58263);
            Object.create(null);
            let o = (...e) => {
                    console ? .warn && (f(e[0]) && (e[0] = `react-i18next:: ${e[0]}`), console.warn(...e))
                },
                a = {},
                l = (...e) => {
                    f(e[0]) && a[e[0]] || (f(e[0]) && (a[e[0]] = new Date), o(...e))
                },
                u = (e, t) => () => {
                    if (e.isInitialized) t();
                    else {
                        let r = () => {
                            setTimeout(() => {
                                e.off("initialized", r)
                            }, 0), t()
                        };
                        e.on("initialized", r)
                    }
                },
                h = (e, t, r) => {
                    e.loadNamespaces(t, u(e, r))
                },
                d = (e, t, r, i) => {
                    f(r) && (r = [r]), r.forEach(t => {
                        0 > e.options.ns.indexOf(t) && e.options.ns.push(t)
                    }), e.loadLanguages(t, u(e, i))
                },
                c = (e, t, r = {}) => t.languages && t.languages.length ? t.hasLoadedNamespace(e, {
                    lng: r.lng,
                    precheck: (t, i) => {
                        if (r.bindI18n ? .indexOf("languageChanging") > -1 && t.services.backendConnector.backend && t.isLanguageChangingTo && !i(t.isLanguageChangingTo, e)) return !1
                    }
                }) : (l("i18n.languages were undefined or empty", t.languages), !0),
                f = e => "string" == typeof e,
                p = e => "object" == typeof e && null !== e,
                m = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g,
                g = {
                    "&amp;": "&",
                    "&#38;": "&",
                    "&lt;": "<",
                    "&#60;": "<",
                    "&gt;": ">",
                    "&#62;": ">",
                    "&apos;": "'",
                    "&#39;": "'",
                    "&quot;": '"',
                    "&#34;": '"',
                    "&nbsp;": " ",
                    "&#160;": " ",
                    "&copy;": "\xa9",
                    "&#169;": "\xa9",
                    "&reg;": "\xae",
                    "&#174;": "\xae",
                    "&hellip;": "…",
                    "&#8230;": "…",
                    "&#x2F;": "/",
                    "&#47;": "/"
                },
                v = e => g[e],
                y = {
                    bindI18n: "languageChanged",
                    bindI18nStore: "",
                    transEmptyNodeValue: "",
                    transSupportBasicHtmlNodes: !0,
                    transWrapTextNodes: "",
                    transKeepBasicHtmlNodesFor: ["br", "strong", "i", "p"],
                    useSuspense: !0,
                    unescape: e => e.replace(m, v)
                },
                x = () => y,
                b = e => Array.isArray(e) ? e : [e],
                S = () => i,
                P = (0, n.createContext)();
            class A {
                constructor() {
                    this.usedNamespaces = {}
                }
                addUsedNamespaces(e) {
                    e.forEach(e => {
                        this.usedNamespaces[e] ? ? = !0
                    })
                }
                getUsedNamespaces() {
                    return Object.keys(this.usedNamespaces)
                }
            }
            let w = (e, t) => {
                    let r = (0, n.useRef)();
                    return (0, n.useEffect)(() => {
                        r.current = t ? r.current : e
                    }, [e, t]), r.current
                },
                E = (e, t, r, i) => e.getFixedT(t, r, i),
                _ = (e, t, r, i) => (0, n.useCallback)(E(e, t, r, i), [e, t, r, i]),
                T = (e, t = {}) => {
                    let {
                        i18n: r
                    } = t, {
                        i18n: i,
                        defaultNS: s
                    } = (0, n.useContext)(P) || {}, o = r || i || S();
                    if (o && !o.reportNamespaces && (o.reportNamespaces = new A), !o) {
                        l("You will need to pass in an i18next instance by using initReactI18next");
                        let e = (e, t) => f(t) ? t : p(t) && f(t.defaultValue) ? t.defaultValue : Array.isArray(e) ? e[e.length - 1] : e,
                            t = [e, {}, !1];
                        return t.t = e, t.i18n = {}, t.ready = !1, t
                    }
                    o.options.react ? .wait && l("It seems you are still using the old wait option, you may migrate to the new useSuspense behaviour.");
                    let a = { ...x(),
                            ...o.options.react,
                            ...t
                        },
                        {
                            useSuspense: u,
                            keyPrefix: m
                        } = a,
                        g = e || s || o.options ? .defaultNS;
                    g = f(g) ? [g] : g || ["translation"], o.reportNamespaces.addUsedNamespaces ? .(g);
                    let v = (o.isInitialized || o.initializedStoreOnce) && g.every(e => c(e, o, a)),
                        y = _(o, t.lng || null, "fallback" === a.nsMode ? g : g[0], m),
                        b = () => y,
                        T = () => E(o, t.lng || null, "fallback" === a.nsMode ? g : g[0], m),
                        [R, C] = (0, n.useState)(b),
                        V = g.join();
                    t.lng && (V = `${t.lng}${V}`);
                    let M = w(V),
                        k = (0, n.useRef)(!0);
                    (0, n.useEffect)(() => {
                        let {
                            bindI18n: e,
                            bindI18nStore: r
                        } = a;
                        k.current = !0, v || u || (t.lng ? d(o, t.lng, g, () => {
                            k.current && C(T)
                        }) : h(o, g, () => {
                            k.current && C(T)
                        })), v && M && M !== V && k.current && C(T);
                        let i = () => {
                            k.current && C(T)
                        };
                        return e && o ? .on(e, i), r && o ? .store.on(r, i), () => {
                            k.current = !1, o && e ? .split(" ").forEach(e => o.off(e, i)), r && o && r.split(" ").forEach(e => o.store.off(e, i))
                        }
                    }, [o, V]), (0, n.useEffect)(() => {
                        k.current && v && C(b)
                    }, [o, m, v]);
                    let D = [R, o, v];
                    if (D.t = R, D.i18n = o, D.ready = v, v || !v && !u) return D;
                    throw new Promise(e => {
                        t.lng ? d(o, t.lng, g, () => e()) : h(o, g, () => e())
                    })
                }
        }
    }
]);