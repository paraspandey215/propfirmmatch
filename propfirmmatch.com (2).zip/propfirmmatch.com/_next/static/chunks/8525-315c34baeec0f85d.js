"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8525], {
        57502: (e, a, r) => {
            r.r(a), r.d(a, {
                PropFirmSelectInline: () => c
            });
            var t = r(12428),
                d = r(35229),
                l = r(52029),
                n = r(57207),
                o = r(62993),
                i = r(70073),
                s = r(20860);

            function c(e) {
                let a = (0, s.r)(e.config, {
                    value: "single" === e.type ? e.value ? [e.value] : [] : e.value,
                    maxDefaultItems: e.itemsCount
                });
                if ("single" === e.type) {
                    var r;
                    return (0, t.jsx)(i.Ee, {
                        value: null !== (r = e.value) && void 0 !== r ? r : "",
                        onValueChange: e.onChange,
                        className: "space-y-2",
                        children: (0, t.jsx)("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
                            children: a.list.map(r => (0, t.jsxs)(n.$, {
                                value: r.id,
                                variant: "pfmCheckbox",
                                className: (0, o.cn)(a.list.length % 2 != 0 && e.itemsCount % 2 != 0 && "last:col-span-full"),
                                contentClassname: "py-1.5 px-2 text-sm justify-start space-x-2.5",
                                children: [(0, t.jsx)(l.L, {
                                    className: "rounded-full",
                                    firm: r
                                }), (0, t.jsx)("span", {
                                    children: r.name
                                })]
                            }, r.id))
                        })
                    })
                }
                return (0, t.jsx)("div", {
                    className: "grid grid-cols-2 gap-2",
                    children: a.list.map(r => {
                        var n;
                        return (0, t.jsxs)(d.aq, {
                            className: (0, o.cn)(a.list.length % 2 != 0 && e.itemsCount % 2 != 0 && "last:col-span-full"),
                            value: r.id,
                            onCheckedChange: a => {
                                if (a) {
                                    var t;
                                    let a = [...null !== (t = e.value) && void 0 !== t ? t : [], r.id].filter(e => e);
                                    e.onChange(e.max ? a.slice(-e.max) : a)
                                } else {
                                    let a = e.value.filter(e => e !== r.id);
                                    e.onChange(a.filter(e => e))
                                }
                            },
                            checked: (null !== (n = e.value) && void 0 !== n ? n : []).includes(r.id),
                            variant: "pfmCheckbox",
                            contentClassname: "py-1.5 px-2 text-sm justify-start space-x-2.5",
                            children: [(0, t.jsx)(l.L, {
                                className: "rounded-full",
                                firm: r
                            }), (0, t.jsx)("span", {
                                children: r.name
                            })]
                        }, r.id)
                    })
                })
            }
        },
        60654: (e, a, r) => {
            r.r(a), r.d(a, {
                PropFirmSelect: () => p
            });
            var t = r(12428),
                d = r(40850),
                l = r(33617),
                n = r(42619),
                o = r(52029),
                i = r(62993),
                s = r(71999),
                c = r(30455),
                u = r(93264),
                g = r(64608),
                m = r(20860);

            function f(e) {
                return (0, t.jsxs)("div", {
                    className: "flex items-center justify-start relative space-x-2.5 text-sm w-full",
                    children: [(0, t.jsx)(o.L, {
                        firm: e.item,
                        className: "rounded-md"
                    }), (0, t.jsx)("span", {
                        children: e.item.name
                    }), e.selected && (0, t.jsx)("div", {
                        className: "text-foreground-primary absolute right-0 top-1/2 transform -translate-y-1/2",
                        children: (0, t.jsx)(s.Z, {
                            className: "size-3"
                        })
                    })]
                })
            }

            function p(e) {
                var a;
                let [r, o] = (0, u.useState)(!1), [s, p] = (0, u.useState)(""), [v] = (0, g.Nr)(s, 300), b = (0, m.r)(e.config, {
                    value: "single" === e.type ? e.value ? [e.value] : [] : e.value,
                    search: v
                }), x = (0, u.useMemo)(() => {
                    var a;
                    if ("single" !== e.type || !e.value) return null;
                    let r = null === (a = b.selectedFirms) || void 0 === a ? void 0 : a[0];
                    return r ? (0, t.jsx)(f, {
                        item: r,
                        selected: !1
                    }) : null
                }, [b.selectedFirms, e.type, e.value]);
                return (0, t.jsxs)(n.J2, {
                    open: r,
                    onOpenChange: e => {
                        o(e), e || p("")
                    },
                    children: [(0, t.jsx)(n.xo, {
                        asChild: !0,
                        children: (0, t.jsxs)(d.zx, {
                            className: "w-full justify-between bg-background-secondary",
                            variant: "darkOutline",
                            children: [(0, t.jsx)("span", {
                                className: (0, i.cn)(("multiple" === e.type || !e.value) && "text-foreground-secondary"),
                                children: x || e.labels.placeholder
                            }), (0, t.jsx)("div", {
                                className: (0, i.cn)("transform transition-all", r && "rotate-180"),
                                children: (0, t.jsx)(c.Z, {
                                    className: "size-2.5"
                                })
                            })]
                        })
                    }), (0, t.jsx)(n.yk, {
                        align: "start",
                        children: (0, t.jsxs)(l.mY, {
                            className: "space-y-1",
                            children: [(0, t.jsx)(l.sZ, {
                                placeholder: e.labels.searchPlaceholder,
                                value: s,
                                onValueChange: p
                            }), (0, t.jsxs)(l.e8, {
                                children: [(0, t.jsx)(l.rb, {
                                    children: e.labels.emptyResult
                                }), (0, t.jsx)(l.fu, {
                                    children: null === (a = b.list) || void 0 === a ? void 0 : a.map(a => (0, t.jsx)(l.di, {
                                        className: "cursor-pointer",
                                        value: a.name,
                                        onSelect: () => {
                                            if ("single" === e.type) e.onChange(a.id), o(!1);
                                            else if (e.value.includes(a.id)) e.onChange(e.value.filter(e => e !== a.id));
                                            else {
                                                let r = [...e.value, a.id];
                                                e.max ? e.onChange(r.slice(-e.max)) : e.onChange(r)
                                            }
                                        },
                                        children: (0, t.jsx)(f, {
                                            item: a,
                                            selected: "single" === e.type ? a.id === e.value : e.value.includes(a.id)
                                        })
                                    }, a.id))
                                })]
                            })]
                        })
                    })]
                })
            }
        },
        93521: (e, a, r) => {
            r.r(a), r.d(a, {
                usePropFirmListApi: () => l
            });
            var t = r(93264),
                d = r(68448);

            function l(e) {
                let [a, r] = (0, t.useState)(null);
                return [a, (0, t.useCallback)(async a => {
                    let t = fetch("".concat(e.baseUrl, "/api/prop-firm/list"), {
                        method: "POST",
                        body: JSON.stringify(a)
                    }).then(e => e.json());
                    try {
                        let e = d.D.parse(await t);
                        r(e)
                    } catch (e) {
                        r(null)
                    }
                }, [e.baseUrl])]
            }
        },
        20860: (e, a, r) => {
            r.d(a, {
                r: () => l
            });
            var t = r(93264),
                d = r(93521);

            function l(e, a) {
                let [r, l] = (0, d.usePropFirmListApi)({
                    baseUrl: e.baseUrl
                }), [n, o] = (0, d.usePropFirmListApi)({
                    baseUrl: e.baseUrl
                }), i = (0, t.useMemo)(() => (null == r ? void 0 : r.data) ? a.value.filter(e => r.data.find(a => a.id === e)).map(e => r.data.find(a => a.id === e)) : [], [null == r ? void 0 : r.data, a.value]), s = (0, t.useMemo)(() => a.value.filter(e => e).filter(e => !i.some(a => a.id === e)), [a.value, i]), c = (0, t.useMemo)(() => {
                    var e;
                    return i.concat(null !== (e = null == n ? void 0 : n.data) && void 0 !== e ? e : [])
                }, [i, null == n ? void 0 : n.data]);
                (0, t.useEffect)(() => {
                    s.length && s.some(e => c.some(a => a.id === e)) && o({
                        firmIds: s
                    })
                }, [o, s, a.value, c]);
                let u = (0, t.useMemo)(() => {
                    var e;
                    let t = null !== (e = null == r ? void 0 : r.data) && void 0 !== e ? e : [],
                        d = a.maxDefaultItems ? t.slice(0, a.maxDefaultItems) : t,
                        l = c.filter(e => !d.some(a => a.id === e.id));
                    return d.concat(l)
                }, [null == r ? void 0 : r.data, a.maxDefaultItems, c]);
                return (0, t.useEffect)(() => {
                    l({
                        search: a.search
                    })
                }, [l, a.search]), {
                    selectedFirms: c,
                    list: u
                }
            }
        },
        68448: (e, a, r) => {
            r.d(a, {
                D: () => l
            });
            var t, d = r(95772);
            let l = d.z.object({
                data: d.z.object({
                    id: d.z.string(),
                    name: d.z.string(),
                    logo: d.z.string().nullable(),
                    logoBackgroundColor: d.z.object({
                        r: d.z.number(),
                        g: d.z.number(),
                        b: d.z.number(),
                        a: null === (t = d.z.number()) || void 0 === t ? void 0 : t.optional()
                    }).nullable(),
                    logoAltText: d.z.string().nullable()
                }).array()
            });
            d.z.object({
                search: d.z.string().optional(),
                firmIds: d.z.string().array().optional()
            }).optional().nullable()
        },
        95805: (e, a, r) => {
            r.d(a, {
                Avatar: () => o,
                AvatarImage: () => i,
                Q: () => s
            });
            var t = r(12428),
                d = r(93264),
                l = r(38001),
                n = r(62993);
            let o = d.forwardRef((e, a) => {
                let {
                    className: r,
                    ...d
                } = e;
                return (0, t.jsx)(l.fC, {
                    ref: a,
                    className: (0, n.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", r),
                    ...d
                })
            });
            o.displayName = l.fC.displayName;
            let i = d.forwardRef((e, a) => {
                let {
                    className: r,
                    ...d
                } = e;
                return (0, t.jsx)(l.Ee, {
                    ref: a,
                    className: (0, n.cn)("aspect-square h-full w-full", r),
                    ...d
                })
            });
            i.displayName = l.Ee.displayName;
            let s = d.forwardRef((e, a) => {
                let {
                    className: r,
                    ...d
                } = e;
                return (0, t.jsx)(l.NY, {
                    ref: a,
                    className: (0, n.cn)("flex h-full w-full items-center justify-center rounded-full bg-muted", r),
                    ...d
                })
            });
            s.displayName = l.NY.displayName
        },
        35229: (e, a, r) => {
            r.d(a, {
                aq: () => i
            });
            var t = r(12428),
                d = r(16335),
                l = r(93264),
                n = r(62993),
                o = r(43748);
            let i = l.forwardRef((e, a) => {
                let {
                    className: r,
                    children: l,
                    contentClassname: i,
                    ...s
                } = e;
                return (0, t.jsx)(o.G7, {
                    className: r,
                    variant: "pfmCheckbox",
                    asChild: !0,
                    children: (0, t.jsx)(d.fC, {
                        ref: a,
                        ...s,
                        children: (0, t.jsx)(o.MB, {
                            className: (0, n.cn)("py-2.5 px-4 tracking-normal", i),
                            children: l
                        })
                    })
                })
            });
            i.displayName = d.fC.displayName
        },
        33617: (e, a, r) => {
            r.d(a, {
                di: () => m,
                e8: () => c,
                fu: () => g,
                mY: () => i,
                rb: () => u,
                sZ: () => s
            });
            var t = r(12428),
                d = r(69126),
                l = r(66453),
                n = r(93264),
                o = r(62993);
            r(1456);
            let i = n.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.mY, {
                    ref: a,
                    className: (0, o.cn)("flex h-full w-full flex-col overflow-hidden rounded-md text-popover-foreground bg-background-secondary", r),
                    ...l
                })
            });
            i.displayName = d.mY.displayName;
            let s = n.forwardRef((e, a) => {
                let {
                    className: r,
                    wrapperClassname: n,
                    hideIcon: i,
                    ...s
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, o.cn)("px-4", n),
                    children: (0, t.jsxs)("div", {
                        className: "flex items-center border-b bg-background-tertiary rounded-md px-4 py-2.5",
                        "cmdk-input-wrapper": "",
                        children: [!i && (0, t.jsx)(l.Z, {
                            className: "mr-2 h-4 w-4 shrink-0 text-foreground-disabled"
                        }), (0, t.jsx)(d.mY.Input, {
                            ref: a,
                            className: (0, o.cn)("flex w-full rounded-md bg-background-tertiary text-sm outline-none placeholder:text-foreground-tertiary disabled:cursor-not-allowed disabled:opacity-50", r),
                            ...s
                        })]
                    })
                })
            });
            s.displayName = d.mY.Input.displayName;
            let c = n.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.mY.List, {
                    ref: a,
                    className: (0, o.cn)("max-h-[300px] overflow-y-auto overflow-x-hidden", r),
                    ...l
                })
            });
            c.displayName = d.mY.List.displayName;
            let u = n.forwardRef((e, a) => (0, t.jsx)(d.mY.Empty, {
                ref: a,
                className: "py-6 text-center text-sm",
                ...e
            }));
            u.displayName = d.mY.Empty.displayName;
            let g = n.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.mY.Group, {
                    ref: a,
                    className: (0, o.cn)("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", r),
                    ...l
                })
            });
            g.displayName = d.mY.Group.displayName, n.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.mY.Separator, {
                    ref: a,
                    className: (0, o.cn)("-mx-1 h-px bg-border", r),
                    ...l
                })
            }).displayName = d.mY.Separator.displayName;
            let m = n.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.mY.Item, {
                    ref: a,
                    className: (0, o.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-3 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected='true']:bg-background-tertiary data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50", r),
                    ...l
                })
            });
            m.displayName = d.mY.Item.displayName
        },
        1456: (e, a, r) => {
            r.d(a, {
                $N: () => h,
                Be: () => y,
                GG: () => m,
                Vq: () => c,
                a7: () => x,
                cN: () => b,
                cZ: () => p,
                fK: () => v,
                hg: () => u
            });
            var t = r(12428),
                d = r(45258),
                l = r(51699),
                n = r(25845),
                o = r(93264),
                i = r(62993);
            let s = (0, l.j)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-screen-md translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", {
                    variants: {
                        variant: {
                            default: "p-5",
                            bordered: "gap-0 [&_.dialog-body]:p-0 [&_.dialog-header]:p-5 [&_.dialog-header]:border-b [&_.dialog-header]:space-y-0 [&_.dialog-footer]:p-5 [&_.dialog-footer]:border-t"
                        },
                        size: {
                            xs: "max-w-screen-xs",
                            sm: "max-w-screen-sm",
                            default: "max-w-screen-md",
                            lg: "max-w-screen-lg",
                            xl: "max-w-screen-xl"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default"
                    }
                }),
                c = d.fC,
                u = d.xz,
                g = d.h_,
                m = d.x8,
                f = o.forwardRef((e, a) => {
                    let {
                        className: r,
                        ...l
                    } = e;
                    return (0, t.jsx)(d.aV, {
                        ref: a,
                        className: (0, i.cn)("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", r),
                        ...l
                    })
                });
            f.displayName = d.aV.displayName;
            let p = o.forwardRef((e, a) => {
                let {
                    className: r,
                    size: l = "default",
                    children: o,
                    variant: c,
                    hideCloseButton: u,
                    ...m
                } = e;
                return (0, t.jsx)(g, {
                    children: (0, t.jsx)(f, {
                        children: (0, t.jsxs)(d.VY, {
                            ref: a,
                            className: (0, i.cn)(s({
                                size: l,
                                variant: c
                            }), r),
                            ...m,
                            children: [o, !u && (0, t.jsxs)(d.x8, {
                                className: "absolute right-5 top-5 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
                                children: [(0, t.jsx)(n.Z, {
                                    className: "h-5 w-5 text-foreground-tertiary"
                                }), (0, t.jsx)("span", {
                                    className: "sr-only",
                                    children: "Close"
                                })]
                            })]
                        })
                    })
                })
            });
            p.displayName = d.VY.displayName;
            let v = e => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, i.cn)("flex flex-col space-y-1.5 text-left dialog-header pb-5", a),
                    ...r
                })
            };
            v.displayName = "DialogHeader";
            let b = e => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, i.cn)("flex justify-end space-x-4 dialog-footer", a),
                    ...r
                })
            };
            b.displayName = "DialogFooter";
            let x = e => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, t.jsx)("div", {
                    className: (0, i.cn)("dialog-body", a),
                    ...r
                })
            };
            x.displayName = "DialogBody";
            let h = o.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.Dx, {
                    ref: a,
                    className: (0, i.cn)("text-lg font-semibold leading-none tracking-tight", r),
                    ...l
                })
            });
            h.displayName = d.Dx.displayName;
            let y = o.forwardRef((e, a) => {
                let {
                    className: r,
                    ...l
                } = e;
                return (0, t.jsx)(d.dk, {
                    ref: a,
                    className: (0, i.cn)("text-sm text-muted-foreground", r),
                    ...l
                })
            });
            y.displayName = d.dk.displayName
        },
        43748: (e, a, r) => {
            r.d(a, {
                G7: () => s,
                MB: () => c
            });
            var t = r(12428),
                d = r(8190),
                l = r(51699),
                n = r(93264),
                o = r(62993);
            let i = (0, l.j)("group transition-colors bg-background-primary flex flex-col relative aria-checked:z-10", {
                    variants: {
                        variant: {
                            pfmSolid: "bg-[image:var(--pfm-gradient)]",
                            pfmPale: 'bg-[image:var(--pfm-gradient-10)] [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--pfm-gradient-10)]',
                            pfmPaleOutline: 'bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--pfm-gradient-10)]',
                            pfmPaleOutline40: 'bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--pfm-gradient-40)]',
                            pfm: 'bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-background',
                            pfmBlue: 'bg-[image:var(--pfm-blue-gradient)] p-px [&>div[data-role="background"]]:bg-background',
                            pfmBlueOutline: 'bg-[image:var(--pfm-blue-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--pfm-blue-gradient-10)]',
                            pfmPaleOutlineLight: 'bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-background/90 [&>div>div[data-role="content"]]:bg-[image:var(--pfm-gradient-10)]',
                            pfmDarkOutline: 'bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-background',
                            pfmCheckbox: 'bg-border aria-checked:bg-[image:var(--pfm-gradient)] p-px [&>div[data-role="background"]]:bg-border [&>div>div[data-role="content"]]:bg-background-secondary',
                            pfmBlueCheckbox: 'bg-border aria-checked:bg-[image:var(--pfm-blue-gradient)] p-px [&>div[data-role="background"]]:bg-border [&>div>div[data-role="content"]]:bg-background-secondary',
                            pfmGreenOrangeOutlineLight: 'bg-[image:var(--green-to-orange-gradient)] p-px [&>div[data-role="background"]]:bg-background/90 [&>div>div[data-role="content"]]:bg-[image:var(--green-to-orange-gradient-10)]',
                            pfmGreenOrangeOutline: 'bg-[image:var(--green-to-orange-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--green-to-orange-gradient-10)]',
                            dark: '[&>div[data-role="background"]]:bg-dark [&>div>div[data-role="content"]]:bg-dark [&>div>div[data-role="content"]]:text-foreground hover:[&>div[data-role="background"]]:bg-dark-hover hover:[&>div>div[data-role="content"]]:bg-dark-hover focus:[&>div[data-role="background"]]:bg-dark-focus focus:[&>div>div[data-role="content"]]:bg-dark-focus disabled:border-0',
                            green: '[&>div[data-role="background"]]:bg-green/30 [&>div>div[data-role="content"]]:text-green-theme',
                            yellow: '[&>div[data-role="background"]]:bg-yellow/30 [&>div>div[data-role="content"]]:text-yellow-foreground',
                            red: '[&>div[data-role="background"]]:bg-red/30 [&>div>div[data-role="content"]]:text-red-theme',
                            redOutline: 'p-px bg-red-theme [&>div[data-role="background"]]:bg-background/90',
                            pfoSolid: 'bg-[image:var(--pfo-gradient)] [&>div[data-role="background"]]:bg-transparent',
                            pfoPaleOutline: 'bg-[image:var(--pfo-gradient)] p-px [&>div[data-role="background"]]:bg-background [&>div>div[data-role="content"]]:bg-[image:var(--pfo-gradient-10)]',
                            pfoPaleOutlineLight: 'bg-[image:var(--pfo-gradient)] p-px [&>div[data-role="background"]]:bg-background/90 [&>div>div[data-role="content"]]:bg-[image:var(--pfo-gradient-10)]',
                            pfoCheckbox: 'bg-border aria-checked:bg-[image:var(--pfo-gradient)] p-px [&>div[data-role="background"]]:bg-border [&>div>div[data-role="content"]]:bg-background-secondary'
                        },
                        rounded: {
                            full: "rounded-full",
                            rounded: "rounded",
                            lg: "rounded-lg",
                            "2xl": "rounded-2xl"
                        }
                    },
                    defaultVariants: {
                        variant: "pfmSolid",
                        rounded: "full"
                    }
                }),
                s = (0, n.forwardRef)((e, a) => {
                    let {
                        children: r,
                        asChild: l,
                        variant: n,
                        rounded: s,
                        className: c,
                        ...u
                    } = e, g = l ? d.g7 : "div";
                    return (0, t.jsx)(g, {
                        ref: a,
                        className: (0, o.cn)(i({
                            variant: n,
                            rounded: s,
                            className: c
                        })),
                        ...u,
                        children: r
                    })
                });
            s.displayName = "GradientPill";
            let c = (0, n.forwardRef)((e, a) => {
                let {
                    children: r,
                    className: d,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    "data-role": "background",
                    className: "rounded-[inherit] group-aria-checked:bg-transparent transition-colors flex-1 flex flex-col w-full h-full",
                    children: (0, t.jsx)("div", {
                        ref: a,
                        ...l,
                        "data-role": "content",
                        className: (0, o.cn)("rounded-[inherit] transition-colors group-aria-checked:bg-background/90 group-disabled:cursor-not-allowed h-full w-full flex-1 flex items-center justify-center tracking-[0.5px] text-sm", d),
                        children: r
                    })
                })
            });
            c.displayName = "GradientPillContent", (0, n.forwardRef)((e, a) => {
                let {
                    children: r,
                    className: d,
                    ...l
                } = e;
                return (0, t.jsx)("div", {
                    ref: a,
                    ...l,
                    "data-role": "content",
                    className: (0, o.cn)("rounded-[inherit] transition-colors group-aria-checked:bg-background/90 group-disabled:cursor-not-allowed h-full w-full flex-1 flex items-center justify-center tracking-[0.5px] text-sm", d),
                    children: r
                })
            }).displayName = "GradientPillContentInner"
        },
        42619: (e, a, r) => {
            r.d(a, {
                J2: () => o,
                QH: () => c,
                xo: () => i,
                yk: () => s
            });
            var t = r(12428),
                d = r(86675),
                l = r(93264),
                n = r(62993);
            let o = d.fC,
                i = d.xz,
                s = l.forwardRef((e, a) => {
                    let {
                        className: r,
                        align: l = "center",
                        sideOffset: o = 4,
                        ...i
                    } = e;
                    return (0, t.jsx)(d.h_, {
                        children: (0, t.jsx)(d.VY, {
                            ref: a,
                            align: l,
                            sideOffset: o,
                            className: (0, n.cn)("z-50 max-h-[--radix-popover-content-available-height] p-4 rounded-md border bg-background-secondary text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", r),
                            ...i
                        })
                    })
                });
            s.displayName = d.VY.displayName;
            let c = d.Eh
        },
        52029: (e, a, r) => {
            r.d(a, {
                L: () => o
            });
            var t = r(12428),
                d = r(62993),
                l = r(32029),
                n = r(95805);

            function o(e) {
                var a, r;
                let {
                    firm: o,
                    className: i
                } = e, s = null !== (a = o.logoBackgroundColor) && void 0 !== a ? a : l.Dp;
                return (0, t.jsx)("div", {
                    className: (0, d.cn)("rounded-full size-6 border flex-none", i),
                    style: {
                        backgroundColor: "rgba(".concat(s.r, ", ").concat(s.g, ", ").concat(s.b, ", ").concat(s.a, ")")
                    },
                    children: o.logo ? (0, t.jsx)("img", {
                        src: o.logo,
                        alt: null !== (r = o.logoAltText) && void 0 !== r ? r : "Logo",
                        className: "w-full h-full object-contain rounded-[inherit]"
                    }) : (0, t.jsx)("div", {
                        className: "flex items-center justify-center",
                        children: (0, t.jsx)(n.Avatar, {
                            className: "size-5",
                            children: (0, t.jsx)(n.Q, {
                                title: o.name,
                                className: "text-xs",
                                children: o.name.substring(0, 2)
                            })
                        })
                    })
                })
            }
        },
        57207: (e, a, r) => {
            r.d(a, {
                $: () => i
            });
            var t = r(12428),
                d = r(70073),
                l = r(93264),
                n = r(62993),
                o = r(43748);
            let i = l.forwardRef((e, a) => {
                let {
                    className: r,
                    children: l,
                    variant: i,
                    contentClassname: s,
                    value: c,
                    ...u
                } = e;
                return (0, t.jsx)(o.G7, {
                    className: r,
                    variant: i,
                    asChild: !0,
                    children: (0, t.jsx)(d.ck, {
                        ref: a,
                        value: c,
                        ...u,
                        children: (0, t.jsx)(o.MB, {
                            className: (0, n.cn)("py-2.5 px-4 tracking-normal", s),
                            children: l
                        })
                    })
                })
            });
            i.displayName = d.ck.displayName
        }
    }
]);