(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8954], {
        56338: (e, t, r) => {
            "use strict";
            r.d(t, {
                ClientClerkProvider: () => R
            });
            var n = r(49433);
            r(22360);
            var i = r(93264),
                l = (0, i.createContext)(null),
                a = ((0, i.createContext)(null), r(47576)),
                o = r(59913),
                s = r(14026),
                u = r(68347),
                d = r(34103),
                c = r(123),
                _ = r(35301);
            let f = e => {
                    var t;
                    return null != window.__clerk_internal_navigations || (window.__clerk_internal_navigations = {}), null != (t = window.__clerk_internal_navigations)[e] || (t[e] = {}), window.__clerk_internal_navigations[e]
                },
                v = e => {
                    let {
                        windowNav: t,
                        routerNav: r,
                        name: n
                    } = e, l = (0, a.usePathname)(), [o, s] = (0, i.useTransition)();
                    t && (f(n).fun = (e, i) => new Promise(l => {
                        var a, o;
                        null != (a = f(n)).promisesBuffer || (a.promisesBuffer = []), null == (o = f(n).promisesBuffer) || o.push(l), s(() => {
                            var n, l, a;
                            (null == (n = null == i ? void 0 : i.__internal_metadata) ? void 0 : n.navigationType) === "internal" ? t((null != (a = null == (l = window.next) ? void 0 : l.version) ? a : "") < "14.1.0" ? history.state : null, "", e): r((0, _.m)(e))
                        })
                    }));
                    let u = () => {
                        var e;
                        null == (e = f(n).promisesBuffer) || e.forEach(e => e()), f(n).promisesBuffer = []
                    };
                    return (0, i.useEffect)(() => (u(), u), []), (0, i.useEffect)(() => {
                        o || u()
                    }, [l, o]), (0, i.useCallback)(e => f(n).fun(e), [])
                },
                p = () => {
                    let e = (0, a.useRouter)();
                    return v({
                        windowNav: "undefined" != typeof window ? window.history.pushState.bind(window.history) : void 0,
                        routerNav: e.push.bind(e),
                        name: "push"
                    })
                },
                E = () => {
                    let e = (0, a.useRouter)();
                    return v({
                        windowNav: "undefined" != typeof window ? window.history.replaceState.bind(window.history) : void 0,
                        routerNav: e.replace.bind(e),
                        name: "replace"
                    })
                },
                L = () => {
                    let e = (0, a.useRouter)(),
                        t = "undefined" != typeof window && window.next && window.next.version >= "14.1.0";
                    return {
                        mode: "path",
                        name: "NextRouter",
                        push: t => e.push(t),
                        replace: r => t ? window.history.replaceState(null, "", r) : e.replace(r),
                        shallowPush(r) {
                            t ? window.history.pushState(null, "", r) : e.push(r, {})
                        },
                        pathname: () => window.location.pathname,
                        searchParams: () => new URLSearchParams(window.location.search)
                    }
                },
                R = e => {
                    let {
                        __unstable_invokeMiddlewareOnAuthStateChange: t = !0,
                        children: r
                    } = e, _ = (0, a.useRouter)(), f = L(), v = p(), R = E(), [C, w] = (0, i.useTransition)();
                    if ((0, s.k)()) return e.children;
                    (0, i.useEffect)(() => {
                        var e;
                        C || null == (e = window.__clerk_internal_invalidateCachePromise) || e.call(window)
                    }, [C]), (0, o.G)(() => {
                        window.__unstable__onBeforeSetActive = () => new Promise(e => {
                            var t;
                            window.__clerk_internal_invalidateCachePromise = e, (null == (t = window.next) ? void 0 : t.version) && "string" == typeof window.next.version && window.next.version.startsWith("13") ? w(() => {
                                _.refresh()
                            }) : (0, c.T)().then(() => e())
                        }), window.__unstable__onAfterSetActive = () => {
                            if (t) return _.refresh()
                        }
                    }, []);
                    let I = (0, d.V)({ ...e,
                        __experimental_router: f,
                        routerPush: v,
                        routerReplace: R
                    });
                    return i.createElement(s.f, {
                        options: I
                    }, i.createElement(n.El, { ...I
                    }, i.createElement(u.z, {
                        router: "app"
                    }), i.createElement(l.Provider, {
                        value: f
                    }, r)))
                }
        },
        14026: (e, t, r) => {
            "use strict";
            r.d(t, {
                f: () => a,
                k: () => l
            });
            var n = r(93264);
            let i = n.createContext(void 0);
            i.displayName = "ClerkNextOptionsCtx";
            let l = () => {
                    let e = n.useContext(i);
                    return null == e ? void 0 : e.value
                },
                a = e => {
                    let {
                        children: t,
                        options: r
                    } = e;
                    return n.createElement(i.Provider, {
                        value: {
                            value: r
                        }
                    }, t)
                }
        },
        59913: (e, t, r) => {
            "use strict";
            r.d(t, {
                G: () => i
            });
            var n = r(93264);
            let i = "undefined" != typeof window ? n.useLayoutEffect : n.useEffect
        },
        68347: (e, t, r) => {
            "use strict";
            r.d(t, {
                z: () => s
            });
            var n = r(49433),
                i = r(33906),
                l = r(7990),
                a = r(93264),
                o = r(14026);

            function s(e) {
                let {
                    publishableKey: t,
                    clerkJSUrl: r,
                    clerkJSVersion: s,
                    clerkJSVariant: u,
                    nonce: d
                } = (0, o.k)(), {
                    domain: c,
                    proxyUrl: _
                } = (0, n.ll)(), f = {
                    domain: c,
                    proxyUrl: _,
                    publishableKey: t,
                    clerkJSUrl: r,
                    clerkJSVersion: s,
                    clerkJSVariant: u,
                    nonce: d
                }, v = (0, i.wE)(f), p = "app" === e.router ? "script" : l.default;
                return a.createElement(p, {
                    src: v,
                    "data-clerk-js-script": !0,
                    async: !0,
                    defer: "pages" !== e.router && void 0,
                    crossOrigin: "anonymous",
                    strategy: "pages" === e.router ? "beforeInteractive" : void 0,
                    ...(0, i.iv)(f)
                })
            }
        },
        34103: (e, t, r) => {
            "use strict";
            r.d(t, {
                V: () => u
            });
            var n = r(37695);
            r(22360);
            var i = r(72369),
                l = r(6598),
                a = r(32608);
            a.env.NEXT_PUBLIC_CLERK_JS_VERSION, a.env.NEXT_PUBLIC_CLERK_JS_URL, a.env.CLERK_API_VERSION, a.env.CLERK_SECRET_KEY, a.env.CLERK_ENCRYPTION_KEY, a.env.CLERK_API_URL || (e => {
                var t;
                let r = null == (t = (0, i.nQ)(e)) ? void 0 : t.frontendApi;
                return (null == r ? void 0 : r.startsWith("clerk.")) && l.mv.some(e => null == r ? void 0 : r.endsWith(e)) ? l.Xv : l.iF.some(e => null == r ? void 0 : r.endsWith(e)) ? l.Fo : l.cM.some(e => null == r ? void 0 : r.endsWith(e)) ? l.Iq : l.Xv
            })("pk_live_Y2xlcmsucHJvcGZpcm1tYXRjaC5jb20k"), a.env.NEXT_PUBLIC_CLERK_DOMAIN, a.env.NEXT_PUBLIC_CLERK_PROXY_URL, (0, n.fQ)(a.env.NEXT_PUBLIC_CLERK_IS_SATELLITE), a.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL, a.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL;
            let o = {
                name: "@clerk/nextjs",
                version: "6.1.3",
                environment: "production"
            };
            (0, n.fQ)(a.env.NEXT_PUBLIC_CLERK_TELEMETRY_DISABLED), (0, n.fQ)(a.env.NEXT_PUBLIC_CLERK_TELEMETRY_DEBUG);
            var s = r(32608);
            let u = e => {
                var t;
                return { ...e,
                    publishableKey: e.publishableKey || "pk_live_Y2xlcmsucHJvcGZpcm1tYXRjaC5jb20k",
                    clerkJSUrl: e.clerkJSUrl || s.env.NEXT_PUBLIC_CLERK_JS_URL,
                    clerkJSVersion: e.clerkJSVersion || s.env.NEXT_PUBLIC_CLERK_JS_VERSION,
                    proxyUrl: e.proxyUrl || s.env.NEXT_PUBLIC_CLERK_PROXY_URL || "",
                    domain: e.domain || s.env.NEXT_PUBLIC_CLERK_DOMAIN || "",
                    isSatellite: e.isSatellite || (0, n.fQ)(s.env.NEXT_PUBLIC_CLERK_IS_SATELLITE),
                    signInUrl: e.signInUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || "",
                    signUpUrl: e.signUpUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || "",
                    signInForceRedirectUrl: e.signInForceRedirectUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_IN_FORCE_REDIRECT_URL || "",
                    signUpForceRedirectUrl: e.signUpForceRedirectUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_UP_FORCE_REDIRECT_URL || "",
                    signInFallbackRedirectUrl: e.signInFallbackRedirectUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_IN_FALLBACK_REDIRECT_URL || "",
                    signUpFallbackRedirectUrl: e.signUpFallbackRedirectUrl || s.env.NEXT_PUBLIC_CLERK_SIGN_UP_FALLBACK_REDIRECT_URL || "",
                    afterSignInUrl: e.afterSignInUrl || s.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL || "",
                    afterSignUpUrl: e.afterSignUpUrl || s.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL || "",
                    telemetry: null != (t = e.telemetry) ? t : {
                        disabled: (0, n.fQ)(s.env.NEXT_PUBLIC_CLERK_TELEMETRY_DISABLED),
                        debug: (0, n.fQ)(s.env.NEXT_PUBLIC_CLERK_TELEMETRY_DEBUG)
                    },
                    sdkMetadata: o
                }
            }
        },
        35301: (e, t, r) => {
            "use strict";

            function n(e) {
                return e
            }
            r.d(t, {
                m: () => n
            })
        },
        91297: (e, t, r) => {
            e.exports = r(10680)
        },
        7990: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                default: () => i.a
            });
            var n = r(88227),
                i = r.n(n),
                l = {};
            for (let e in n) "default" !== e && (l[e] = () => n[e]);
            r.d(t, l)
        },
        39034: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    callServer: function() {
                        return n.callServer
                    },
                    createServerReference: function() {
                        return l
                    },
                    findSourceMapURL: function() {
                        return i.findSourceMapURL
                    }
                });
            let n = r(41877),
                i = r(85247),
                l = r(52143).createServerReference
        },
        10680: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "useRouter", {
                enumerable: !0,
                get: function() {
                    return l
                }
            });
            let n = r(93264),
                i = r(5519);

            function l() {
                return (0, n.useContext)(i.RouterContext)
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        88227: (e, t, r) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    default: function() {
                        return R
                    },
                    handleClientScriptLoad: function() {
                        return p
                    },
                    initScriptLoader: function() {
                        return E
                    }
                });
            let n = r(81838),
                i = r(86077),
                l = r(12428),
                a = n._(r(36720)),
                o = i._(r(93264)),
                s = r(43568),
                u = r(78792),
                d = r(56214),
                c = new Map,
                _ = new Set,
                f = e => {
                    if (a.default.preinit) {
                        e.forEach(e => {
                            a.default.preinit(e, {
                                as: "style"
                            })
                        });
                        return
                    }
                    if ("undefined" != typeof window) {
                        let t = document.head;
                        e.forEach(e => {
                            let r = document.createElement("link");
                            r.type = "text/css", r.rel = "stylesheet", r.href = e, t.appendChild(r)
                        })
                    }
                },
                v = e => {
                    let {
                        src: t,
                        id: r,
                        onLoad: n = () => {},
                        onReady: i = null,
                        dangerouslySetInnerHTML: l,
                        children: a = "",
                        strategy: o = "afterInteractive",
                        onError: s,
                        stylesheets: d
                    } = e, v = r || t;
                    if (v && _.has(v)) return;
                    if (c.has(t)) {
                        _.add(v), c.get(t).then(n, s);
                        return
                    }
                    let p = () => {
                            i && i(), _.add(v)
                        },
                        E = document.createElement("script"),
                        L = new Promise((e, t) => {
                            E.addEventListener("load", function(t) {
                                e(), n && n.call(this, t), p()
                            }), E.addEventListener("error", function(e) {
                                t(e)
                            })
                        }).catch(function(e) {
                            s && s(e)
                        });
                    l ? (E.innerHTML = l.__html || "", p()) : a ? (E.textContent = "string" == typeof a ? a : Array.isArray(a) ? a.join("") : "", p()) : t && (E.src = t, c.set(t, L)), (0, u.setAttributesFromProps)(E, e), "worker" === o && E.setAttribute("type", "text/partytown"), E.setAttribute("data-nscript", o), d && f(d), document.body.appendChild(E)
                };

            function p(e) {
                let {
                    strategy: t = "afterInteractive"
                } = e;
                "lazyOnload" === t ? window.addEventListener("load", () => {
                    (0, d.requestIdleCallback)(() => v(e))
                }) : v(e)
            }

            function E(e) {
                e.forEach(p), [...document.querySelectorAll('[data-nscript="beforeInteractive"]'), ...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e => {
                    let t = e.id || e.getAttribute("src");
                    _.add(t)
                })
            }

            function L(e) {
                let {
                    id: t,
                    src: r = "",
                    onLoad: n = () => {},
                    onReady: i = null,
                    strategy: u = "afterInteractive",
                    onError: c,
                    stylesheets: f,
                    ...p
                } = e, {
                    updateScripts: E,
                    scripts: L,
                    getIsSsr: R,
                    appDir: C,
                    nonce: w
                } = (0, o.useContext)(s.HeadManagerContext), I = (0, o.useRef)(!1);
                (0, o.useEffect)(() => {
                    let e = t || r;
                    I.current || (i && e && _.has(e) && i(), I.current = !0)
                }, [i, t, r]);
                let h = (0, o.useRef)(!1);
                if ((0, o.useEffect)(() => {
                        !h.current && ("afterInteractive" === u ? v(e) : "lazyOnload" === u && ("complete" === document.readyState ? (0, d.requestIdleCallback)(() => v(e)) : window.addEventListener("load", () => {
                            (0, d.requestIdleCallback)(() => v(e))
                        })), h.current = !0)
                    }, [e, u]), ("beforeInteractive" === u || "worker" === u) && (E ? (L[u] = (L[u] || []).concat([{
                        id: t,
                        src: r,
                        onLoad: n,
                        onReady: i,
                        onError: c,
                        ...p
                    }]), E(L)) : R && R() ? _.add(t || r) : R && !R() && v(e)), C) {
                    if (f && f.forEach(e => {
                            a.default.preinit(e, {
                                as: "style"
                            })
                        }), "beforeInteractive" === u) return r ? (a.default.preload(r, p.integrity ? {
                        as: "script",
                        integrity: p.integrity,
                        nonce: w,
                        crossOrigin: p.crossOrigin
                    } : {
                        as: "script",
                        nonce: w,
                        crossOrigin: p.crossOrigin
                    }), (0, l.jsx)("script", {
                        nonce: w,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([r, { ...p,
                                id: t
                            }]) + ")"
                        }
                    })) : (p.dangerouslySetInnerHTML && (p.children = p.dangerouslySetInnerHTML.__html, delete p.dangerouslySetInnerHTML), (0, l.jsx)("script", {
                        nonce: w,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([0, { ...p,
                                id: t
                            }]) + ")"
                        }
                    }));
                    "afterInteractive" === u && r && a.default.preload(r, p.integrity ? {
                        as: "script",
                        integrity: p.integrity,
                        nonce: w,
                        crossOrigin: p.crossOrigin
                    } : {
                        as: "script",
                        nonce: w,
                        crossOrigin: p.crossOrigin
                    })
                }
                return null
            }
            Object.defineProperty(L, "__nextScript", {
                value: !0
            });
            let R = L;
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        78792: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "setAttributesFromProps", {
                enumerable: !0,
                get: function() {
                    return l
                }
            });
            let r = {
                    acceptCharset: "accept-charset",
                    className: "class",
                    htmlFor: "for",
                    httpEquiv: "http-equiv",
                    noModule: "noModule"
                },
                n = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];

            function i(e) {
                return ["async", "defer", "noModule"].includes(e)
            }

            function l(e, t) {
                for (let [l, a] of Object.entries(t)) {
                    if (!t.hasOwnProperty(l) || n.includes(l) || void 0 === a) continue;
                    let o = r[l] || l.toLowerCase();
                    "SCRIPT" === e.tagName && i(o) ? e[o] = !!a : e.setAttribute(o, String(a)), (!1 === a || "SCRIPT" === e.tagName && i(o) && (!a || "false" === a)) && (e.setAttribute(o, ""), e.removeAttribute(o))
                }
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        33906: (e, t, r) => {
            "use strict";
            r.d(t, {
                Aw: () => i.Aw,
                EJ: () => l,
                JM: () => n.JM,
                aw: () => n.aw,
                iv: () => i.iv,
                wE: () => i.wE
            });
            var n = r(30269),
                i = r(87914);

            function l(e, t, r) {
                let i = t.path || (null == r ? void 0 : r.path);
                return "path" === (t.routing || (null == r ? void 0 : r.routing) || "path") ? i ? { ...r,
                    ...t,
                    routing: "path"
                } : n.RM.throw((0, n.Gv)(e)) : t.path ? n.RM.throw((0, n.RE)(e)) : { ...r,
                    ...t,
                    path: void 0
                }
            }
        }
    }
]);