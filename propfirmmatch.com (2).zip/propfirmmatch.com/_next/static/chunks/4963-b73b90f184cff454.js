"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4963], {
        77105: (e, s, l) => {
            l.d(s, {
                HomepageFooter: () => u
            });
            var t = l(12428),
                c = l(67345),
                r = l(57917),
                a = l(54495),
                i = l(9855),
                n = l(91023),
                o = l(6185),
                p = l(98661),
                h = l(97385),
                m = l(3934);

            function d(e) {
                return (0, t.jsx)("p", {
                    className: "text-sm font-semibold uppercase",
                    children: e.children
                })
            }

            function x(e) {
                return (0, t.jsx)("p", {
                    className: "text-sm text-foreground-secondary",
                    children: (0, t.jsx)(m.default, {
                        href: e.href,
                        className: "hover:underline",
                        children: e.children
                    })
                })
            }
            let f = e => (0, t.jsxs)("div", {
                className: "space-y-4 pb-8",
                children: [(0, t.jsx)(d, {
                    children: e.category.label
                }), e.category.items.map((s, l) => (0, t.jsx)(x, {
                    href: s.href,
                    children: s.label
                }, "".concat(e.category.label, "-").concat(l)))]
            });

            function u() {
                let {
                    t: e
                } = (0, o.$G)(), s = (0, p.mM)(), l = [{
                    label: e("Prop Firms"),
                    items: [{
                        label: e("All Prop Firms"),
                        href: "/all-prop-firms"
                    }, {
                        label: e("Compare Challenges"),
                        href: "/prop-firm-challenges"
                    }, {
                        label: e("Best Sellers"),
                        href: "/best-sellers"
                    }, {
                        label: e("Favorite Firms"),
                        href: "/favorite-firms"
                    }, {
                        label: e("Announcements"),
                        href: "/prop-firm-announcements"
                    }, {
                        label: e("Prop Firm Rules"),
                        href: "/prop-firm-rules"
                    }, {
                        label: e("Reviews"),
                        href: "/reviews"
                    }, {
                        label: e("Demo Accounts"),
                        href: "/prop-firm-demo-accounts"
                    }, {
                        label: e("Unlisted Firms"),
                        href: "/unlisted-firms"
                    }]
                }, {
                    label: e("Offers"),
                    items: [{
                        label: e("Exclusive Offers"),
                        href: "/exclusive-offers"
                    }, {
                        label: e("Extra Account Promo"),
                        href: "/extra-account-promo"
                    }, {
                        label: e("All Current Offers"),
                        href: "/offers"
                    }]
                }, {
                    label: e("Resources"),
                    items: [{
                        label: e("High Impact News"),
                        href: "/high-impact-news"
                    }, {
                        label: e("Blog"),
                        href: "/blog"
                    }, {
                        label: e("Prop Firm Features"),
                        href: "/prop-firm-lists"
                    }]
                }, {
                    label: e("Programs"),
                    items: [{
                        label: e("Loyalty Program"),
                        href: "/loyalty-program"
                    }, {
                        label: e("Affiliate Program"),
                        href: "/join-affiliate-program"
                    }]
                }, {
                    label: e("Company"),
                    items: [{
                        label: e("About Us"),
                        href: "/about-us"
                    }, {
                        label: e("Careers"),
                        href: "/"
                    }, {
                        label: e("Prop Firm Business"),
                        href: s.NEXT_PUBLIC_BUSINESS_WEBSITE_URL
                    }, {
                        label: e("Press"),
                        href: "/press"
                    }, {
                        label: e("Sitemap"),
                        href: "/"
                    }]
                }, {
                    label: e("Get Help"),
                    items: [{
                        label: e("Contact Us"),
                        href: "/contact"
                    }, {
                        label: e("How it Works"),
                        href: "/how-it-works"
                    }, {
                        label: e("Status"),
                        href: "/"
                    }]
                }];
                return (0, t.jsxs)("div", {
                    className: "space-y-4",
                    children: [(0, t.jsxs)("div", {
                        className: "relative pl-[76px] md:pl-[230px]",
                        children: [(0, t.jsx)("div", {
                            className: "absolute top-0 left-0",
                            children: (0, t.jsx)(r.PFMLogo, {})
                        }), (0, t.jsxs)("div", {
                            className: "grid gap-4 xs:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
                            children: [(0, t.jsx)("div", {
                                className: "space-y-4",
                                children: l.slice(0, 1).map(e => (0, t.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, t.jsx)("div", {
                                className: "space-y-4",
                                children: l.slice(1, 3).map(e => (0, t.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, t.jsx)("div", {
                                className: "space-y-4",
                                children: l.slice(3, 5).map(e => (0, t.jsx)(f, {
                                    category: e
                                }, e.label))
                            }), (0, t.jsx)("div", {
                                className: "space-y-4",
                                children: l.slice(5, 6).map(e => (0, t.jsx)(f, {
                                    category: e
                                }, e.label))
                            })]
                        })]
                    }), (0, t.jsxs)("div", {
                        children: [(0, t.jsx)(h.Separator, {
                            className: "flex w-full h-px bg-border-disabled"
                        }), (0, t.jsxs)("div", {
                            className: "flex flex-col-reverse space-y-4 md:space-y-0 md:flex-row items-center justify-between text-xs text-foreground-secondary md:px-4 xl:px-0 py-5 md:py-10",
                            children: [(0, t.jsxs)("div", {
                                className: "flex flex-col-reverse md:flex-row",
                                children: [(0, t.jsxs)("p", {
                                    className: "pt-2 md:pt-0",
                                    children: ["\xa9\xa0", new Date().getFullYear(), "\xa0", e("Prop Firm Match. All rights reserved.")]
                                }), (0, t.jsxs)("div", {
                                    className: "flex items-center space-x-8 mt-4 md:mt-0 md:ml-4 md:pl-4 md:border-l",
                                    children: [(0, t.jsx)(m.default, {
                                        href: "/privacy-policy",
                                        className: "box-content cursor-pointer hover:underline",
                                        target: "_blank",
                                        children: e("Privacy Policy")
                                    }), (0, t.jsx)(m.default, {
                                        href: "/terms-and-conditions",
                                        className: "box-content cursor-pointer hover:underline",
                                        target: "_blank",
                                        children: e("Terms & Conditions")
                                    })]
                                })]
                            }), (0, t.jsxs)("div", {
                                className: "flex items-center space-x-4 xl:space-x-7",
                                children: [(0, t.jsx)(i.u, {}), (0, t.jsx)(c.C, {
                                    className: "w-6 h-6"
                                }), (0, t.jsx)(n.V, {}), (0, t.jsx)(a.r, {})]
                            })]
                        })]
                    })]
                })
            }
        },
        91192: (e, s, l) => {
            l.d(s, {
                TrustpilotCarousel: () => v
            });
            var t = l(12428),
                c = l(6185),
                r = l(31077),
                a = l(32709);

            function i(e) {
                return (0, t.jsxs)("svg", {
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    x: "0px",
                    y: "0px",
                    viewBox: "0 0 1132.8 278.2",
                    xmlSpace: "preserve",
                    className: e.className,
                    children: [(0, t.jsx)("g", {
                        id: "Type",
                        children: (0, t.jsx)("g", {
                            children: (0, t.jsx)("path", {
                                fill: "currentColor",
                                d: "M297.7,98.6h114.7V120h-45.1v120.3h-24.8V120h-44.9V98.6z M407.5,137.7h21.2v19.8h0.4c0.7-2.8,2-5.5,3.9-8.1 c1.9-2.6,4.2-5.1,6.9-7.2c2.7-2.2,5.7-3.9,9-5.3c3.3-1.3,6.7-2,10.1-2c2.6,0,4.5,0.1,5.5,0.2c1,0.1,2,0.3,3.1,0.4v21.8 c-1.6-0.3-3.2-0.5-4.9-0.7c-1.7-0.2-3.3-0.3-4.9-0.3c-3.8,0-7.4,0.8-10.8,2.3c-3.4,1.5-6.3,3.8-8.8,6.7c-2.5,3-4.5,6.6-6,11 c-1.5,4.4-2.2,9.4-2.2,15.1v48.8h-22.6V137.7z M571.5,240.3h-22.2V226h-0.4c-2.8,5.2-6.9,9.3-12.4,12.4 c-5.5,3.1-11.1,4.7-16.8,4.7c-13.5,0-23.3-3.3-29.3-10c-6-6.7-9-16.8-9-30.3v-65.1H504v62.9c0,9,1.7,15.4,5.2,19.1 c3.4,3.7,8.3,5.6,14.5,5.6c4.8,0,8.7-0.7,11.9-2.2c3.2-1.5,5.8-3.4,7.7-5.9c2-2.4,3.4-5.4,4.3-8.8c0.9-3.4,1.3-7.1,1.3-11.1v-59.5 h22.6V240.3z M610,207.4c0.7,6.6,3.2,11.2,7.5,13.9c4.4,2.6,9.6,4,15.7,4c2.1,0,4.5-0.2,7.2-0.5c2.7-0.3,5.3-1,7.6-1.9 c2.4-0.9,4.3-2.3,5.9-4.1c1.5-1.8,2.2-4.1,2.1-7c-0.1-2.9-1.2-5.3-3.2-7.1c-2-1.9-4.5-3.3-7.6-4.5c-3.1-1.1-6.6-2.1-10.6-2.9 c-4-0.8-8-1.7-12.1-2.6c-4.2-0.9-8.3-2.1-12.2-3.4c-3.9-1.3-7.4-3.1-10.5-5.4c-3.1-2.2-5.6-5.1-7.4-8.6c-1.9-3.5-2.8-7.8-2.8-13 c0-5.6,1.4-10.2,4.1-14c2.7-3.8,6.2-6.8,10.3-9.1c4.2-2.3,8.8-3.9,13.9-4.9c5.1-0.9,10-1.4,14.6-1.4c5.3,0,10.4,0.6,15.2,1.7 c4.8,1.1,9.2,2.9,13.1,5.5c3.9,2.5,7.1,5.8,9.7,9.8c2.6,4,4.2,8.9,4.9,14.6h-23.6c-1.1-5.4-3.5-9.1-7.4-10.9 c-3.9-1.9-8.4-2.8-13.4-2.8c-1.6,0-3.5,0.1-5.7,0.4c-2.2,0.3-4.2,0.8-6.2,1.5c-1.9,0.7-3.5,1.8-4.9,3.2c-1.3,1.4-2,3.2-2,5.5 c0,2.8,1,5,2.9,6.7c1.9,1.7,4.4,3.1,7.5,4.3c3.1,1.1,6.6,2.1,10.6,2.9c4,0.8,8.1,1.7,12.3,2.6c4.1,0.9,8.1,2.1,12.1,3.4 c4,1.3,7.5,3.1,10.6,5.4c3.1,2.3,5.6,5.1,7.5,8.5c1.9,3.4,2.9,7.7,2.9,12.7c0,6.1-1.4,11.2-4.2,15.5c-2.8,4.2-6.4,7.7-10.8,10.3 c-4.4,2.6-9.4,4.6-14.8,5.8c-5.4,1.2-10.8,1.8-16.1,1.8c-6.5,0-12.5-0.7-18-2.2c-5.5-1.5-10.3-3.7-14.3-6.6c-4-3-7.2-6.7-9.5-11.1 c-2.3-4.4-3.5-9.7-3.7-15.8H610z M684.6,137.7h17.1v-30.8h22.6v30.8h20.4v16.9h-20.4v54.8c0,2.4,0.1,4.4,0.3,6.2 c0.2,1.7,0.7,3.2,1.4,4.4c0.7,1.2,1.8,2.1,3.3,2.7c1.5,0.6,3.4,0.9,6,0.9c1.6,0,3.2,0,4.8-0.1c1.6-0.1,3.2-0.3,4.8-0.7v17.5 c-2.5,0.3-5,0.5-7.3,0.8c-2.4,0.3-4.8,0.4-7.3,0.4c-6,0-10.8-0.6-14.4-1.7c-3.6-1.1-6.5-2.8-8.5-5c-2.1-2.2-3.4-4.9-4.2-8.2 c-0.7-3.3-1.2-7.1-1.3-11.3v-60.5h-17.1V137.7z M760.7,137.7h21.4v13.9h0.4c3.2-6,7.6-10.2,13.3-12.8c5.7-2.6,11.8-3.9,18.5-3.9 c8.1,0,15.1,1.4,21.1,4.3c6,2.8,11,6.7,15,11.7c4,5,6.9,10.8,8.9,17.4c2,6.6,3,13.7,3,21.2c0,6.9-0.9,13.6-2.7,20 c-1.8,6.5-4.5,12.2-8.1,17.2c-3.6,5-8.2,8.9-13.8,11.9c-5.6,3-12.1,4.5-19.7,4.5c-3.3,0-6.6-0.3-9.9-0.9c-3.3-0.6-6.5-1.6-9.5-2.9 c-3-1.3-5.9-3-8.4-5.1c-2.6-2.1-4.7-4.5-6.5-7.2h-0.4v51.2h-22.6V137.7z M839.7,189.1c0-4.6-0.6-9.1-1.8-13.5 c-1.2-4.4-3-8.2-5.4-11.6c-2.4-3.4-5.4-6.1-8.9-8.1c-3.6-2-7.7-3.1-12.3-3.1c-9.5,0-16.7,3.3-21.5,9.9c-4.8,6.6-7.2,15.4-7.2,26.4 c0,5.2,0.6,10,1.9,14.4c1.3,4.4,3.1,8.2,5.7,11.4c2.5,3.2,5.5,5.7,9,7.5c3.5,1.9,7.6,2.8,12.2,2.8c5.2,0,9.5-1.1,13.1-3.2 c3.6-2.1,6.5-4.9,8.8-8.2c2.3-3.4,4-7.2,5-11.5C839.2,198,839.7,193.6,839.7,189.1z M879.6,98.6h22.6V120h-22.6V98.6z M879.6,137.7h22.6v102.6h-22.6V137.7z M922.4,98.6H945v141.7h-22.6V98.6z M1014.3,243.1c-8.2,0-15.5-1.4-21.9-4.1 c-6.4-2.7-11.8-6.5-16.3-11.2c-4.4-4.8-7.8-10.5-10.1-17.1c-2.3-6.6-3.5-13.9-3.5-21.8c0-7.8,1.2-15,3.5-21.6 c2.3-6.6,5.7-12.3,10.1-17.1c4.4-4.8,9.9-8.5,16.3-11.2c6.4-2.7,13.7-4.1,21.9-4.1c8.2,0,15.5,1.4,21.9,4.1 c6.4,2.7,11.8,6.5,16.3,11.2c4.4,4.8,7.8,10.5,10.1,17.1c2.3,6.6,3.5,13.8,3.5,21.6c0,7.9-1.2,15.2-3.5,21.8 c-2.3,6.6-5.7,12.3-10.1,17.1c-4.4,4.8-9.9,8.5-16.3,11.2C1029.8,241.7,1022.5,243.1,1014.3,243.1z M1014.3,225.2 c5,0,9.4-1.1,13.1-3.2c3.7-2.1,6.7-4.9,9.1-8.3c2.4-3.4,4.1-7.3,5.3-11.6c1.1-4.3,1.7-8.7,1.7-13.2c0-4.4-0.6-8.7-1.7-13.1 c-1.1-4.4-2.9-8.2-5.3-11.6c-2.4-3.4-5.4-6.1-9.1-8.2c-3.7-2.1-8.1-3.2-13.1-3.2c-5,0-9.4,1.1-13.1,3.2c-3.7,2.1-6.7,4.9-9.1,8.2 c-2.4,3.4-4.1,7.2-5.3,11.6c-1.1,4.4-1.7,8.7-1.7,13.1c0,4.5,0.6,8.9,1.7,13.2c1.1,4.3,2.9,8.2,5.3,11.6c2.4,3.4,5.4,6.2,9.1,8.3 C1004.9,224.2,1009.3,225.2,1014.3,225.2z M1072.7,137.7h17.1v-30.8h22.6v30.8h20.4v16.9h-20.4v54.8c0,2.4,0.1,4.4,0.3,6.2 c0.2,1.7,0.7,3.2,1.4,4.4c0.7,1.2,1.8,2.1,3.3,2.7c1.5,0.6,3.4,0.9,6,0.9c1.6,0,3.2,0,4.8-0.1c1.6-0.1,3.2-0.3,4.8-0.7v17.5 c-2.5,0.3-5,0.5-7.3,0.8c-2.4,0.3-4.8,0.4-7.3,0.4c-6,0-10.8-0.6-14.4-1.7c-3.6-1.1-6.5-2.8-8.5-5c-2.1-2.2-3.4-4.9-4.2-8.2 c-0.7-3.3-1.2-7.1-1.3-11.3v-60.5h-17.1V137.7z"
                            })
                        })
                    }), (0, t.jsxs)("g", {
                        id: "Star",
                        children: [(0, t.jsx)("polygon", {
                            fill: "#00B67A",
                            points: "271.3,98.6 167.7,98.6 135.7,0 103.6,98.6 0,98.5 83.9,159.5 51.8,258 135.7,197.1 219.5,258  187.5,159.5 271.3,98.6 271.3,98.6 271.3,98.6  "
                        }), (0, t.jsx)("polygon", {
                            fill: "#005128",
                            points: "194.7,181.8 187.5,159.5 135.7,197.1  "
                        })]
                    })]
                })
            }
            var n = l(95805),
                o = l(37672),
                p = l(56764),
                h = l(42619),
                m = l(83352),
                d = l(93264);

            function x(e) {
                let {
                    t: s
                } = (0, c.$G)(), l = (0, d.useMemo)(() => e.review.trustpilotContent.length > 120 ? "".concat(e.review.trustpilotContent.slice(0, 120), "...") : e.review.trustpilotContent, [e.review.trustpilotContent]);
                return (0, t.jsxs)(o.Zb, {
                    className: "h-full flex flex-col border-0",
                    children: [(0, t.jsxs)(o.Ol, {
                        className: "space-y-5 pb-3",
                        children: [(0, t.jsxs)("div", {
                            className: "space-x-3.5 flex items-center",
                            children: [(0, t.jsxs)(n.Avatar, {
                                children: [e.review.trustpilotUserProfileImageUrl && (0, t.jsx)(n.AvatarImage, {
                                    src: e.review.trustpilotUserProfileImageUrl
                                }), (0, t.jsx)(n.Q, {
                                    children: e.review.trustpilotUserName.charAt(0)
                                })]
                            }), (0, t.jsxs)("div", {
                                children: [(0, t.jsx)("p", {
                                    className: "font-semibold mb-1",
                                    children: function(e) {
                                        let [s, l] = e.split(" ");
                                        return "".concat(s, " ").concat((null == l ? void 0 : l.charAt(0)) || "").trim()
                                    }(e.review.trustpilotUserName)
                                }), (0, t.jsx)("p", {
                                    className: "text-sm text-foreground-secondary",
                                    children: e.review.trustpilotUserLocation
                                })]
                            })]
                        }), (0, t.jsx)(o.ll, {
                            className: "text-lg",
                            children: (0, t.jsx)(m.o3, {
                                tooltipContentSize: "xs",
                                children: e.review.trustpilotTitle
                            })
                        })]
                    }), (0, t.jsx)(o.aY, {
                        className: "pb-5 flex-1 flex flex-col justify-between",
                        children: (0, t.jsxs)(o.SZ, {
                            className: "overflow-hidden",
                            children: [l, " ", e.review.trustpilotContent.length > 120 && (0, t.jsxs)(h.J2, {
                                children: [(0, t.jsx)(h.xo, {
                                    className: "text-primary-theme hover:underline",
                                    children: s("See More")
                                }), (0, t.jsx)(h.yk, {
                                    className: "w-72 p-4",
                                    children: e.review.trustpilotContent
                                })]
                            })]
                        })
                    }), (0, t.jsxs)(o.eW, {
                        className: "mt-16 text-muted-foreground flex gap-2.5 text-sm justify-between items-end",
                        children: [(0, t.jsx)("img", {
                            src: "/trustpilot-rating.png",
                            alt: "Trustpilot Rank"
                        }), (0, t.jsx)(p.r, {
                            date: e.review.trustpilotCreatedAt,
                            format: "short",
                            className: "text-wrap"
                        })]
                    })]
                })
            }
            var f = l(39081),
                u = l(3934);

            function v(e) {
                let {
                    t: s
                } = (0, c.$G)();
                return (0, t.jsxs)(f.W, {
                    className: "py-24 flex flex-col items-center",
                    children: [(0, t.jsx)("span", {
                        className: "hidden md:block text-center text-sm font-medium uppercase text-primary-foreground mb-4",
                        children: s("Trustpilot Reviews")
                    }), (0, t.jsx)("p", {
                        className: "text-xl md:text-4xl font-semibold tracking-tight mb-4 font-serif",
                        children: s("Trusted By Professionals")
                    }), (0, t.jsx)(u.default, {
                        href: "https://www.trustpilot.com/review/propfirmmatch.com",
                        target: "_blank",
                        children: (0, t.jsx)(i, {
                            className: "mb-5 h-10"
                        })
                    }), (0, t.jsxs)(r.lr, {
                        className: "w-full flex items-center gap-4 relative",
                        opts: {
                            align: "start"
                        },
                        hideDots: !0,
                        plugins: [(0, a.Z)({
                            delay: 5e3
                        })],
                        children: [(0, t.jsx)(r.am, {
                            className: "static 2xl:absolute translate-y-0 top-auto h-8 w-8 xl:h-12 xl:w-12 bg-white bg-opacity-60 focus:bg-white focus:bg-opacity-30 hover:bg-white hover:bg-opacity-10"
                        }), (0, t.jsx)(r.KI, {
                            containerClassName: "h-full",
                            className: "h-full -ml-4",
                            children: e.reviews.map(e => (0, t.jsx)(r.d$, {
                                className: "md:basis-1/2 lg:basis-1/3 xl:basis-1/4",
                                children: (0, t.jsx)(x, {
                                    review: e
                                })
                            }, e.id))
                        }), (0, t.jsx)(r.Pz, {
                            className: "static 2xl:absolute translate-y-0 top-auto h-8 w-8 xl:h-12 xl:w-12 bg-white bg-opacity-60 focus:bg-white focus:bg-opacity-30 hover:bg-white hover:bg-opacity-10"
                        })]
                    })]
                })
            }
        },
        54258: (e, s, l) => {
            l.d(s, {
                Q: () => t
            });
            let t = (0, l(52231).f)("h3", "text-2xl font-semibold tracking-tight scroll-m-20");
            t.displayName = "TypographyH3"
        },
        32709: (e, s, l) => {
            l.d(s, {
                Z: () => c
            });
            let t = {
                active: !0,
                breakpoints: {},
                delay: 4e3,
                jump: !1,
                playOnInit: !0,
                stopOnFocusIn: !0,
                stopOnInteraction: !0,
                stopOnMouseEnter: !1,
                stopOnLastSnap: !1,
                rootNode: null
            };

            function c(e = {}) {
                let s, l, r;
                let a = !1,
                    i = !0,
                    n = !1,
                    o = 0;

                function p() {
                    if (r || !i) return;
                    a || l.emit("autoplay:play");
                    let {
                        ownerWindow: e
                    } = l.internalEngine();
                    e.clearInterval(o), o = e.setInterval(f, s.delay), a = !0
                }

                function h() {
                    if (r) return;
                    a && l.emit("autoplay:stop");
                    let {
                        ownerWindow: e
                    } = l.internalEngine();
                    e.clearInterval(o), o = 0, a = !1
                }

                function m() {
                    if (d()) return i = a, h();
                    i && p()
                }

                function d() {
                    let {
                        ownerDocument: e
                    } = l.internalEngine();
                    return "hidden" === e.visibilityState
                }

                function x(e) {
                    void 0 !== e && (n = e), i = !0, p()
                }

                function f() {
                    let {
                        index: e
                    } = l.internalEngine(), t = e.clone().add(1).get(), c = l.scrollSnapList().length - 1;
                    s.stopOnLastSnap && t === c && h(), l.canScrollNext() ? l.scrollNext(n) : l.scrollTo(0, n)
                }
                return {
                    name: "autoplay",
                    options: e,
                    init: function(a, o) {
                        l = a;
                        let {
                            mergeOptions: x,
                            optionsAtMedia: f
                        } = o, u = x(t, c.globalOptions);
                        if (s = f(x(u, e)), l.scrollSnapList().length <= 1) return;
                        n = s.jump, r = !1;
                        let {
                            eventStore: v,
                            ownerDocument: b
                        } = l.internalEngine(), g = l.rootNode(), j = s.rootNode && s.rootNode(g) || g, y = l.containerNode();
                        l.on("pointerDown", h), s.stopOnInteraction || l.on("pointerUp", p), s.stopOnMouseEnter && (v.add(j, "mouseenter", () => {
                            i = !1, h()
                        }), s.stopOnInteraction || v.add(j, "mouseleave", () => {
                            i = !0, p()
                        })), s.stopOnFocusIn && (l.on("slideFocusStart", h), s.stopOnInteraction || v.add(y, "focusout", p)), v.add(b, "visibilitychange", m), s.playOnInit && !d() && p()
                    },
                    destroy: function() {
                        l.off("pointerDown", h).off("pointerUp", p).off("slideFocusStart", h), h(), r = !0, a = !1
                    },
                    play: x,
                    stop: function() {
                        a && h()
                    },
                    reset: function() {
                        a && x()
                    },
                    isPlaying: function() {
                        return a
                    }
                }
            }
            c.globalOptions = void 0
        }
    }
]);