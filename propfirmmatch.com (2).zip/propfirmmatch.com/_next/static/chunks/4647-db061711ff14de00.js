"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4647], {
        47576: (e, t, r) => {
            r.r(t);
            var s = r(96151),
                n = {};
            for (let e in s) "default" !== e && (n[e] = () => s[e]);
            r.d(t, n)
        },
        80568: (e, t, r) => {
            r.d(t, {
                j: () => i
            });
            var s = r(4436),
                n = r(10751),
                i = new class extends s.l {#
                    e;#
                    t;#
                    r;
                    constructor() {
                        super(), this.#r = e => {
                            if (!n.sk && window.addEventListener) {
                                let t = () => e();
                                return window.addEventListener("visibilitychange", t, !1), () => {
                                    window.removeEventListener("visibilitychange", t)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#t || this.setEventListener(this.#r)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#t ? .(), this.#t = void 0)
                    }
                    setEventListener(e) {
                        this.#r = e, this.#t ? .(), this.#t = e(e => {
                            "boolean" == typeof e ? this.setFocused(e) : this.onFocus()
                        })
                    }
                    setFocused(e) {
                        this.#e !== e && (this.#e = e, this.onFocus())
                    }
                    onFocus() {
                        let e = this.isFocused();
                        this.listeners.forEach(t => {
                            t(e)
                        })
                    }
                    isFocused() {
                        return "boolean" == typeof this.#e ? this.#e : globalThis.document ? .visibilityState !== "hidden"
                    }
                }
        },
        68714: (e, t, r) => {
            function s(e) {
                return e
            }

            function n(e) {
                return e.state.isPaused
            }

            function i(e) {
                return "success" === e.state.status
            }

            function a(e, t = {}) {
                let r = t.shouldDehydrateMutation ? ? e.getDefaultOptions().dehydrate ? .shouldDehydrateMutation ? ? n,
                    u = e.getMutationCache().getAll().flatMap(e => r(e) ? [{
                        mutationKey: e.options.mutationKey,
                        state: e.state,
                        ...e.options.scope && {
                            scope: e.options.scope
                        },
                        ...e.meta && {
                            meta: e.meta
                        }
                    }] : []),
                    o = t.shouldDehydrateQuery ? ? e.getDefaultOptions().dehydrate ? .shouldDehydrateQuery ? ? i,
                    l = t.serializeData ? ? e.getDefaultOptions().dehydrate ? .serializeData ? ? s;
                return {
                    mutations: u,
                    queries: e.getQueryCache().getAll().flatMap(e => o(e) ? [{
                        state: { ...e.state,
                            ...void 0 !== e.state.data && {
                                data: l(e.state.data)
                            }
                        },
                        queryKey: e.queryKey,
                        queryHash: e.queryHash,
                        ..."pending" === e.state.status && {
                            promise: e.promise ? .then(l).catch(e => Promise.reject(Error("redacted")))
                        },
                        ...e.meta && {
                            meta: e.meta
                        }
                    }] : [])
                }
            }

            function u(e, t, r) {
                if ("object" != typeof t || null === t) return;
                let n = e.getMutationCache(),
                    i = e.getQueryCache(),
                    a = r ? .defaultOptions ? .deserializeData ? ? e.getDefaultOptions().hydrate ? .deserializeData ? ? s,
                    u = t.mutations || [],
                    o = t.queries || [];
                u.forEach(({
                    state: t,
                    ...s
                }) => {
                    n.build(e, { ...e.getDefaultOptions().hydrate ? .mutations,
                        ...r ? .defaultOptions ? .mutations,
                        ...s
                    }, t)
                }), o.forEach(({
                    queryKey: t,
                    state: s,
                    queryHash: n,
                    meta: u,
                    promise: o
                }) => {
                    let l = i.get(n),
                        c = void 0 === s.data ? s.data : a(s.data);
                    if (l) {
                        if (l.state.dataUpdatedAt < s.dataUpdatedAt) {
                            let {
                                fetchStatus: e,
                                ...t
                            } = s;
                            l.setState({ ...t,
                                data: c
                            })
                        }
                    } else l = i.build(e, { ...e.getDefaultOptions().hydrate ? .queries,
                        ...r ? .defaultOptions ? .queries,
                        queryKey : t,
                        queryHash : n,
                        meta : u
                    }, { ...s,
                        data: c,
                        fetchStatus: "idle"
                    });
                    if (o) {
                        let e = Promise.resolve(o).then(a);
                        l.fetch(void 0, {
                            initialPromise: e
                        })
                    }
                })
            }
            r.d(t, {
                D: () => a,
                ZB: () => u,
                d_: () => i
            })
        },
        72535: (e, t, r) => {
            r.d(t, {
                Gm: () => n,
                Qy: () => u,
                ZF: () => o
            });
            var s = r(10751);

            function n(e) {
                return {
                    onFetch: (t, r) => {
                        let n = t.options,
                            u = t.fetchOptions ? .meta ? .fetchMore ? .direction,
                            o = t.state.data ? .pages || [],
                            l = t.state.data ? .pageParams || [],
                            c = {
                                pages: [],
                                pageParams: []
                            },
                            h = 0,
                            d = async () => {
                                let r = !1,
                                    d = e => {
                                        Object.defineProperty(e, "signal", {
                                            enumerable: !0,
                                            get: () => (t.signal.aborted ? r = !0 : t.signal.addEventListener("abort", () => {
                                                r = !0
                                            }), t.signal)
                                        })
                                    },
                                    f = (0, s.cG)(t.options, t.fetchOptions),
                                    p = async (e, n, i) => {
                                        if (r) return Promise.reject();
                                        if (null == n && e.pages.length) return Promise.resolve(e);
                                        let a = {
                                            queryKey: t.queryKey,
                                            pageParam: n,
                                            direction: i ? "backward" : "forward",
                                            meta: t.options.meta
                                        };
                                        d(a);
                                        let u = await f(a),
                                            {
                                                maxPages: o
                                            } = t.options,
                                            l = i ? s.Ht : s.VX;
                                        return {
                                            pages: l(e.pages, u, o),
                                            pageParams: l(e.pageParams, n, o)
                                        }
                                    };
                                if (u && o.length) {
                                    let e = "backward" === u,
                                        t = {
                                            pages: o,
                                            pageParams: l
                                        },
                                        r = (e ? a : i)(n, t);
                                    c = await p(t, r, e)
                                } else {
                                    let t = e ? ? o.length;
                                    do {
                                        let e = 0 === h ? l[0] ? ? n.initialPageParam : i(n, c);
                                        if (h > 0 && null == e) break;
                                        c = await p(c, e), h++
                                    } while (h < t)
                                }
                                return c
                            };
                        t.options.persister ? t.fetchFn = () => t.options.persister ? .(d, {
                            queryKey: t.queryKey,
                            meta: t.options.meta,
                            signal: t.signal
                        }, r) : t.fetchFn = d
                    }
                }
            }

            function i(e, {
                pages: t,
                pageParams: r
            }) {
                let s = t.length - 1;
                return t.length > 0 ? e.getNextPageParam(t[s], t, r[s], r) : void 0
            }

            function a(e, {
                pages: t,
                pageParams: r
            }) {
                return t.length > 0 ? e.getPreviousPageParam ? .(t[0], t, r[0], r) : void 0
            }

            function u(e, t) {
                return !!t && null != i(e, t)
            }

            function o(e, t) {
                return !!t && !!e.getPreviousPageParam && null != a(e, t)
            }
        },
        75122: (e, t, r) => {
            r.d(t, {
                c: () => i
            });
            var s = r(32682),
                n = r(72535),
                i = class extends s.z {
                    constructor(e, t) {
                        super(e, t)
                    }
                    bindMethods() {
                        super.bindMethods(), this.fetchNextPage = this.fetchNextPage.bind(this), this.fetchPreviousPage = this.fetchPreviousPage.bind(this)
                    }
                    setOptions(e, t) {
                        super.setOptions({ ...e,
                            behavior: (0, n.Gm)()
                        }, t)
                    }
                    getOptimisticResult(e) {
                        return e.behavior = (0, n.Gm)(), super.getOptimisticResult(e)
                    }
                    fetchNextPage(e) {
                        return this.fetch({ ...e,
                            meta: {
                                fetchMore: {
                                    direction: "forward"
                                }
                            }
                        })
                    }
                    fetchPreviousPage(e) {
                        return this.fetch({ ...e,
                            meta: {
                                fetchMore: {
                                    direction: "backward"
                                }
                            }
                        })
                    }
                    createResult(e, t) {
                        let {
                            state: r
                        } = e, s = super.createResult(e, t), {
                            isFetching: i,
                            isRefetching: a,
                            isError: u,
                            isRefetchError: o
                        } = s, l = r.fetchMeta ? .fetchMore ? .direction, c = u && "forward" === l, h = i && "forward" === l, d = u && "backward" === l, f = i && "backward" === l;
                        return { ...s,
                            fetchNextPage: this.fetchNextPage,
                            fetchPreviousPage: this.fetchPreviousPage,
                            hasNextPage: (0, n.Qy)(t, r.data),
                            hasPreviousPage: (0, n.ZF)(t, r.data),
                            isFetchNextPageError: c,
                            isFetchingNextPage: h,
                            isFetchPreviousPageError: d,
                            isFetchingPreviousPage: f,
                            isRefetchError: o && !c && !d,
                            isRefetching: a && !h && !f
                        }
                    }
                }
        },
        94716: (e, t, r) => {
            r.d(t, {
                R: () => u,
                m: () => a
            });
            var s = r(68086),
                n = r(36040),
                i = r(38706),
                a = class extends n.F {#
                    s;#
                    n;#
                    i;
                    constructor(e) {
                        super(), this.mutationId = e.mutationId, this.#n = e.mutationCache, this.#s = [], this.state = e.state || u(), this.setOptions(e.options), this.scheduleGc()
                    }
                    setOptions(e) {
                        this.options = e, this.updateGcTime(this.options.gcTime)
                    }
                    get meta() {
                        return this.options.meta
                    }
                    addObserver(e) {
                        this.#s.includes(e) || (this.#s.push(e), this.clearGcTimeout(), this.#n.notify({
                            type: "observerAdded",
                            mutation: this,
                            observer: e
                        }))
                    }
                    removeObserver(e) {
                        this.#s = this.#s.filter(t => t !== e), this.scheduleGc(), this.#n.notify({
                            type: "observerRemoved",
                            mutation: this,
                            observer: e
                        })
                    }
                    optionalRemove() {
                        this.#s.length || ("pending" === this.state.status ? this.scheduleGc() : this.#n.remove(this))
                    }
                    continue () {
                        return this.#i ? .continue() ? ? this.execute(this.state.variables)
                    }
                    async execute(e) {
                        this.#i = (0, i.Mz)({
                            fn: () => this.options.mutationFn ? this.options.mutationFn(e) : Promise.reject(Error("No mutationFn found")),
                            onFail: (e, t) => {
                                this.#a({
                                    type: "failed",
                                    failureCount: e,
                                    error: t
                                })
                            },
                            onPause: () => {
                                this.#a({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#a({
                                    type: "continue"
                                })
                            },
                            retry: this.options.retry ? ? 0,
                            retryDelay: this.options.retryDelay,
                            networkMode: this.options.networkMode,
                            canRun: () => this.#n.canRun(this)
                        });
                        let t = "pending" === this.state.status,
                            r = !this.#i.canStart();
                        try {
                            if (!t) {
                                this.#a({
                                    type: "pending",
                                    variables: e,
                                    isPaused: r
                                }), await this.#n.config.onMutate ? .(e, this);
                                let t = await this.options.onMutate ? .(e);
                                t !== this.state.context && this.#a({
                                    type: "pending",
                                    context: t,
                                    variables: e,
                                    isPaused: r
                                })
                            }
                            let s = await this.#i.start();
                            return await this.#n.config.onSuccess ? .(s, e, this.state.context, this), await this.options.onSuccess ? .(s, e, this.state.context), await this.#n.config.onSettled ? .(s, null, this.state.variables, this.state.context, this), await this.options.onSettled ? .(s, null, e, this.state.context), this.#a({
                                type: "success",
                                data: s
                            }), s
                        } catch (t) {
                            try {
                                throw await this.#n.config.onError ? .(t, e, this.state.context, this), await this.options.onError ? .(t, e, this.state.context), await this.#n.config.onSettled ? .(void 0, t, this.state.variables, this.state.context, this), await this.options.onSettled ? .(void 0, t, e, this.state.context), t
                            } finally {
                                this.#a({
                                    type: "error",
                                    error: t
                                })
                            }
                        } finally {
                            this.#n.runNext(this)
                        }
                    }#
                    a(e) {
                        this.state = (t => {
                            switch (e.type) {
                                case "failed":
                                    return { ...t,
                                        failureCount: e.failureCount,
                                        failureReason: e.error
                                    };
                                case "pause":
                                    return { ...t,
                                        isPaused: !0
                                    };
                                case "continue":
                                    return { ...t,
                                        isPaused: !1
                                    };
                                case "pending":
                                    return { ...t,
                                        context: e.context,
                                        data: void 0,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        isPaused: e.isPaused,
                                        status: "pending",
                                        variables: e.variables,
                                        submittedAt: Date.now()
                                    };
                                case "success":
                                    return { ...t,
                                        data: e.data,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        status: "success",
                                        isPaused: !1
                                    };
                                case "error":
                                    return { ...t,
                                        data: void 0,
                                        error: e.error,
                                        failureCount: t.failureCount + 1,
                                        failureReason: e.error,
                                        isPaused: !1,
                                        status: "error"
                                    }
                            }
                        })(this.state), s.V.batch(() => {
                            this.#s.forEach(t => {
                                t.onMutationUpdate(e)
                            }), this.#n.notify({
                                mutation: this,
                                type: "updated",
                                action: e
                            })
                        })
                    }
                };

            function u() {
                return {
                    context: void 0,
                    data: void 0,
                    error: null,
                    failureCount: 0,
                    failureReason: null,
                    isPaused: !1,
                    status: "idle",
                    variables: void 0,
                    submittedAt: 0
                }
            }
        },
        68086: (e, t, r) => {
            r.d(t, {
                V: () => s
            });
            var s = function() {
                let e = [],
                    t = 0,
                    r = e => {
                        e()
                    },
                    s = e => {
                        e()
                    },
                    n = e => setTimeout(e, 0),
                    i = s => {
                        t ? e.push(s) : n(() => {
                            r(s)
                        })
                    },
                    a = () => {
                        let t = e;
                        e = [], t.length && n(() => {
                            s(() => {
                                t.forEach(e => {
                                    r(e)
                                })
                            })
                        })
                    };
                return {
                    batch: e => {
                        let r;
                        t++;
                        try {
                            r = e()
                        } finally {
                            --t || a()
                        }
                        return r
                    },
                    batchCalls: e => (...t) => {
                        i(() => {
                            e(...t)
                        })
                    },
                    schedule: i,
                    setNotifyFunction: e => {
                        r = e
                    },
                    setBatchNotifyFunction: e => {
                        s = e
                    },
                    setScheduler: e => {
                        n = e
                    }
                }
            }()
        },
        6231: (e, t, r) => {
            r.d(t, {
                N: () => i
            });
            var s = r(4436),
                n = r(10751),
                i = new class extends s.l {#
                    u = !0;#
                    t;#
                    r;
                    constructor() {
                        super(), this.#r = e => {
                            if (!n.sk && window.addEventListener) {
                                let t = () => e(!0),
                                    r = () => e(!1);
                                return window.addEventListener("online", t, !1), window.addEventListener("offline", r, !1), () => {
                                    window.removeEventListener("online", t), window.removeEventListener("offline", r)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#t || this.setEventListener(this.#r)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#t ? .(), this.#t = void 0)
                    }
                    setEventListener(e) {
                        this.#r = e, this.#t ? .(), this.#t = e(this.setOnline.bind(this))
                    }
                    setOnline(e) {
                        this.#u !== e && (this.#u = e, this.listeners.forEach(t => {
                            t(e)
                        }))
                    }
                    isOnline() {
                        return this.#u
                    }
                }
        },
        57626: (e, t, r) => {
            r.d(t, {
                A: () => u,
                z: () => o
            });
            var s = r(10751),
                n = r(68086),
                i = r(38706),
                a = r(36040),
                u = class extends a.F {#
                    o;#
                    l;#
                    c;#
                    i;#
                    h;#
                    d;
                    constructor(e) {
                        super(), this.#d = !1, this.#h = e.defaultOptions, this.setOptions(e.options), this.observers = [], this.#c = e.cache, this.queryKey = e.queryKey, this.queryHash = e.queryHash, this.#o = function(e) {
                            let t = "function" == typeof e.initialData ? e.initialData() : e.initialData,
                                r = void 0 !== t,
                                s = r ? "function" == typeof e.initialDataUpdatedAt ? e.initialDataUpdatedAt() : e.initialDataUpdatedAt : 0;
                            return {
                                data: t,
                                dataUpdateCount: 0,
                                dataUpdatedAt: r ? s ? ? Date.now() : 0,
                                error: null,
                                errorUpdateCount: 0,
                                errorUpdatedAt: 0,
                                fetchFailureCount: 0,
                                fetchFailureReason: null,
                                fetchMeta: null,
                                isInvalidated: !1,
                                status: r ? "success" : "pending",
                                fetchStatus: "idle"
                            }
                        }(this.options), this.state = e.state ? ? this.#o, this.scheduleGc()
                    }
                    get meta() {
                        return this.options.meta
                    }
                    get promise() {
                        return this.#i ? .promise
                    }
                    setOptions(e) {
                        this.options = { ...this.#h,
                            ...e
                        }, this.updateGcTime(this.options.gcTime)
                    }
                    optionalRemove() {
                        this.observers.length || "idle" !== this.state.fetchStatus || this.#c.remove(this)
                    }
                    setData(e, t) {
                        let r = (0, s.oE)(this.state.data, e, this.options);
                        return this.#a({
                            data: r,
                            type: "success",
                            dataUpdatedAt: t ? .updatedAt,
                            manual: t ? .manual
                        }), r
                    }
                    setState(e, t) {
                        this.#a({
                            type: "setState",
                            state: e,
                            setStateOptions: t
                        })
                    }
                    cancel(e) {
                        let t = this.#i ? .promise;
                        return this.#i ? .cancel(e), t ? t.then(s.ZT).catch(s.ZT) : Promise.resolve()
                    }
                    destroy() {
                        super.destroy(), this.cancel({
                            silent: !0
                        })
                    }
                    reset() {
                        this.destroy(), this.setState(this.#o)
                    }
                    isActive() {
                        return this.observers.some(e => !1 !== (0, s.Nc)(e.options.enabled, this))
                    }
                    isDisabled() {
                        return this.getObserversCount() > 0 ? !this.isActive() : this.options.queryFn === s.CN || this.state.dataUpdateCount + this.state.errorUpdateCount === 0
                    }
                    isStale() {
                        return !!this.state.isInvalidated || (this.getObserversCount() > 0 ? this.observers.some(e => e.getCurrentResult().isStale) : void 0 === this.state.data)
                    }
                    isStaleByTime(e = 0) {
                        return this.state.isInvalidated || void 0 === this.state.data || !(0, s.Kp)(this.state.dataUpdatedAt, e)
                    }
                    onFocus() {
                        let e = this.observers.find(e => e.shouldFetchOnWindowFocus());
                        e ? .refetch({
                            cancelRefetch: !1
                        }), this.#i ? .continue()
                    }
                    onOnline() {
                        let e = this.observers.find(e => e.shouldFetchOnReconnect());
                        e ? .refetch({
                            cancelRefetch: !1
                        }), this.#i ? .continue()
                    }
                    addObserver(e) {
                        this.observers.includes(e) || (this.observers.push(e), this.clearGcTimeout(), this.#c.notify({
                            type: "observerAdded",
                            query: this,
                            observer: e
                        }))
                    }
                    removeObserver(e) {
                        this.observers.includes(e) && (this.observers = this.observers.filter(t => t !== e), this.observers.length || (this.#i && (this.#d ? this.#i.cancel({
                            revert: !0
                        }) : this.#i.cancelRetry()), this.scheduleGc()), this.#c.notify({
                            type: "observerRemoved",
                            query: this,
                            observer: e
                        }))
                    }
                    getObserversCount() {
                        return this.observers.length
                    }
                    invalidate() {
                        this.state.isInvalidated || this.#a({
                            type: "invalidate"
                        })
                    }
                    fetch(e, t) {
                        if ("idle" !== this.state.fetchStatus) {
                            if (void 0 !== this.state.data && t ? .cancelRefetch) this.cancel({
                                silent: !0
                            });
                            else if (this.#i) return this.#i.continueRetry(), this.#i.promise
                        }
                        if (e && this.setOptions(e), !this.options.queryFn) {
                            let e = this.observers.find(e => e.options.queryFn);
                            e && this.setOptions(e.options)
                        }
                        let r = new AbortController,
                            n = e => {
                                Object.defineProperty(e, "signal", {
                                    enumerable: !0,
                                    get: () => (this.#d = !0, r.signal)
                                })
                            },
                            a = {
                                fetchOptions: t,
                                options: this.options,
                                queryKey: this.queryKey,
                                state: this.state,
                                fetchFn: () => {
                                    let e = (0, s.cG)(this.options, t),
                                        r = {
                                            queryKey: this.queryKey,
                                            meta: this.meta
                                        };
                                    return (n(r), this.#d = !1, this.options.persister) ? this.options.persister(e, r, this) : e(r)
                                }
                            };
                        n(a), this.options.behavior ? .onFetch(a, this), this.#l = this.state, ("idle" === this.state.fetchStatus || this.state.fetchMeta !== a.fetchOptions ? .meta) && this.#a({
                            type: "fetch",
                            meta: a.fetchOptions ? .meta
                        });
                        let u = e => {
                            (0, i.DV)(e) && e.silent || this.#a({
                                type: "error",
                                error: e
                            }), (0, i.DV)(e) || (this.#c.config.onError ? .(e, this), this.#c.config.onSettled ? .(this.state.data, e, this)), this.scheduleGc()
                        };
                        return this.#i = (0, i.Mz)({
                            initialPromise: t ? .initialPromise,
                            fn: a.fetchFn,
                            abort: r.abort.bind(r),
                            onSuccess: e => {
                                if (void 0 === e) {
                                    u(Error(`${this.queryHash} data is undefined`));
                                    return
                                }
                                try {
                                    this.setData(e)
                                } catch (e) {
                                    u(e);
                                    return
                                }
                                this.#c.config.onSuccess ? .(e, this), this.#c.config.onSettled ? .(e, this.state.error, this), this.scheduleGc()
                            },
                            onError: u,
                            onFail: (e, t) => {
                                this.#a({
                                    type: "failed",
                                    failureCount: e,
                                    error: t
                                })
                            },
                            onPause: () => {
                                this.#a({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#a({
                                    type: "continue"
                                })
                            },
                            retry: a.options.retry,
                            retryDelay: a.options.retryDelay,
                            networkMode: a.options.networkMode,
                            canRun: () => !0
                        }), this.#i.start()
                    }#
                    a(e) {
                        this.state = (t => {
                            switch (e.type) {
                                case "failed":
                                    return { ...t,
                                        fetchFailureCount: e.failureCount,
                                        fetchFailureReason: e.error
                                    };
                                case "pause":
                                    return { ...t,
                                        fetchStatus: "paused"
                                    };
                                case "continue":
                                    return { ...t,
                                        fetchStatus: "fetching"
                                    };
                                case "fetch":
                                    return { ...t,
                                        ...o(t.data, this.options),
                                        fetchMeta: e.meta ? ? null
                                    };
                                case "success":
                                    return { ...t,
                                        data: e.data,
                                        dataUpdateCount: t.dataUpdateCount + 1,
                                        dataUpdatedAt: e.dataUpdatedAt ? ? Date.now(),
                                        error: null,
                                        isInvalidated: !1,
                                        status: "success",
                                        ...!e.manual && {
                                            fetchStatus: "idle",
                                            fetchFailureCount: 0,
                                            fetchFailureReason: null
                                        }
                                    };
                                case "error":
                                    let r = e.error;
                                    if ((0, i.DV)(r) && r.revert && this.#l) return { ...this.#l,
                                        fetchStatus: "idle"
                                    };
                                    return { ...t,
                                        error: r,
                                        errorUpdateCount: t.errorUpdateCount + 1,
                                        errorUpdatedAt: Date.now(),
                                        fetchFailureCount: t.fetchFailureCount + 1,
                                        fetchFailureReason: r,
                                        fetchStatus: "idle",
                                        status: "error"
                                    };
                                case "invalidate":
                                    return { ...t,
                                        isInvalidated: !0
                                    };
                                case "setState":
                                    return { ...t,
                                        ...e.state
                                    }
                            }
                        })(this.state), n.V.batch(() => {
                            this.observers.forEach(e => {
                                e.onQueryUpdate()
                            }), this.#c.notify({
                                query: this,
                                type: "updated",
                                action: e
                            })
                        })
                    }
                };

            function o(e, t) {
                return {
                    fetchFailureCount: 0,
                    fetchFailureReason: null,
                    fetchStatus: (0, i.Kw)(t.networkMode) ? "fetching" : "paused",
                    ...void 0 === e && {
                        error: null,
                        status: "pending"
                    }
                }
            }
        },
        35713: (e, t, r) => {
            r.d(t, {
                S: () => p
            });
            var s = r(10751),
                n = r(57626),
                i = r(68086),
                a = r(4436),
                u = class extends a.l {
                    constructor(e = {}) {
                        super(), this.config = e, this.#f = new Map
                    }#
                    f;
                    build(e, t, r) {
                        let i = t.queryKey,
                            a = t.queryHash ? ? (0, s.Rm)(i, t),
                            u = this.get(a);
                        return u || (u = new n.A({
                            cache: this,
                            queryKey: i,
                            queryHash: a,
                            options: e.defaultQueryOptions(t),
                            state: r,
                            defaultOptions: e.getQueryDefaults(i)
                        }), this.add(u)), u
                    }
                    add(e) {
                        this.#f.has(e.queryHash) || (this.#f.set(e.queryHash, e), this.notify({
                            type: "added",
                            query: e
                        }))
                    }
                    remove(e) {
                        let t = this.#f.get(e.queryHash);
                        t && (e.destroy(), t === e && this.#f.delete(e.queryHash), this.notify({
                            type: "removed",
                            query: e
                        }))
                    }
                    clear() {
                        i.V.batch(() => {
                            this.getAll().forEach(e => {
                                this.remove(e)
                            })
                        })
                    }
                    get(e) {
                        return this.#f.get(e)
                    }
                    getAll() {
                        return [...this.#f.values()]
                    }
                    find(e) {
                        let t = {
                            exact: !0,
                            ...e
                        };
                        return this.getAll().find(e => (0, s._x)(t, e))
                    }
                    findAll(e = {}) {
                        let t = this.getAll();
                        return Object.keys(e).length > 0 ? t.filter(t => (0, s._x)(e, t)) : t
                    }
                    notify(e) {
                        i.V.batch(() => {
                            this.listeners.forEach(t => {
                                t(e)
                            })
                        })
                    }
                    onFocus() {
                        i.V.batch(() => {
                            this.getAll().forEach(e => {
                                e.onFocus()
                            })
                        })
                    }
                    onOnline() {
                        i.V.batch(() => {
                            this.getAll().forEach(e => {
                                e.onOnline()
                            })
                        })
                    }
                },
                o = r(94716),
                l = class extends a.l {
                    constructor(e = {}) {
                        super(), this.config = e, this.#p = new Map, this.#y = Date.now()
                    }#
                    p;#
                    y;
                    build(e, t, r) {
                        let s = new o.m({
                            mutationCache: this,
                            mutationId: ++this.#y,
                            options: e.defaultMutationOptions(t),
                            state: r
                        });
                        return this.add(s), s
                    }
                    add(e) {
                        let t = c(e),
                            r = this.#p.get(t) ? ? [];
                        r.push(e), this.#p.set(t, r), this.notify({
                            type: "added",
                            mutation: e
                        })
                    }
                    remove(e) {
                        let t = c(e);
                        if (this.#p.has(t)) {
                            let r = this.#p.get(t) ? .filter(t => t !== e);
                            r && (0 === r.length ? this.#p.delete(t) : this.#p.set(t, r))
                        }
                        this.notify({
                            type: "removed",
                            mutation: e
                        })
                    }
                    canRun(e) {
                        let t = this.#p.get(c(e)) ? .find(e => "pending" === e.state.status);
                        return !t || t === e
                    }
                    runNext(e) {
                        let t = this.#p.get(c(e)) ? .find(t => t !== e && t.state.isPaused);
                        return t ? .continue() ? ? Promise.resolve()
                    }
                    clear() {
                        i.V.batch(() => {
                            this.getAll().forEach(e => {
                                this.remove(e)
                            })
                        })
                    }
                    getAll() {
                        return [...this.#p.values()].flat()
                    }
                    find(e) {
                        let t = {
                            exact: !0,
                            ...e
                        };
                        return this.getAll().find(e => (0, s.X7)(t, e))
                    }
                    findAll(e = {}) {
                        return this.getAll().filter(t => (0, s.X7)(e, t))
                    }
                    notify(e) {
                        i.V.batch(() => {
                            this.listeners.forEach(t => {
                                t(e)
                            })
                        })
                    }
                    resumePausedMutations() {
                        let e = this.getAll().filter(e => e.state.isPaused);
                        return i.V.batch(() => Promise.all(e.map(e => e.continue().catch(s.ZT))))
                    }
                };

            function c(e) {
                return e.options.scope ? .id ? ? String(e.mutationId)
            }
            var h = r(80568),
                d = r(6231),
                f = r(72535),
                p = class {#
                    m;#
                    n;#
                    h;#
                    g;#
                    b;#
                    v;#
                    w;#
                    O;
                    constructor(e = {}) {
                        this.#m = e.queryCache || new u, this.#n = e.mutationCache || new l, this.#h = e.defaultOptions || {}, this.#g = new Map, this.#b = new Map, this.#v = 0
                    }
                    mount() {
                        this.#v++, 1 === this.#v && (this.#w = h.j.subscribe(async e => {
                            e && (await this.resumePausedMutations(), this.#m.onFocus())
                        }), this.#O = d.N.subscribe(async e => {
                            e && (await this.resumePausedMutations(), this.#m.onOnline())
                        }))
                    }
                    unmount() {
                        this.#v--, 0 === this.#v && (this.#w ? .(), this.#w = void 0, this.#O ? .(), this.#O = void 0)
                    }
                    isFetching(e) {
                        return this.#m.findAll({ ...e,
                            fetchStatus: "fetching"
                        }).length
                    }
                    isMutating(e) {
                        return this.#n.findAll({ ...e,
                            status: "pending"
                        }).length
                    }
                    getQueryData(e) {
                        let t = this.defaultQueryOptions({
                            queryKey: e
                        });
                        return this.#m.get(t.queryHash) ? .state.data
                    }
                    ensureQueryData(e) {
                        let t = this.getQueryData(e.queryKey);
                        if (void 0 === t) return this.fetchQuery(e); {
                            let r = this.defaultQueryOptions(e),
                                n = this.#m.build(this, r);
                            return e.revalidateIfStale && n.isStaleByTime((0, s.KC)(r.staleTime, n)) && this.prefetchQuery(r), Promise.resolve(t)
                        }
                    }
                    getQueriesData(e) {
                        return this.#m.findAll(e).map(({
                            queryKey: e,
                            state: t
                        }) => [e, t.data])
                    }
                    setQueryData(e, t, r) {
                        let n = this.defaultQueryOptions({
                                queryKey: e
                            }),
                            i = this.#m.get(n.queryHash),
                            a = i ? .state.data,
                            u = (0, s.SE)(t, a);
                        if (void 0 !== u) return this.#m.build(this, n).setData(u, { ...r,
                            manual: !0
                        })
                    }
                    setQueriesData(e, t, r) {
                        return i.V.batch(() => this.#m.findAll(e).map(({
                            queryKey: e
                        }) => [e, this.setQueryData(e, t, r)]))
                    }
                    getQueryState(e) {
                        let t = this.defaultQueryOptions({
                            queryKey: e
                        });
                        return this.#m.get(t.queryHash) ? .state
                    }
                    removeQueries(e) {
                        let t = this.#m;
                        i.V.batch(() => {
                            t.findAll(e).forEach(e => {
                                t.remove(e)
                            })
                        })
                    }
                    resetQueries(e, t) {
                        let r = this.#m,
                            s = {
                                type: "active",
                                ...e
                            };
                        return i.V.batch(() => (r.findAll(e).forEach(e => {
                            e.reset()
                        }), this.refetchQueries(s, t)))
                    }
                    cancelQueries(e = {}, t = {}) {
                        let r = {
                            revert: !0,
                            ...t
                        };
                        return Promise.all(i.V.batch(() => this.#m.findAll(e).map(e => e.cancel(r)))).then(s.ZT).catch(s.ZT)
                    }
                    invalidateQueries(e = {}, t = {}) {
                        return i.V.batch(() => {
                            if (this.#m.findAll(e).forEach(e => {
                                    e.invalidate()
                                }), "none" === e.refetchType) return Promise.resolve();
                            let r = { ...e,
                                type: e.refetchType ? ? e.type ? ? "active"
                            };
                            return this.refetchQueries(r, t)
                        })
                    }
                    refetchQueries(e = {}, t) {
                        let r = { ...t,
                            cancelRefetch: t ? .cancelRefetch ? ? !0
                        };
                        return Promise.all(i.V.batch(() => this.#m.findAll(e).filter(e => !e.isDisabled()).map(e => {
                            let t = e.fetch(void 0, r);
                            return r.throwOnError || (t = t.catch(s.ZT)), "paused" === e.state.fetchStatus ? Promise.resolve() : t
                        }))).then(s.ZT)
                    }
                    fetchQuery(e) {
                        let t = this.defaultQueryOptions(e);
                        void 0 === t.retry && (t.retry = !1);
                        let r = this.#m.build(this, t);
                        return r.isStaleByTime((0, s.KC)(t.staleTime, r)) ? r.fetch(t) : Promise.resolve(r.state.data)
                    }
                    prefetchQuery(e) {
                        return this.fetchQuery(e).then(s.ZT).catch(s.ZT)
                    }
                    fetchInfiniteQuery(e) {
                        return e.behavior = (0, f.Gm)(e.pages), this.fetchQuery(e)
                    }
                    prefetchInfiniteQuery(e) {
                        return this.fetchInfiniteQuery(e).then(s.ZT).catch(s.ZT)
                    }
                    ensureInfiniteQueryData(e) {
                        return e.behavior = (0, f.Gm)(e.pages), this.ensureQueryData(e)
                    }
                    resumePausedMutations() {
                        return d.N.isOnline() ? this.#n.resumePausedMutations() : Promise.resolve()
                    }
                    getQueryCache() {
                        return this.#m
                    }
                    getMutationCache() {
                        return this.#n
                    }
                    getDefaultOptions() {
                        return this.#h
                    }
                    setDefaultOptions(e) {
                        this.#h = e
                    }
                    setQueryDefaults(e, t) {
                        this.#g.set((0, s.Ym)(e), {
                            queryKey: e,
                            defaultOptions: t
                        })
                    }
                    getQueryDefaults(e) {
                        let t = [...this.#g.values()],
                            r = {};
                        return t.forEach(t => {
                            (0, s.to)(e, t.queryKey) && (r = { ...r,
                                ...t.defaultOptions
                            })
                        }), r
                    }
                    setMutationDefaults(e, t) {
                        this.#b.set((0, s.Ym)(e), {
                            mutationKey: e,
                            defaultOptions: t
                        })
                    }
                    getMutationDefaults(e) {
                        let t = [...this.#b.values()],
                            r = {};
                        return t.forEach(t => {
                            (0, s.to)(e, t.mutationKey) && (r = { ...r,
                                ...t.defaultOptions
                            })
                        }), r
                    }
                    defaultQueryOptions(e) {
                        if (e._defaulted) return e;
                        let t = { ...this.#h.queries,
                            ...this.getQueryDefaults(e.queryKey),
                            ...e,
                            _defaulted: !0
                        };
                        return t.queryHash || (t.queryHash = (0, s.Rm)(t.queryKey, t)), void 0 === t.refetchOnReconnect && (t.refetchOnReconnect = "always" !== t.networkMode), void 0 === t.throwOnError && (t.throwOnError = !!t.suspense), !t.networkMode && t.persister && (t.networkMode = "offlineFirst"), !0 !== t.enabled && t.queryFn === s.CN && (t.enabled = !1), t
                    }
                    defaultMutationOptions(e) {
                        return e ? ._defaulted ? e : { ...this.#h.mutations,
                            ...e ? .mutationKey && this.getMutationDefaults(e.mutationKey),
                            ...e,
                            _defaulted : !0
                        }
                    }
                    clear() {
                        this.#m.clear(), this.#n.clear()
                    }
                }
        },
        32682: (e, t, r) => {
            r.d(t, {
                z: () => l
            });
            var s = r(80568),
                n = r(68086),
                i = r(57626),
                a = r(4436),
                u = r(47162),
                o = r(10751),
                l = class extends a.l {
                    constructor(e, t) {
                        super(), this.options = t, this.#R = e, this.#E = null, this.#C = (0, u.O)(), this.options.experimental_prefetchInRender || this.#C.reject(Error("experimental_prefetchInRender feature flag is not enabled")), this.bindMethods(), this.setOptions(t)
                    }#
                    R;#
                    S = void 0;#
                    Q = void 0;#
                    P = void 0;#
                    q;#
                    D;#
                    C;#
                    E;#
                    I;#
                    T;#
                    _;#
                    x;#
                    A;#
                    k;#
                    M = new Set;
                    bindMethods() {
                        this.refetch = this.refetch.bind(this)
                    }
                    onSubscribe() {
                        1 === this.listeners.size && (this.#S.addObserver(this), c(this.#S, this.options) ? this.#j() : this.updateResult(), this.#F())
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.destroy()
                    }
                    shouldFetchOnReconnect() {
                        return h(this.#S, this.options, this.options.refetchOnReconnect)
                    }
                    shouldFetchOnWindowFocus() {
                        return h(this.#S, this.options, this.options.refetchOnWindowFocus)
                    }
                    destroy() {
                        this.listeners = new Set, this.#N(), this.#U(), this.#S.removeObserver(this)
                    }
                    setOptions(e, t) {
                        let r = this.options,
                            s = this.#S;
                        if (this.options = this.#R.defaultQueryOptions(e), void 0 !== this.options.enabled && "boolean" != typeof this.options.enabled && "function" != typeof this.options.enabled && "boolean" != typeof(0, o.Nc)(this.options.enabled, this.#S)) throw Error("Expected enabled to be a boolean or a callback that returns a boolean");
                        this.#K(), this.#S.setOptions(this.options), r._defaulted && !(0, o.VS)(this.options, r) && this.#R.getQueryCache().notify({
                            type: "observerOptionsUpdated",
                            query: this.#S,
                            observer: this
                        });
                        let n = this.hasListeners();
                        n && d(this.#S, s, this.options, r) && this.#j(), this.updateResult(t), n && (this.#S !== s || (0, o.Nc)(this.options.enabled, this.#S) !== (0, o.Nc)(r.enabled, this.#S) || (0, o.KC)(this.options.staleTime, this.#S) !== (0, o.KC)(r.staleTime, this.#S)) && this.#V();
                        let i = this.#L();
                        n && (this.#S !== s || (0, o.Nc)(this.options.enabled, this.#S) !== (0, o.Nc)(r.enabled, this.#S) || i !== this.#k) && this.#z(i)
                    }
                    getOptimisticResult(e) {
                        let t = this.#R.getQueryCache().build(this.#R, e),
                            r = this.createResult(t, e);
                        return (0, o.VS)(this.getCurrentResult(), r) || (this.#P = r, this.#D = this.options, this.#q = this.#S.state), r
                    }
                    getCurrentResult() {
                        return this.#P
                    }
                    trackResult(e, t) {
                        let r = {};
                        return Object.keys(e).forEach(s => {
                            Object.defineProperty(r, s, {
                                configurable: !1,
                                enumerable: !0,
                                get: () => (this.trackProp(s), t ? .(s), e[s])
                            })
                        }), r
                    }
                    trackProp(e) {
                        this.#M.add(e)
                    }
                    getCurrentQuery() {
                        return this.#S
                    }
                    refetch({ ...e
                    } = {}) {
                        return this.fetch({ ...e
                        })
                    }
                    fetchOptimistic(e) {
                        let t = this.#R.defaultQueryOptions(e),
                            r = this.#R.getQueryCache().build(this.#R, t);
                        return r.fetch().then(() => this.createResult(r, t))
                    }
                    fetch(e) {
                        return this.#j({ ...e,
                            cancelRefetch: e.cancelRefetch ? ? !0
                        }).then(() => (this.updateResult(), this.#P))
                    }#
                    j(e) {
                        this.#K();
                        let t = this.#S.fetch(this.options, e);
                        return e ? .throwOnError || (t = t.catch(o.ZT)), t
                    }#
                    V() {
                        this.#N();
                        let e = (0, o.KC)(this.options.staleTime, this.#S);
                        if (o.sk || this.#P.isStale || !(0, o.PN)(e)) return;
                        let t = (0, o.Kp)(this.#P.dataUpdatedAt, e);
                        this.#x = setTimeout(() => {
                            this.#P.isStale || this.updateResult()
                        }, t + 1)
                    }#
                    L() {
                        return ("function" == typeof this.options.refetchInterval ? this.options.refetchInterval(this.#S) : this.options.refetchInterval) ? ? !1
                    }#
                    z(e) {
                        this.#U(), this.#k = e, !o.sk && !1 !== (0, o.Nc)(this.options.enabled, this.#S) && (0, o.PN)(this.#k) && 0 !== this.#k && (this.#A = setInterval(() => {
                            (this.options.refetchIntervalInBackground || s.j.isFocused()) && this.#j()
                        }, this.#k))
                    }#
                    F() {
                        this.#V(), this.#z(this.#L())
                    }#
                    N() {
                        this.#x && (clearTimeout(this.#x), this.#x = void 0)
                    }#
                    U() {
                        this.#A && (clearInterval(this.#A), this.#A = void 0)
                    }
                    createResult(e, t) {
                        let r;
                        let s = this.#S,
                            n = this.options,
                            a = this.#P,
                            l = this.#q,
                            h = this.#D,
                            p = e !== s ? e.state : this.#Q,
                            {
                                state: y
                            } = e,
                            m = { ...y
                            },
                            g = !1;
                        if (t._optimisticResults) {
                            let r = this.hasListeners(),
                                a = !r && c(e, t),
                                u = r && d(e, s, t, n);
                            (a || u) && (m = { ...m,
                                ...(0, i.z)(y.data, e.options)
                            }), "isRestoring" === t._optimisticResults && (m.fetchStatus = "idle")
                        }
                        let {
                            error: b,
                            errorUpdatedAt: v,
                            status: w
                        } = m;
                        if (t.select && void 0 !== m.data) {
                            if (a && m.data === l ? .data && t.select === this.#I) r = this.#T;
                            else try {
                                this.#I = t.select, r = t.select(m.data), r = (0, o.oE)(a ? .data, r, t), this.#T = r, this.#E = null
                            } catch (e) {
                                this.#E = e
                            }
                        } else r = m.data;
                        if (void 0 !== t.placeholderData && void 0 === r && "pending" === w) {
                            let e;
                            if (a ? .isPlaceholderData && t.placeholderData === h ? .placeholderData) e = a.data;
                            else if (e = "function" == typeof t.placeholderData ? t.placeholderData(this.#_ ? .state.data, this.#_) : t.placeholderData, t.select && void 0 !== e) try {
                                e = t.select(e), this.#E = null
                            } catch (e) {
                                this.#E = e
                            }
                            void 0 !== e && (w = "success", r = (0, o.oE)(a ? .data, e, t), g = !0)
                        }
                        this.#E && (b = this.#E, r = this.#T, v = Date.now(), w = "error");
                        let O = "fetching" === m.fetchStatus,
                            R = "pending" === w,
                            E = "error" === w,
                            C = R && O,
                            S = void 0 !== r,
                            Q = {
                                status: w,
                                fetchStatus: m.fetchStatus,
                                isPending: R,
                                isSuccess: "success" === w,
                                isError: E,
                                isInitialLoading: C,
                                isLoading: C,
                                data: r,
                                dataUpdatedAt: m.dataUpdatedAt,
                                error: b,
                                errorUpdatedAt: v,
                                failureCount: m.fetchFailureCount,
                                failureReason: m.fetchFailureReason,
                                errorUpdateCount: m.errorUpdateCount,
                                isFetched: m.dataUpdateCount > 0 || m.errorUpdateCount > 0,
                                isFetchedAfterMount: m.dataUpdateCount > p.dataUpdateCount || m.errorUpdateCount > p.errorUpdateCount,
                                isFetching: O,
                                isRefetching: O && !R,
                                isLoadingError: E && !S,
                                isPaused: "paused" === m.fetchStatus,
                                isPlaceholderData: g,
                                isRefetchError: E && S,
                                isStale: f(e, t),
                                refetch: this.refetch,
                                promise: this.#C
                            };
                        if (this.options.experimental_prefetchInRender) {
                            let t = e => {
                                    "error" === Q.status ? e.reject(Q.error) : void 0 !== Q.data && e.resolve(Q.data)
                                },
                                r = () => {
                                    t(this.#C = Q.promise = (0, u.O)())
                                },
                                n = this.#C;
                            switch (n.status) {
                                case "pending":
                                    e.queryHash === s.queryHash && t(n);
                                    break;
                                case "fulfilled":
                                    ("error" === Q.status || Q.data !== n.value) && r();
                                    break;
                                case "rejected":
                                    ("error" !== Q.status || Q.error !== n.reason) && r()
                            }
                        }
                        return Q
                    }
                    updateResult(e) {
                        let t = this.#P,
                            r = this.createResult(this.#S, this.options);
                        if (this.#q = this.#S.state, this.#D = this.options, void 0 !== this.#q.data && (this.#_ = this.#S), (0, o.VS)(r, t)) return;
                        this.#P = r;
                        let s = {};
                        e ? .listeners !== !1 && (() => {
                            if (!t) return !0;
                            let {
                                notifyOnChangeProps: e
                            } = this.options, r = "function" == typeof e ? e() : e;
                            if ("all" === r || !r && !this.#M.size) return !0;
                            let s = new Set(r ? ? this.#M);
                            return this.options.throwOnError && s.add("error"), Object.keys(this.#P).some(e => this.#P[e] !== t[e] && s.has(e))
                        })() && (s.listeners = !0), this.#H({ ...s,
                            ...e
                        })
                    }#
                    K() {
                        let e = this.#R.getQueryCache().build(this.#R, this.options);
                        if (e === this.#S) return;
                        let t = this.#S;
                        this.#S = e, this.#Q = e.state, this.hasListeners() && (t ? .removeObserver(this), e.addObserver(this))
                    }
                    onQueryUpdate() {
                        this.updateResult(), this.hasListeners() && this.#F()
                    }#
                    H(e) {
                        n.V.batch(() => {
                            e.listeners && this.listeners.forEach(e => {
                                e(this.#P)
                            }), this.#R.getQueryCache().notify({
                                query: this.#S,
                                type: "observerResultsUpdated"
                            })
                        })
                    }
                };

            function c(e, t) {
                return !1 !== (0, o.Nc)(t.enabled, e) && void 0 === e.state.data && !("error" === e.state.status && !1 === t.retryOnMount) || void 0 !== e.state.data && h(e, t, t.refetchOnMount)
            }

            function h(e, t, r) {
                if (!1 !== (0, o.Nc)(t.enabled, e)) {
                    let s = "function" == typeof r ? r(e) : r;
                    return "always" === s || !1 !== s && f(e, t)
                }
                return !1
            }

            function d(e, t, r, s) {
                return (e !== t || !1 === (0, o.Nc)(s.enabled, e)) && (!r.suspense || "error" !== e.state.status) && f(e, r)
            }

            function f(e, t) {
                return !1 !== (0, o.Nc)(t.enabled, e) && e.isStaleByTime((0, o.KC)(t.staleTime, e))
            }
        },
        36040: (e, t, r) => {
            r.d(t, {
                F: () => n
            });
            var s = r(10751),
                n = class {#
                    B;
                    destroy() {
                        this.clearGcTimeout()
                    }
                    scheduleGc() {
                        this.clearGcTimeout(), (0, s.PN)(this.gcTime) && (this.#B = setTimeout(() => {
                            this.optionalRemove()
                        }, this.gcTime))
                    }
                    updateGcTime(e) {
                        this.gcTime = Math.max(this.gcTime || 0, e ? ? (s.sk ? 1 / 0 : 3e5))
                    }
                    clearGcTimeout() {
                        this.#B && (clearTimeout(this.#B), this.#B = void 0)
                    }
                }
        },
        38706: (e, t, r) => {
            r.d(t, {
                DV: () => c,
                Kw: () => o,
                Mz: () => h
            });
            var s = r(80568),
                n = r(6231),
                i = r(47162),
                a = r(10751);

            function u(e) {
                return Math.min(1e3 * 2 ** e, 3e4)
            }

            function o(e) {
                return (e ? ? "online") !== "online" || n.N.isOnline()
            }
            var l = class extends Error {
                constructor(e) {
                    super("CancelledError"), this.revert = e ? .revert, this.silent = e ? .silent
                }
            };

            function c(e) {
                return e instanceof l
            }

            function h(e) {
                let t, r = !1,
                    c = 0,
                    h = !1,
                    d = (0, i.O)(),
                    f = () => s.j.isFocused() && ("always" === e.networkMode || n.N.isOnline()) && e.canRun(),
                    p = () => o(e.networkMode) && e.canRun(),
                    y = r => {
                        h || (h = !0, e.onSuccess ? .(r), t ? .(), d.resolve(r))
                    },
                    m = r => {
                        h || (h = !0, e.onError ? .(r), t ? .(), d.reject(r))
                    },
                    g = () => new Promise(r => {
                        t = e => {
                            (h || f()) && r(e)
                        }, e.onPause ? .()
                    }).then(() => {
                        t = void 0, h || e.onContinue ? .()
                    }),
                    b = () => {
                        let t;
                        if (h) return;
                        let s = 0 === c ? e.initialPromise : void 0;
                        try {
                            t = s ? ? e.fn()
                        } catch (e) {
                            t = Promise.reject(e)
                        }
                        Promise.resolve(t).then(y).catch(t => {
                            if (h) return;
                            let s = e.retry ? ? (a.sk ? 0 : 3),
                                n = e.retryDelay ? ? u,
                                i = "function" == typeof n ? n(c, t) : n,
                                o = !0 === s || "number" == typeof s && c < s || "function" == typeof s && s(c, t);
                            if (r || !o) {
                                m(t);
                                return
                            }
                            c++, e.onFail ? .(c, t), (0, a._v)(i).then(() => f() ? void 0 : g()).then(() => {
                                r ? m(t) : b()
                            })
                        })
                    };
                return {
                    promise: d,
                    cancel: t => {
                        h || (m(new l(t)), e.abort ? .())
                    },
                    continue: () => (t ? .(), d),
                    cancelRetry: () => {
                        r = !0
                    },
                    continueRetry: () => {
                        r = !1
                    },
                    canStart: p,
                    start: () => (p() ? b() : g().then(b), d)
                }
            }
        },
        4436: (e, t, r) => {
            r.d(t, {
                l: () => s
            });
            var s = class {
                constructor() {
                    this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
                }
                subscribe(e) {
                    return this.listeners.add(e), this.onSubscribe(), () => {
                        this.listeners.delete(e), this.onUnsubscribe()
                    }
                }
                hasListeners() {
                    return this.listeners.size > 0
                }
                onSubscribe() {}
                onUnsubscribe() {}
            }
        },
        47162: (e, t, r) => {
            r.d(t, {
                O: () => s
            });

            function s() {
                let e, t;
                let r = new Promise((r, s) => {
                    e = r, t = s
                });

                function s(e) {
                    Object.assign(r, e), delete r.resolve, delete r.reject
                }
                return r.status = "pending", r.catch(() => {}), r.resolve = t => {
                    s({
                        status: "fulfilled",
                        value: t
                    }), e(t)
                }, r.reject = e => {
                    s({
                        status: "rejected",
                        reason: e
                    }), t(e)
                }, r
            }
        },
        10751: (e, t, r) => {
            r.d(t, {
                CN: () => C,
                Ht: () => E,
                KC: () => o,
                Kp: () => u,
                Nc: () => l,
                PN: () => a,
                Q$: () => y,
                Rm: () => d,
                SE: () => i,
                VS: () => m,
                VX: () => R,
                X7: () => h,
                Ym: () => f,
                ZT: () => n,
                _v: () => w,
                _x: () => c,
                cG: () => S,
                oE: () => O,
                sk: () => s,
                to: () => p
            });
            var s = "undefined" == typeof window || "Deno" in globalThis;

            function n() {}

            function i(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function a(e) {
                return "number" == typeof e && e >= 0 && e !== 1 / 0
            }

            function u(e, t) {
                return Math.max(e + (t || 0) - Date.now(), 0)
            }

            function o(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function l(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function c(e, t) {
                let {
                    type: r = "all",
                    exact: s,
                    fetchStatus: n,
                    predicate: i,
                    queryKey: a,
                    stale: u
                } = e;
                if (a) {
                    if (s) {
                        if (t.queryHash !== d(a, t.options)) return !1
                    } else if (!p(t.queryKey, a)) return !1
                }
                if ("all" !== r) {
                    let e = t.isActive();
                    if ("active" === r && !e || "inactive" === r && e) return !1
                }
                return ("boolean" != typeof u || t.isStale() === u) && (!n || n === t.state.fetchStatus) && (!i || !!i(t))
            }

            function h(e, t) {
                let {
                    exact: r,
                    status: s,
                    predicate: n,
                    mutationKey: i
                } = e;
                if (i) {
                    if (!t.options.mutationKey) return !1;
                    if (r) {
                        if (f(t.options.mutationKey) !== f(i)) return !1
                    } else if (!p(t.options.mutationKey, i)) return !1
                }
                return (!s || t.state.status === s) && (!n || !!n(t))
            }

            function d(e, t) {
                return (t ? .queryKeyHashFn || f)(e)
            }

            function f(e) {
                return JSON.stringify(e, (e, t) => b(t) ? Object.keys(t).sort().reduce((e, r) => (e[r] = t[r], e), {}) : t)
            }

            function p(e, t) {
                return e === t || typeof e == typeof t && !!e && !!t && "object" == typeof e && "object" == typeof t && !Object.keys(t).some(r => !p(e[r], t[r]))
            }

            function y(e, t) {
                if (e === t) return e;
                let r = g(e) && g(t);
                if (r || b(e) && b(t)) {
                    let s = r ? e : Object.keys(e),
                        n = s.length,
                        i = r ? t : Object.keys(t),
                        a = i.length,
                        u = r ? [] : {},
                        o = 0;
                    for (let n = 0; n < a; n++) {
                        let a = r ? n : i[n];
                        (!r && s.includes(a) || r) && void 0 === e[a] && void 0 === t[a] ? (u[a] = void 0, o++) : (u[a] = y(e[a], t[a]), u[a] === e[a] && void 0 !== e[a] && o++)
                    }
                    return n === a && o === n ? e : u
                }
                return t
            }

            function m(e, t) {
                if (!t || Object.keys(e).length !== Object.keys(t).length) return !1;
                for (let r in e)
                    if (e[r] !== t[r]) return !1;
                return !0
            }

            function g(e) {
                return Array.isArray(e) && e.length === Object.keys(e).length
            }

            function b(e) {
                if (!v(e)) return !1;
                let t = e.constructor;
                if (void 0 === t) return !0;
                let r = t.prototype;
                return !!(v(r) && r.hasOwnProperty("isPrototypeOf")) && Object.getPrototypeOf(e) === Object.prototype
            }

            function v(e) {
                return "[object Object]" === Object.prototype.toString.call(e)
            }

            function w(e) {
                return new Promise(t => {
                    setTimeout(t, e)
                })
            }

            function O(e, t, r) {
                return "function" == typeof r.structuralSharing ? r.structuralSharing(e, t) : !1 !== r.structuralSharing ? y(e, t) : t
            }

            function R(e, t, r = 0) {
                let s = [...e, t];
                return r && s.length > r ? s.slice(1) : s
            }

            function E(e, t, r = 0) {
                let s = [t, ...e];
                return r && s.length > r ? s.slice(0, -1) : s
            }
            var C = Symbol();

            function S(e, t) {
                return !e.queryFn && t ? .initialPromise ? () => t.initialPromise : e.queryFn && e.queryFn !== C ? e.queryFn : () => Promise.reject(Error(`Missing queryFn: '${e.queryHash}'`))
            }
        },
        90188: (e, t, r) => {
            r.d(t, {
                V: () => f
            });
            var s = r(45447),
                n = r(10751),
                i = r(68714),
                a = r(93264),
                u = r(47576),
                o = {
                    "&": "\\u0026",
                    ">": "\\u003e",
                    "<": "\\u003c",
                    "\u2028": "\\u2028",
                    "\u2029": "\\u2029"
                },
                l = /[&><\u2028\u2029]/g;

            function c(e) {
                return e.replace(l, e => o[e])
            }
            var h = r(12428);
            Symbol("serialized");
            var d = function() {
                let e = a.createContext(null);
                return {
                    Provider: function(t) {
                        let r = "__RQ".concat(a.useId()),
                            s = c(JSON.stringify(r)),
                            [i] = a.useState(() => {
                                var e;
                                return null !== (e = t.transformer) && void 0 !== e ? e : {
                                    serialize: e => e,
                                    deserialize: e => e
                                }
                            }),
                            [o] = a.useState(() => n.sk ? [] : {
                                push() {}
                            }),
                            l = a.useRef(0);
                        if ((0, u.useServerInsertedHTML)(() => {
                                var e, r;
                                if (o.push(...null !== (r = null === (e = t.onFlush) || void 0 === e ? void 0 : e.call(t)) && void 0 !== r ? r : []), !o.length) return null;
                                let n = o.map(e => i.serialize(e)).map(e => JSON.stringify(e)).join(",");
                                o.length = 0;
                                let a = ["window[".concat(s, "] = window[").concat(s, "] || [];"), "window[".concat(s, "].push(").concat(c(n), ");")];
                                return (0, h.jsx)("script", {
                                    nonce: t.nonce,
                                    dangerouslySetInnerHTML: {
                                        __html: a.join("")
                                    }
                                }, l.current++)
                            }), !n.sk) {
                            var d, f;
                            let e = window;
                            if (!(null === (d = e[r]) || void 0 === d ? void 0 : d.initialized)) {
                                let s = function() {
                                    for (var e = arguments.length, r = Array(e), s = 0; s < e; s++) r[s] = arguments[s];
                                    let n = r.map(e => i.deserialize(e));
                                    t.onEntries(n)
                                };
                                s(...null !== (f = e[r]) && void 0 !== f ? f : []), e[r] = {
                                    initialized: !0,
                                    push: s
                                }
                            }
                        }
                        return (0, h.jsx)(e.Provider, {
                            value: {
                                stream: o,
                                id: r
                            },
                            children: t.children
                        })
                    },
                    context: e
                }
            }();

            function f(e) {
                let t = (0, s.useQueryClient)(e.queryClient),
                    [r] = a.useState(() => new Set);
                return n.sk && t.getQueryCache().subscribe(e => {
                    switch (e.type) {
                        case "added":
                        case "updated":
                            r.add(e.query.queryHash)
                    }
                }), (0, h.jsx)(d.Provider, {
                    onFlush: () => {
                        var s, n, a, u;
                        let o = null !== (u = null === (n = e.options) || void 0 === n ? void 0 : null === (s = n.dehydrate) || void 0 === s ? void 0 : s.shouldDehydrateQuery) && void 0 !== u ? u : i.d_,
                            l = (0, i.D)(t, { ...null === (a = e.options) || void 0 === a ? void 0 : a.dehydrate,
                                shouldDehydrateQuery: e => r.has(e.queryHash) && o(e)
                            });
                        return (r.clear(), l.queries.length) ? [l] : []
                    },
                    onEntries: r => {
                        for (let n of r) {
                            var s;
                            (0, i.ZB)(t, n, null === (s = e.options) || void 0 === s ? void 0 : s.hydrate)
                        }
                    },
                    transformer: e.transformer,
                    nonce: e.nonce,
                    children: e.children
                })
            }
        },
        45447: (e, t, r) => {
            r.r(t), r.d(t, {
                QueryClientContext: () => i,
                QueryClientProvider: () => u,
                useQueryClient: () => a
            });
            var s = r(93264),
                n = r(12428),
                i = s.createContext(void 0),
                a = e => {
                    let t = s.useContext(i);
                    if (e) return e;
                    if (!t) throw Error("No QueryClient set, use QueryClientProvider to set one");
                    return t
                },
                u = e => {
                    let {
                        client: t,
                        children: r
                    } = e;
                    return s.useEffect(() => (t.mount(), () => {
                        t.unmount()
                    }), [t]), (0, n.jsx)(i.Provider, {
                        value: t,
                        children: r
                    })
                }
        },
        45468: (e, t, r) => {
            r.d(t, {
                QueryErrorResetBoundary: () => o,
                useQueryErrorResetBoundary: () => u
            });
            var s = r(93264),
                n = r(12428);

            function i() {
                let e = !1;
                return {
                    clearReset: () => {
                        e = !1
                    },
                    reset: () => {
                        e = !0
                    },
                    isReset: () => e
                }
            }
            var a = s.createContext(i()),
                u = () => s.useContext(a),
                o = e => {
                    let {
                        children: t
                    } = e, [r] = s.useState(() => i());
                    return (0, n.jsx)(a.Provider, {
                        value: r,
                        children: "function" == typeof t ? t(r) : t
                    })
                }
        },
        91911: (e, t, r) => {
            r.d(t, {
                JN: () => a,
                KJ: () => u,
                pf: () => i
            });
            var s = r(93264),
                n = r(91303),
                i = (e, t) => {
                    (e.suspense || e.throwOnError || e.experimental_prefetchInRender) && !t.isReset() && (e.retryOnMount = !1)
                },
                a = e => {
                    s.useEffect(() => {
                        e.clearReset()
                    }, [e])
                },
                u = e => {
                    let {
                        result: t,
                        errorResetBoundary: r,
                        throwOnError: s,
                        query: i
                    } = e;
                    return t.isError && !r.isReset() && !t.isFetching && i && (0, n.L)(s, [t.error, i])
                }
        },
        32271: (e, t, r) => {
            r.d(t, {
                IsRestoringProvider: () => a,
                useIsRestoring: () => i
            });
            var s = r(93264),
                n = s.createContext(!1),
                i = () => s.useContext(n),
                a = n.Provider
        },
        9237: (e, t, r) => {
            r.d(t, {
                A8: () => n,
                Ct: () => s,
                SB: () => a,
                Z$: () => i,
                j8: () => u
            });
            var s = (e, t) => void 0 === t.state.data,
                n = e => {
                    e.suspense && (void 0 === e.staleTime && (e.staleTime = 1e3), "number" == typeof e.gcTime && (e.gcTime = Math.max(e.gcTime, 1e3)))
                },
                i = (e, t) => e.isLoading && e.isFetching && !t,
                a = (e, t) => e ? .suspense && t.isPending,
                u = (e, t, r) => t.fetchOptimistic(e).catch(() => {
                    r.clearReset()
                })
        },
        87673: (e, t, r) => {
            r.d(t, {
                r: () => d
            });
            var s = r(93264),
                n = r(68086),
                i = r(10751),
                a = r(45447),
                u = r(45468),
                o = r(91911),
                l = r(32271),
                c = r(9237),
                h = r(91303);

            function d(e, t, r) {
                var d, f, p, y, m;
                let g = (0, a.useQueryClient)(r),
                    b = (0, l.useIsRestoring)(),
                    v = (0, u.useQueryErrorResetBoundary)(),
                    w = g.defaultQueryOptions(e);
                null === (f = g.getDefaultOptions().queries) || void 0 === f || null === (d = f._experimental_beforeQuery) || void 0 === d || d.call(f, w), w._optimisticResults = b ? "isRestoring" : "optimistic", (0, c.A8)(w), (0, o.pf)(w, v), (0, o.JN)(v);
                let O = !g.getQueryCache().get(w.queryHash),
                    [R] = s.useState(() => new t(g, w)),
                    E = R.getOptimisticResult(w);
                if (s.useSyncExternalStore(s.useCallback(e => {
                        let t = b ? () => void 0 : R.subscribe(n.V.batchCalls(e));
                        return R.updateResult(), t
                    }, [R, b]), () => R.getCurrentResult(), () => R.getCurrentResult()), s.useEffect(() => {
                        R.setOptions(w, {
                            listeners: !1
                        })
                    }, [w, R]), (0, c.SB)(w, E)) throw (0, c.j8)(w, R, v);
                if ((0, o.KJ)({
                        result: E,
                        errorResetBoundary: v,
                        throwOnError: w.throwOnError,
                        query: g.getQueryCache().get(w.queryHash)
                    })) throw E.error;
                if (null === (y = g.getDefaultOptions().queries) || void 0 === y || null === (p = y._experimental_afterQuery) || void 0 === p || p.call(y, w, E), w.experimental_prefetchInRender && !i.sk && (0, c.Z$)(E, b)) {
                    let e = O ? (0, c.j8)(w, R, v) : null === (m = g.getQueryCache().get(w.queryHash)) || void 0 === m ? void 0 : m.promise;
                    null == e || e.catch(h.Z).finally(() => {
                        R.updateResult()
                    })
                }
                return w.notifyOnChangeProps ? E : R.trackResult(E)
            }
        },
        39967: (e, t, r) => {
            r.d(t, {
                useInfiniteQuery: () => i
            });
            var s = r(75122),
                n = r(87673);

            function i(e, t) {
                return (0, n.r)(e, s.c, t)
            }
        },
        88438: (e, t, r) => {
            r.d(t, {
                useMutation: () => h
            });
            var s = r(93264),
                n = r(94716),
                i = r(68086),
                a = r(4436),
                u = r(10751),
                o = class extends a.l {#
                    R;#
                    P = void 0;#
                    G;#
                    Z;
                    constructor(e, t) {
                        super(), this.#R = e, this.setOptions(t), this.bindMethods(), this.#$()
                    }
                    bindMethods() {
                        this.mutate = this.mutate.bind(this), this.reset = this.reset.bind(this)
                    }
                    setOptions(e) {
                        let t = this.options;
                        this.options = this.#R.defaultMutationOptions(e), (0, u.VS)(this.options, t) || this.#R.getMutationCache().notify({
                            type: "observerOptionsUpdated",
                            mutation: this.#G,
                            observer: this
                        }), t ? .mutationKey && this.options.mutationKey && (0, u.Ym)(t.mutationKey) !== (0, u.Ym)(this.options.mutationKey) ? this.reset() : this.#G ? .state.status === "pending" && this.#G.setOptions(this.options)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.#G ? .removeObserver(this)
                    }
                    onMutationUpdate(e) {
                        this.#$(), this.#H(e)
                    }
                    getCurrentResult() {
                        return this.#P
                    }
                    reset() {
                        this.#G ? .removeObserver(this), this.#G = void 0, this.#$(), this.#H()
                    }
                    mutate(e, t) {
                        return this.#Z = t, this.#G ? .removeObserver(this), this.#G = this.#R.getMutationCache().build(this.#R, this.options), this.#G.addObserver(this), this.#G.execute(e)
                    }#
                    $() {
                        let e = this.#G ? .state ? ? (0, n.R)();
                        this.#P = { ...e,
                            isPending: "pending" === e.status,
                            isSuccess: "success" === e.status,
                            isError: "error" === e.status,
                            isIdle: "idle" === e.status,
                            mutate: this.mutate,
                            reset: this.reset
                        }
                    }#
                    H(e) {
                        i.V.batch(() => {
                            if (this.#Z && this.hasListeners()) {
                                let t = this.#P.variables,
                                    r = this.#P.context;
                                e ? .type === "success" ? (this.#Z.onSuccess ? .(e.data, t, r), this.#Z.onSettled ? .(e.data, null, t, r)) : e ? .type === "error" && (this.#Z.onError ? .(e.error, t, r), this.#Z.onSettled ? .(void 0, e.error, t, r))
                            }
                            this.listeners.forEach(e => {
                                e(this.#P)
                            })
                        })
                    }
                },
                l = r(45447),
                c = r(91303);

            function h(e, t) {
                let r = (0, l.useQueryClient)(t),
                    [n] = s.useState(() => new o(r, e));
                s.useEffect(() => {
                    n.setOptions(e)
                }, [n, e]);
                let a = s.useSyncExternalStore(s.useCallback(e => n.subscribe(i.V.batchCalls(e)), [n]), () => n.getCurrentResult(), () => n.getCurrentResult()),
                    u = s.useCallback((e, t) => {
                        n.mutate(e, t).catch(c.Z)
                    }, [n]);
                if (a.error && (0, c.L)(n.options.throwOnError, [a.error])) throw a.error;
                return { ...a,
                    mutate: u,
                    mutateAsync: a.mutate
                }
            }
        },
        83730: (e, t, r) => {
            r.d(t, {
                useQueries: () => y
            });
            var s = r(93264),
                n = r(68086),
                i = r(32682),
                a = r(4436),
                u = r(10751);

            function o(e, t) {
                return e.filter(e => !t.includes(e))
            }
            var l = class extends a.l {#
                    R;#
                    W;#
                    f;#
                    Y;#
                    s;#
                    J;#
                    X;#
                    ee;
                    constructor(e, t, r) {
                        super(), this.#R = e, this.#Y = r, this.#f = [], this.#s = [], this.#W = [], this.setQueries(t)
                    }
                    onSubscribe() {
                        1 === this.listeners.size && this.#s.forEach(e => {
                            e.subscribe(t => {
                                this.#et(e, t)
                            })
                        })
                    }
                    onUnsubscribe() {
                        this.listeners.size || this.destroy()
                    }
                    destroy() {
                        this.listeners = new Set, this.#s.forEach(e => {
                            e.destroy()
                        })
                    }
                    setQueries(e, t, r) {
                        this.#f = e, this.#Y = t, n.V.batch(() => {
                            let e = this.#s,
                                t = this.#er(this.#f);
                            t.forEach(e => e.observer.setOptions(e.defaultedQueryOptions, r));
                            let s = t.map(e => e.observer),
                                n = s.map(e => e.getCurrentResult()),
                                i = s.some((t, r) => t !== e[r]);
                            (e.length !== s.length || i) && (this.#s = s, this.#W = n, this.hasListeners() && (o(e, s).forEach(e => {
                                e.destroy()
                            }), o(s, e).forEach(e => {
                                e.subscribe(t => {
                                    this.#et(e, t)
                                })
                            }), this.#H()))
                        })
                    }
                    getCurrentResult() {
                        return this.#W
                    }
                    getQueries() {
                        return this.#s.map(e => e.getCurrentQuery())
                    }
                    getObservers() {
                        return this.#s
                    }
                    getOptimisticResult(e, t) {
                        let r = this.#er(e),
                            s = r.map(e => e.observer.getOptimisticResult(e.defaultedQueryOptions));
                        return [s, e => this.#es(e ? ? s, t), () => r.map((e, t) => {
                            let n = s[t];
                            return e.defaultedQueryOptions.notifyOnChangeProps ? n : e.observer.trackResult(n, e => {
                                r.forEach(t => {
                                    t.observer.trackProp(e)
                                })
                            })
                        })]
                    }#
                    es(e, t) {
                        return t ? (this.#J && this.#W === this.#ee && t === this.#X || (this.#X = t, this.#ee = this.#W, this.#J = (0, u.Q$)(this.#J, t(e))), this.#J) : e
                    }#
                    er(e) {
                        let t = new Map(this.#s.map(e => [e.options.queryHash, e])),
                            r = [];
                        return e.forEach(e => {
                            let s = this.#R.defaultQueryOptions(e),
                                n = t.get(s.queryHash);
                            if (n) r.push({
                                defaultedQueryOptions: s,
                                observer: n
                            });
                            else {
                                let e = this.#s.find(e => e.options.queryHash === s.queryHash);
                                r.push({
                                    defaultedQueryOptions: s,
                                    observer: e ? ? new i.z(this.#R, s)
                                })
                            }
                        }), r.sort((t, r) => e.findIndex(e => e.queryHash === t.defaultedQueryOptions.queryHash) - e.findIndex(e => e.queryHash === r.defaultedQueryOptions.queryHash))
                    }#
                    et(e, t) {
                        let r = this.#s.indexOf(e); - 1 !== r && (this.#W = function(e, t, r) {
                            let s = e.slice(0);
                            return s[t] = r, s
                        }(this.#W, r, t), this.#H())
                    }#
                    H() {
                        this.hasListeners() && this.#J !== this.#es(this.#W, this.#Y ? .combine) && n.V.batch(() => {
                            this.listeners.forEach(e => {
                                e(this.#W)
                            })
                        })
                    }
                },
                c = r(45447),
                h = r(32271),
                d = r(45468),
                f = r(91911),
                p = r(9237);

            function y(e, t) {
                let {
                    queries: r,
                    ...a
                } = e, u = (0, c.useQueryClient)(t), o = (0, h.useIsRestoring)(), y = (0, d.useQueryErrorResetBoundary)(), m = s.useMemo(() => r.map(e => {
                    let t = u.defaultQueryOptions(e);
                    return t._optimisticResults = o ? "isRestoring" : "optimistic", t
                }), [r, u, o]);
                m.forEach(e => {
                    (0, p.A8)(e), (0, f.pf)(e, y)
                }), (0, f.JN)(y);
                let [g] = s.useState(() => new l(u, m, a)), [b, v, w] = g.getOptimisticResult(m, a.combine);
                s.useSyncExternalStore(s.useCallback(e => o ? () => void 0 : g.subscribe(n.V.batchCalls(e)), [g, o]), () => g.getCurrentResult(), () => g.getCurrentResult()), s.useEffect(() => {
                    g.setQueries(m, a, {
                        listeners: !1
                    })
                }, [m, a, g]);
                let O = b.some((e, t) => (0, p.SB)(m[t], e)) ? b.flatMap((e, t) => {
                    let r = m[t];
                    if (r) {
                        let t = new i.z(u, r);
                        if ((0, p.SB)(r, e)) return (0, p.j8)(r, t, y);
                        (0, p.Z$)(e, o) && (0, p.j8)(r, t, y)
                    }
                    return []
                }) : [];
                if (O.length > 0) throw Promise.all(O);
                let R = b.find((e, t) => {
                    let r = m[t];
                    return r && (0, f.KJ)({
                        result: e,
                        errorResetBoundary: y,
                        throwOnError: r.throwOnError,
                        query: u.getQueryCache().get(r.queryHash)
                    })
                });
                if (null == R ? void 0 : R.error) throw R.error;
                return v(w())
            }
        },
        41137: (e, t, r) => {
            r.d(t, {
                useQuery: () => i
            });
            var s = r(32682),
                n = r(87673);

            function i(e, t) {
                return (0, n.r)(e, s.z, t)
            }
        },
        40491: (e, t, r) => {
            r.d(t, {
                useSuspenseInfiniteQuery: () => a
            });
            var s = r(75122),
                n = r(87673),
                i = r(9237);

            function a(e, t) {
                return (0, n.r)({ ...e,
                    enabled: !0,
                    suspense: !0,
                    throwOnError: i.Ct
                }, s.c, t)
            }
        },
        49177: (e, t, r) => {
            r.d(t, {
                useSuspenseQueries: () => i
            });
            var s = r(83730),
                n = r(9237);

            function i(e, t) {
                return (0, s.useQueries)({ ...e,
                    queries: e.queries.map(e => ({ ...e,
                        suspense: !0,
                        throwOnError: n.Ct,
                        enabled: !0,
                        placeholderData: void 0
                    }))
                }, t)
            }
        },
        69586: (e, t, r) => {
            r.d(t, {
                useSuspenseQuery: () => a
            });
            var s = r(32682),
                n = r(87673),
                i = r(9237);

            function a(e, t) {
                return (0, n.r)({ ...e,
                    enabled: !0,
                    suspense: !0,
                    throwOnError: i.Ct,
                    placeholderData: void 0
                }, s.z, t)
            }
        },
        91303: (e, t, r) => {
            function s(e, t) {
                return "function" == typeof e ? e(...t) : !!e
            }

            function n() {}
            r.d(t, {
                L: () => s,
                Z: () => n
            })
        },
        72140: (e, t, r) => {
            r.d(t, {
                NT: () => o,
                Bm: () => d,
                fE: () => l,
                ny: () => f,
                N8: () => Q
            });
            var s = r(29045),
                n = r(53775);

            function i(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            class a extends Error {
                static from(e, t = {}) {
                    return e instanceof a || e instanceof Error && "TRPCClientError" === e.name ? (t.meta && (e.meta = { ...e.meta,
                        ...t.meta
                    }), e) : (0, n.Kn)(e) && (0, n.Kn)(e.error) && "number" == typeof e.error.code && "string" == typeof e.error.message ? new a(e.error.message, { ...t,
                        result: e
                    }) : new a("string" == typeof e ? e : (0, n.Kn)(e) && "string" == typeof e.message ? e.message : "Unknown error", { ...t,
                        cause: e
                    })
                }
                constructor(e, t) {
                    let r = t ? .cause;
                    super(e, {
                        cause: r
                    }), i(this, "cause", void 0), i(this, "shape", void 0), i(this, "data", void 0), i(this, "meta", void 0), this.meta = t ? .meta, this.cause = r, this.shape = t ? .result ? .error, this.data = t ? .result ? .error.data, this.name = "TRPCClientError", Object.setPrototypeOf(this, a.prototype)
                }
            }

            function u(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            class o {
                $request(e) {
                    var t;
                    return (t = {
                        links: this.links,
                        op: { ...e,
                            context: e.context ? ? {},
                            id: ++this.requestId
                        }
                    }, (0, s.LO)(e => (function e(r = 0, s = t.op) {
                        let n = t.links[r];
                        if (!n) throw Error("No more links to execute - did you forget to add an ending link?");
                        return n({
                            op: s,
                            next: t => e(r + 1, t)
                        })
                    })().subscribe(e))).pipe((0, s.BN)())
                }
                async requestAsPromise(e) {
                    try {
                        let t = this.$request(e);
                        return (await (0, s.xA)(t)).result.data
                    } catch (e) {
                        throw a.from(e)
                    }
                }
                query(e, t, r) {
                    return this.requestAsPromise({
                        type: "query",
                        path: e,
                        input: t,
                        context: r ? .context,
                        signal: r ? .signal
                    })
                }
                mutation(e, t, r) {
                    return this.requestAsPromise({
                        type: "mutation",
                        path: e,
                        input: t,
                        context: r ? .context,
                        signal: r ? .signal
                    })
                }
                subscription(e, t, r) {
                    return this.$request({
                        type: "subscription",
                        path: e,
                        input: t,
                        context: r.context,
                        signal: r.signal
                    }).subscribe({
                        next(e) {
                            switch (e.result.type) {
                                case "state":
                                    r.onConnectionStateChange ? .(e.result);
                                    break;
                                case "started":
                                    r.onStarted ? .({
                                        context: e.context
                                    });
                                    break;
                                case "stopped":
                                    r.onStopped ? .();
                                    break;
                                case "data":
                                case void 0:
                                    r.onData ? .(e.result.data)
                            }
                        },
                        error(e) {
                            r.onError ? .(e)
                        },
                        complete() {
                            r.onComplete ? .()
                        }
                    })
                }
                constructor(e) {
                    u(this, "links", void 0), u(this, "runtime", void 0), u(this, "requestId", void 0), this.requestId = 0, this.runtime = {}, this.links = e.links.map(e => e(this.runtime))
                }
            }

            function l(e) {
                return new o(e)
            }
            let c = {
                    query: "query",
                    mutate: "mutation",
                    subscribe: "subscription"
                },
                h = e => c[e];

            function d(e) {
                let t = (0, n.IX)(({
                    path: t,
                    args: r
                }) => {
                    let s = [...t],
                        n = h(s.pop()),
                        i = s.join(".");
                    return e[n](i, ...r)
                });
                return (0, n.yh)(r => e.hasOwnProperty(r) ? e[r] : "__untypedClient" === r ? e : t[r])
            }

            function f(e) {
                return e.__untypedClient
            }
            let p = () => {
                throw Error("Something went wrong. Please submit an issue at https://github.com/trpc/trpc/issues/new")
            };

            function y(e) {
                let t = null,
                    r = null,
                    s = () => {
                        clearTimeout(r), r = null, t = null
                    };

                function n() {
                    let r = function(t) {
                        let r = [
                                []
                            ],
                            s = 0;
                        for (;;) {
                            let n = t[s];
                            if (!n) break;
                            let i = r[r.length - 1];
                            if (n.aborted) {
                                n.reject ? .(Error("Aborted")), s++;
                                continue
                            }
                            if (e.validate(i.concat(n).map(e => e.key))) {
                                i.push(n), s++;
                                continue
                            }
                            if (0 === i.length) {
                                n.reject ? .(Error("Input is too big for a single dispatch")), s++;
                                continue
                            }
                            r.push([])
                        }
                        return r
                    }(t);
                    for (let t of (s(), r)) {
                        if (!t.length) continue;
                        let r = {
                            items: t
                        };
                        for (let e of t) e.batch = r;
                        e.fetch(r.items.map(e => e.key)).then(async e => {
                            for (let t of (await Promise.all(e.map(async (e, t) => {
                                    let s = r.items[t];
                                    try {
                                        let t = await Promise.resolve(e);
                                        s.resolve ? .(t)
                                    } catch (e) {
                                        s.reject ? .(e)
                                    }
                                    s.batch = null, s.reject = null, s.resolve = null
                                })), r.items)) t.reject ? .(Error("Missing result")), t.batch = null
                        }).catch(e => {
                            for (let t of r.items) t.reject ? .(e), t.batch = null
                        })
                    }
                }
                return {
                    load: function(e) {
                        let s = {
                                aborted: !1,
                                key: e,
                                batch: null,
                                resolve: p,
                                reject: p
                            },
                            i = new Promise((e, r) => {
                                s.reject = r, s.resolve = e, t || (t = []), t.push(s)
                            });
                        return r || (r = setTimeout(n)), i
                    }
                }
            }
            let m = e => "function" == typeof e,
                g = {
                    query: "GET",
                    mutation: "POST",
                    subscription: "PATCH"
                };

            function b(e) {
                return "input" in e ? e.transformer.input.serialize(e.input) : function(e) {
                    let t = {};
                    for (let r = 0; r < e.length; r++) {
                        let s = e[r];
                        t[r] = s
                    }
                    return t
                }(e.inputs.map(t => e.transformer.input.serialize(t)))
            }
            let v = e => {
                    let t = e.url.split("?"),
                        r = t[0].replace(/\/$/, "") + "/" + e.path,
                        s = [];
                    if (t[1] && s.push(t[1]), "inputs" in e && s.push("batch=1"), "query" === e.type || "subscription" === e.type) {
                        let t = b(e);
                        void 0 !== t && "POST" !== e.methodOverride && s.push(`input=${encodeURIComponent(JSON.stringify(t))}`)
                    }
                    return s.length && (r += "?" + s.join("&")), r
                },
                w = e => {
                    if ("query" === e.type && "POST" !== e.methodOverride) return;
                    let t = b(e);
                    return void 0 !== t ? JSON.stringify(t) : void 0
                },
                O = e => S({ ...e,
                    contentTypeHeader: "application/json",
                    getUrl: v,
                    getBody: w
                });
            class R extends Error {
                constructor() {
                    let e = "AbortError";
                    super(e), this.name = e, this.message = e
                }
            }
            let E = e => {
                if (e ? .aborted) {
                    if (e.throwIfAborted ? .(), "undefined" != typeof DOMException) throw new DOMException("AbortError", "AbortError");
                    throw new R
                }
            };
            async function C(e) {
                E(e.signal);
                let t = e.getUrl(e),
                    r = e.getBody(e),
                    {
                        type: s
                    } = e,
                    n = await (async () => {
                        let t = await e.headers();
                        return Symbol.iterator in t ? Object.fromEntries(t) : t
                    })(),
                    i = { ...e.contentTypeHeader ? {
                            "content-type": e.contentTypeHeader
                        } : {},
                        ...e.trpcAcceptHeader ? {
                            "trpc-accept": e.trpcAcceptHeader
                        } : void 0,
                        ...n
                    };
                return (function(e) {
                    if (e) return e;
                    if ("undefined" != typeof window && m(window.fetch)) return window.fetch;
                    if ("undefined" != typeof globalThis && m(globalThis.fetch)) return globalThis.fetch;
                    throw Error("No fetch implementation found")
                })(e.fetch)(t, {
                    method: e.methodOverride ? ? g[s],
                    signal: e.signal,
                    body: r,
                    headers: i
                })
            }
            async function S(e) {
                let t = {},
                    r = await C(e);
                t.response = r;
                let s = await r.json();
                return t.responseJSON = s, {
                    json: s,
                    meta: t
                }
            }

            function Q(e) {
                var t;
                let r = {
                        url: e.url.toString(),
                        fetch: e.fetch,
                        transformer: (t = e.transformer) ? "input" in t ? t : {
                            input: t,
                            output: t
                        } : {
                            input: {
                                serialize: e => e,
                                deserialize: e => e
                            },
                            output: {
                                serialize: e => e,
                                deserialize: e => e
                            }
                        },
                        methodOverride: e.methodOverride
                    },
                    i = e.maxURLLength ? ? 1 / 0;
                return () => {
                    let t = t => ({
                            validate(e) {
                                if (i === 1 / 0) return !0;
                                let s = e.map(e => e.path).join(","),
                                    n = e.map(e => e.input);
                                return v({ ...r,
                                    type: t,
                                    path: s,
                                    inputs: n,
                                    signal: null
                                }).length <= i
                            },
                            async fetch(s) {
                                let n = s.map(e => e.path).join(","),
                                    i = s.map(e => e.input),
                                    a = function(...e) {
                                        let t = new AbortController,
                                            r = e.length,
                                            s = 0,
                                            n = () => {
                                                ++s === r && t.abort()
                                            };
                                        for (let t of e) t ? .aborted ? n() : t ? .addEventListener("abort", n, {
                                            once: !0
                                        });
                                        return t.signal
                                    }(...s.map(e => e.signal)),
                                    u = await O({ ...r,
                                        path: n,
                                        inputs: i,
                                        type: t,
                                        headers: () => e.headers ? "function" == typeof e.headers ? e.headers({
                                            opList: s
                                        }) : e.headers : {},
                                        signal: a
                                    });
                                return (Array.isArray(u.json) ? u.json : s.map(() => u.json)).map(e => ({
                                    meta: u.meta,
                                    json: e
                                }))
                            }
                        }),
                        u = {
                            query: y(t("query")),
                            mutation: y(t("mutation"))
                        };
                    return ({
                        op: e
                    }) => (0, s.LO)(t => {
                        let s;
                        if ("subscription" === e.type) throw Error("Subscriptions are unsupported by `httpLink` - use `httpSubscriptionLink` or `wsLink`");
                        return u[e.type].load(e).then(e => {
                            s = e;
                            let i = (0, n.F7)(e.json, r.transformer.output);
                            if (!i.ok) {
                                t.error(a.from(i.error, {
                                    meta: e.meta
                                }));
                                return
                            }
                            t.next({
                                context: e.meta,
                                result: i.result
                            }), t.complete()
                        }).catch(e => {
                            t.error(a.from(e, {
                                meta: s ? .meta
                            }))
                        }), () => {}
                    })
                }
            }
            class P extends Error {
                constructor(e) {
                    super(e ? .message ? ? "WebSocket closed", {
                        cause: e ? .cause
                    }), this.name = "TRPCWebSocketClosedError", Object.setPrototypeOf(this, P.prototype)
                }
            }
            var q = r(48719);
            r(1544), r(8316), r(90037), r(46880), q.u.BAD_GATEWAY, q.u.SERVICE_UNAVAILABLE, q.u.GATEWAY_TIMEOUT, q.u.INTERNAL_SERVER_ERROR
        },
        69339: (e, t, r) => {
            r.d(t, {
                ec: () => Q
            });
            var s = r(72140),
                n = r(10751),
                i = r(53775);

            function a(e, t, r) {
                let s = e.flatMap(e => e.split("."));
                if (!t && (!r || "any" === r)) return s.length ? [s] : [];
                if ("infinite" === r && (0, i.Kn)(t) && ("direction" in t || "cursor" in t)) {
                    let {
                        cursor: e,
                        direction: r,
                        ...n
                    } = t;
                    return [s, {
                        input: n,
                        type: "infinite"
                    }]
                }
                return [s, { ...void 0 !== t && t !== n.CN && {
                        input: t
                    },
                    ...r && "any" !== r && {
                        type: r
                    }
                }]
            }

            function u(e) {
                return a(e, void 0, "any")
            }
            var o = r(93264);
            let l = ["client", "ssrContext", "ssrState", "abortOnUnmount"],
                c = o.createContext ? .(null),
                h = e => {
                    switch (e) {
                        case "queryOptions":
                        case "fetch":
                        case "ensureData":
                        case "prefetch":
                        case "getData":
                        case "setData":
                        case "setQueriesData":
                            return "query";
                        case "infiniteQueryOptions":
                        case "fetchInfinite":
                        case "prefetchInfinite":
                        case "getInfiniteData":
                        case "setInfiniteData":
                            return "infinite";
                        case "setMutationDefaults":
                        case "getMutationDefaults":
                        case "isMutating":
                        case "cancel":
                        case "invalidate":
                        case "refetch":
                        case "reset":
                            return "any"
                    }
                };
            var d = r(41137),
                f = r(45447),
                p = r(69586),
                y = r(88438),
                m = r(39967),
                g = r(40491),
                b = r(83730),
                v = r(49177);

            function w(e, t, r) {
                let s = e[0],
                    n = e[1] ? .input;
                return r && (n = { ...n ? ? {},
                    ...r.pageParam ? {
                        cursor: r.pageParam
                    } : {},
                    direction : r.direction
                }), [s.join("."), n, t ? .trpc]
            }

            function O(e) {
                return {
                    path: e.path.join(".")
                }
            }

            function R(e) {
                let t = O(e);
                return o.useMemo(() => t, [t])
            }
            async function E(e, t, r) {
                let s = t.getQueryCache().build(t, {
                    queryKey: r
                });
                s.setState({
                    data: [],
                    status: "success"
                });
                let n = [];
                for await (let t of e) n.push(t), s.setState({
                    data: [...n]
                });
                return n
            }

            function C(e) {
                return (0, i.IX)(t => {
                    let r = t.path,
                        s = r.join("."),
                        [n, i] = t.args;
                    return {
                        queryKey: a(r, n, "query"),
                        queryFn: () => e.query(s, n, i ? .trpc),
                        ...i
                    }
                })
            }
            let S = (e, t) => new Proxy(e, {
                get: (e, r) => (t(r), e[r])
            });

            function Q(e) {
                return function(e) {
                    let t = (0, i.IX)(({
                        path: t,
                        args: r
                    }) => {
                        let s = [...t],
                            n = s.pop();
                        if ("useMutation" === n) return e[n](s, ...r);
                        if ("_def" === n) return {
                            path: s
                        };
                        let [i, ...a] = r, u = a[0] || {};
                        return e[n](s, i, u)
                    });
                    return (0, i.yh)(r => "useContext" === r || "useUtils" === r ? () => {
                        let t = e.useUtils();
                        return o.useMemo(() => (function(e) {
                            let t = (0, s.Bm)(e.client),
                                r = (0, i.IX)(t => {
                                    let r = [...t.path],
                                        s = r.pop(),
                                        n = [...t.args],
                                        i = n.shift(),
                                        o = a(r, i, h(s));
                                    return ({
                                        infiniteQueryOptions: () => e.infiniteQueryOptions(r, o, n[0]),
                                        queryOptions: () => e.queryOptions(r, o, ...n),
                                        fetch: () => e.fetchQuery(o, ...n),
                                        fetchInfinite: () => e.fetchInfiniteQuery(o, n[0]),
                                        prefetch: () => e.prefetchQuery(o, ...n),
                                        prefetchInfinite: () => e.prefetchInfiniteQuery(o, n[0]),
                                        ensureData: () => e.ensureQueryData(o, ...n),
                                        invalidate: () => e.invalidateQueries(o, ...n),
                                        reset: () => e.resetQueries(o, ...n),
                                        refetch: () => e.refetchQueries(o, ...n),
                                        cancel: () => e.cancelQuery(o, ...n),
                                        setData: () => {
                                            e.setQueryData(o, n[0], n[1])
                                        },
                                        setQueriesData: () => e.setQueriesData(o, n[0], n[1], n[2]),
                                        setInfiniteData: () => {
                                            e.setInfiniteQueryData(o, n[0], n[1])
                                        },
                                        getData: () => e.getQueryData(o),
                                        getInfiniteData: () => e.getInfiniteQueryData(o),
                                        setMutationDefaults: () => e.setMutationDefaults(u(r), i),
                                        getMutationDefaults: () => e.getMutationDefaults(u(r)),
                                        isMutating: () => e.isMutating({
                                            mutationKey: u(r)
                                        })
                                    })[s]()
                                });
                            return (0, i.yh)(s => "client" === s ? t : l.includes(s) ? e[s] : r[s])
                        })(t), [t])
                    } : e.hasOwnProperty(r) ? e[r] : t[r])
                }(function(e) {
                    let t = e ? .overrides ? .useMutation ? .onSuccess ? ? (e => e.originalFn()),
                        r = e ? .context ? ? c;

                    function l() {
                        let e = o.useContext(r);
                        if (!e) throw Error("Unable to find tRPC Context. Did you forget to wrap your App inside `withTRPC` HoC?");
                        return e
                    }

                    function h(e, t) {
                        let {
                            queryClient: r,
                            ssrState: s
                        } = l();
                        return s && "mounted" !== s && r.getQueryCache().find({
                            queryKey: e
                        }) ? .state.status === "error" ? {
                            retryOnMount: !1,
                            ...t
                        } : t
                    }
                    return {
                        Provider: e => {
                            let {
                                abortOnUnmount: t = !1,
                                client: a,
                                queryClient: u,
                                ssrContext: l
                            } = e, [c, h] = o.useState(e.ssrState ? ? !1), d = o.useMemo(() => (function(e) {
                                let {
                                    client: t,
                                    queryClient: r
                                } = e, a = t instanceof s.NT ? t : (0, s.ny)(t);
                                return {
                                    infiniteQueryOptions: (e, t, r) => {
                                        let s = t[1] ? .input === n.CN,
                                            i = async e => {
                                                let s = { ...r,
                                                    trpc: { ...r ? .trpc,
                                                        ...r ? .trpc ? .abortOnUnmount ? {
                                                            signal: e.signal
                                                        } : {
                                                            signal: null
                                                        }
                                                    }
                                                };
                                                return await a.query(...w(t, s, {
                                                    direction: e.direction,
                                                    pageParam: e.pageParam
                                                }))
                                            };
                                        return Object.assign({ ...r,
                                            initialData: r ? .initialData,
                                            queryKey: t,
                                            queryFn: s ? n.CN : i,
                                            initialPageParam: r ? .initialCursor ? ? null
                                        }, {
                                            trpc: O({
                                                path: e
                                            })
                                        })
                                    },
                                    queryOptions: (e, t, s) => {
                                        let u = t[1] ? .input === n.CN,
                                            o = async e => {
                                                let n = { ...s,
                                                        trpc: { ...s ? .trpc,
                                                            ...s ? .trpc ? .abortOnUnmount ? {
                                                                signal: e.signal
                                                            } : {
                                                                signal: null
                                                            }
                                                        }
                                                    },
                                                    u = await a.query(...w(t, n));
                                                return (0, i.D0)(u) ? E(u, r, t) : u
                                            };
                                        return Object.assign({ ...s,
                                            initialData: s ? .initialData,
                                            queryKey: t,
                                            queryFn: u ? n.CN : o
                                        }, {
                                            trpc: O({
                                                path: e
                                            })
                                        })
                                    },
                                    fetchQuery: (e, t) => r.fetchQuery({ ...t,
                                        queryKey: e,
                                        queryFn: () => a.query(...w(e, t))
                                    }),
                                    fetchInfiniteQuery: (e, t) => r.fetchInfiniteQuery({ ...t,
                                        queryKey: e,
                                        queryFn: ({
                                            pageParam: r,
                                            direction: s
                                        }) => a.query(...w(e, t, {
                                            pageParam: r,
                                            direction: s
                                        })),
                                        initialPageParam: t ? .initialCursor ? ? null
                                    }),
                                    prefetchQuery: (e, t) => r.prefetchQuery({ ...t,
                                        queryKey: e,
                                        queryFn: () => a.query(...w(e, t))
                                    }),
                                    prefetchInfiniteQuery: (e, t) => r.prefetchInfiniteQuery({ ...t,
                                        queryKey: e,
                                        queryFn: ({
                                            pageParam: r,
                                            direction: s
                                        }) => a.query(...w(e, t, {
                                            pageParam: r,
                                            direction: s
                                        })),
                                        initialPageParam: t ? .initialCursor ? ? null
                                    }),
                                    ensureQueryData: (e, t) => r.ensureQueryData({ ...t,
                                        queryKey: e,
                                        queryFn: () => a.query(...w(e, t))
                                    }),
                                    invalidateQueries: (e, t, s) => r.invalidateQueries({ ...t,
                                        queryKey: e
                                    }, s),
                                    resetQueries: (e, t, s) => r.resetQueries({ ...t,
                                        queryKey: e
                                    }, s),
                                    refetchQueries: (e, t, s) => r.refetchQueries({ ...t,
                                        queryKey: e
                                    }, s),
                                    cancelQuery: (e, t) => r.cancelQueries({
                                        queryKey: e
                                    }, t),
                                    setQueryData: (e, t, s) => r.setQueryData(e, t, s),
                                    setQueriesData: (e, t, s, n) => r.setQueriesData({ ...t,
                                        queryKey: e
                                    }, s, n),
                                    getQueryData: e => r.getQueryData(e),
                                    setInfiniteQueryData: (e, t, s) => r.setQueryData(e, t, s),
                                    getInfiniteQueryData: e => r.getQueryData(e),
                                    setMutationDefaults: (t, s) => {
                                        let n = t[0];
                                        return r.setMutationDefaults(t, "function" == typeof s ? s({
                                            canonicalMutationFn: t => a.mutation(...w([n, {
                                                input: t
                                            }], e))
                                        }) : s)
                                    },
                                    getMutationDefaults: e => r.getMutationDefaults(e),
                                    isMutating: e => r.isMutating({ ...e,
                                        exact: !0
                                    })
                                }
                            })({
                                client: a,
                                queryClient: u
                            }), [a, u]), f = o.useMemo(() => ({
                                abortOnUnmount: t,
                                queryClient: u,
                                client: a,
                                ssrContext: l ? ? null,
                                ssrState: c,
                                ...d
                            }), [t, a, d, u, l, c]);
                            return o.useEffect(() => {
                                h(e => !!e && "mounted")
                            }, []), o.createElement(r.Provider, {
                                value: f
                            }, e.children)
                        },
                        createClient: e => (0, s.fE)(e),
                        useContext: l,
                        useUtils: l,
                        useQuery: function(t, r, s) {
                            let {
                                abortOnUnmount: u,
                                client: o,
                                ssrState: c,
                                queryClient: f,
                                prefetchQuery: p
                            } = l(), y = a(t, r, "query"), m = f.getQueryDefaults(y), g = r === n.CN;
                            "undefined" != typeof window || "prepass" !== c || s ? .trpc ? .ssr === !1 || (s ? .enabled ? ? m ? .enabled) === !1 || g || f.getQueryCache().find({
                                queryKey: y
                            }) || p(y, s);
                            let b = h(y, { ...m,
                                    ...s
                                }),
                                v = s ? .trpc ? .abortOnUnmount ? ? e ? .abortOnUnmount ? ? u,
                                O = (0, d.useQuery)({ ...b,
                                    queryKey: y,
                                    queryFn: g ? r : async e => {
                                        let t = { ...b,
                                                trpc: { ...b ? .trpc,
                                                    ...v ? {
                                                        signal: e.signal
                                                    } : {
                                                        signal: null
                                                    }
                                                }
                                            },
                                            r = await o.query(...w(y, t));
                                        return (0, i.D0)(r) ? E(r, f, y) : r
                                    }
                                }, f);
                            return O.trpc = R({
                                path: t
                            }), O
                        },
                        usePrefetchQuery: function(t, r, s) {
                            let i = l(),
                                u = a(t, r, "query"),
                                o = r === n.CN,
                                c = s ? .trpc ? .abortOnUnmount ? ? e ? .abortOnUnmount ? ? i.abortOnUnmount;
                            ! function(e, t) {
                                let r = (0, f.useQueryClient)(void 0);
                                r.getQueryState(e.queryKey) || r.prefetchQuery(e)
                            }({ ...s,
                                queryKey: u,
                                queryFn: o ? r : e => {
                                    let t = {
                                        trpc: { ...s ? .trpc,
                                            ...c ? {
                                                signal: e.signal
                                            } : {}
                                        }
                                    };
                                    return i.client.query(...w(u, t))
                                }
                            })
                        },
                        useSuspenseQuery: function(t, r, s) {
                            let n = l(),
                                i = a(t, r, "query"),
                                u = s ? .trpc ? .abortOnUnmount ? ? e ? .abortOnUnmount ? ? n.abortOnUnmount,
                                o = (0, p.useSuspenseQuery)({ ...s,
                                    queryKey: i,
                                    queryFn: e => {
                                        let t = { ...s,
                                            trpc: { ...s ? .trpc,
                                                ...u ? {
                                                    signal: e.signal
                                                } : {
                                                    signal: null
                                                }
                                            }
                                        };
                                        return n.client.query(...w(i, t))
                                    }
                                }, n.queryClient);
                            return o.trpc = R({
                                path: t
                            }), [o.data, o]
                        },
                        useQueries: e => {
                            let {
                                ssrState: t,
                                queryClient: r,
                                prefetchQuery: s,
                                client: n
                            } = l(), i = e(C(n));
                            if ("undefined" == typeof window && "prepass" === t)
                                for (let e of i) e.trpc ? .ssr === !1 || r.getQueryCache().find({
                                    queryKey: e.queryKey
                                }) || s(e.queryKey, e);
                            return (0, b.useQueries)({
                                queries: i.map(e => ({ ...e,
                                    queryKey: e.queryKey
                                }))
                            }, r)
                        },
                        useSuspenseQueries: e => {
                            let {
                                queryClient: t,
                                client: r
                            } = l(), s = e(C(r)), n = (0, v.useSuspenseQueries)({
                                queries: s.map(e => ({ ...e,
                                    queryFn: e.queryFn,
                                    queryKey: e.queryKey
                                }))
                            }, t);
                            return [n.map(e => e.data), n]
                        },
                        useMutation: function(e, r) {
                            let {
                                client: s,
                                queryClient: n
                            } = l(), i = u(e), a = n.defaultMutationOptions(n.getMutationDefaults(i)), o = (0, y.useMutation)({ ...r,
                                mutationKey: i,
                                mutationFn: t => s.mutation(...w([e, {
                                    input: t
                                }], r)),
                                onSuccess: (...e) => t({
                                    originalFn: () => r ? .onSuccess ? .(...e) ? ? a ? .onSuccess ? .(...e),
                                    queryClient: n,
                                    meta: r ? .meta ? ? a ? .meta ? ? {}
                                })
                            }, n);
                            return o.trpc = R({
                                path: e
                            }), o
                        },
                        useSubscription: function(e, t, r) {
                            let s = r ? .enabled ? ? t !== n.CN,
                                i = (0, n.Ym)(a(e, t, "any")),
                                {
                                    client: u
                                } = l(),
                                c = o.useRef(r);
                            c.current = r;
                            let h = o.useRef(new Set([])),
                                d = o.useCallback(e => {
                                    h.current.add(e)
                                }, []),
                                f = o.useRef(),
                                p = o.useCallback(() => {
                                    if (f.current ? .(), v(y), !s) return;
                                    let r = !1,
                                        n = u.subscription(e.join("."), t ? ? void 0, {
                                            onStarted: () => {
                                                r || (c.current.onStarted ? .(), v(e => ({ ...e,
                                                    status: "pending",
                                                    error: null
                                                })))
                                            },
                                            onData: e => {
                                                r || (c.current.onData ? .(e), v(t => ({ ...t,
                                                    status: "pending",
                                                    data: e,
                                                    error: null
                                                })))
                                            },
                                            onError: e => {
                                                r || (c.current.onError ? .(e), v(t => ({ ...t,
                                                    status: "error",
                                                    error: e
                                                })))
                                            },
                                            onConnectionStateChange: e => {
                                                let t = {
                                                    status: e.state,
                                                    error: e.error
                                                };
                                                v(e => ({ ...e,
                                                    ...t
                                                }))
                                            }
                                        });
                                    f.current = () => {
                                        r = !0, n.unsubscribe()
                                    }
                                }, [i, s]),
                                y = o.useCallback(() => s ? {
                                    data: void 0,
                                    error: null,
                                    status: "connecting",
                                    reset: p
                                } : {
                                    data: void 0,
                                    error: null,
                                    status: "idle",
                                    reset: p
                                }, [s, p]),
                                m = o.useRef(y()),
                                [g, b] = o.useState(S(m.current, d));
                            g.reset = p;
                            let v = o.useCallback(e => {
                                let t = m.current,
                                    r = m.current = e(t),
                                    s = !1;
                                for (let e of h.current)
                                    if (t[e] !== r[e]) {
                                        s = !0;
                                        break
                                    }
                                s && b(S(r, d))
                            }, [d]);
                            return o.useEffect(() => {
                                if (s) return p(), () => {
                                    f.current ? .()
                                }
                            }, [p, s]), g
                        },
                        useInfiniteQuery: function(e, t, r) {
                            let {
                                client: s,
                                ssrState: i,
                                prefetchInfiniteQuery: u,
                                queryClient: o,
                                abortOnUnmount: c
                            } = l(), d = a(e, t, "infinite"), f = o.getQueryDefaults(d), p = t === n.CN;
                            "undefined" != typeof window || "prepass" !== i || r ? .trpc ? .ssr === !1 || (r ? .enabled ? ? f ? .enabled) === !1 || p || o.getQueryCache().find({
                                queryKey: d
                            }) || u(d, { ...f,
                                ...r
                            });
                            let y = h(d, { ...f,
                                    ...r
                                }),
                                g = r ? .trpc ? .abortOnUnmount ? ? c,
                                b = (0, m.useInfiniteQuery)({ ...y,
                                    initialPageParam: r.initialCursor ? ? null,
                                    persister: r.persister,
                                    queryKey: d,
                                    queryFn: p ? t : e => {
                                        let t = { ...y,
                                            trpc: { ...y ? .trpc,
                                                ...g ? {
                                                    signal: e.signal
                                                } : {
                                                    signal: null
                                                }
                                            }
                                        };
                                        return s.query(...w(d, t, {
                                            pageParam: e.pageParam ? ? r.initialCursor,
                                            direction: e.direction
                                        }))
                                    }
                                }, o);
                            return b.trpc = R({
                                path: e
                            }), b
                        },
                        usePrefetchInfiniteQuery: function(e, t, r) {
                            let s = l(),
                                i = a(e, t, "infinite"),
                                u = s.queryClient.getQueryDefaults(i),
                                o = t === n.CN,
                                c = h(i, { ...u,
                                    ...r
                                }),
                                d = r ? .trpc ? .abortOnUnmount ? ? s.abortOnUnmount;
                            ! function(e, t) {
                                let r = (0, f.useQueryClient)(void 0);
                                r.getQueryState(e.queryKey) || r.prefetchInfiniteQuery(e)
                            }({ ...r,
                                initialPageParam: r.initialCursor ? ? null,
                                queryKey: i,
                                queryFn: o ? t : e => {
                                    let t = { ...c,
                                        trpc: { ...c ? .trpc,
                                            ...d ? {
                                                signal: e.signal
                                            } : {}
                                        }
                                    };
                                    return s.client.query(...w(i, t, {
                                        pageParam: e.pageParam ? ? r.initialCursor,
                                        direction: e.direction
                                    }))
                                }
                            })
                        },
                        useSuspenseInfiniteQuery: function(e, t, r) {
                            let s = l(),
                                n = a(e, t, "infinite"),
                                i = s.queryClient.getQueryDefaults(n),
                                u = h(n, { ...i,
                                    ...r
                                }),
                                o = r ? .trpc ? .abortOnUnmount ? ? s.abortOnUnmount,
                                c = (0, g.useSuspenseInfiniteQuery)({ ...r,
                                    initialPageParam: r.initialCursor ? ? null,
                                    queryKey: n,
                                    queryFn: e => {
                                        let t = { ...u,
                                            trpc: { ...u ? .trpc,
                                                ...o ? {
                                                    signal: e.signal
                                                } : {}
                                            }
                                        };
                                        return s.client.query(...w(n, t, {
                                            pageParam: e.pageParam ? ? r.initialCursor,
                                            direction: e.direction
                                        }))
                                    }
                                }, s.queryClient);
                            return c.trpc = R({
                                path: e
                            }), [c.data, c]
                        }
                    }
                }(e))
            }
        },
        29045: (e, t, r) => {
            function s(e) {
                let t = {
                    subscribe(t) {
                        let r = null,
                            s = !1,
                            n = !1,
                            i = !1;

                        function a() {
                            if (null === r) {
                                i = !0;
                                return
                            }!n && (n = !0, "function" == typeof r ? r() : r && r.unsubscribe())
                        }
                        return r = e({
                            next(e) {
                                s || t.next ? .(e)
                            },
                            error(e) {
                                s || (s = !0, t.error ? .(e), a())
                            },
                            complete() {
                                s || (s = !0, t.complete ? .(), a())
                            }
                        }), i && a(), {
                            unsubscribe: a
                        }
                    },
                    pipe: (...e) => e.reduce(n, t)
                };
                return t
            }

            function n(e, t) {
                return t(e)
            }

            function i(e) {
                let t = new AbortController;
                return new Promise((r, s) => {
                    let n = !1;

                    function i() {
                        n || (n = !0, a.unsubscribe())
                    }
                    t.signal.addEventListener("abort", () => {
                        s(t.signal.reason)
                    });
                    let a = e.subscribe({
                        next(e) {
                            n = !0, r(e), i()
                        },
                        error(e) {
                            s(e)
                        },
                        complete() {
                            t.abort(), i()
                        }
                    })
                })
            }

            function a(e) {
                return e => {
                    let t = 0,
                        r = null,
                        n = [];
                    return s(s => (t++, n.push(s), r || (r = e.subscribe({
                        next(e) {
                            for (let t of n) t.next ? .(e)
                        },
                        error(e) {
                            for (let t of n) t.error ? .(e)
                        },
                        complete() {
                            for (let e of n) e.complete ? .()
                        }
                    })), {
                        unsubscribe() {
                            t--,
                            function() {
                                if (0 === t && r) {
                                    let e = r;
                                    r = null, e.unsubscribe()
                                }
                            }();
                            let e = n.findIndex(e => e === s);
                            e > -1 && n.splice(e, 1)
                        }
                    }))
                }
            }
            r.d(t, {
                LO: () => s,
                xA: () => i,
                BN: () => a
            }), Symbol()
        },
        53775: (e, t, r) => {
            r.d(t, {
                yh: () => a,
                IX: () => i,
                D0: () => u.D0,
                Kn: () => u.Kn,
                F7: () => p
            });
            let s = () => {},
                n = e => {
                    Object.freeze && Object.freeze(e)
                },
                i = e => (function e(t, r, i) {
                    let a = r.join(".");
                    return i[a] ? ? (i[a] = new Proxy(s, {
                        get(s, n) {
                            if ("string" == typeof n && "then" !== n) return e(t, [...r, n], i)
                        },
                        apply(e, s, i) {
                            let a = r[r.length - 1],
                                u = {
                                    args: i,
                                    path: r
                                };
                            return "call" === a ? u = {
                                args: i.length >= 2 ? [i[1]] : [],
                                path: r.slice(0, -1)
                            } : "apply" === a && (u = {
                                args: i.length >= 2 ? i[1] : [],
                                path: r.slice(0, -1)
                            }), n(u.args), n(u.path), t(u)
                        }
                    })), i[a]
                })(e, [], Object.create(null)),
                a = e => new Proxy(s, {
                    get(t, r) {
                        if ("string" == typeof r && "then" !== r) return e(r)
                    }
                });
            r(48719);
            var u = r(86906);

            function o(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            class l extends Error {}

            function c(e) {
                if (e instanceof h || e instanceof Error && "TRPCError" === e.name) return e;
                let t = new h({
                    code: "INTERNAL_SERVER_ERROR",
                    cause: e
                });
                return e instanceof Error && e.stack && (t.stack = e.stack), t
            }
            class h extends Error {
                constructor(e) {
                    let t = function(e) {
                        if (e instanceof Error) return e;
                        let t = typeof e;
                        if ("undefined" !== t && "function" !== t && null !== e) {
                            if ("object" !== t) return Error(String(e));
                            if ((0, u.Kn)(e)) {
                                let t = new l;
                                for (let r in e) t[r] = e[r];
                                return t
                            }
                        }
                    }(e.cause);
                    super(e.message ? ? t ? .message ? ? e.code, {
                        cause: t
                    }), o(this, "cause", void 0), o(this, "code", void 0), this.code = e.code, this.name = "TRPCError", this.cause || (this.cause = t)
                }
            }
            r(8316), r(90037), Symbol();
            Symbol(), Symbol("ping");
            let d = {
                input: {
                    serialize: e => e,
                    deserialize: e => e
                },
                output: {
                    serialize: e => e,
                    deserialize: e => e
                }
            };
            class f extends Error {
                constructor() {
                    super("Unable to transform response from server")
                }
            }

            function p(e, t) {
                let r;
                try {
                    r = function(e, t) {
                        if ("error" in e) {
                            let r = t.deserialize(e.error);
                            return {
                                ok: !1,
                                error: { ...e,
                                    error: r
                                }
                            }
                        }
                        return {
                            ok: !0,
                            result: { ...e.result,
                                ...(!e.result.type || "data" === e.result.type) && {
                                    type: "data",
                                    data: t.deserialize(e.result.data)
                                }
                            }
                        }
                    }(e, t)
                } catch {
                    throw new f
                }
                if (!r.ok && (!(0, u.Kn)(r.error.error) || "number" != typeof r.error.error.code) || r.ok && !(0, u.Kn)(r.result)) throw new f;
                return r
            }
            let y = ({
                    shape: e
                }) => e,
                m = "middlewareMarker";

            function g(e) {
                if ("function" == typeof e && "function" == typeof e.assert) return e.assert.bind(e);
                if ("function" == typeof e) return e;
                if ("function" == typeof e.parseAsync) return e.parseAsync.bind(e);
                if ("function" == typeof e.parse) return e.parse.bind(e);
                if ("function" == typeof e.validateSync) return e.validateSync.bind(e);
                if ("function" == typeof e.create) return e.create.bind(e);
                if ("function" == typeof e.assert) return t => (e.assert(t), t);
                throw Error("Could not find a validator fn")
            }

            function b(e, t) {
                let {
                    middlewares: r = [],
                    inputs: s,
                    meta: n,
                    ...i
                } = t;
                return v({ ...(0, u.Ne)(e, i),
                    inputs: [...e.inputs, ...s ? ? []],
                    middlewares: [...e.middlewares, ...r],
                    meta: e.meta && n ? { ...e.meta,
                        ...n
                    } : n ? ? e.meta
                })
            }

            function v(e = {}) {
                let t = {
                    procedure: !0,
                    inputs: [],
                    middlewares: [],
                    ...e
                };
                return {
                    _def: t,
                    input(e) {
                        let r = g(e);
                        return b(t, {
                            inputs: [e],
                            middlewares: [function(e) {
                                let t = async function(t) {
                                    let r;
                                    let s = await t.getRawInput();
                                    try {
                                        r = await e(s)
                                    } catch (e) {
                                        throw new h({
                                            code: "BAD_REQUEST",
                                            cause: e
                                        })
                                    }
                                    let n = (0, u.Kn)(t.input) && (0, u.Kn)(r) ? { ...t.input,
                                        ...r
                                    } : r;
                                    return t.next({
                                        input: n
                                    })
                                };
                                return t._type = "input", t
                            }(r)]
                        })
                    },
                    output(e) {
                        let r = g(e);
                        return b(t, {
                            output: e,
                            middlewares: [function(e) {
                                let t = async function({
                                    next: t
                                }) {
                                    let r = await t();
                                    if (!r.ok) return r;
                                    try {
                                        let t = await e(r.data);
                                        return { ...r,
                                            data: t
                                        }
                                    } catch (e) {
                                        throw new h({
                                            message: "Output validation failed",
                                            code: "INTERNAL_SERVER_ERROR",
                                            cause: e
                                        })
                                    }
                                };
                                return t._type = "output", t
                            }(r)]
                        })
                    },
                    meta: e => b(t, {
                        meta: e
                    }),
                    use: e => b(t, {
                        middlewares: "_middlewares" in e ? e._middlewares : [e]
                    }),
                    unstable_concat: e => b(t, e._def),
                    query: e => w({ ...t,
                        type: "query"
                    }, e),
                    mutation: e => w({ ...t,
                        type: "mutation"
                    }, e),
                    subscription: e => w({ ...t,
                        type: "subscription"
                    }, e),
                    experimental_caller: e => b(t, {
                        caller: e
                    })
                }
            }

            function w(e, t) {
                let r = b(e, {
                        resolver: t,
                        middlewares: [async function(e) {
                            return {
                                marker: m,
                                ok: !0,
                                data: await t(e),
                                ctx: e.ctx
                            }
                        }]
                    }),
                    s = { ...r._def,
                        type: e.type,
                        experimental_caller: !!r._def.caller,
                        meta: r._def.meta,
                        $types: null
                    },
                    n = function(e) {
                        async function t(t) {
                            if (!t || !("getRawInput" in t)) throw Error(O);
                            let r = await R(0, e, t);
                            if (!r) throw new h({
                                code: "INTERNAL_SERVER_ERROR",
                                message: "No result from middlewares - did you forget to `return next()`?"
                            });
                            if (!r.ok) throw r.error;
                            return r.data
                        }
                        return t._def = e, t
                    }(r._def),
                    i = r._def.caller;
                if (!i) return n;
                let a = async (...e) => await i({
                    args: e,
                    invoke: n,
                    _def: s
                });
                return a._def = s, a
            }
            let O = `
This is a client-only function.
If you want to call this function on the server, see https://trpc.io/docs/v11/server/server-side-calls
`.trim();
            async function R(e, t, r) {
                try {
                    let s = t.middlewares[e];
                    return await s({ ...r,
                        meta: t.meta,
                        input: r.input,
                        next: s => R(e + 1, t, { ...r,
                            ctx: s ? .ctx ? { ...r.ctx,
                                ...s.ctx
                            } : r.ctx,
                            input: s && "input" in s ? s.input : r.input,
                            getRawInput: s ? .getRawInput ? ? r.getRawInput
                        })
                    })
                } catch (e) {
                    return {
                        ok: !1,
                        error: c(e),
                        marker: m
                    }
                }
            }
            var E = r(46880);
            let C = {
                    _ctx: null,
                    _errorShape: null,
                    _meta: null,
                    queries: {},
                    mutations: {},
                    subscriptions: {},
                    errorFormatter: y,
                    transformer: d
                },
                S = ["then", "call", "apply"];

            function Q(e) {
                return function(t) {
                    let r = new Set(Object.keys(t).filter(e => S.includes(e)));
                    if (r.size > 0) throw Error("Reserved words used in `router({})` call: " + Array.from(r).join(", "));
                    let s = (0, u.St)({}),
                        n = function e(t, r = []) {
                            let n = (0, u.St)({});
                            for (let [i, a] of Object.entries(t ? ? {})) {
                                if (a._def && "router" in a._def) {
                                    n[i] = e(a._def.record, [...r, i]);
                                    continue
                                }
                                if ("function" != typeof a) {
                                    n[i] = e(a, [...r, i]);
                                    continue
                                }
                                let t = [...r, i].join(".");
                                if (s[t]) throw Error(`Duplicate key: ${t}`);
                                s[t] = a, n[i] = a
                            }
                            return n
                        }(t),
                        i = {
                            _config: e,
                            router: !0,
                            procedures: s,
                            ...C,
                            record: n
                        };
                    return { ...n,
                        _def: i,
                        createCaller: P()({
                            _def: i
                        })
                    }
                }
            }

            function P() {
                return function(e) {
                    let t = e._def;
                    return function(e, r) {
                        return i(async ({
                            path: s,
                            args: n
                        }) => {
                            let i;
                            let a = s.join(".");
                            if (1 === s.length && "_def" === s[0]) return t;
                            let o = t.procedures[a];
                            try {
                                return i = (0, u.mf)(e) ? await Promise.resolve(e()) : e, await o({
                                    path: a,
                                    getRawInput: async () => n[0],
                                    ctx: i,
                                    type: o._def.type,
                                    signal: r ? .signal
                                })
                            } catch (e) {
                                throw r ? .onError ? .({
                                    ctx: i,
                                    error: c(e),
                                    input: n[0],
                                    path: a,
                                    type: o._def.type
                                }), e
                            }
                        })
                    }
                }
            }

            function q(...e) {
                let t = (0, u.Ne)({}, ...e.map(e => e._def.record));
                return Q({
                    errorFormatter: e.reduce((e, t) => {
                        if (t._def._config.errorFormatter && t._def._config.errorFormatter !== y) {
                            if (e !== y && e !== t._def._config.errorFormatter) throw Error("You seem to have several error formatters");
                            return t._def._config.errorFormatter
                        }
                        return e
                    }, y),
                    transformer: e.reduce((e, t) => {
                        if (t._def._config.transformer && t._def._config.transformer !== d) {
                            if (e !== d && e !== t._def._config.transformer) throw Error("You seem to have several transformers");
                            return t._def._config.transformer
                        }
                        return e
                    }, d),
                    isDev: e.every(e => e._def._config.isDev),
                    allowOutsideOfServer: e.every(e => e._def._config.allowOutsideOfServer),
                    isServer: e.every(e => e._def._config.isServer),
                    $types: e[0] ? ._def._config.$types
                })(t)
            }
            class D {
                context() {
                    return new D
                }
                meta() {
                    return new D
                }
                create(e) {
                    var t;
                    let r = { ...e,
                        transformer: "input" in (t = e ? .transformer ? ? d) ? t : {
                            input: t,
                            output: t
                        },
                        isDev: e ? .isDev ? ? globalThis.process ? .env.NODE_ENV !== "production",
                        allowOutsideOfServer: e ? .allowOutsideOfServer ? ? !1,
                        errorFormatter: e ? .errorFormatter ? ? y,
                        isServer: e ? .isServer ? ? E.h,
                        $types: null
                    };
                    if (!(e ? .isServer ? ? E.h) && e ? .allowOutsideOfServer !== !0) throw Error("You're trying to use @trpc/server in a non-server environment. This is not supported by default.");
                    return {
                        _config: r,
                        procedure: v({
                            meta: e ? .defaultMeta
                        }),
                        middleware: function(e) {
                            return function e(t) {
                                return {
                                    _middlewares: t,
                                    unstable_pipe: r => e([...t, ..."_middlewares" in r ? r._middlewares : [r]])
                                }
                            }([e])
                        },
                        router: Q(r),
                        mergeRouters: q,
                        createCallerFactory: P()
                    }
                }
            }
            new D, r(1544)
        },
        46880: (e, t, r) => {
            r.d(t, {
                h: () => s
            });
            let s = "undefined" == typeof window || "Deno" in window || globalThis.process ? .env ? .NODE_ENV === "test" || !!globalThis.process ? .env ? .JEST_WORKER_ID || !!globalThis.process ? .env ? .VITEST_WORKER_ID
        },
        48719: (e, t, r) => {
            r.d(t, {
                u: () => s
            });
            let s = {
                PARSE_ERROR: -32700,
                BAD_REQUEST: -32600,
                INTERNAL_SERVER_ERROR: -32603,
                NOT_IMPLEMENTED: -32603,
                BAD_GATEWAY: -32603,
                SERVICE_UNAVAILABLE: -32603,
                GATEWAY_TIMEOUT: -32603,
                UNAUTHORIZED: -32001,
                FORBIDDEN: -32003,
                NOT_FOUND: -32004,
                METHOD_NOT_SUPPORTED: -32005,
                TIMEOUT: -32008,
                CONFLICT: -32009,
                PRECONDITION_FAILED: -32012,
                PAYLOAD_TOO_LARGE: -32013,
                UNSUPPORTED_MEDIA_TYPE: -32015,
                UNPROCESSABLE_CONTENT: -32022,
                TOO_MANY_REQUESTS: -32029,
                CLIENT_CLOSED_REQUEST: -32099
            }
        },
        1544: (e, t, r) => {
            r(86906)
        },
        90037: (e, t, r) => {
            var s, n;
            (s = Symbol).dispose ? ? (s.dispose = Symbol()), (n = Symbol).asyncDispose ? ? (n.asyncDispose = Symbol())
        },
        86906: (e, t, r) => {
            r.d(t, {
                D0: () => l,
                Kn: () => i,
                Ne: () => n,
                St: () => u,
                mf: () => a,
                yu: () => s
            });
            let s = Symbol();

            function n(e, ...t) {
                let r = Object.assign(Object.create(null), e);
                for (let e of t)
                    for (let t in e) {
                        if (t in r && r[t] !== e[t]) throw Error(`Duplicate key ${t}`);
                        r[t] = e[t]
                    }
                return r
            }

            function i(e) {
                return !!e && !Array.isArray(e) && "object" == typeof e
            }

            function a(e) {
                return "function" == typeof e
            }

            function u(e) {
                return Object.assign(Object.create(null), e)
            }
            let o = "function" == typeof Symbol && !!Symbol.asyncIterator;

            function l(e) {
                return o && i(e) && Symbol.asyncIterator in e
            }
        },
        8316: (e, t, r) => {
            new WeakMap, Symbol.toStringTag
        },
        15357: (e, t, r) => {
            r.d(t, {
                ZP: () => $
            });
            class s {
                constructor() {
                    this.keyToValue = new Map, this.valueToKey = new Map
                }
                set(e, t) {
                    this.keyToValue.set(e, t), this.valueToKey.set(t, e)
                }
                getByKey(e) {
                    return this.keyToValue.get(e)
                }
                getByValue(e) {
                    return this.valueToKey.get(e)
                }
                clear() {
                    this.keyToValue.clear(), this.valueToKey.clear()
                }
            }
            class n {
                constructor(e) {
                    this.generateIdentifier = e, this.kv = new s
                }
                register(e, t) {
                    this.kv.getByValue(e) || (t || (t = this.generateIdentifier(e)), this.kv.set(t, e))
                }
                clear() {
                    this.kv.clear()
                }
                getIdentifier(e) {
                    return this.kv.getByValue(e)
                }
                getValue(e) {
                    return this.kv.getByKey(e)
                }
            }
            class i extends n {
                constructor() {
                    super(e => e.name), this.classToAllowedProps = new Map
                }
                register(e, t) {
                    "object" == typeof t ? (t.allowProps && this.classToAllowedProps.set(e, t.allowProps), super.register(e, t.identifier)) : super.register(e, t)
                }
                getAllowedProps(e) {
                    return this.classToAllowedProps.get(e)
                }
            }

            function a(e, t) {
                Object.entries(e).forEach(([e, r]) => t(r, e))
            }

            function u(e, t) {
                return -1 !== e.indexOf(t)
            }

            function o(e, t) {
                for (let r = 0; r < e.length; r++) {
                    let s = e[r];
                    if (t(s)) return s
                }
            }
            class l {
                constructor() {
                    this.transfomers = {}
                }
                register(e) {
                    this.transfomers[e.name] = e
                }
                findApplicable(e) {
                    return function(e, t) {
                        let r = function(e) {
                            if ("values" in Object) return Object.values(e);
                            let t = [];
                            for (let r in e) e.hasOwnProperty(r) && t.push(e[r]);
                            return t
                        }(e);
                        if ("find" in r) return r.find(t);
                        for (let e = 0; e < r.length; e++) {
                            let s = r[e];
                            if (t(s)) return s
                        }
                    }(this.transfomers, t => t.isApplicable(e))
                }
                findByName(e) {
                    return this.transfomers[e]
                }
            }
            let c = e => Object.prototype.toString.call(e).slice(8, -1),
                h = e => void 0 === e,
                d = e => null === e,
                f = e => "object" == typeof e && null !== e && e !== Object.prototype && (null === Object.getPrototypeOf(e) || Object.getPrototypeOf(e) === Object.prototype),
                p = e => f(e) && 0 === Object.keys(e).length,
                y = e => Array.isArray(e),
                m = e => "string" == typeof e,
                g = e => "number" == typeof e && !isNaN(e),
                b = e => "boolean" == typeof e,
                v = e => e instanceof Map,
                w = e => e instanceof Set,
                O = e => "Symbol" === c(e),
                R = e => "number" == typeof e && isNaN(e),
                E = e => b(e) || d(e) || h(e) || g(e) || m(e) || O(e),
                C = e => e === 1 / 0 || e === -1 / 0,
                S = e => e.replace(/\./g, "\\."),
                Q = e => e.map(String).map(S).join("."),
                P = e => {
                    let t = [],
                        r = "";
                    for (let s = 0; s < e.length; s++) {
                        let n = e.charAt(s);
                        if ("\\" === n && "." === e.charAt(s + 1)) {
                            r += ".", s++;
                            continue
                        }
                        if ("." === n) {
                            t.push(r), r = "";
                            continue
                        }
                        r += n
                    }
                    let s = r;
                    return t.push(s), t
                };

            function q(e, t, r, s) {
                return {
                    isApplicable: e,
                    annotation: t,
                    transform: r,
                    untransform: s
                }
            }
            let D = [q(h, "undefined", () => null, () => void 0), q(e => "bigint" == typeof e, "bigint", e => e.toString(), e => "undefined" != typeof BigInt ? BigInt(e) : (console.error("Please add a BigInt polyfill."), e)), q(e => e instanceof Date && !isNaN(e.valueOf()), "Date", e => e.toISOString(), e => new Date(e)), q(e => e instanceof Error, "Error", (e, t) => {
                let r = {
                    name: e.name,
                    message: e.message
                };
                return t.allowedErrorProps.forEach(t => {
                    r[t] = e[t]
                }), r
            }, (e, t) => {
                let r = Error(e.message);
                return r.name = e.name, r.stack = e.stack, t.allowedErrorProps.forEach(t => {
                    r[t] = e[t]
                }), r
            }), q(e => e instanceof RegExp, "regexp", e => "" + e, e => new RegExp(e.slice(1, e.lastIndexOf("/")), e.slice(e.lastIndexOf("/") + 1))), q(w, "set", e => [...e.values()], e => new Set(e)), q(v, "map", e => [...e.entries()], e => new Map(e)), q(e => R(e) || C(e), "number", e => R(e) ? "NaN" : e > 0 ? "Infinity" : "-Infinity", Number), q(e => 0 === e && 1 / e == -1 / 0, "number", () => "-0", Number), q(e => e instanceof URL, "URL", e => e.toString(), e => new URL(e))];

            function I(e, t, r, s) {
                return {
                    isApplicable: e,
                    annotation: t,
                    transform: r,
                    untransform: s
                }
            }
            let T = I((e, t) => !!O(e) && !!t.symbolRegistry.getIdentifier(e), (e, t) => ["symbol", t.symbolRegistry.getIdentifier(e)], e => e.description, (e, t, r) => {
                    let s = r.symbolRegistry.getValue(t[1]);
                    if (!s) throw Error("Trying to deserialize unknown symbol");
                    return s
                }),
                _ = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array, Uint8ClampedArray].reduce((e, t) => (e[t.name] = t, e), {}),
                x = I(e => ArrayBuffer.isView(e) && !(e instanceof DataView), e => ["typed-array", e.constructor.name], e => [...e], (e, t) => {
                    let r = _[t[1]];
                    if (!r) throw Error("Trying to deserialize unknown typed array");
                    return new r(e)
                });

            function A(e, t) {
                return !!e ? .constructor && !!t.classRegistry.getIdentifier(e.constructor)
            }
            let k = I(A, (e, t) => ["class", t.classRegistry.getIdentifier(e.constructor)], (e, t) => {
                    let r = t.classRegistry.getAllowedProps(e.constructor);
                    if (!r) return { ...e
                    };
                    let s = {};
                    return r.forEach(t => {
                        s[t] = e[t]
                    }), s
                }, (e, t, r) => {
                    let s = r.classRegistry.getValue(t[1]);
                    if (!s) throw Error("Trying to deserialize unknown class - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564");
                    return Object.assign(Object.create(s.prototype), e)
                }),
                M = I((e, t) => !!t.customTransformerRegistry.findApplicable(e), (e, t) => ["custom", t.customTransformerRegistry.findApplicable(e).name], (e, t) => t.customTransformerRegistry.findApplicable(e).serialize(e), (e, t, r) => {
                    let s = r.customTransformerRegistry.findByName(t[1]);
                    if (!s) throw Error("Trying to deserialize unknown custom value");
                    return s.deserialize(e)
                }),
                j = [k, T, M, x],
                F = (e, t) => {
                    let r = o(j, r => r.isApplicable(e, t));
                    if (r) return {
                        value: r.transform(e, t),
                        type: r.annotation(e, t)
                    };
                    let s = o(D, r => r.isApplicable(e, t));
                    if (s) return {
                        value: s.transform(e, t),
                        type: s.annotation
                    }
                },
                N = {};
            D.forEach(e => {
                N[e.annotation] = e
            });
            let U = (e, t, r) => {
                    if (y(t)) switch (t[0]) {
                        case "symbol":
                            return T.untransform(e, t, r);
                        case "class":
                            return k.untransform(e, t, r);
                        case "custom":
                            return M.untransform(e, t, r);
                        case "typed-array":
                            return x.untransform(e, t, r);
                        default:
                            throw Error("Unknown transformation: " + t)
                    } else {
                        let s = N[t];
                        if (!s) throw Error("Unknown transformation: " + t);
                        return s.untransform(e, r)
                    }
                },
                K = (e, t) => {
                    let r = e.keys();
                    for (; t > 0;) r.next(), t--;
                    return r.next().value
                };

            function V(e) {
                if (u(e, "__proto__")) throw Error("__proto__ is not allowed as a property");
                if (u(e, "prototype")) throw Error("prototype is not allowed as a property");
                if (u(e, "constructor")) throw Error("constructor is not allowed as a property")
            }
            let L = (e, t) => {
                    V(t);
                    for (let r = 0; r < t.length; r++) {
                        let s = t[r];
                        if (w(e)) e = K(e, +s);
                        else if (v(e)) {
                            let n = +s,
                                i = 0 == +t[++r] ? "key" : "value",
                                a = K(e, n);
                            switch (i) {
                                case "key":
                                    e = a;
                                    break;
                                case "value":
                                    e = e.get(a)
                            }
                        } else e = e[s]
                    }
                    return e
                },
                z = (e, t, r) => {
                    if (V(t), 0 === t.length) return r(e);
                    let s = e;
                    for (let e = 0; e < t.length - 1; e++) {
                        let r = t[e];
                        if (y(s)) s = s[+r];
                        else if (f(s)) s = s[r];
                        else if (w(s)) s = K(s, +r);
                        else if (v(s)) {
                            if (e === t.length - 2) break;
                            let n = +r,
                                i = 0 == +t[++e] ? "key" : "value",
                                a = K(s, n);
                            switch (i) {
                                case "key":
                                    s = a;
                                    break;
                                case "value":
                                    s = s.get(a)
                            }
                        }
                    }
                    let n = t[t.length - 1];
                    if (y(s) ? s[+n] = r(s[+n]) : f(s) && (s[n] = r(s[n])), w(s)) {
                        let e = K(s, +n),
                            t = r(e);
                        e !== t && (s.delete(e), s.add(t))
                    }
                    if (v(s)) {
                        let e = K(s, +t[t.length - 2]);
                        switch (0 == +n ? "key" : "value") {
                            case "key":
                                {
                                    let t = r(e);s.set(t, s.get(e)),
                                    t !== e && s.delete(e);
                                    break
                                }
                            case "value":
                                s.set(e, r(s.get(e)))
                        }
                    }
                    return e
                },
                H = (e, t) => f(e) || y(e) || v(e) || w(e) || A(e, t),
                B = (e, t, r, s, n = [], i = [], o = new Map) => {
                    let l = E(e);
                    if (!l) {
                        ! function(e, t, r) {
                            let s = r.get(e);
                            s ? s.push(t) : r.set(e, [t])
                        }(e, n, t);
                        let r = o.get(e);
                        if (r) return s ? {
                            transformedValue: null
                        } : r
                    }
                    if (!H(e, r)) {
                        let t = F(e, r),
                            s = t ? {
                                transformedValue: t.value,
                                annotations: [t.type]
                            } : {
                                transformedValue: e
                            };
                        return l || o.set(e, s), s
                    }
                    if (u(i, e)) return {
                        transformedValue: null
                    };
                    let c = F(e, r),
                        h = c ? .value ? ? e,
                        d = y(h) ? [] : {},
                        m = {};
                    a(h, (u, l) => {
                        if ("__proto__" === l || "constructor" === l || "prototype" === l) throw Error(`Detected property ${l}. This is a prototype pollution risk, please remove it from your object.`);
                        let c = B(u, t, r, s, [...n, l], [...i, e], o);
                        d[l] = c.transformedValue, y(c.annotations) ? m[l] = c.annotations : f(c.annotations) && a(c.annotations, (e, t) => {
                            m[S(l) + "." + t] = e
                        })
                    });
                    let g = p(m) ? {
                        transformedValue: d,
                        annotations: c ? [c.type] : void 0
                    } : {
                        transformedValue: d,
                        annotations: c ? [c.type, m] : m
                    };
                    return l || o.set(e, g), g
                };

            function G(e) {
                return Object.prototype.toString.call(e).slice(8, -1)
            }

            function Z(e) {
                return "Array" === G(e)
            }
            class $ {
                constructor({
                    dedupe: e = !1
                } = {}) {
                    this.classRegistry = new i, this.symbolRegistry = new n(e => e.description ? ? ""), this.customTransformerRegistry = new l, this.allowedErrorProps = [], this.dedupe = e
                }
                serialize(e) {
                    let t = new Map,
                        r = B(e, t, this, this.dedupe),
                        s = {
                            json: r.transformedValue
                        };
                    r.annotations && (s.meta = { ...s.meta,
                        values: r.annotations
                    });
                    let n = function(e, t) {
                        let r;
                        let s = {};
                        return (e.forEach(e => {
                            if (e.length <= 1) return;
                            t || (e = e.map(e => e.map(String)).sort((e, t) => e.length - t.length));
                            let [n, ...i] = e;
                            0 === n.length ? r = i.map(Q) : s[Q(n)] = i.map(Q)
                        }), r) ? p(s) ? [r] : [r, s] : p(s) ? void 0 : s
                    }(t, this.dedupe);
                    return n && (s.meta = { ...s.meta,
                        referentialEqualities: n
                    }), s
                }
                deserialize(e) {
                    let {
                        json: t,
                        meta: r
                    } = e, s = function e(t, r = {}) {
                        return Z(t) ? t.map(t => e(t, r)) : ! function(e) {
                            if ("Object" !== G(e)) return !1;
                            let t = Object.getPrototypeOf(e);
                            return !!t && t.constructor === Object && t === Object.prototype
                        }(t) ? t : [...Object.getOwnPropertyNames(t), ...Object.getOwnPropertySymbols(t)].reduce((s, n) => {
                            if (Z(r.props) && !r.props.includes(n)) return s;
                            let i = e(t[n], r);
                            return ! function(e, t, r, s, n) {
                                let i = ({}).propertyIsEnumerable.call(s, t) ? "enumerable" : "nonenumerable";
                                "enumerable" === i && (e[t] = r), n && "nonenumerable" === i && Object.defineProperty(e, t, {
                                    value: r,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                })
                            }(s, n, i, t, r.nonenumerable), s
                        }, {})
                    }(t);
                    if (r ? .values) {
                        var n, i, u;
                        n = s, i = r.values, u = this,
                            function e(t, r, s = []) {
                                if (!t) return;
                                if (!y(t)) {
                                    a(t, (t, n) => e(t, r, [...s, ...P(n)]));
                                    return
                                }
                                let [n, i] = t;
                                i && a(i, (t, n) => {
                                    e(t, r, [...s, ...P(n)])
                                }), r(n, s)
                            }(i, (e, t) => {
                                n = z(n, t, t => U(t, e, u))
                            }), s = n
                    }
                    return r ? .referentialEqualities && (s = function(e, t) {
                        function r(t, r) {
                            let s = L(e, P(r));
                            t.map(P).forEach(t => {
                                e = z(e, t, () => s)
                            })
                        }
                        if (y(t)) {
                            let [s, n] = t;
                            s.forEach(t => {
                                e = z(e, P(t), () => e)
                            }), n && a(n, r)
                        } else a(t, r);
                        return e
                    }(s, r.referentialEqualities)), s
                }
                stringify(e) {
                    return JSON.stringify(this.serialize(e))
                }
                parse(e) {
                    return this.deserialize(JSON.parse(e))
                }
                registerClass(e, t) {
                    this.classRegistry.register(e, t)
                }
                registerSymbol(e, t) {
                    this.symbolRegistry.register(e, t)
                }
                registerCustom(e, t) {
                    this.customTransformerRegistry.register({
                        name: t,
                        ...e
                    })
                }
                allowErrorProps(...e) {
                    this.allowedErrorProps.push(...e)
                }
            }
            $.defaultInstance = new $, $.serialize = $.defaultInstance.serialize.bind($.defaultInstance), $.deserialize = $.defaultInstance.deserialize.bind($.defaultInstance), $.stringify = $.defaultInstance.stringify.bind($.defaultInstance), $.parse = $.defaultInstance.parse.bind($.defaultInstance), $.registerClass = $.defaultInstance.registerClass.bind($.defaultInstance), $.registerSymbol = $.defaultInstance.registerSymbol.bind($.defaultInstance), $.registerCustom = $.defaultInstance.registerCustom.bind($.defaultInstance), $.allowErrorProps = $.defaultInstance.allowErrorProps.bind($.defaultInstance), $.serialize, $.deserialize, $.stringify, $.parse, $.registerClass, $.registerCustom, $.registerSymbol, $.allowErrorProps
        }
    }
]);