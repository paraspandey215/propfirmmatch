(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3823], {
        24683: () => {},
        58117: (e, l, u) => {
            "use strict";
            u.r(l), u.d(l, {
                default: () => f
            });
            var n = u(12428),
                r = u(49433),
                t = u(1545),
                a = u(93125),
                d = u.n(a),
                i = u(93264);

            function s(e) {
                var l;
                d()({
                    app_id: "hidozuu2",
                    ...e ? {
                        user_id: e.userId,
                        name: e.name,
                        email: e.email,
                        created_at: (null !== (l = e.createdAt) && void 0 !== l ? l : new Date).getTime()
                    } : {}
                })
            }

            function c(e) {
                var l, u, n;
                let {
                    user: r
                } = e;
                return s({
                    createdAt: r.createdAt,
                    email: null !== (u = null === (l = r.primaryEmailAddress) || void 0 === l ? void 0 : l.emailAddress) && void 0 !== u ? u : "",
                    name: null !== (n = r.fullName) && void 0 !== n ? n : "",
                    userId: r.id
                }), null
            }

            function m() {
                return s(), null
            }

            function f() {
                let [e, l] = (0, i.useState)(!1);
                (0, i.useEffect)(() => l(!0), [l]);
                let u = (0, r.aF)();
                return e ? (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(t.CH, {
                        children: u.user ? (0, n.jsx)(c, {
                            user: u.user
                        }) : (0, n.jsx)(m, {})
                    }), (0, n.jsx)(t.tj, {
                        children: (0, n.jsx)(m, {})
                    })]
                }) : null
            }
        }
    }
]);