"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2457], {
        14887: (e, t, n) => {
            n.d(t, {
                PromisifiedAuthProvider: () => s,
                y: () => c
            });
            var r = n(49433),
                i = n(33906),
                o = n(91297),
                u = n(68042),
                a = n(93264),
                E = n(32608);
            let _ = a.createContext(null);

            function s(e) {
                let {
                    authPromise: t,
                    children: n
                } = e;
                return a.createElement(_.Provider, {
                    value: t
                }, n)
            }

            function c() {
                let e = (0, o.useRouter)(),
                    t = a.useContext(_),
                    n = t;
                if (t && "then" in t && (n = a.use(t)), "undefined" != typeof window) return (0, r.aC)(n);
                if (e) return (0, r.aC)();
                if (!n && E.env.NEXT_PHASE !== u.PHASE_PRODUCTION_BUILD) throw Error("Clerk: useAuth() called in static mode, wrap this component in <ClerkProvider dynamic> to make auth data available during server-side rendering.");
                return (0, i.aw)(n)
            }
        },
        72714: (e, t, n) => {
            n.d(t, {
                AuthenticateWithRedirectCallback: () => r.vn,
                ClerkLoaded: () => r.a7,
                ClerkLoading: () => r.qI,
                RedirectToCreateOrganization: () => r.gM,
                RedirectToOrganizationProfile: () => r.yB,
                RedirectToSignIn: () => r.N1,
                RedirectToSignUp: () => r.C2,
                RedirectToUserProfile: () => r.sO
            });
            var r = n(49433);
            n(33906)
        },
        2276: (e, t, n) => {
            n.d(t, {
                __experimental_useReverification: () => r.jJ,
                useAuth: () => i.y,
                useClerk: () => r.ll,
                useEmailLink: () => r.E2,
                useOrganization: () => r.o8,
                useOrganizationList: () => r.eW,
                useSession: () => r.kP,
                useSessionList: () => r.xo,
                useSignIn: () => r.zq,
                useSignUp: () => r.QS,
                useUser: () => r.aF
            });
            var r = n(49433);
            n(95460);
            var i = n(14887)
        },
        48411: (e, t, n) => {
            n.d(t, {
                CreateOrganization: () => l,
                GoogleOneTap: () => r.Kb,
                OrganizationList: () => r.Bg,
                OrganizationProfile: () => T,
                OrganizationSwitcher: () => r.Li,
                SignIn: () => I,
                SignInButton: () => r.$d,
                SignInWithMetamaskButton: () => r.qu,
                SignOutButton: () => r.AM,
                SignUp: () => S,
                SignUpButton: () => r.gX,
                UserButton: () => r.l8,
                UserProfile: () => f
            });
            var r = n(49433),
                i = n(93264),
                o = n(33906),
                u = n(6649),
                a = n(91297);
            let E = () => ({
                    pagesRouter: (0, a.useRouter)()
                }),
                _ = (e, t, n, o = !0) => {
                    let a = i.useRef(0),
                        {
                            pagesRouter: _
                        } = E(),
                        {
                            session: s,
                            isLoaded: c
                        } = (0, r.kP)();
                    (0, u.rx)() || i.useEffect(() => {
                        if (!c || n && "path" !== n || o && !s) return;
                        let r = new AbortController,
                            i = () => {
                                let n = _ ? `${t}/[[...index]].tsx` : `${t}/[[...rest]]/page.tsx`;
                                throw Error(`
Clerk: The <${e}/> component is not configured correctly. The most likely reasons for this error are:

1. The "${t}" route is not a catch-all route.
It is recommended to convert this route to a catch-all route, eg: "${n}". Alternatively, you can update the <${e}/> component to use hash-based routing by setting the "routing" prop to "hash".

2. The <${e}/> component is mounted in a catch-all route, but all routes under "${t}" are protected by the middleware.
To resolve this, ensure that the middleware does not protect the catch-all route or any of its children. If you are using the "createRouteMatcher" helper, consider adding "(.*)" to the end of the route pattern, eg: "${t}(.*)". For more information, see: https://clerk.com/docs/references/nextjs/clerk-middleware#create-route-matcher
`)
                            };
                        return _ ? _.pathname.match(/\[\[\.\.\..+]]/) || i() : (async () => {
                            let t;
                            if (a.current++, !(a.current > 1)) {
                                try {
                                    let n = `${window.location.origin}${window.location.pathname}/${e}_clerk_catchall_check_${Date.now()}`;
                                    t = await fetch(n, {
                                        signal: r.signal
                                    })
                                } catch (e) {}(null == t ? void 0 : t.status) === 404 && i()
                            }
                        })(), () => {
                            a.current > 1 && r.abort()
                        }
                    }, [c])
                },
                s = () => {
                    let e = i.useRef(),
                        {
                            pagesRouter: t
                        } = E();
                    if (t) return e.current || (e.current = t.pathname.replace(/\/\[\[\.\.\..*/, "")), e.current;
                    let r = n(47576).usePathname,
                        o = n(47576).useParams,
                        u = (r() || "").split("/").filter(Boolean),
                        a = Object.values(o() || {}).filter(e => Array.isArray(e)).flat(1 / 0);
                    return e.current || (e.current = `/${u.slice(0,u.length-a.length).join("/")}`), e.current
                };

            function c(e, t, n = !0) {
                let r = s(),
                    i = (0, o.EJ)(e, t, {
                        path: r
                    });
                return _(e, r, i.routing, n), i
            }
            let f = Object.assign(e => i.createElement(r.Iw, { ...c("UserProfile", e)
                }), { ...r.Iw
                }),
                l = e => i.createElement(r.Gp, { ...c("CreateOrganization", e)
                }),
                T = Object.assign(e => i.createElement(r.A, { ...c("OrganizationProfile", e)
                }), { ...r.A
                }),
                I = e => i.createElement(r.cL, { ...c("SignIn", e, !1)
                }),
                S = e => i.createElement(r.Mo, { ...c("SignUp", e, !1)
                })
        },
        68042: (e, t, n) => {
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    APP_BUILD_MANIFEST: function() {
                        return A
                    },
                    APP_CLIENT_INTERNALS: function() {
                        return q
                    },
                    APP_PATHS_MANIFEST: function() {
                        return S
                    },
                    APP_PATH_ROUTES_MANIFEST: function() {
                        return d
                    },
                    BARREL_OPTIMIZATION_PREFIX: function() {
                        return G
                    },
                    BLOCKED_PAGES: function() {
                        return j
                    },
                    BUILD_ID_FILE: function() {
                        return w
                    },
                    BUILD_MANIFEST: function() {
                        return R
                    },
                    CLIENT_PUBLIC_FILES_PATH: function() {
                        return y
                    },
                    CLIENT_REFERENCE_MANIFEST: function() {
                        return $
                    },
                    CLIENT_STATIC_FILES_PATH: function() {
                        return k
                    },
                    CLIENT_STATIC_FILES_RUNTIME_AMP: function() {
                        return J
                    },
                    CLIENT_STATIC_FILES_RUNTIME_MAIN: function() {
                        return V
                    },
                    CLIENT_STATIC_FILES_RUNTIME_MAIN_APP: function() {
                        return K
                    },
                    CLIENT_STATIC_FILES_RUNTIME_POLYFILLS: function() {
                        return ee
                    },
                    CLIENT_STATIC_FILES_RUNTIME_POLYFILLS_SYMBOL: function() {
                        return et
                    },
                    CLIENT_STATIC_FILES_RUNTIME_REACT_REFRESH: function() {
                        return Q
                    },
                    CLIENT_STATIC_FILES_RUNTIME_WEBPACK: function() {
                        return Z
                    },
                    COMPILER_INDEXES: function() {
                        return o
                    },
                    COMPILER_NAMES: function() {
                        return i
                    },
                    CONFIG_FILES: function() {
                        return B
                    },
                    DEFAULT_RUNTIME_WEBPACK: function() {
                        return en
                    },
                    DEFAULT_SANS_SERIF_FONT: function() {
                        return ea
                    },
                    DEFAULT_SERIF_FONT: function() {
                        return eu
                    },
                    DEV_CLIENT_MIDDLEWARE_MANIFEST: function() {
                        return F
                    },
                    DEV_CLIENT_PAGES_MANIFEST: function() {
                        return M
                    },
                    EDGE_RUNTIME_WEBPACK: function() {
                        return er
                    },
                    EDGE_UNSUPPORTED_NODE_APIS: function() {
                        return ef
                    },
                    EXPORT_DETAIL: function() {
                        return P
                    },
                    EXPORT_MARKER: function() {
                        return C
                    },
                    FUNCTIONS_CONFIG_MANIFEST: function() {
                        return N
                    },
                    IMAGES_MANIFEST: function() {
                        return g
                    },
                    INTERCEPTION_ROUTE_REWRITE_MANIFEST: function() {
                        return Y
                    },
                    MIDDLEWARE_BUILD_MANIFEST: function() {
                        return H
                    },
                    MIDDLEWARE_MANIFEST: function() {
                        return D
                    },
                    MIDDLEWARE_REACT_LOADABLE_MANIFEST: function() {
                        return X
                    },
                    MODERN_BROWSERSLIST_TARGET: function() {
                        return r.default
                    },
                    NEXT_BUILTIN_DOCUMENT: function() {
                        return W
                    },
                    NEXT_FONT_MANIFEST: function() {
                        return p
                    },
                    PAGES_MANIFEST: function() {
                        return T
                    },
                    PHASE_DEVELOPMENT_SERVER: function() {
                        return c
                    },
                    PHASE_EXPORT: function() {
                        return E
                    },
                    PHASE_INFO: function() {
                        return l
                    },
                    PHASE_PRODUCTION_BUILD: function() {
                        return _
                    },
                    PHASE_PRODUCTION_SERVER: function() {
                        return s
                    },
                    PHASE_TEST: function() {
                        return f
                    },
                    PRERENDER_MANIFEST: function() {
                        return L
                    },
                    REACT_LOADABLE_MANIFEST: function() {
                        return v
                    },
                    ROUTES_MANIFEST: function() {
                        return O
                    },
                    RSC_MODULE_TYPES: function() {
                        return ec
                    },
                    SERVER_DIRECTORY: function() {
                        return b
                    },
                    SERVER_FILES_MANIFEST: function() {
                        return h
                    },
                    SERVER_PROPS_ID: function() {
                        return eo
                    },
                    SERVER_REFERENCE_MANIFEST: function() {
                        return z
                    },
                    STATIC_PROPS_ID: function() {
                        return ei
                    },
                    STATIC_STATUS_PAGES: function() {
                        return eE
                    },
                    STRING_LITERAL_DROP_BUNDLE: function() {
                        return x
                    },
                    SUBRESOURCE_INTEGRITY_MANIFEST: function() {
                        return m
                    },
                    SYSTEM_ENTRYPOINTS: function() {
                        return el
                    },
                    TRACE_OUTPUT_VERSION: function() {
                        return e_
                    },
                    TURBOPACK_CLIENT_MIDDLEWARE_MANIFEST: function() {
                        return U
                    },
                    TURBO_TRACE_DEFAULT_MEMORY_LIMIT: function() {
                        return es
                    },
                    UNDERSCORE_NOT_FOUND_ROUTE: function() {
                        return u
                    },
                    UNDERSCORE_NOT_FOUND_ROUTE_ENTRY: function() {
                        return a
                    },
                    WEBPACK_STATS: function() {
                        return I
                    }
                });
            let r = n(81838)._(n(85302)),
                i = {
                    client: "client",
                    server: "server",
                    edgeServer: "edge-server"
                },
                o = {
                    [i.client]: 0,
                    [i.server]: 1,
                    [i.edgeServer]: 2
                },
                u = "/_not-found",
                a = "" + u + "/page",
                E = "phase-export",
                _ = "phase-production-build",
                s = "phase-production-server",
                c = "phase-development-server",
                f = "phase-test",
                l = "phase-info",
                T = "pages-manifest.json",
                I = "webpack-stats.json",
                S = "app-paths-manifest.json",
                d = "app-path-routes-manifest.json",
                R = "build-manifest.json",
                A = "app-build-manifest.json",
                N = "functions-config-manifest.json",
                m = "subresource-integrity-manifest",
                p = "next-font-manifest",
                C = "export-marker.json",
                P = "export-detail.json",
                L = "prerender-manifest.json",
                O = "routes-manifest.json",
                g = "images-manifest.json",
                h = "required-server-files.json",
                M = "_devPagesManifest.json",
                D = "middleware-manifest.json",
                U = "_clientMiddlewareManifest.json",
                F = "_devMiddlewareManifest.json",
                v = "react-loadable-manifest.json",
                b = "server",
                B = ["next.config.js", "next.config.mjs", "next.config.ts"],
                w = "BUILD_ID",
                j = ["/_document", "/_app", "/_error"],
                y = "public",
                k = "static",
                x = "__NEXT_DROP_CLIENT_FILE__",
                W = "__NEXT_BUILTIN_DOCUMENT__",
                G = "__barrel_optimize__",
                $ = "client-reference-manifest",
                z = "server-reference-manifest",
                H = "middleware-build-manifest",
                X = "middleware-react-loadable-manifest",
                Y = "interception-route-rewrite-manifest",
                V = "main",
                K = "" + V + "-app",
                q = "app-pages-internals",
                Q = "react-refresh",
                J = "amp",
                Z = "webpack",
                ee = "polyfills",
                et = Symbol(ee),
                en = "webpack-runtime",
                er = "edge-runtime-webpack",
                ei = "__N_SSG",
                eo = "__N_SSP",
                eu = {
                    name: "Times New Roman",
                    xAvgCharWidth: 821,
                    azAvgWidth: 854.3953488372093,
                    unitsPerEm: 2048
                },
                ea = {
                    name: "Arial",
                    xAvgCharWidth: 904,
                    azAvgWidth: 934.5116279069767,
                    unitsPerEm: 2048
                },
                eE = ["/500"],
                e_ = 1,
                es = 6e3,
                ec = {
                    client: "client",
                    server: "server"
                },
                ef = ["clearImmediate", "setImmediate", "BroadcastChannel", "ByteLengthQueuingStrategy", "CompressionStream", "CountQueuingStrategy", "DecompressionStream", "DomException", "MessageChannel", "MessageEvent", "MessagePort", "ReadableByteStreamController", "ReadableStreamBYOBRequest", "ReadableStreamDefaultController", "TransformStreamDefaultController", "WritableStreamDefaultController"],
                el = new Set([V, Q, J, K]);
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        85302: e => {
            e.exports = ["chrome 64", "edge 79", "firefox 67", "opera 51", "safari 12"]
        }
    }
]);