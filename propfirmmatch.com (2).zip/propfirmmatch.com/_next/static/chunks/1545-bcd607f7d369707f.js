"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1545], {
        1545: (e, t, r) => {
            r.d(t, {
                CH: () => i,
                tj: () => s
            }), r(91297), r(93264);
            var a = (r(56338), r(49433)),
                n = r(33906),
                o = r(690);
            r(59913), r(14026), r(68347);
            r(34103), r(35301), (0, n.JM)({
                packageName: "@clerk/nextjs"
            }), (0, n.Aw)("@clerk/nextjs");
            let i = a.CH,
                s = a.tj;
            a.Cv
        },
        95340: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "detectDomainLocale", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let r = function() {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r]
            };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        99215: (e, t, r) => {
            function a(e, t) {
                return e
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "removeLocale", {
                enumerable: !0,
                get: function() {
                    return a
                }
            }), r(32103), ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        23803: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    createRouteLoader: function() {
                        return _
                    },
                    getClientBuildManifest: function() {
                        return p
                    },
                    isAssetError: function() {
                        return u
                    },
                    markAssetError: function() {
                        return h
                    }
                }), r(81838), r(80120);
            let a = r(22203),
                n = r(56214),
                o = r(25331),
                i = r(17730);

            function s(e, t, r) {
                let a, n = t.get(e);
                if (n) return "future" in n ? n.future : Promise.resolve(n);
                let o = new Promise(e => {
                    a = e
                });
                return t.set(e, {
                    resolve: a,
                    future: o
                }), r ? r().then(e => (a(e), e)).catch(r => {
                    throw t.delete(e), r
                }) : o
            }
            let l = Symbol("ASSET_LOAD_ERROR");

            function h(e) {
                return Object.defineProperty(e, l, {})
            }

            function u(e) {
                return e && l in e
            }
            let c = function(e) {
                    try {
                        return e = document.createElement("link"), !!window.MSInputMethodContext && !!document.documentMode || e.relList.supports("prefetch")
                    } catch (e) {
                        return !1
                    }
                }(),
                d = () => (0, o.getDeploymentIdQueryOrEmptyString)();

            function f(e, t, r) {
                return new Promise((a, o) => {
                    let i = !1;
                    e.then(e => {
                        i = !0, a(e)
                    }).catch(o), (0, n.requestIdleCallback)(() => setTimeout(() => {
                        i || o(r)
                    }, t))
                })
            }

            function p() {
                return self.__BUILD_MANIFEST ? Promise.resolve(self.__BUILD_MANIFEST) : f(new Promise(e => {
                    let t = self.__BUILD_MANIFEST_CB;
                    self.__BUILD_MANIFEST_CB = () => {
                        e(self.__BUILD_MANIFEST), t && t()
                    }
                }), 3800, h(Error("Failed to load client build manifest")))
            }

            function m(e, t) {
                return p().then(r => {
                    if (!(t in r)) throw h(Error("Failed to lookup route: " + t));
                    let n = r[t].map(t => e + "/_next/" + (0, i.encodeURIPath)(t));
                    return {
                        scripts: n.filter(e => e.endsWith(".js")).map(e => (0, a.__unsafeCreateTrustedScriptURL)(e) + d()),
                        css: n.filter(e => e.endsWith(".css")).map(e => e + d())
                    }
                })
            }

            function _(e) {
                let t = new Map,
                    r = new Map,
                    a = new Map,
                    o = new Map;

                function i(e) {
                    {
                        var t;
                        let a = r.get(e.toString());
                        return a || (document.querySelector('script[src^="' + e + '"]') ? Promise.resolve() : (r.set(e.toString(), a = new Promise((r, a) => {
                            (t = document.createElement("script")).onload = r, t.onerror = () => a(h(Error("Failed to load script: " + e))), t.crossOrigin = void 0, t.src = e, document.body.appendChild(t)
                        })), a))
                    }
                }

                function l(e) {
                    let t = a.get(e);
                    return t || a.set(e, t = fetch(e, {
                        credentials: "same-origin"
                    }).then(t => {
                        if (!t.ok) throw Error("Failed to load stylesheet: " + e);
                        return t.text().then(t => ({
                            href: e,
                            content: t
                        }))
                    }).catch(e => {
                        throw h(e)
                    })), t
                }
                return {
                    whenEntrypoint: e => s(e, t),
                    onEntrypoint(e, r) {
                        (r ? Promise.resolve().then(() => r()).then(e => ({
                            component: e && e.default || e,
                            exports: e
                        }), e => ({
                            error: e
                        })) : Promise.resolve(void 0)).then(r => {
                            let a = t.get(e);
                            a && "resolve" in a ? r && (t.set(e, r), a.resolve(r)) : (r ? t.set(e, r) : t.delete(e), o.delete(e))
                        })
                    },
                    loadRoute(r, a) {
                        return s(r, o, () => {
                            let n;
                            return f(m(e, r).then(e => {
                                let {
                                    scripts: a,
                                    css: n
                                } = e;
                                return Promise.all([t.has(r) ? [] : Promise.all(a.map(i)), Promise.all(n.map(l))])
                            }).then(e => this.whenEntrypoint(r).then(t => ({
                                entrypoint: t,
                                styles: e[1]
                            }))), 3800, h(Error("Route did not complete loading: " + r))).then(e => {
                                let {
                                    entrypoint: t,
                                    styles: r
                                } = e, a = Object.assign({
                                    styles: r
                                }, t);
                                return "error" in t ? t : a
                            }).catch(e => {
                                if (a) throw e;
                                return {
                                    error: e
                                }
                            }).finally(() => null == n ? void 0 : n())
                        })
                    },
                    prefetch(t) {
                        let r;
                        return (r = navigator.connection) && (r.saveData || /2g/.test(r.effectiveType)) ? Promise.resolve() : m(e, t).then(e => Promise.all(c ? e.scripts.map(e => {
                            var t, r, a;
                            return t = e.toString(), r = "script", new Promise((e, n) => {
                                if (document.querySelector('\n      link[rel="prefetch"][href^="' + t + '"],\n      link[rel="preload"][href^="' + t + '"],\n      script[src^="' + t + '"]')) return e();
                                a = document.createElement("link"), r && (a.as = r), a.rel = "prefetch", a.crossOrigin = void 0, a.onload = e, a.onerror = () => n(h(Error("Failed to prefetch: " + t))), a.href = t, document.head.appendChild(a)
                            })
                        }) : [])).then(() => {
                            (0, n.requestIdleCallback)(() => this.loadRoute(t, !0).catch(() => {}))
                        }).catch(() => {})
                    }
                }
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        690: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    Router: function() {
                        return o.default
                    },
                    createRouter: function() {
                        return m
                    },
                    default: function() {
                        return f
                    },
                    makePublicRouterInstance: function() {
                        return _
                    },
                    useRouter: function() {
                        return p
                    },
                    withRouter: function() {
                        return l.default
                    }
                });
            let a = r(81838),
                n = a._(r(93264)),
                o = a._(r(16687)),
                i = r(5519),
                s = a._(r(37588)),
                l = a._(r(70268)),
                h = {
                    router: null,
                    readyCallbacks: [],
                    ready(e) {
                        if (this.router) return e();
                        "undefined" != typeof window && this.readyCallbacks.push(e)
                    }
                },
                u = ["pathname", "route", "query", "asPath", "components", "isFallback", "basePath", "locale", "locales", "defaultLocale", "isReady", "isPreview", "isLocaleDomain", "domainLocales"],
                c = ["push", "replace", "reload", "back", "prefetch", "beforePopState"];

            function d() {
                if (!h.router) throw Error('No router instance found.\nYou should only use "next/router" on the client side of your app.\n');
                return h.router
            }
            Object.defineProperty(h, "events", {
                get: () => o.default.events
            }), u.forEach(e => {
                Object.defineProperty(h, e, {
                    get: () => d()[e]
                })
            }), c.forEach(e => {
                h[e] = function() {
                    for (var t = arguments.length, r = Array(t), a = 0; a < t; a++) r[a] = arguments[a];
                    return d()[e](...r)
                }
            }), ["routeChangeStart", "beforeHistoryChange", "routeChangeComplete", "routeChangeError", "hashChangeStart", "hashChangeComplete"].forEach(e => {
                h.ready(() => {
                    o.default.events.on(e, function() {
                        for (var t = arguments.length, r = Array(t), a = 0; a < t; a++) r[a] = arguments[a];
                        let n = "on" + e.charAt(0).toUpperCase() + e.substring(1);
                        if (h[n]) try {
                            h[n](...r)
                        } catch (e) {
                            console.error("Error when running the Router event: " + n), console.error((0, s.default)(e) ? e.message + "\n" + e.stack : e + "")
                        }
                    })
                })
            });
            let f = h;

            function p() {
                let e = n.default.useContext(i.RouterContext);
                if (!e) throw Error("NextRouter was not mounted. https://nextjs.org/docs/messages/next-router-not-mounted");
                return e
            }

            function m() {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return h.router = new o.default(...t), h.readyCallbacks.forEach(e => e()), h.readyCallbacks = [], h.router
            }

            function _(e) {
                let t = {};
                for (let r of u) {
                    if ("object" == typeof e[r]) {
                        t[r] = Object.assign(Array.isArray(e[r]) ? [] : {}, e[r]);
                        continue
                    }
                    t[r] = e[r]
                }
                return t.events = o.default.events, c.forEach(r => {
                    t[r] = function() {
                        for (var t = arguments.length, a = Array(t), n = 0; n < t; n++) a[n] = arguments[n];
                        return e[r](...a)
                    }
                }), t
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        22203: (e, t) => {
            let r;

            function a(e) {
                var t;
                return (null == (t = function() {
                    if (void 0 === r && "undefined" != typeof window) {
                        var e;
                        r = (null == (e = window.trustedTypes) ? void 0 : e.createPolicy("nextjs", {
                            createHTML: e => e,
                            createScript: e => e,
                            createScriptURL: e => e
                        })) || null
                    }
                    return r
                }()) ? void 0 : t.createScriptURL(e)) || e
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "__unsafeCreateTrustedScriptURL", {
                enumerable: !0,
                get: function() {
                    return a
                }
            }), ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        70268: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return o
                }
            }), r(81838);
            let a = r(12428);
            r(93264);
            let n = r(690);

            function o(e) {
                function t(t) {
                    return (0, a.jsx)(e, {
                        router: (0, n.useRouter)(),
                        ...t
                    })
                }
                return t.getInitialProps = e.getInitialProps, t.origGetInitialProps = e.origGetInitialProps, t
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        68551: (e, t) => {
            function r(e) {
                return "/api" === e || !!(null == e ? void 0 : e.startsWith("/api/"))
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "isAPIRoute", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        99132: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "BloomFilter", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            class r {
                static from(e, t) {
                    void 0 === t && (t = 1e-4);
                    let a = new r(e.length, t);
                    for (let t of e) a.add(t);
                    return a
                }
                export () {
                    return {
                        numItems: this.numItems,
                        errorRate: this.errorRate,
                        numBits: this.numBits,
                        numHashes: this.numHashes,
                        bitArray: this.bitArray
                    }
                }
                import (e) {
                    this.numItems = e.numItems, this.errorRate = e.errorRate, this.numBits = e.numBits, this.numHashes = e.numHashes, this.bitArray = e.bitArray
                }
                add(e) {
                    this.getHashValues(e).forEach(e => {
                        this.bitArray[e] = 1
                    })
                }
                contains(e) {
                    return this.getHashValues(e).every(e => this.bitArray[e])
                }
                getHashValues(e) {
                    let t = [];
                    for (let r = 1; r <= this.numHashes; r++) {
                        let a = function(e) {
                            let t = 0;
                            for (let r = 0; r < e.length; r++) t = Math.imul(t ^ e.charCodeAt(r), 0x5bd1e995), t ^= t >>> 13, t = Math.imul(t, 0x5bd1e995);
                            return t >>> 0
                        }("" + e + r) % this.numBits;
                        t.push(a)
                    }
                    return t
                }
                constructor(e, t = 1e-4) {
                    this.numItems = e, this.errorRate = t, this.numBits = Math.ceil(-(e * Math.log(t)) / (Math.log(2) * Math.log(2))), this.numHashes = Math.ceil(this.numBits / e * Math.log(2)), this.bitArray = Array(this.numBits).fill(0)
                }
            }
        },
        52848: (e, t) => {
            function r(e, t) {
                let r;
                let a = e.split("/");
                return (t || []).some(t => !!a[1] && a[1].toLowerCase() === t.toLowerCase() && (r = t, a.splice(1, 1), e = a.join("/") || "/", !0)), {
                    pathname: e,
                    detectedLocale: r
                }
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "normalizeLocalePath", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        18470: (e, t) => {
            function r() {
                let e = Object.create(null);
                return {
                    on(t, r) {
                        (e[t] || (e[t] = [])).push(r)
                    },
                    off(t, r) {
                        e[t] && e[t].splice(e[t].indexOf(r) >>> 0, 1)
                    },
                    emit(t) {
                        for (var r = arguments.length, a = Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++) a[n - 1] = arguments[n];
                        (e[t] || []).slice().map(e => {
                            e(...a)
                        })
                    }
                }
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        89865: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "denormalizePagePath", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let a = r(4977),
                n = r(57448);

            function o(e) {
                let t = (0, n.normalizePathSep)(e);
                return t.startsWith("/index/") && !(0, a.isDynamicRoute)(t) ? t.slice(6) : "/index" !== t ? t : "/"
            }
        },
        57448: (e, t) => {
            function r(e) {
                return e.replace(/\\/g, "/")
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "normalizePathSep", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        16687: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var r in t) Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: t[r]
                    })
                }(t, {
                    createKey: function() {
                        return q
                    },
                    default: function() {
                        return z
                    },
                    matchesMiddleware: function() {
                        return N
                    }
                });
            let a = r(81838),
                n = r(86077),
                o = r(55559),
                i = r(23803),
                s = r(88227),
                l = n._(r(37588)),
                h = r(89865),
                u = r(52848),
                c = a._(r(18470)),
                d = r(42511),
                f = r(26213),
                p = r(91293);
            r(24683);
            let m = r(69273),
                _ = r(20511),
                g = r(94703);
            r(95340);
            let P = r(32103),
                v = r(12550),
                y = r(99215),
                w = r(71403),
                b = r(42941),
                S = r(6141),
                j = r(45507),
                R = r(68551),
                L = r(47153),
                C = r(46833),
                O = r(30048),
                x = r(21436),
                E = r(86733),
                A = r(94029),
                M = r(40164),
                I = r(51504);

            function T() {
                return Object.assign(Error("Route Cancelled"), {
                    cancelled: !0
                })
            }
            async function N(e) {
                let t = await Promise.resolve(e.router.pageLoader.getMiddleware());
                if (!t) return !1;
                let {
                    pathname: r
                } = (0, P.parsePath)(e.asPath), a = (0, S.hasBasePath)(r) ? (0, w.removeBasePath)(r) : r, n = (0, b.addBasePath)((0, v.addLocale)(a, e.locale));
                return t.some(e => new RegExp(e.regexp).test(n))
            }

            function k(e) {
                let t = (0, d.getLocationOrigin)();
                return e.startsWith(t) ? e.substring(t.length) : e
            }

            function B(e, t, r) {
                let [a, n] = (0, j.resolveHref)(e, t, !0), o = (0, d.getLocationOrigin)(), i = a.startsWith(o), s = n && n.startsWith(o);
                a = k(a), n = n ? k(n) : n;
                let l = i ? a : (0, b.addBasePath)(a),
                    h = r ? k((0, j.resolveHref)(e, r)) : n || a;
                return {
                    url: l,
                    as: s ? h : (0, b.addBasePath)(h)
                }
            }

            function H(e, t) {
                let r = (0, o.removeTrailingSlash)((0, h.denormalizePagePath)(e));
                return "/404" === r || "/_error" === r ? e : (t.includes(r) || t.some(t => {
                    if ((0, f.isDynamicRoute)(t) && (0, _.getRouteRegex)(t).re.test(r)) return e = t, !0
                }), (0, o.removeTrailingSlash)(e))
            }
            async function D(e) {
                if (!await N(e) || !e.fetchData) return null;
                let t = await e.fetchData(),
                    r = await
                function(e, t, r) {
                    let a = {
                            basePath: r.router.basePath,
                            i18n: {
                                locales: r.router.locales
                            },
                            trailingSlash: !1
                        },
                        n = t.headers.get("x-nextjs-rewrite"),
                        s = n || t.headers.get("x-nextjs-matched-path"),
                        l = t.headers.get("x-matched-path");
                    if (!l || s || l.includes("__next_data_catchall") || l.includes("/_error") || l.includes("/404") || (s = l), s) {
                        if (s.startsWith("/")) {
                            let t = (0, p.parseRelativeUrl)(s),
                                l = (0, L.getNextPathnameInfo)(t.pathname, {
                                    nextConfig: a,
                                    parseData: !0
                                }),
                                h = (0, o.removeTrailingSlash)(l.pathname);
                            return Promise.all([r.router.pageLoader.getPageList(), (0, i.getClientBuildManifest)()]).then(o => {
                                let [i, {
                                    __rewrites: s
                                }] = o, c = (0, v.addLocale)(l.pathname, l.locale);
                                if ((0, f.isDynamicRoute)(c) || !n && i.includes((0, u.normalizeLocalePath)((0, w.removeBasePath)(c), r.router.locales).pathname)) {
                                    let r = (0, L.getNextPathnameInfo)((0, p.parseRelativeUrl)(e).pathname, {
                                        nextConfig: a,
                                        parseData: !0
                                    });
                                    c = (0, b.addBasePath)(r.pathname), t.pathname = c
                                }
                                if (!i.includes(h)) {
                                    let e = H(h, i);
                                    e !== h && (h = e)
                                }
                                let d = i.includes(h) ? h : H((0, u.normalizeLocalePath)((0, w.removeBasePath)(t.pathname), r.router.locales).pathname, i);
                                if ((0, f.isDynamicRoute)(d)) {
                                    let e = (0, m.getRouteMatcher)((0, _.getRouteRegex)(d))(c);
                                    Object.assign(t.query, e || {})
                                }
                                return {
                                    type: "rewrite",
                                    parsedAs: t,
                                    resolvedHref: d
                                }
                            })
                        }
                        let t = (0, P.parsePath)(e);
                        return Promise.resolve({
                            type: "redirect-external",
                            destination: "" + (0, C.formatNextPathnameInfo)({ ...(0, L.getNextPathnameInfo)(t.pathname, {
                                    nextConfig: a,
                                    parseData: !0
                                }),
                                defaultLocale: r.router.defaultLocale,
                                buildId: ""
                            }) + t.query + t.hash
                        })
                    }
                    let h = t.headers.get("x-nextjs-redirect");
                    if (h) {
                        if (h.startsWith("/")) {
                            let e = (0, P.parsePath)(h),
                                t = (0, C.formatNextPathnameInfo)({ ...(0, L.getNextPathnameInfo)(e.pathname, {
                                        nextConfig: a,
                                        parseData: !0
                                    }),
                                    defaultLocale: r.router.defaultLocale,
                                    buildId: ""
                                });
                            return Promise.resolve({
                                type: "redirect-internal",
                                newAs: "" + t + e.query + e.hash,
                                newUrl: "" + t + e.query + e.hash
                            })
                        }
                        return Promise.resolve({
                            type: "redirect-external",
                            destination: h
                        })
                    }
                    return Promise.resolve({
                        type: "next"
                    })
                }(t.dataHref, t.response, e);
                return {
                    dataHref: t.dataHref,
                    json: t.json,
                    response: t.response,
                    text: t.text,
                    cacheKey: t.cacheKey,
                    effect: r
                }
            }
            let U = Symbol("SSG_DATA_NOT_FOUND");

            function F(e) {
                try {
                    return JSON.parse(e)
                } catch (e) {
                    return null
                }
            }

            function W(e) {
                let {
                    dataHref: t,
                    inflightCache: r,
                    isPrefetch: a,
                    hasMiddleware: n,
                    isServerRender: o,
                    parseJSON: s,
                    persistCache: l,
                    isBackground: h,
                    unstable_skipClientCache: u
                } = e, {
                    href: c
                } = new URL(t, window.location.href), d = e => {
                    var h;
                    return (function e(t, r, a) {
                        return fetch(t, {
                            credentials: "same-origin",
                            method: a.method || "GET",
                            headers: Object.assign({}, a.headers, {
                                "x-nextjs-data": "1"
                            })
                        }).then(n => !n.ok && r > 1 && n.status >= 500 ? e(t, r - 1, a) : n)
                    })(t, o ? 3 : 1, {
                        headers: Object.assign({}, a ? {
                            purpose: "prefetch"
                        } : {}, a && n ? {
                            "x-middleware-prefetch": "1"
                        } : {}),
                        method: null != (h = null == e ? void 0 : e.method) ? h : "GET"
                    }).then(r => r.ok && (null == e ? void 0 : e.method) === "HEAD" ? {
                        dataHref: t,
                        response: r,
                        text: "",
                        json: {},
                        cacheKey: c
                    } : r.text().then(e => {
                        if (!r.ok) {
                            if (n && [301, 302, 307, 308].includes(r.status)) return {
                                dataHref: t,
                                response: r,
                                text: e,
                                json: {},
                                cacheKey: c
                            };
                            if (404 === r.status) {
                                var a;
                                if (null == (a = F(e)) ? void 0 : a.notFound) return {
                                    dataHref: t,
                                    json: {
                                        notFound: U
                                    },
                                    response: r,
                                    text: e,
                                    cacheKey: c
                                }
                            }
                            let s = Error("Failed to load static props");
                            throw o || (0, i.markAssetError)(s), s
                        }
                        return {
                            dataHref: t,
                            json: s ? F(e) : null,
                            response: r,
                            text: e,
                            cacheKey: c
                        }
                    })).then(e => (l && "no-cache" !== e.response.headers.get("x-middleware-cache") || delete r[c], e)).catch(e => {
                        throw u || delete r[c], ("Failed to fetch" === e.message || "NetworkError when attempting to fetch resource." === e.message || "Load failed" === e.message) && (0, i.markAssetError)(e), e
                    })
                };
                return u && l ? d({}).then(e => ("no-cache" !== e.response.headers.get("x-middleware-cache") && (r[c] = Promise.resolve(e)), e)) : void 0 !== r[c] ? r[c] : r[c] = d(h ? {
                    method: "HEAD"
                } : {})
            }

            function q() {
                return Math.random().toString(36).slice(2, 10)
            }

            function V(e) {
                let {
                    url: t,
                    router: r
                } = e;
                if (t === (0, b.addBasePath)((0, v.addLocale)(r.asPath, r.locale))) throw Error("Invariant: attempted to hard navigate to the same URL " + t + " " + location.href);
                window.location.href = t
            }
            let G = e => {
                let {
                    route: t,
                    router: r
                } = e, a = !1, n = r.clc = () => {
                    a = !0
                };
                return () => {
                    if (a) {
                        let e = Error('Abort fetching component for route: "' + t + '"');
                        throw e.cancelled = !0, e
                    }
                    n === r.clc && (r.clc = null)
                }
            };
            class z {
                reload() {
                    window.location.reload()
                }
                back() {
                    window.history.back()
                }
                forward() {
                    window.history.forward()
                }
                push(e, t, r) {
                    return void 0 === r && (r = {}), {
                        url: e,
                        as: t
                    } = B(this, e, t), this.change("pushState", e, t, r)
                }
                replace(e, t, r) {
                    return void 0 === r && (r = {}), {
                        url: e,
                        as: t
                    } = B(this, e, t), this.change("replaceState", e, t, r)
                }
                async _bfl(e, t, a, n) {
                    {
                        if (!this._bfl_s && !this._bfl_d) {
                            let t, o;
                            let {
                                BloomFilter: s
                            } = r(99132);
                            try {
                                ({
                                    __routerFilterStatic: t,
                                    __routerFilterDynamic: o
                                } = await (0, i.getClientBuildManifest)())
                            } catch (t) {
                                if (console.error(t), n) return !0;
                                return V({
                                    url: (0, b.addBasePath)((0, v.addLocale)(e, a || this.locale, this.defaultLocale)),
                                    router: this
                                }), new Promise(() => {})
                            }(null == t ? void 0 : t.numHashes) && (this._bfl_s = new s(t.numItems, t.errorRate), this._bfl_s.import(t)), (null == o ? void 0 : o.numHashes) && (this._bfl_d = new s(o.numItems, o.errorRate), this._bfl_d.import(o))
                        }
                        let u = !1,
                            c = !1;
                        for (let {
                                as: r,
                                allowMatchCurrent: i
                            } of [{
                                as: e
                            }, {
                                as: t
                            }])
                            if (r) {
                                let t = (0, o.removeTrailingSlash)(new URL(r, "http://n").pathname),
                                    d = (0, b.addBasePath)((0, v.addLocale)(t, a || this.locale));
                                if (i || t !== (0, o.removeTrailingSlash)(new URL(this.asPath, "http://n").pathname)) {
                                    var s, l, h;
                                    for (let e of (u = u || !!(null == (s = this._bfl_s) ? void 0 : s.contains(t)) || !!(null == (l = this._bfl_s) ? void 0 : l.contains(d)), [t, d])) {
                                        let t = e.split("/");
                                        for (let e = 0; !c && e < t.length + 1; e++) {
                                            let r = t.slice(0, e).join("/");
                                            if (r && (null == (h = this._bfl_d) ? void 0 : h.contains(r))) {
                                                c = !0;
                                                break
                                            }
                                        }
                                    }
                                    if (u || c) {
                                        if (n) return !0;
                                        return V({
                                            url: (0, b.addBasePath)((0, v.addLocale)(e, a || this.locale, this.defaultLocale)),
                                            router: this
                                        }), new Promise(() => {})
                                    }
                                }
                            }
                    }
                    return !1
                }
                async change(e, t, r, a, n) {
                    var h, u, c, j, R, L, C, E, I;
                    let k, D;
                    if (!(0, x.isLocalURL)(t)) return V({
                        url: t,
                        router: this
                    }), !1;
                    let F = 1 === a._h;
                    F || a.shallow || await this._bfl(r, void 0, a.locale);
                    let W = F || a._shouldResolveHref || (0, P.parsePath)(t).pathname === (0, P.parsePath)(r).pathname,
                        q = { ...this.state
                        },
                        G = !0 !== this.isReady;
                    this.isReady = !0;
                    let X = this.isSsr;
                    if (F || (this.isSsr = !1), F && this.clc) return !1;
                    let K = q.locale;
                    d.ST && performance.mark("routeChange");
                    let {
                        shallow: J = !1,
                        scroll: Q = !0
                    } = a, $ = {
                        shallow: J
                    };
                    this._inFlightRoute && this.clc && (X || z.events.emit("routeChangeError", T(), this._inFlightRoute, $), this.clc(), this.clc = null), r = (0, b.addBasePath)((0, v.addLocale)((0, S.hasBasePath)(r) ? (0, w.removeBasePath)(r) : r, a.locale, this.defaultLocale));
                    let Y = (0, y.removeLocale)((0, S.hasBasePath)(r) ? (0, w.removeBasePath)(r) : r, q.locale);
                    this._inFlightRoute = r;
                    let Z = K !== q.locale;
                    if (!F && this.onlyAHashChange(Y) && !Z) {
                        q.asPath = Y, z.events.emit("hashChangeStart", r, $), this.changeState(e, t, r, { ...a,
                            scroll: !1
                        }), Q && this.scrollToHash(Y);
                        try {
                            await this.set(q, this.components[q.route], null)
                        } catch (e) {
                            throw (0, l.default)(e) && e.cancelled && z.events.emit("routeChangeError", e, Y, $), e
                        }
                        return z.events.emit("hashChangeComplete", r, $), !0
                    }
                    let ee = (0, p.parseRelativeUrl)(t),
                        {
                            pathname: et,
                            query: er
                        } = ee;
                    try {
                        [k, {
                            __rewrites: D
                        }] = await Promise.all([this.pageLoader.getPageList(), (0, i.getClientBuildManifest)(), this.pageLoader.getMiddleware()])
                    } catch (e) {
                        return V({
                            url: r,
                            router: this
                        }), !1
                    }
                    this.urlIsNew(Y) || Z || (e = "replaceState");
                    let ea = r;
                    et = et ? (0, o.removeTrailingSlash)((0, w.removeBasePath)(et)) : et;
                    let en = (0, o.removeTrailingSlash)(et),
                        eo = r.startsWith("/") && (0, p.parseRelativeUrl)(r).pathname;
                    if (null == (h = this.components[et]) ? void 0 : h.__appRouter) return V({
                        url: r,
                        router: this
                    }), new Promise(() => {});
                    let ei = !!(eo && en !== eo && (!(0, f.isDynamicRoute)(en) || !(0, m.getRouteMatcher)((0, _.getRouteRegex)(en))(eo))),
                        es = !a.shallow && await N({
                            asPath: r,
                            locale: q.locale,
                            router: this
                        });
                    if (F && es && (W = !1), W && "/_error" !== et && (a._shouldResolveHref = !0, ee.pathname = H(et, k), ee.pathname === et || (et = ee.pathname, ee.pathname = (0, b.addBasePath)(et), es || (t = (0, g.formatWithValidation)(ee)))), !(0, x.isLocalURL)(r)) return V({
                        url: r,
                        router: this
                    }), !1;
                    ea = (0, y.removeLocale)((0, w.removeBasePath)(ea), q.locale), en = (0, o.removeTrailingSlash)(et);
                    let el = !1;
                    if ((0, f.isDynamicRoute)(en)) {
                        let e = (0, p.parseRelativeUrl)(ea),
                            a = e.pathname,
                            n = (0, _.getRouteRegex)(en);
                        el = (0, m.getRouteMatcher)(n)(a);
                        let o = en === a,
                            i = o ? (0, M.interpolateAs)(en, a, er) : {};
                        if (el && (!o || i.result)) o ? r = (0, g.formatWithValidation)(Object.assign({}, e, {
                            pathname: i.result,
                            query: (0, A.omit)(er, i.params)
                        })) : Object.assign(er, el);
                        else {
                            let e = Object.keys(n.groups).filter(e => !er[e] && !n.groups[e].optional);
                            if (e.length > 0 && !es) throw Error((o ? "The provided `href` (" + t + ") value is missing query values (" + e.join(", ") + ") to be interpolated properly. " : "The provided `as` value (" + a + ") is incompatible with the `href` value (" + en + "). ") + "Read more: https://nextjs.org/docs/messages/" + (o ? "href-interpolation-failed" : "incompatible-href-as"))
                        }
                    }
                    F || z.events.emit("routeChangeStart", r, $);
                    let eh = "/404" === this.pathname || "/_error" === this.pathname;
                    try {
                        let o = await this.getRouteInfo({
                            route: en,
                            pathname: et,
                            query: er,
                            as: r,
                            resolvedAs: ea,
                            routeProps: $,
                            locale: q.locale,
                            isPreview: q.isPreview,
                            hasMiddleware: es,
                            unstable_skipClientCache: a.unstable_skipClientCache,
                            isQueryUpdating: F && !this.isFallback,
                            isMiddlewareRewrite: ei
                        });
                        if (F || a.shallow || await this._bfl(r, "resolvedAs" in o ? o.resolvedAs : void 0, q.locale), "route" in o && es) {
                            en = et = o.route || en, $.shallow || (er = Object.assign({}, o.query || {}, er));
                            let e = (0, S.hasBasePath)(ee.pathname) ? (0, w.removeBasePath)(ee.pathname) : ee.pathname;
                            if (el && et !== e && Object.keys(el).forEach(e => {
                                    el && er[e] === el[e] && delete er[e]
                                }), (0, f.isDynamicRoute)(et)) {
                                let e = !$.shallow && o.resolvedAs ? o.resolvedAs : (0, b.addBasePath)((0, v.addLocale)(new URL(r, location.href).pathname, q.locale), !0);
                                (0, S.hasBasePath)(e) && (e = (0, w.removeBasePath)(e));
                                let t = (0, _.getRouteRegex)(et),
                                    a = (0, m.getRouteMatcher)(t)(new URL(e, location.href).pathname);
                                a && Object.assign(er, a)
                            }
                        }
                        if ("type" in o) {
                            if ("redirect-internal" === o.type) return this.change(e, o.newUrl, o.newAs, a);
                            return V({
                                url: o.destination,
                                router: this
                            }), new Promise(() => {})
                        }
                        let i = o.Component;
                        if (i && i.unstable_scriptLoader && [].concat(i.unstable_scriptLoader()).forEach(e => {
                                (0, s.handleClientScriptLoad)(e.props)
                            }), (o.__N_SSG || o.__N_SSP) && o.props) {
                            if (o.props.pageProps && o.props.pageProps.__N_REDIRECT) {
                                a.locale = !1;
                                let t = o.props.pageProps.__N_REDIRECT;
                                if (t.startsWith("/") && !1 !== o.props.pageProps.__N_REDIRECT_BASE_PATH) {
                                    let r = (0, p.parseRelativeUrl)(t);
                                    r.pathname = H(r.pathname, k);
                                    let {
                                        url: n,
                                        as: o
                                    } = B(this, t, t);
                                    return this.change(e, n, o, a)
                                }
                                return V({
                                    url: t,
                                    router: this
                                }), new Promise(() => {})
                            }
                            if (q.isPreview = !!o.props.__N_PREVIEW, o.props.notFound === U) {
                                let e;
                                try {
                                    await this.fetchComponent("/404"), e = "/404"
                                } catch (t) {
                                    e = "/_error"
                                }
                                if (o = await this.getRouteInfo({
                                        route: e,
                                        pathname: e,
                                        query: er,
                                        as: r,
                                        resolvedAs: ea,
                                        routeProps: {
                                            shallow: !1
                                        },
                                        locale: q.locale,
                                        isPreview: q.isPreview,
                                        isNotFound: !0
                                    }), "type" in o) throw Error("Unexpected middleware effect on /404")
                            }
                        }
                        F && "/_error" === this.pathname && (null == (c = self.__NEXT_DATA__.props) ? void 0 : null == (u = c.pageProps) ? void 0 : u.statusCode) === 500 && (null == (j = o.props) ? void 0 : j.pageProps) && (o.props.pageProps.statusCode = 500);
                        let h = a.shallow && q.route === (null != (R = o.route) ? R : en),
                            d = null != (L = a.scroll) ? L : !F && !h,
                            g = null != n ? n : d ? {
                                x: 0,
                                y: 0
                            } : null,
                            P = { ...q,
                                route: en,
                                pathname: et,
                                query: er,
                                asPath: Y,
                                isFallback: !1
                            };
                        if (F && eh) {
                            if (o = await this.getRouteInfo({
                                    route: this.pathname,
                                    pathname: this.pathname,
                                    query: er,
                                    as: r,
                                    resolvedAs: ea,
                                    routeProps: {
                                        shallow: !1
                                    },
                                    locale: q.locale,
                                    isPreview: q.isPreview,
                                    isQueryUpdating: F && !this.isFallback
                                }), "type" in o) throw Error("Unexpected middleware effect on " + this.pathname);
                            "/_error" === this.pathname && (null == (E = self.__NEXT_DATA__.props) ? void 0 : null == (C = E.pageProps) ? void 0 : C.statusCode) === 500 && (null == (I = o.props) ? void 0 : I.pageProps) && (o.props.pageProps.statusCode = 500);
                            try {
                                await this.set(P, o, g)
                            } catch (e) {
                                throw (0, l.default)(e) && e.cancelled && z.events.emit("routeChangeError", e, Y, $), e
                            }
                            return !0
                        }
                        if (z.events.emit("beforeHistoryChange", r, $), this.changeState(e, t, r, a), !(F && !g && !G && !Z && (0, O.compareRouterStates)(P, this.state))) {
                            try {
                                await this.set(P, o, g)
                            } catch (e) {
                                if (e.cancelled) o.error = o.error || e;
                                else throw e
                            }
                            if (o.error) throw F || z.events.emit("routeChangeError", o.error, Y, $), o.error;
                            F || z.events.emit("routeChangeComplete", r, $), d && /#.+$/.test(r) && this.scrollToHash(r)
                        }
                        return !0
                    } catch (e) {
                        if ((0, l.default)(e) && e.cancelled) return !1;
                        throw e
                    }
                }
                changeState(e, t, r, a) {
                    void 0 === a && (a = {}), ("pushState" !== e || (0, d.getURL)() !== r) && (this._shallow = a.shallow, window.history[e]({
                        url: t,
                        as: r,
                        options: a,
                        __N: !0,
                        key: this._key = "pushState" !== e ? this._key : q()
                    }, "", r))
                }
                async handleRouteInfoError(e, t, r, a, n, o) {
                    if (e.cancelled) throw e;
                    if ((0, i.isAssetError)(e) || o) throw z.events.emit("routeChangeError", e, a, n), V({
                        url: a,
                        router: this
                    }), T();
                    console.error(e);
                    try {
                        let a;
                        let {
                            page: n,
                            styleSheets: o
                        } = await this.fetchComponent("/_error"), i = {
                            props: a,
                            Component: n,
                            styleSheets: o,
                            err: e,
                            error: e
                        };
                        if (!i.props) try {
                            i.props = await this.getInitialProps(n, {
                                err: e,
                                pathname: t,
                                query: r
                            })
                        } catch (e) {
                            console.error("Error in error page `getInitialProps`: ", e), i.props = {}
                        }
                        return i
                    } catch (e) {
                        return this.handleRouteInfoError((0, l.default)(e) ? e : Error(e + ""), t, r, a, n, !0)
                    }
                }
                async getRouteInfo(e) {
                    let {
                        route: t,
                        pathname: r,
                        query: a,
                        as: n,
                        resolvedAs: i,
                        routeProps: s,
                        locale: h,
                        hasMiddleware: c,
                        isPreview: d,
                        unstable_skipClientCache: f,
                        isQueryUpdating: p,
                        isMiddlewareRewrite: m,
                        isNotFound: _
                    } = e, P = t;
                    try {
                        var v, y, b, S;
                        let e = this.components[P];
                        if (s.shallow && e && this.route === P) return e;
                        let t = G({
                            route: P,
                            router: this
                        });
                        c && (e = void 0);
                        let l = !e || "initial" in e ? void 0 : e,
                            j = {
                                dataHref: this.pageLoader.getDataHref({
                                    href: (0, g.formatWithValidation)({
                                        pathname: r,
                                        query: a
                                    }),
                                    skipInterpolation: !0,
                                    asPath: _ ? "/404" : i,
                                    locale: h
                                }),
                                hasMiddleware: !0,
                                isServerRender: this.isSsr,
                                parseJSON: !0,
                                inflightCache: p ? this.sbc : this.sdc,
                                persistCache: !d,
                                isPrefetch: !1,
                                unstable_skipClientCache: f,
                                isBackground: p
                            },
                            L = p && !m ? null : await D({
                                fetchData: () => W(j),
                                asPath: _ ? "/404" : i,
                                locale: h,
                                router: this
                            }).catch(e => {
                                if (p) return null;
                                throw e
                            });
                        if (L && ("/_error" === r || "/404" === r) && (L.effect = void 0), p && (L ? L.json = self.__NEXT_DATA__.props : L = {
                                json: self.__NEXT_DATA__.props
                            }), t(), (null == L ? void 0 : null == (v = L.effect) ? void 0 : v.type) === "redirect-internal" || (null == L ? void 0 : null == (y = L.effect) ? void 0 : y.type) === "redirect-external") return L.effect;
                        if ((null == L ? void 0 : null == (b = L.effect) ? void 0 : b.type) === "rewrite") {
                            let t = (0, o.removeTrailingSlash)(L.effect.resolvedHref),
                                n = await this.pageLoader.getPageList();
                            if ((!p || n.includes(t)) && (P = t, r = L.effect.resolvedHref, a = { ...a,
                                    ...L.effect.parsedAs.query
                                }, i = (0, w.removeBasePath)((0, u.normalizeLocalePath)(L.effect.parsedAs.pathname, this.locales).pathname), e = this.components[P], s.shallow && e && this.route === P && !c)) return { ...e,
                                route: P
                            }
                        }
                        if ((0, R.isAPIRoute)(P)) return V({
                            url: n,
                            router: this
                        }), new Promise(() => {});
                        let C = l || await this.fetchComponent(P).then(e => ({
                                Component: e.page,
                                styleSheets: e.styleSheets,
                                __N_SSG: e.mod.__N_SSG,
                                __N_SSP: e.mod.__N_SSP
                            })),
                            O = null == L ? void 0 : null == (S = L.response) ? void 0 : S.headers.get("x-middleware-skip"),
                            x = C.__N_SSG || C.__N_SSP;
                        O && (null == L ? void 0 : L.dataHref) && delete this.sdc[L.dataHref];
                        let {
                            props: E,
                            cacheKey: A
                        } = await this._getData(async () => {
                            if (x) {
                                if ((null == L ? void 0 : L.json) && !O) return {
                                    cacheKey: L.cacheKey,
                                    props: L.json
                                };
                                let e = (null == L ? void 0 : L.dataHref) ? L.dataHref : this.pageLoader.getDataHref({
                                        href: (0, g.formatWithValidation)({
                                            pathname: r,
                                            query: a
                                        }),
                                        asPath: i,
                                        locale: h
                                    }),
                                    t = await W({
                                        dataHref: e,
                                        isServerRender: this.isSsr,
                                        parseJSON: !0,
                                        inflightCache: O ? {} : this.sdc,
                                        persistCache: !d,
                                        isPrefetch: !1,
                                        unstable_skipClientCache: f
                                    });
                                return {
                                    cacheKey: t.cacheKey,
                                    props: t.json || {}
                                }
                            }
                            return {
                                headers: {},
                                props: await this.getInitialProps(C.Component, {
                                    pathname: r,
                                    query: a,
                                    asPath: n,
                                    locale: h,
                                    locales: this.locales,
                                    defaultLocale: this.defaultLocale
                                })
                            }
                        });
                        return C.__N_SSP && j.dataHref && A && delete this.sdc[A], this.isPreview || !C.__N_SSG || p || W(Object.assign({}, j, {
                            isBackground: !0,
                            persistCache: !1,
                            inflightCache: this.sbc
                        })).catch(() => {}), E.pageProps = Object.assign({}, E.pageProps), C.props = E, C.route = P, C.query = a, C.resolvedAs = i, this.components[P] = C, C
                    } catch (e) {
                        return this.handleRouteInfoError((0, l.getProperError)(e), r, a, n, s)
                    }
                }
                set(e, t, r) {
                    return this.state = e, this.sub(t, this.components["/_app"].Component, r)
                }
                beforePopState(e) {
                    this._bps = e
                }
                onlyAHashChange(e) {
                    if (!this.asPath) return !1;
                    let [t, r] = this.asPath.split("#", 2), [a, n] = e.split("#", 2);
                    return !!n && t === a && r === n || t === a && r !== n
                }
                scrollToHash(e) {
                    let [, t = ""] = e.split("#", 2);
                    (0, I.handleSmoothScroll)(() => {
                        if ("" === t || "top" === t) {
                            window.scrollTo(0, 0);
                            return
                        }
                        let e = decodeURIComponent(t),
                            r = document.getElementById(e);
                        if (r) {
                            r.scrollIntoView();
                            return
                        }
                        let a = document.getElementsByName(e)[0];
                        a && a.scrollIntoView()
                    }, {
                        onlyHashChange: this.onlyAHashChange(e)
                    })
                }
                urlIsNew(e) {
                    return this.asPath !== e
                }
                async prefetch(e, t, r) {
                    if (void 0 === t && (t = e), void 0 === r && (r = {}), "undefined" != typeof window && (0, E.isBot)(window.navigator.userAgent)) return;
                    let a = (0, p.parseRelativeUrl)(e),
                        n = a.pathname,
                        {
                            pathname: i,
                            query: s
                        } = a,
                        l = i,
                        h = await this.pageLoader.getPageList(),
                        u = t,
                        c = void 0 !== r.locale ? r.locale || void 0 : this.locale,
                        d = await N({
                            asPath: t,
                            locale: c,
                            router: this
                        });
                    a.pathname = H(a.pathname, h), (0, f.isDynamicRoute)(a.pathname) && (i = a.pathname, a.pathname = i, Object.assign(s, (0, m.getRouteMatcher)((0, _.getRouteRegex)(a.pathname))((0, P.parsePath)(t).pathname) || {}), d || (e = (0, g.formatWithValidation)(a)));
                    let v = await D({
                        fetchData: () => W({
                            dataHref: this.pageLoader.getDataHref({
                                href: (0, g.formatWithValidation)({
                                    pathname: l,
                                    query: s
                                }),
                                skipInterpolation: !0,
                                asPath: u,
                                locale: c
                            }),
                            hasMiddleware: !0,
                            isServerRender: !1,
                            parseJSON: !0,
                            inflightCache: this.sdc,
                            persistCache: !this.isPreview,
                            isPrefetch: !0
                        }),
                        asPath: t,
                        locale: c,
                        router: this
                    });
                    if ((null == v ? void 0 : v.effect.type) === "rewrite" && (a.pathname = v.effect.resolvedHref, i = v.effect.resolvedHref, s = { ...s,
                            ...v.effect.parsedAs.query
                        }, u = v.effect.parsedAs.pathname, e = (0, g.formatWithValidation)(a)), (null == v ? void 0 : v.effect.type) === "redirect-external") return;
                    let y = (0, o.removeTrailingSlash)(i);
                    await this._bfl(t, u, r.locale, !0) && (this.components[n] = {
                        __appRouter: !0
                    }), await Promise.all([this.pageLoader._isSsg(y).then(t => !!t && W({
                        dataHref: (null == v ? void 0 : v.json) ? null == v ? void 0 : v.dataHref : this.pageLoader.getDataHref({
                            href: e,
                            asPath: u,
                            locale: c
                        }),
                        isServerRender: !1,
                        parseJSON: !0,
                        inflightCache: this.sdc,
                        persistCache: !this.isPreview,
                        isPrefetch: !0,
                        unstable_skipClientCache: r.unstable_skipClientCache || r.priority && !0
                    }).then(() => !1).catch(() => !1)), this.pageLoader[r.priority ? "loadPage" : "prefetch"](y)])
                }
                async fetchComponent(e) {
                    let t = G({
                        route: e,
                        router: this
                    });
                    try {
                        let r = await this.pageLoader.loadPage(e);
                        return t(), r
                    } catch (e) {
                        throw t(), e
                    }
                }
                _getData(e) {
                    let t = !1,
                        r = () => {
                            t = !0
                        };
                    return this.clc = r, e().then(e => {
                        if (r === this.clc && (this.clc = null), t) {
                            let e = Error("Loading initial props cancelled");
                            throw e.cancelled = !0, e
                        }
                        return e
                    })
                }
                getInitialProps(e, t) {
                    let {
                        Component: r
                    } = this.components["/_app"], a = this._wrapApp(r);
                    return t.AppTree = a, (0, d.loadGetInitialProps)(r, {
                        AppTree: a,
                        Component: e,
                        router: this,
                        ctx: t
                    })
                }
                get route() {
                    return this.state.route
                }
                get pathname() {
                    return this.state.pathname
                }
                get query() {
                    return this.state.query
                }
                get asPath() {
                    return this.state.asPath
                }
                get locale() {
                    return this.state.locale
                }
                get isFallback() {
                    return this.state.isFallback
                }
                get isPreview() {
                    return this.state.isPreview
                }
                constructor(e, t, r, {
                    initialProps: a,
                    pageLoader: n,
                    App: i,
                    wrapApp: s,
                    Component: l,
                    err: h,
                    subscription: u,
                    isFallback: c,
                    locale: m,
                    locales: _,
                    defaultLocale: P,
                    domainLocales: v,
                    isPreview: y
                }) {
                    this.sdc = {}, this.sbc = {}, this.isFirstPopStateEvent = !0, this._key = q(), this.onPopState = e => {
                        let t;
                        let {
                            isFirstPopStateEvent: r
                        } = this;
                        this.isFirstPopStateEvent = !1;
                        let a = e.state;
                        if (!a) {
                            let {
                                pathname: e,
                                query: t
                            } = this;
                            this.changeState("replaceState", (0, g.formatWithValidation)({
                                pathname: (0, b.addBasePath)(e),
                                query: t
                            }), (0, d.getURL)());
                            return
                        }
                        if (a.__NA) {
                            window.location.reload();
                            return
                        }
                        if (!a.__N || r && this.locale === a.options.locale && a.as === this.asPath) return;
                        let {
                            url: n,
                            as: o,
                            options: i,
                            key: s
                        } = a;
                        this._key = s;
                        let {
                            pathname: l
                        } = (0, p.parseRelativeUrl)(n);
                        (!this.isSsr || o !== (0, b.addBasePath)(this.asPath) || l !== (0, b.addBasePath)(this.pathname)) && (!this._bps || this._bps(a)) && this.change("replaceState", n, o, Object.assign({}, i, {
                            shallow: i.shallow && this._shallow,
                            locale: i.locale || this.defaultLocale,
                            _h: 0
                        }), t)
                    };
                    let w = (0, o.removeTrailingSlash)(e);
                    this.components = {}, "/_error" !== e && (this.components[w] = {
                        Component: l,
                        initial: !0,
                        props: a,
                        err: h,
                        __N_SSG: a && a.__N_SSG,
                        __N_SSP: a && a.__N_SSP
                    }), this.components["/_app"] = {
                        Component: i,
                        styleSheets: []
                    }, this.events = z.events, this.pageLoader = n;
                    let S = (0, f.isDynamicRoute)(e) && self.__NEXT_DATA__.autoExport;
                    if (this.basePath = "", this.sub = u, this.clc = null, this._wrapApp = s, this.isSsr = !0, this.isLocaleDomain = !1, this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.isExperimentalCompile || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !S && !self.location.search), this.state = {
                            route: w,
                            pathname: e,
                            query: t,
                            asPath: S ? e : r,
                            isPreview: !!y,
                            locale: void 0,
                            isFallback: c
                        }, this._initialMatchesMiddlewarePromise = Promise.resolve(!1), "undefined" != typeof window) {
                        if (!r.startsWith("//")) {
                            let a = {
                                    locale: m
                                },
                                n = (0, d.getURL)();
                            this._initialMatchesMiddlewarePromise = N({
                                router: this,
                                locale: m,
                                asPath: n
                            }).then(o => (a._shouldResolveHref = r !== e, this.changeState("replaceState", o ? n : (0, g.formatWithValidation)({
                                pathname: (0, b.addBasePath)(e),
                                query: t
                            }), n, a), o))
                        }
                        window.addEventListener("popstate", this.onPopState)
                    }
                }
            }
            z.events = (0, c.default)()
        },
        63186: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "addLocale", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let a = r(73725),
                n = r(72805);

            function o(e, t, r, o) {
                if (!t || t === r) return e;
                let i = e.toLowerCase();
                return !o && ((0, n.pathHasPrefix)(i, "/api") || (0, n.pathHasPrefix)(i, "/" + t.toLowerCase())) ? e : (0, a.addPathPrefix)(e, "/" + t)
            }
        },
        72371: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "addPathSuffix", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let a = r(32103);

            function n(e, t) {
                if (!e.startsWith("/") || !t) return e;
                let {
                    pathname: r,
                    query: n,
                    hash: o
                } = (0, a.parsePath)(e);
                return "" + r + t + n + o
            }
        },
        30048: (e, t) => {
            function r(e, t) {
                let r = Object.keys(e);
                if (r.length !== Object.keys(t).length) return !1;
                for (let a = r.length; a--;) {
                    let n = r[a];
                    if ("query" === n) {
                        let r = Object.keys(e.query);
                        if (r.length !== Object.keys(t.query).length) return !1;
                        for (let a = r.length; a--;) {
                            let n = r[a];
                            if (!t.query.hasOwnProperty(n) || e.query[n] !== t.query[n]) return !1
                        }
                    } else if (!t.hasOwnProperty(n) || e[n] !== t[n]) return !1
                }
                return !0
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "compareRouterStates", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        46833: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "formatNextPathnameInfo", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let a = r(55559),
                n = r(73725),
                o = r(72371),
                i = r(63186);

            function s(e) {
                let t = (0, i.addLocale)(e.pathname, e.locale, e.buildId ? void 0 : e.defaultLocale, e.ignorePrefix);
                return (e.buildId || !e.trailingSlash) && (t = (0, a.removeTrailingSlash)(t)), e.buildId && (t = (0, o.addPathSuffix)((0, n.addPathPrefix)(t, "/_next/data/" + e.buildId), "/" === e.pathname ? "index.json" : ".json")), t = (0, n.addPathPrefix)(t, e.basePath), !e.buildId && e.trailingSlash ? t.endsWith("/") ? t : (0, o.addPathSuffix)(t, "/") : (0, a.removeTrailingSlash)(t)
            }
        },
        80120: (e, t) => {
            function r(e, t) {
                return void 0 === t && (t = ""), ("/" === e ? "/index" : /^\/index(\/|$)/.test(e) ? "/index" + e : e) + t
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        47153: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "getNextPathnameInfo", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            let a = r(52848),
                n = r(8951),
                o = r(72805);

            function i(e, t) {
                var r, i;
                let {
                    basePath: s,
                    i18n: l,
                    trailingSlash: h
                } = null != (r = t.nextConfig) ? r : {}, u = {
                    pathname: e,
                    trailingSlash: "/" !== e ? e.endsWith("/") : h
                };
                s && (0, o.pathHasPrefix)(u.pathname, s) && (u.pathname = (0, n.removePathPrefix)(u.pathname, s), u.basePath = s);
                let c = u.pathname;
                if (u.pathname.startsWith("/_next/data/") && u.pathname.endsWith(".json")) {
                    let e = u.pathname.replace(/^\/_next\/data\//, "").replace(/\.json$/, "").split("/"),
                        r = e[0];
                    u.buildId = r, c = "index" !== e[1] ? "/" + e.slice(1).join("/") : "/", !0 === t.parseData && (u.pathname = c)
                }
                if (l) {
                    let e = t.i18nProvider ? t.i18nProvider.analyze(u.pathname) : (0, a.normalizeLocalePath)(u.pathname, l.locales);
                    u.locale = e.detectedLocale, u.pathname = null != (i = e.pathname) ? i : u.pathname, !e.detectedLocale && u.buildId && (e = t.i18nProvider ? t.i18nProvider.analyze(c) : (0, a.normalizeLocalePath)(c, l.locales)).detectedLocale && (u.locale = e.detectedLocale)
                }
                return u
            }
        },
        91293: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "parseRelativeUrl", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let a = r(42511),
                n = r(4177);

            function o(e, t, r) {
                void 0 === r && (r = !0);
                let o = new URL("undefined" == typeof window ? "http://n" : (0, a.getLocationOrigin)()),
                    i = t ? new URL(t, o) : e.startsWith(".") ? new URL("undefined" == typeof window ? "http://n" : window.location.href) : o,
                    {
                        pathname: s,
                        searchParams: l,
                        search: h,
                        hash: u,
                        href: c,
                        origin: d
                    } = new URL(e, i);
                if (d !== o.origin) throw Error("invariant: invalid relative URL, router received " + e);
                return {
                    pathname: s,
                    query: r ? (0, n.searchParamsToUrlQuery)(l) : void 0,
                    search: h,
                    hash: u,
                    href: c.slice(d.length)
                }
            }
        },
        8951: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "removePathPrefix", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let a = r(72805);

            function n(e, t) {
                if (!(0, a.pathHasPrefix)(e, t)) return e;
                let r = e.slice(t.length);
                return r.startsWith("/") ? r : "/" + r
            }
        }
    }
]);