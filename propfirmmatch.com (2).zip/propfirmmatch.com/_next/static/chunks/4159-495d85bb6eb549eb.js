"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4159], {
        48411: (e, t, r) => {
            r.d(t, {
                CreateOrganization: () => p,
                GoogleOneTap: () => n.Kb,
                OrganizationList: () => n.Bg,
                OrganizationProfile: () => h,
                OrganizationSwitcher: () => n.Li,
                SignIn: () => y,
                SignInButton: () => n.$d,
                SignInWithMetamaskButton: () => n.qu,
                SignOutButton: () => n.AM,
                SignUp: () => g,
                SignUpButton: () => n.gX,
                UserButton: () => n.l8,
                UserProfile: () => f
            });
            var n = r(49433),
                a = r(93264),
                l = r(33906),
                o = r(6649),
                i = r(91297);
            let u = () => ({
                    pagesRouter: (0, i.useRouter)()
                }),
                s = (e, t, r, l = !0) => {
                    let i = a.useRef(0),
                        {
                            pagesRouter: s
                        } = u(),
                        {
                            session: c,
                            isLoaded: d
                        } = (0, n.kP)();
                    (0, o.rx)() || a.useEffect(() => {
                        if (!d || r && "path" !== r || l && !c) return;
                        let n = new AbortController,
                            a = () => {
                                let r = s ? `${t}/[[...index]].tsx` : `${t}/[[...rest]]/page.tsx`;
                                throw Error(`
Clerk: The <${e}/> component is not configured correctly. The most likely reasons for this error are:

1. The "${t}" route is not a catch-all route.
It is recommended to convert this route to a catch-all route, eg: "${r}". Alternatively, you can update the <${e}/> component to use hash-based routing by setting the "routing" prop to "hash".

2. The <${e}/> component is mounted in a catch-all route, but all routes under "${t}" are protected by the middleware.
To resolve this, ensure that the middleware does not protect the catch-all route or any of its children. If you are using the "createRouteMatcher" helper, consider adding "(.*)" to the end of the route pattern, eg: "${t}(.*)". For more information, see: https://clerk.com/docs/references/nextjs/clerk-middleware#create-route-matcher
`)
                            };
                        return s ? s.pathname.match(/\[\[\.\.\..+]]/) || a() : (async () => {
                            let t;
                            if (i.current++, !(i.current > 1)) {
                                try {
                                    let r = `${window.location.origin}${window.location.pathname}/${e}_clerk_catchall_check_${Date.now()}`;
                                    t = await fetch(r, {
                                        signal: n.signal
                                    })
                                } catch (e) {}(null == t ? void 0 : t.status) === 404 && a()
                            }
                        })(), () => {
                            i.current > 1 && n.abort()
                        }
                    }, [d])
                },
                c = () => {
                    let e = a.useRef(),
                        {
                            pagesRouter: t
                        } = u();
                    if (t) return e.current || (e.current = t.pathname.replace(/\/\[\[\.\.\..*/, "")), e.current;
                    let n = r(47576).usePathname,
                        l = r(47576).useParams,
                        o = (n() || "").split("/").filter(Boolean),
                        i = Object.values(l() || {}).filter(e => Array.isArray(e)).flat(1 / 0);
                    return e.current || (e.current = `/${o.slice(0,o.length-i.length).join("/")}`), e.current
                };

            function d(e, t, r = !0) {
                let n = c(),
                    a = (0, l.EJ)(e, t, {
                        path: n
                    });
                return s(e, n, a.routing, r), a
            }
            let f = Object.assign(e => a.createElement(n.Iw, { ...d("UserProfile", e)
                }), { ...n.Iw
                }),
                p = e => a.createElement(n.Gp, { ...d("CreateOrganization", e)
                }),
                h = Object.assign(e => a.createElement(n.A, { ...d("OrganizationProfile", e)
                }), { ...n.A
                }),
                y = e => a.createElement(n.cL, { ...d("SignIn", e, !1)
                }),
                g = e => a.createElement(n.Mo, { ...d("SignUp", e, !1)
                })
        },
        86384: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("Bookmark", [
                ["path", {
                    d: "m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",
                    key: "1fy3hk"
                }]
            ])
        },
        68019: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("CircleHelp", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
                    key: "1u773s"
                }],
                ["path", {
                    d: "M12 17h.01",
                    key: "p32p05"
                }]
            ])
        },
        2402: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("LogOut", [
                ["path", {
                    d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
                    key: "1uf3rs"
                }],
                ["polyline", {
                    points: "16 17 21 12 16 7",
                    key: "1gabdz"
                }],
                ["line", {
                    x1: "21",
                    x2: "9",
                    y1: "12",
                    y2: "12",
                    key: "1uyos4"
                }]
            ])
        },
        1481: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("Menu", [
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "12",
                    y2: "12",
                    key: "1e0a9i"
                }],
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "6",
                    y2: "6",
                    key: "1owob3"
                }],
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "18",
                    y2: "18",
                    key: "yk5zj1"
                }]
            ])
        },
        26268: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("Minus", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }]
            ])
        },
        75014: (e, t, r) => {
            r.d(t, {
                Z: () => n
            });
            let n = (0, r(66127).Z)("User", [
                ["path", {
                    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
                    key: "975kel"
                }],
                ["circle", {
                    cx: "12",
                    cy: "7",
                    r: "4",
                    key: "17ys0d"
                }]
            ])
        },
        66921: (e, t, r) => {
            var n = r(66707);
            r.o(n, "useCurrentLocale") && r.d(t, {
                useCurrentLocale: function() {
                    return n.useCurrentLocale
                }
            })
        },
        66707: function(e, t, r) {
            var n = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useCurrentLocale = void 0;
            let a = n(r(98335));
            t.useCurrentLocale = a.default
        },
        98335: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let n = r(47576),
                a = (e, t) => {
                    let r = t.split("; ");
                    for (let t = 0; t < r.length; t++) {
                        let n = r[t].split("=");
                        if (n[0] === e) return n[1]
                    }
                    return null
                };
            t.default = (e, t) => {
                let {
                    basePath: r = "",
                    locales: l
                } = e;
                if (t || "undefined" == typeof window || (t = document.cookie), t) {
                    let r = a(e.localeCookie || "NEXT_LOCALE", t);
                    if (r && l.includes(r)) return r
                }
                if (e.noPrefix) return e.defaultLocale;
                let o = (0, n.usePathname)();
                return l.find(e => {
                    let t = r.replace(/\/$/, "");
                    return "undefined" == typeof window && (t = ""), o === "".concat(t, "/").concat(e) || o.startsWith("".concat(t, "/").concat(e, "/"))
                }) || (e.prefixDefault ? void 0 : e.defaultLocale)
            }
        },
        88480: (e, t, r) => {
            r.d(t, {
                default: () => a.a
            });
            var n = r(9998),
                a = r.n(n)
        },
        9998: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return a
                }
            });
            let n = r(81838)._(r(41718));

            function a(e, t) {
                var r;
                let a = {};
                "function" == typeof e && (a.loader = e);
                let l = { ...a,
                    ...t
                };
                return (0, n.default)({ ...l,
                    modules: null == (r = l.loadableGenerated) ? void 0 : r.modules
                })
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        50606: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "BailoutToCSR", {
                enumerable: !0,
                get: function() {
                    return a
                }
            });
            let n = r(90484);

            function a(e) {
                let {
                    reason: t,
                    children: r
                } = e;
                if ("undefined" == typeof window) throw new n.BailoutToCSRError(t);
                return r
            }
        },
        41718: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = r(12428),
                a = r(93264),
                l = r(50606),
                o = r(40913);

            function i(e) {
                return {
                    default: e && "default" in e ? e.default : e
                }
            }
            let u = {
                    loader: () => Promise.resolve(i(() => null)),
                    loading: null,
                    ssr: !0
                },
                s = function(e) {
                    let t = { ...u,
                            ...e
                        },
                        r = (0, a.lazy)(() => t.loader().then(i)),
                        s = t.loading;

                    function c(e) {
                        let i = s ? (0, n.jsx)(s, {
                                isLoading: !0,
                                pastDelay: !0,
                                error: null
                            }) : null,
                            u = !t.ssr || !!t.loading,
                            c = u ? a.Suspense : a.Fragment,
                            d = t.ssr ? (0, n.jsxs)(n.Fragment, {
                                children: ["undefined" == typeof window ? (0, n.jsx)(o.PreloadChunks, {
                                    moduleIds: t.modules
                                }) : null, (0, n.jsx)(r, { ...e
                                })]
                            }) : (0, n.jsx)(l.BailoutToCSR, {
                                reason: "next/dynamic",
                                children: (0, n.jsx)(r, { ...e
                                })
                            });
                        return (0, n.jsx)(c, { ...u ? {
                                fallback: i
                            } : {},
                            children: d
                        })
                    }
                    return c.displayName = "LoadableComponent", c
                }
        },
        40913: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "PreloadChunks", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            let n = r(12428),
                a = r(36720),
                l = r(7425),
                o = r(17730);

            function i(e) {
                let {
                    moduleIds: t
                } = e;
                if ("undefined" != typeof window) return null;
                let r = l.workAsyncStorage.getStore();
                if (void 0 === r) return null;
                let i = [];
                if (r.reactLoadableManifest && t) {
                    let e = r.reactLoadableManifest;
                    for (let r of t) {
                        if (!e[r]) continue;
                        let t = e[r].files;
                        i.push(...t)
                    }
                }
                return 0 === i.length ? null : (0, n.jsx)(n.Fragment, {
                    children: i.map(e => {
                        let t = r.assetPrefix + "/_next/" + (0, o.encodeURIPath)(e);
                        return e.endsWith(".css") ? (0, n.jsx)("link", {
                            precedence: "dynamic",
                            href: t,
                            rel: "stylesheet",
                            as: "style"
                        }, e) : ((0, a.preload)(t, {
                            as: "script",
                            fetchPriority: "low"
                        }), null)
                    })
                })
            }
        },
        32840: (e, t, r) => {
            r.d(t, {
                $j: () => N,
                Dx: () => I,
                VY: () => $,
                aU: () => E,
                aV: () => S,
                dk: () => z,
                fC: () => D,
                h_: () => L,
                xz: () => R
            });
            var n = r(93264),
                a = r(34500),
                l = r(99385),
                o = r(45258),
                i = r(69933),
                u = r(8190),
                s = r(12428),
                c = "AlertDialog",
                [d, f] = (0, a.b)(c, [o.p8]),
                p = (0, o.p8)(),
                h = e => {
                    let {
                        __scopeAlertDialog: t,
                        ...r
                    } = e, n = p(t);
                    return (0, s.jsx)(o.fC, { ...n,
                        ...r,
                        modal: !0
                    })
                };
            h.displayName = c;
            var y = n.forwardRef((e, t) => {
                let {
                    __scopeAlertDialog: r,
                    ...n
                } = e, a = p(r);
                return (0, s.jsx)(o.xz, { ...a,
                    ...n,
                    ref: t
                })
            });
            y.displayName = "AlertDialogTrigger";
            var g = e => {
                let {
                    __scopeAlertDialog: t,
                    ...r
                } = e, n = p(t);
                return (0, s.jsx)(o.h_, { ...n,
                    ...r
                })
            };
            g.displayName = "AlertDialogPortal";
            var m = n.forwardRef((e, t) => {
                let {
                    __scopeAlertDialog: r,
                    ...n
                } = e, a = p(r);
                return (0, s.jsx)(o.aV, { ...a,
                    ...n,
                    ref: t
                })
            });
            m.displayName = "AlertDialogOverlay";
            var v = "AlertDialogContent",
                [x, b] = d(v),
                j = n.forwardRef((e, t) => {
                    let {
                        __scopeAlertDialog: r,
                        children: a,
                        ...c
                    } = e, d = p(r), f = n.useRef(null), h = (0, l.e)(t, f), y = n.useRef(null);
                    return (0, s.jsx)(o.jm, {
                        contentName: v,
                        titleName: w,
                        docsSlug: "alert-dialog",
                        children: (0, s.jsx)(x, {
                            scope: r,
                            cancelRef: y,
                            children: (0, s.jsxs)(o.VY, {
                                role: "alertdialog",
                                ...d,
                                ...c,
                                ref: h,
                                onOpenAutoFocus: (0, i.M)(c.onOpenAutoFocus, e => {
                                    var t;
                                    e.preventDefault(), null === (t = y.current) || void 0 === t || t.focus({
                                        preventScroll: !0
                                    })
                                }),
                                onPointerDownOutside: e => e.preventDefault(),
                                onInteractOutside: e => e.preventDefault(),
                                children: [(0, s.jsx)(u.A4, {
                                    children: a
                                }), (0, s.jsx)(M, {
                                    contentRef: f
                                })]
                            })
                        })
                    })
                });
            j.displayName = v;
            var w = "AlertDialogTitle",
                k = n.forwardRef((e, t) => {
                    let {
                        __scopeAlertDialog: r,
                        ...n
                    } = e, a = p(r);
                    return (0, s.jsx)(o.Dx, { ...a,
                        ...n,
                        ref: t
                    })
                });
            k.displayName = w;
            var _ = "AlertDialogDescription",
                O = n.forwardRef((e, t) => {
                    let {
                        __scopeAlertDialog: r,
                        ...n
                    } = e, a = p(r);
                    return (0, s.jsx)(o.dk, { ...a,
                        ...n,
                        ref: t
                    })
                });
            O.displayName = _;
            var P = n.forwardRef((e, t) => {
                let {
                    __scopeAlertDialog: r,
                    ...n
                } = e, a = p(r);
                return (0, s.jsx)(o.x8, { ...a,
                    ...n,
                    ref: t
                })
            });
            P.displayName = "AlertDialogAction";
            var A = "AlertDialogCancel",
                C = n.forwardRef((e, t) => {
                    let {
                        __scopeAlertDialog: r,
                        ...n
                    } = e, {
                        cancelRef: a
                    } = b(A, r), i = p(r), u = (0, l.e)(t, a);
                    return (0, s.jsx)(o.x8, { ...i,
                        ...n,
                        ref: u
                    })
                });
            C.displayName = A;
            var M = e => {
                    let {
                        contentRef: t
                    } = e, r = "`".concat(v, "` requires a description for the component to be accessible for screen reader users.\n\nYou can add a description to the `").concat(v, "` by passing a `").concat(_, "` component as a child, which also benefits sighted users by adding visible context to the dialog.\n\nAlternatively, you can use your own component as a description by assigning it an `id` and passing the same value to the `aria-describedby` prop in `").concat(v, "`. If the description is confusing or duplicative for sighted users, you can use the `@radix-ui/react-visually-hidden` primitive as a wrapper around your description component.\n\nFor more information, see https://radix-ui.com/primitives/docs/components/alert-dialog");
                    return n.useEffect(() => {
                        var e;
                        document.getElementById(null === (e = t.current) || void 0 === e ? void 0 : e.getAttribute("aria-describedby")) || console.warn(r)
                    }, [r, t]), null
                },
                D = h,
                R = y,
                L = g,
                S = m,
                $ = j,
                E = P,
                N = C,
                I = k,
                z = O
        }
    }
]);