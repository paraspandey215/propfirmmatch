"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7698], {
        40850: (a, o, e) => {
            e.d(o, {
                dc: () => r,
                uv: () => p,
                zx: () => A
            });
            var i = e(12428),
                s = e(8190),
                l = e(51699),
                n = e(93264),
                h = e(62993);
            let r = (0, l.j)("inline-flex items-center cursor-pointer justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:bg-dark-disabled disabled:border disabled:text-foreground-disabled disabled:border-border-disabled", {
                    variants: {
                        variant: {
                            default: "bg-primary-theme border-primary-theme text-primary-theme-foreground border hover:bg-primary-hover hover:border-primary-hover focus:bg-primary-focus focus:border-primary-focus",
                            primary: "bg-primary-theme border-primary-theme text-primary-theme-foreground border hover:bg-primary-hover hover:border-primary-hover focus:bg-primary-focus focus:border-primary-focus",
                            dark: "bg-dark text-foreground hover:bg-dark-hover focus:bg-dark-focus disabled:border-0",
                            darkActive: "bg-background-contrast text-foreground-contrast",
                            green: "bg-green-theme text-foreground hover:bg-green-hover focus:bg-green-focus disabled:border-0",
                            white: "bg-white text-black hover:bg-primary-theme disabled:border-0 hover:text-primary-theme-foreground focus:bg-primary-theme focus:border-primary-focus focus:text-white",
                            red: "bg-red-theme text-foreground hover:bg-red-hover focus:bg-red-focus disabled:border-0",
                            primaryOutline: "border border-primary-theme text-primary-theme hover:bg-primary-hover hover:border-primary-hover hover:text-foreground focus:bg-primary-focus focus:border-primary-focus focus:text-foreground",
                            darkOutline: "border border-dark text-foreground hover:bg-dark-hover hover:border-dark-hover hover:text-foreground focus:bg-dark-focus focus:border-dark-focus focus:text-foreground",
                            greenOutline: "border border-green-theme text-green-theme hover:bg-green-hover hover:border-green-hover hover:text-foreground focus:bg-green-focus focus:border-green-focus focus:text-foreground",
                            redOutline: "border border-red-theme text-red-theme hover:bg-red-hover hover:border-red-hover hover:text-foreground focus:bg-red-focus focus:border-red-focus focus:text-foreground",
                            blueOutline: "border border-blue-theme text-white hover:bg-blue-theme hover:border-blue-theme hover:text-foreground focus:bg-blue-theme focus:border-blue-theme focus:text-foreground",
                            alternativeOutline: "border border-alternative text-foreground hover:bg-alternative-hover hover:text-foreground-contrast focus:bg-background-contrast focus:text-foreground-contrast",
                            alternativeDarkOutline: "border border-dark text-foreground hover:bg-dark-hover hover:border-dark hover:text-foreground focus:bg-dark-focus focus:border-dark-focus focus:text-foreground",
                            pfmGradient: "text-foreground text-sm bg-[image:var(--pfm-gradient)] hover:opacity-90 disabled:text-foreground-disabled disabled:bg-background-secondary disabled:bg-none border-none transition-all",
                            pfmBlueGradient: "text-foreground text-sm bg-[image:var(--pfm-blue-gradient)] hover:opacity-90 disabled:text-foreground-disabled disabled:bg-background-secondary disabled:bg-none border-none transition-all",
                            pfmLink: "text-primary-theme underline-offset-4 hover:underline hover:text-primary-hover",
                            pfmPurpleLink: "text-purple-theme underline-offset-4 hover:underline hover:text-purple-hover",
                            destructive: "bg-red-theme text-foreground hover:bg-red-hover focus:bg-red-focus disabled:border-0",
                            secondary: "bg-dark text-foreground hover:bg-dark-hover focus:bg-dark-focus disabled:border-0",
                            outline: "border border-dark text-foreground hover:bg-dark-hover hover:border-dark-hover hover:text-foreground focus:bg-dark-focus focus:border-dark-focus focus:text-foreground",
                            destructiveOutline: "border border-red-theme text-red-theme hover:bg-red-hover hover:border-red-hover hover:text-foreground focus:bg-red-focus focus:border-red-focus focus:text-foreground",
                            ghost: "hover:bg-background-secondary",
                            link: "text-primary-theme underline-offset-4 hover:underline"
                        },
                        size: {
                            "2xs": "h-6.5 px-3 text-xs [&_svg]:w-3 [&_svg]:h-3",
                            xs: "h-8 md:h-8.5 px-2 md:px-3 text-[9px] md:text-xs [&_svg]:w-3 [&_svg]:h-3",
                            sm: "h-9 px-3 [&_svg]:w-3 [&_svg]:h-3",
                            default: "h-10 px-5 py-2 [&_svg]:w-3.5 [&_svg]:h-3.5",
                            lg: "h-12 px-5 [&_svg]:w-4 [&_svg]:h-4",
                            xl: "h-13 px-6 [&_svg]:w-5 [&_svg]:h-5",
                            icon2Xs: "size-4 rounded-sm",
                            iconXs: "size-5 p-1",
                            iconSm: "size-7 p-2",
                            icon: "size-8.5 p-2.5",
                            iconLg: "size-10 p-3",
                            iconXl: "size-11 p-3.5"
                        },
                        rounded: {
                            default: "rounded-md",
                            full: "rounded-full"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default",
                        rounded: "default"
                    }
                }),
                A = n.forwardRef((a, o) => {
                    let {
                        className: e,
                        variant: l,
                        size: n,
                        rounded: A,
                        asChild: p = !1,
                        children: m,
                        ...t
                    } = a, d = p ? s.g7 : "button";
                    return (0, i.jsx)(d, {
                        className: (0, h.cn)(r({
                            variant: l,
                            size: n,
                            rounded: A,
                            className: e
                        })),
                        ref: o,
                        ...t,
                        children: m
                    })
                });

            function p(a) {
                return (0, i.jsx)("span", {
                    className: (0, h.cn)("mr-2", a.className),
                    children: a.children
                })
            }
            A.displayName = "Button"
        },
        62993: (a, o, e) => {
            e.d(o, {
                cn: () => l
            });
            var i = e(44273),
                s = e(99211);

            function l() {
                for (var a = arguments.length, o = Array(a), e = 0; e < a; e++) o[e] = arguments[e];
                return (0, s.m6)((0, i.W)(o))
            }
        },
        32029: (a, o, e) => {
            function i(a) {
                throw Error("Unexpected value: " + JSON.stringify(a))
            }
            e.d(o, {
                Mf: () => A,
                $Y: () => s,
                Mk: () => n,
                Dp: () => c,
                sh: () => p,
                vE: () => i,
                uf: () => h,
                mv: () => l,
                jq: () => t,
                gH: () => d,
                eq: () => u,
                _G: () => b
            });
            let s = [{
                name: "Afghanistan",
                isoAlpha3: "AFG",
                isoAlpha2: "AF"
            }, {
                name: "\xc5land Islands",
                isoAlpha3: "ALA",
                isoAlpha2: "AX"
            }, {
                name: "Albania",
                isoAlpha3: "ALB",
                isoAlpha2: "AL"
            }, {
                name: "Algeria",
                isoAlpha3: "DZA",
                isoAlpha2: "DZ"
            }, {
                name: "American Samoa",
                isoAlpha3: "ASM",
                isoAlpha2: "AS"
            }, {
                name: "Andorra",
                isoAlpha3: "AND",
                isoAlpha2: "AD"
            }, {
                name: "Angola",
                isoAlpha3: "AGO",
                isoAlpha2: "AO"
            }, {
                name: "Anguilla",
                isoAlpha3: "AIA",
                isoAlpha2: "AI"
            }, {
                name: "Antarctica",
                isoAlpha3: "ATA",
                isoAlpha2: "AQ"
            }, {
                name: "Antigua and Barbuda",
                isoAlpha3: "ATG",
                isoAlpha2: "AG"
            }, {
                name: "Argentina",
                isoAlpha3: "ARG",
                isoAlpha2: "AR"
            }, {
                name: "Armenia",
                isoAlpha3: "ARM",
                isoAlpha2: "AM"
            }, {
                name: "Aruba",
                isoAlpha3: "ABW",
                isoAlpha2: "AW"
            }, {
                name: "Australia",
                isoAlpha3: "AUS",
                isoAlpha2: "AU"
            }, {
                name: "Austria",
                isoAlpha3: "AUT",
                isoAlpha2: "AT"
            }, {
                name: "Azerbaijan",
                isoAlpha3: "AZE",
                isoAlpha2: "AZ"
            }, {
                name: "Bahamas",
                isoAlpha3: "BHS",
                isoAlpha2: "BS"
            }, {
                name: "Bahrain",
                isoAlpha3: "BHR",
                isoAlpha2: "BH"
            }, {
                name: "Bangladesh",
                isoAlpha3: "BGD",
                isoAlpha2: "BD"
            }, {
                name: "Barbados",
                isoAlpha3: "BRB",
                isoAlpha2: "BB"
            }, {
                name: "Belarus",
                isoAlpha3: "BLR",
                isoAlpha2: "BY"
            }, {
                name: "Belgium",
                isoAlpha3: "BEL",
                isoAlpha2: "BE"
            }, {
                name: "Belize",
                isoAlpha3: "BLZ",
                isoAlpha2: "BZ"
            }, {
                name: "Benin",
                isoAlpha3: "BEN",
                isoAlpha2: "BJ"
            }, {
                name: "Bermuda",
                isoAlpha3: "BMU",
                isoAlpha2: "BM"
            }, {
                name: "Bhutan",
                isoAlpha3: "BTN",
                isoAlpha2: "BT"
            }, {
                name: "Bolivia, Plurinational State of",
                isoAlpha3: "BOL",
                isoAlpha2: "BO"
            }, {
                name: "Bonaire, Sint Eustatius and Saba",
                isoAlpha3: "BES",
                isoAlpha2: "BQ"
            }, {
                name: "Bosnia and Herzegovina",
                isoAlpha3: "BIH",
                isoAlpha2: "BA"
            }, {
                name: "Botswana",
                isoAlpha3: "BWA",
                isoAlpha2: "BW"
            }, {
                name: "Bouvet Island",
                isoAlpha3: "BVT",
                isoAlpha2: "BV"
            }, {
                name: "Brazil",
                isoAlpha3: "BRA",
                isoAlpha2: "BR"
            }, {
                name: "British Indian Ocean Territory",
                isoAlpha3: "IOT",
                isoAlpha2: "IO"
            }, {
                name: "Brunei Darussalam",
                isoAlpha3: "BRN",
                isoAlpha2: "BN"
            }, {
                name: "Bulgaria",
                isoAlpha3: "BGR",
                isoAlpha2: "BG"
            }, {
                name: "Burkina Faso",
                isoAlpha3: "BFA",
                isoAlpha2: "BF"
            }, {
                name: "Burundi",
                isoAlpha3: "BDI",
                isoAlpha2: "BI"
            }, {
                name: "Cabo Verde",
                isoAlpha3: "CPV",
                isoAlpha2: "CV"
            }, {
                name: "Cambodia",
                isoAlpha3: "KHM",
                isoAlpha2: "KH"
            }, {
                name: "Cameroon",
                isoAlpha3: "CMR",
                isoAlpha2: "CM"
            }, {
                name: "Canada",
                isoAlpha3: "CAN",
                isoAlpha2: "CA"
            }, {
                name: "Cayman Islands",
                isoAlpha3: "CYM",
                isoAlpha2: "KY"
            }, {
                name: "Central African Republic",
                isoAlpha3: "CAF",
                isoAlpha2: "CF"
            }, {
                name: "Chad",
                isoAlpha3: "TCD",
                isoAlpha2: "TD"
            }, {
                name: "Chile",
                isoAlpha3: "CHL",
                isoAlpha2: "CL"
            }, {
                name: "China",
                isoAlpha3: "CHN",
                isoAlpha2: "CN"
            }, {
                name: "Christmas Island",
                isoAlpha3: "CXR",
                isoAlpha2: "CX"
            }, {
                name: "Cocos (Keeling) Islands",
                isoAlpha3: "CCK",
                isoAlpha2: "CC"
            }, {
                name: "Colombia",
                isoAlpha3: "COL",
                isoAlpha2: "CO"
            }, {
                name: "Comoros",
                isoAlpha3: "COM",
                isoAlpha2: "KM"
            }, {
                name: "Congo, Democratic Republic of the",
                isoAlpha3: "COD",
                isoAlpha2: "CD"
            }, {
                name: "Congo",
                isoAlpha3: "COG",
                isoAlpha2: "CG"
            }, {
                name: "Cook Islands",
                isoAlpha3: "COK",
                isoAlpha2: "CK"
            }, {
                name: "Costa Rica",
                isoAlpha3: "CRI",
                isoAlpha2: "CR"
            }, {
                name: "C\xf4te d'Ivoire",
                isoAlpha3: "CIV",
                isoAlpha2: "CI"
            }, {
                name: "Croatia",
                isoAlpha3: "HRV",
                isoAlpha2: "HR"
            }, {
                name: "Cuba",
                isoAlpha3: "CUB",
                isoAlpha2: "CU"
            }, {
                name: "Cura\xe7ao",
                isoAlpha3: "CUW",
                isoAlpha2: "CW"
            }, {
                name: "Cyprus",
                isoAlpha3: "CYP",
                isoAlpha2: "CY"
            }, {
                name: "Czechia",
                isoAlpha3: "CZE",
                isoAlpha2: "CZ"
            }, {
                name: "Denmark",
                isoAlpha3: "DNK",
                isoAlpha2: "DK"
            }, {
                name: "Djibouti",
                isoAlpha3: "DJI",
                isoAlpha2: "DJ"
            }, {
                name: "Dominica",
                isoAlpha3: "DMA",
                isoAlpha2: "DM"
            }, {
                name: "Dominican Republic",
                isoAlpha3: "DOM",
                isoAlpha2: "DO"
            }, {
                name: "Ecuador",
                isoAlpha3: "ECU",
                isoAlpha2: "EC"
            }, {
                name: "Egypt",
                isoAlpha3: "EGY",
                isoAlpha2: "EG"
            }, {
                name: "El Salvador",
                isoAlpha3: "SLV",
                isoAlpha2: "SV"
            }, {
                name: "Equatorial Guinea",
                isoAlpha3: "GNQ",
                isoAlpha2: "GQ"
            }, {
                name: "Eritrea",
                isoAlpha3: "ERI",
                isoAlpha2: "ER"
            }, {
                name: "Estonia",
                isoAlpha3: "EST",
                isoAlpha2: "EE"
            }, {
                name: "Eswatini",
                isoAlpha3: "SWZ",
                isoAlpha2: "SZ"
            }, {
                name: "Ethiopia",
                isoAlpha3: "ETH",
                isoAlpha2: "ET"
            }, {
                name: "Falkland Islands (Malvinas)",
                isoAlpha3: "FLK",
                isoAlpha2: "FK"
            }, {
                name: "Faroe Islands",
                isoAlpha3: "FRO",
                isoAlpha2: "FO"
            }, {
                name: "Fiji",
                isoAlpha3: "FJI",
                isoAlpha2: "FJ"
            }, {
                name: "Finland",
                isoAlpha3: "FIN",
                isoAlpha2: "FI"
            }, {
                name: "France",
                isoAlpha3: "FRA",
                isoAlpha2: "FR"
            }, {
                name: "French Guiana",
                isoAlpha3: "GUF",
                isoAlpha2: "GF"
            }, {
                name: "French Polynesia",
                isoAlpha3: "PYF",
                isoAlpha2: "PF"
            }, {
                name: "French Southern Territories",
                isoAlpha3: "ATF",
                isoAlpha2: "TF"
            }, {
                name: "Gabon",
                isoAlpha3: "GAB",
                isoAlpha2: "GA"
            }, {
                name: "Gambia",
                isoAlpha3: "GMB",
                isoAlpha2: "GM"
            }, {
                name: "Georgia",
                isoAlpha3: "GEO",
                isoAlpha2: "GE"
            }, {
                name: "Germany",
                isoAlpha3: "DEU",
                isoAlpha2: "DE"
            }, {
                name: "Ghana",
                isoAlpha3: "GHA",
                isoAlpha2: "GH"
            }, {
                name: "Gibraltar",
                isoAlpha3: "GIB",
                isoAlpha2: "GI"
            }, {
                name: "Greece",
                isoAlpha3: "GRC",
                isoAlpha2: "GR"
            }, {
                name: "Greenland",
                isoAlpha3: "GRL",
                isoAlpha2: "GL"
            }, {
                name: "Grenada",
                isoAlpha3: "GRD",
                isoAlpha2: "GD"
            }, {
                name: "Guadeloupe",
                isoAlpha3: "GLP",
                isoAlpha2: "GP"
            }, {
                name: "Guam",
                isoAlpha3: "GUM",
                isoAlpha2: "GU"
            }, {
                name: "Guatemala",
                isoAlpha3: "GTM",
                isoAlpha2: "GT"
            }, {
                name: "Guernsey",
                isoAlpha3: "GGY",
                isoAlpha2: "GG"
            }, {
                name: "Guinea-Bissau",
                isoAlpha3: "GNB",
                isoAlpha2: "GW"
            }, {
                name: "Guinea",
                isoAlpha3: "GIN",
                isoAlpha2: "GN"
            }, {
                name: "Guyana",
                isoAlpha3: "GUY",
                isoAlpha2: "GY"
            }, {
                name: "Haiti",
                isoAlpha3: "HTI",
                isoAlpha2: "HT"
            }, {
                name: "Heard Island and McDonald Islands",
                isoAlpha3: "HMD",
                isoAlpha2: "HM"
            }, {
                name: "Holy See",
                isoAlpha3: "VAT",
                isoAlpha2: "VA"
            }, {
                name: "Honduras",
                isoAlpha3: "HND",
                isoAlpha2: "HN"
            }, {
                name: "Hong Kong",
                isoAlpha3: "HKG",
                isoAlpha2: "HK"
            }, {
                name: "Hungary",
                isoAlpha3: "HUN",
                isoAlpha2: "HU"
            }, {
                name: "Iceland",
                isoAlpha3: "ISL",
                isoAlpha2: "IS"
            }, {
                name: "India",
                isoAlpha3: "IND",
                isoAlpha2: "IN"
            }, {
                name: "Indonesia",
                isoAlpha3: "IDN",
                isoAlpha2: "ID"
            }, {
                name: "Iran",
                isoAlpha3: "IRN",
                isoAlpha2: "IR"
            }, {
                name: "Iraq",
                isoAlpha3: "IRQ",
                isoAlpha2: "IQ"
            }, {
                name: "Ireland",
                isoAlpha3: "IRL",
                isoAlpha2: "IE"
            }, {
                name: "Isle of Man",
                isoAlpha3: "IMN",
                isoAlpha2: "IM"
            }, {
                name: "Israel",
                isoAlpha3: "ISR",
                isoAlpha2: "IL"
            }, {
                name: "Italy",
                isoAlpha3: "ITA",
                isoAlpha2: "IT"
            }, {
                name: "Jamaica",
                isoAlpha3: "JAM",
                isoAlpha2: "JM"
            }, {
                name: "Japan",
                isoAlpha3: "JPN",
                isoAlpha2: "JP"
            }, {
                name: "Jersey",
                isoAlpha3: "JEY",
                isoAlpha2: "JE"
            }, {
                name: "Jordan",
                isoAlpha3: "JOR",
                isoAlpha2: "JO"
            }, {
                name: "Kazakhstan",
                isoAlpha3: "KAZ",
                isoAlpha2: "KZ"
            }, {
                name: "Kenya",
                isoAlpha3: "KEN",
                isoAlpha2: "KE"
            }, {
                name: "Kiribati",
                isoAlpha3: "KIR",
                isoAlpha2: "KI"
            }, {
                name: "Korea, Democratic People's Republic of",
                isoAlpha3: "PRK",
                isoAlpha2: "KP"
            }, {
                name: "Korea, Republic of",
                isoAlpha3: "KOR",
                isoAlpha2: "KR"
            }, {
                name: "Kuwait",
                isoAlpha3: "KWT",
                isoAlpha2: "KW"
            }, {
                name: "Kyrgyzstan",
                isoAlpha3: "KGZ",
                isoAlpha2: "KG"
            }, {
                name: "Lao People's Democratic Republic",
                isoAlpha3: "LAO",
                isoAlpha2: "LA"
            }, {
                name: "Latvia",
                isoAlpha3: "LVA",
                isoAlpha2: "LV"
            }, {
                name: "Lebanon",
                isoAlpha3: "LBN",
                isoAlpha2: "LB"
            }, {
                name: "Lesotho",
                isoAlpha3: "LSO",
                isoAlpha2: "LS"
            }, {
                name: "Liberia",
                isoAlpha3: "LBR",
                isoAlpha2: "LR"
            }, {
                name: "Libya",
                isoAlpha3: "LBY",
                isoAlpha2: "LY"
            }, {
                name: "Liechtenstein",
                isoAlpha3: "LIE",
                isoAlpha2: "LI"
            }, {
                name: "Lithuania",
                isoAlpha3: "LTU",
                isoAlpha2: "LT"
            }, {
                name: "Luxembourg",
                isoAlpha3: "LUX",
                isoAlpha2: "LU"
            }, {
                name: "Macao",
                isoAlpha3: "MAC",
                isoAlpha2: "MO"
            }, {
                name: "Madagascar",
                isoAlpha3: "MDG",
                isoAlpha2: "MG"
            }, {
                name: "Malawi",
                isoAlpha3: "MWI",
                isoAlpha2: "MW"
            }, {
                name: "Malaysia",
                isoAlpha3: "MYS",
                isoAlpha2: "MY"
            }, {
                name: "Maldives",
                isoAlpha3: "MDV",
                isoAlpha2: "MV"
            }, {
                name: "Mali",
                isoAlpha3: "MLI",
                isoAlpha2: "ML"
            }, {
                name: "Malta",
                isoAlpha3: "MLT",
                isoAlpha2: "MT"
            }, {
                name: "Marshall Islands",
                isoAlpha3: "MHL",
                isoAlpha2: "MH"
            }, {
                name: "Martinique",
                isoAlpha3: "MTQ",
                isoAlpha2: "MQ"
            }, {
                name: "Mauritania",
                isoAlpha3: "MRT",
                isoAlpha2: "MR"
            }, {
                name: "Mauritius",
                isoAlpha3: "MUS",
                isoAlpha2: "MU"
            }, {
                name: "Mayotte",
                isoAlpha3: "MYT",
                isoAlpha2: "YT"
            }, {
                name: "Mexico",
                isoAlpha3: "MEX",
                isoAlpha2: "MX"
            }, {
                name: "Micronesia, Federated States of",
                isoAlpha3: "FSM",
                isoAlpha2: "FM"
            }, {
                name: "Moldova, Republic of",
                isoAlpha3: "MDA",
                isoAlpha2: "MD"
            }, {
                name: "Monaco",
                isoAlpha3: "MCO",
                isoAlpha2: "MC"
            }, {
                name: "Mongolia",
                isoAlpha3: "MNG",
                isoAlpha2: "MN"
            }, {
                name: "Montenegro",
                isoAlpha3: "MNE",
                isoAlpha2: "ME"
            }, {
                name: "Montserrat",
                isoAlpha3: "MSR",
                isoAlpha2: "MS"
            }, {
                name: "Morocco",
                isoAlpha3: "MAR",
                isoAlpha2: "MA"
            }, {
                name: "Mozambique",
                isoAlpha3: "MOZ",
                isoAlpha2: "MZ"
            }, {
                name: "Myanmar",
                isoAlpha3: "MMR",
                isoAlpha2: "MM"
            }, {
                name: "Namibia",
                isoAlpha3: "NAM",
                isoAlpha2: "NA"
            }, {
                name: "Nauru",
                isoAlpha3: "NRU",
                isoAlpha2: "NR"
            }, {
                name: "Nepal",
                isoAlpha3: "NPL",
                isoAlpha2: "NP"
            }, {
                name: "Netherlands, Kingdom of the",
                isoAlpha3: "NLD",
                isoAlpha2: "NL"
            }, {
                name: "New Caledonia",
                isoAlpha3: "NCL",
                isoAlpha2: "NC"
            }, {
                name: "New Zealand",
                isoAlpha3: "NZL",
                isoAlpha2: "NZ"
            }, {
                name: "Nicaragua",
                isoAlpha3: "NIC",
                isoAlpha2: "NI"
            }, {
                name: "Niger",
                isoAlpha3: "NER",
                isoAlpha2: "NE"
            }, {
                name: "Nigeria",
                isoAlpha3: "NGA",
                isoAlpha2: "NG"
            }, {
                name: "Niue",
                isoAlpha3: "NIU",
                isoAlpha2: "NU"
            }, {
                name: "Norfolk Island",
                isoAlpha3: "NFK",
                isoAlpha2: "NF"
            }, {
                name: "North Macedonia",
                isoAlpha3: "MKD",
                isoAlpha2: "MK"
            }, {
                name: "Northern Mariana Islands",
                isoAlpha3: "MNP",
                isoAlpha2: "MP"
            }, {
                name: "Norway",
                isoAlpha3: "NOR",
                isoAlpha2: "NO"
            }, {
                name: "Oman",
                isoAlpha3: "OMN",
                isoAlpha2: "OM"
            }, {
                name: "Pakistan",
                isoAlpha3: "PAK",
                isoAlpha2: "PK"
            }, {
                name: "Palau",
                isoAlpha3: "PLW",
                isoAlpha2: "PW"
            }, {
                name: "Palestine, State of",
                isoAlpha3: "PSE",
                isoAlpha2: "PS"
            }, {
                name: "Panama",
                isoAlpha3: "PAN",
                isoAlpha2: "PA"
            }, {
                name: "Papua New Guinea",
                isoAlpha3: "PNG",
                isoAlpha2: "PG"
            }, {
                name: "Paraguay",
                isoAlpha3: "PRY",
                isoAlpha2: "PY"
            }, {
                name: "Peru",
                isoAlpha3: "PER",
                isoAlpha2: "PE"
            }, {
                name: "Philippines",
                isoAlpha3: "PHL",
                isoAlpha2: "PH"
            }, {
                name: "Pitcairn",
                isoAlpha3: "PCN",
                isoAlpha2: "PN"
            }, {
                name: "Poland",
                isoAlpha3: "POL",
                isoAlpha2: "PL"
            }, {
                name: "Portugal",
                isoAlpha3: "PRT",
                isoAlpha2: "PT"
            }, {
                name: "Puerto Rico",
                isoAlpha3: "PRI",
                isoAlpha2: "PR"
            }, {
                name: "Qatar",
                isoAlpha3: "QAT",
                isoAlpha2: "QA"
            }, {
                name: "R\xe9union",
                isoAlpha3: "REU",
                isoAlpha2: "RE"
            }, {
                name: "Romania",
                isoAlpha3: "ROU",
                isoAlpha2: "RO"
            }, {
                name: "Russian Federation",
                isoAlpha3: "RUS",
                isoAlpha2: "RU"
            }, {
                name: "Rwanda",
                isoAlpha3: "RWA",
                isoAlpha2: "RW"
            }, {
                name: "Saint Barth\xe9lemy",
                isoAlpha3: "BLM",
                isoAlpha2: "BL"
            }, {
                name: "Saint Helena, Ascension and Tristan da Cunha",
                isoAlpha3: "SHN",
                isoAlpha2: "SH"
            }, {
                name: "Saint Kitts and Nevis",
                isoAlpha3: "KNA",
                isoAlpha2: "KN"
            }, {
                name: "Saint Lucia",
                isoAlpha3: "LCA",
                isoAlpha2: "LC"
            }, {
                name: "Saint Martin (French part)",
                isoAlpha3: "MAF",
                isoAlpha2: "MF"
            }, {
                name: "Saint Pierre and Miquelon",
                isoAlpha3: "SPM",
                isoAlpha2: "PM"
            }, {
                name: "Saint Vincent and the Grenadines",
                isoAlpha3: "VCT",
                isoAlpha2: "VC"
            }, {
                name: "Samoa",
                isoAlpha3: "WSM",
                isoAlpha2: "WS"
            }, {
                name: "San Marino",
                isoAlpha3: "SMR",
                isoAlpha2: "SM"
            }, {
                name: "Sao Tome and Principe",
                isoAlpha3: "STP",
                isoAlpha2: "ST"
            }, {
                name: "Saudi Arabia",
                isoAlpha3: "SAU",
                isoAlpha2: "SA"
            }, {
                name: "Senegal",
                isoAlpha3: "SEN",
                isoAlpha2: "SN"
            }, {
                name: "Serbia",
                isoAlpha3: "SRB",
                isoAlpha2: "RS"
            }, {
                name: "Seychelles",
                isoAlpha3: "SYC",
                isoAlpha2: "SC"
            }, {
                name: "Sierra Leone",
                isoAlpha3: "SLE",
                isoAlpha2: "SL"
            }, {
                name: "Singapore",
                isoAlpha3: "SGP",
                isoAlpha2: "SG"
            }, {
                name: "Sint Maarten (Dutch part)",
                isoAlpha3: "SXM",
                isoAlpha2: "SX"
            }, {
                name: "Slovakia",
                isoAlpha3: "SVK",
                isoAlpha2: "SK"
            }, {
                name: "Slovenia",
                isoAlpha3: "SVN",
                isoAlpha2: "SI"
            }, {
                name: "Solomon Islands",
                isoAlpha3: "SLB",
                isoAlpha2: "SB"
            }, {
                name: "Somalia",
                isoAlpha3: "SOM",
                isoAlpha2: "SO"
            }, {
                name: "South Africa",
                isoAlpha3: "ZAF",
                isoAlpha2: "ZA"
            }, {
                name: "South Georgia and the South Sandwich Islands",
                isoAlpha3: "SGS",
                isoAlpha2: "GS"
            }, {
                name: "South Sudan",
                isoAlpha3: "SSD",
                isoAlpha2: "SS"
            }, {
                name: "Spain",
                isoAlpha3: "ESP",
                isoAlpha2: "ES"
            }, {
                name: "Sri Lanka",
                isoAlpha3: "LKA",
                isoAlpha2: "LK"
            }, {
                name: "Sudan",
                isoAlpha3: "SDN",
                isoAlpha2: "SD"
            }, {
                name: "Suriname",
                isoAlpha3: "SUR",
                isoAlpha2: "SR"
            }, {
                name: "Svalbard and Jan Mayen",
                isoAlpha3: "SJM",
                isoAlpha2: "SJ"
            }, {
                name: "Sweden",
                isoAlpha3: "SWE",
                isoAlpha2: "SE"
            }, {
                name: "Switzerland",
                isoAlpha3: "CHE",
                isoAlpha2: "CH"
            }, {
                name: "Syrian Arab Republic",
                isoAlpha3: "SYR",
                isoAlpha2: "SY"
            }, {
                name: "Taiwan, Province of China",
                isoAlpha3: "TWN",
                isoAlpha2: "TW"
            }, {
                name: "Tajikistan",
                isoAlpha3: "TJK",
                isoAlpha2: "TJ"
            }, {
                name: "Tanzania, United Republic of",
                isoAlpha3: "TZA",
                isoAlpha2: "TZ"
            }, {
                name: "Thailand",
                isoAlpha3: "THA",
                isoAlpha2: "TH"
            }, {
                name: "Timor-Leste",
                isoAlpha3: "TLS",
                isoAlpha2: "TL"
            }, {
                name: "Togo",
                isoAlpha3: "TGO",
                isoAlpha2: "TG"
            }, {
                name: "Tokelau",
                isoAlpha3: "TKL",
                isoAlpha2: "TK"
            }, {
                name: "Tonga",
                isoAlpha3: "TON",
                isoAlpha2: "TO"
            }, {
                name: "Trinidad and Tobago",
                isoAlpha3: "TTO",
                isoAlpha2: "TT"
            }, {
                name: "Tunisia",
                isoAlpha3: "TUN",
                isoAlpha2: "TN"
            }, {
                name: "T\xfcrkiye",
                isoAlpha3: "TUR",
                isoAlpha2: "TR"
            }, {
                name: "Turkmenistan",
                isoAlpha3: "TKM",
                isoAlpha2: "TM"
            }, {
                name: "Turks and Caicos Islands",
                isoAlpha3: "TCA",
                isoAlpha2: "TC"
            }, {
                name: "Tuvalu",
                isoAlpha3: "TUV",
                isoAlpha2: "TV"
            }, {
                name: "Uganda",
                isoAlpha3: "UGA",
                isoAlpha2: "UG"
            }, {
                name: "Ukraine",
                isoAlpha3: "UKR",
                isoAlpha2: "UA"
            }, {
                name: "Dubai (UAE)",
                isoAlpha3: "ARE",
                isoAlpha2: "AE"
            }, {
                name: "United Kingdom",
                isoAlpha3: "GBR",
                isoAlpha2: "GB"
            }, {
                name: "United States Minor Outlying Islands",
                isoAlpha3: "UMI",
                isoAlpha2: "UM"
            }, {
                name: "United States",
                isoAlpha3: "USA",
                isoAlpha2: "US"
            }, {
                name: "Uruguay",
                isoAlpha3: "URY",
                isoAlpha2: "UY"
            }, {
                name: "Uzbekistan",
                isoAlpha3: "UZB",
                isoAlpha2: "UZ"
            }, {
                name: "Vanuatu",
                isoAlpha3: "VUT",
                isoAlpha2: "VU"
            }, {
                name: "Venezuela, Bolivarian Republic of",
                isoAlpha3: "VEN",
                isoAlpha2: "VE"
            }, {
                name: "Vietnam",
                isoAlpha3: "VNM",
                isoAlpha2: "VN"
            }, {
                name: "Virgin Islands (British)",
                isoAlpha3: "VGB",
                isoAlpha2: "VG"
            }, {
                name: "Virgin Islands (U.S.)",
                isoAlpha3: "VIR",
                isoAlpha2: "VI"
            }, {
                name: "Wallis and Futuna",
                isoAlpha3: "WLF",
                isoAlpha2: "WF"
            }, {
                name: "Western Sahara",
                isoAlpha3: "ESH",
                isoAlpha2: "EH"
            }, {
                name: "Yemen",
                isoAlpha3: "YEM",
                isoAlpha2: "YE"
            }, {
                name: "Zambia",
                isoAlpha3: "ZMB",
                isoAlpha2: "ZM"
            }, {
                name: "Zimbabwe",
                isoAlpha3: "ZWE",
                isoAlpha2: "ZW"
            }];

            function l(a) {
                return "https://flagcdn.com/w80/".concat(a.toLowerCase(), ".png")
            }
            let n = [{
                code: "USD",
                name: "United States Dollar",
                countryCodeIsoAlpha2: "US"
            }, {
                code: "CHF",
                name: "Swiss Franc",
                countryCodeIsoAlpha2: "CH"
            }, {
                code: "EUR",
                name: "Euro",
                countryCodeIsoAlpha2: "EU"
            }, {
                code: "AUD",
                name: "Australian Dollar",
                countryCodeIsoAlpha2: "AU"
            }, {
                code: "CAD",
                name: "Canadian Dollar",
                countryCodeIsoAlpha2: "CA"
            }, {
                code: "CNY",
                name: "Chinese Yuan",
                countryCodeIsoAlpha2: "CN"
            }, {
                code: "GBP",
                name: "Pound Sterling",
                countryCodeIsoAlpha2: "GB"
            }, {
                code: "NZD",
                name: "New Zealand Dollar",
                countryCodeIsoAlpha2: "NZ"
            }, {
                code: "JPY",
                name: "Japanese Yen",
                countryCodeIsoAlpha2: "JP"
            }];

            function h(a) {
                let {
                    value: o,
                    currency: e,
                    locale: i = "en-US",
                    notation: s,
                    maximumFractionDigits: l = 1,
                    minimumFractionDigits: n = 0
                } = a;
                return new Intl.NumberFormat(i, {
                    style: e ? "currency" : "decimal",
                    currency: e,
                    notation: s,
                    minimumFractionDigits: n,
                    maximumFractionDigits: l
                }).format(o)
            }(r || (r = {})).NONE = "NONE";
            var r, A, p, m = e(95772);
            let t = m.z.object({
                skip: m.z.number().int().nonnegative().optional(),
                take: m.z.number().int().min(1).max(100).optional()
            });

            function d(a) {
                let o = Object.fromEntries(Object.entries(a));
                return Object.keys(o).forEach(a => void 0 === o[a] && delete o[a]), o
            }
            let u = m.ZP.object({
                    r: m.ZP.number(),
                    g: m.ZP.number(),
                    b: m.ZP.number(),
                    a: m.ZP.number().optional()
                }),
                c = {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                };

            function b(a) {
                let {
                    maxLimit: o,
                    minLimit: e = 0,
                    value: i
                } = a, s = null != o ? o : e > 100 ? e + 100 : 100;
                return (Math.min(Math.max(i, e), s) - e) / (s - e) * 100
            }(A || (A = {})).USD = "USD",
                function(a) {
                    a.Asc = "asc", a.Desc = "desc"
                }(p || (p = {})), m.z.object({
                    direction: m.z.nativeEnum(p)
                })
        }
    }
]);