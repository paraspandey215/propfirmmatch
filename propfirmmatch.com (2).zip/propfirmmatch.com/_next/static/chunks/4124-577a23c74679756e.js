"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4124], {
        63319: (e, t, n) => {
            n.r(t), n.d(t, {
                useLocale: () => l,
                useTranslation: () => s
            });
            var r = n(93264),
                i = n(10375);
            let o = /{{\s*(\w+)\s*}}/g;
            var a = n(29782);

            function s(e) {
                let t = function() {
                    let e = (0, r.useContext)(i.O);
                    return (0, r.useCallback)((t, n) => {
                        var r, i;
                        let o = n || e.defaultNamespace;
                        return (null === (r = e.resources[o]) || void 0 === r ? void 0 : r[t]) || (null === (i = e.fallbackResources[o]) || void 0 === i ? void 0 : i[t]) || t
                    }, [e.defaultNamespace, e.fallbackResources, e.resources])
                }();
                return {
                    t: (0, r.useCallback)(function(n) {
                        let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        return function(e) {
                            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            return e.replace(o, (e, n) => void 0 !== t[n] ? t[n] : e)
                        }(t(n, e), r)
                    }, [t, e])
                }
            }

            function l() {
                return {
                    locale: (0, r.useContext)(i.O).locale,
                    defaultLocale: a.E.defaultLocale
                }
            }
        },
        6185: (e, t, n) => {
            n.d(t, {
                cC: () => a,
                bU: () => r.useLocale,
                $G: () => r.useTranslation
            });
            var r = n(63319),
                i = n(12428),
                o = n(93264);

            function a(e) {
                let {
                    i18nKey: t,
                    components: n = {},
                    values: r = {}
                } = e, a = function(e) {
                    var t, n, r;
                    let i = [],
                        o = 0;
                    for (; o < e.length;) {
                        if (e.startsWith("<", o)) {
                            let n = e.substring(o).match(/^<\/?(\w+)(\s*\/?)>/);
                            if (n) {
                                let e = "/" === n[0][1],
                                    r = n[1],
                                    a = null === (t = n[2]) || void 0 === t ? void 0 : t.includes("/");
                                i.push({
                                    type: e ? "endTag" : "startTag",
                                    name: r,
                                    ...e ? {} : {
                                        selfClosing: a
                                    }
                                }), o += n[0].length;
                                continue
                            }
                        } else if (e.startsWith("{{", o)) {
                            let t = e.substring(o).match(/^\{\{\s*(\w+)\s*\}\}/);
                            if (t) {
                                i.push({
                                    type: "variable",
                                    name: null !== (n = t[1]) && void 0 !== n ? n : ""
                                }), o += t[0].length;
                                continue
                            }
                        }
                        let r = o;
                        for (; r < e.length && !e.startsWith("<", r) && !e.startsWith("{{", r);) r++;
                        let a = e.substring(o, r);
                        i.push({
                            type: "text",
                            content: a
                        }), o = r
                    }
                    let a = [],
                        s = [{
                            children: a
                        }];
                    if (i.forEach(e => {
                            let t = s[s.length - 1];
                            if ("text" === e.type || "variable" === e.type) null == t || t.children.push(e);
                            else if ("startTag" === e.type) {
                                let n = {
                                    type: "component",
                                    name: e.name,
                                    children: []
                                };
                                null == t || t.children.push(n), e.selfClosing || s.push({
                                    name: e.name,
                                    children: n.children
                                })
                            } else if ("endTag" === e.type) {
                                var n;
                                if (s.length > 1 && (null === (n = s[s.length - 1]) || void 0 === n ? void 0 : n.name) === e.name) s.pop();
                                else throw Error("Mismatched end tag: </".concat(e.name, ">"))
                            }
                        }), s.length > 1) throw Error("Unclosed tag: " + (null === (r = s[s.length - 1]) || void 0 === r ? void 0 : r.name));
                    return a
                }(t);
                return (0, i.jsx)(i.Fragment, {
                    children: function e(t, n, r) {
                        return t.map((t, i) => {
                            if ("text" === t.type) return t.content;
                            if ("variable" === t.type) {
                                let e = r[t.name];
                                if (void 0 === e) throw Error("Variable not found: ".concat(t.name));
                                return e
                            }
                            if ("component" !== t.type) return null; {
                                let a = n[t.name];
                                if (!a) throw Error("Component not found: ".concat(t.name));
                                let s = t.children && t.children.length > 0,
                                    l = s ? e(t.children, n, r) : null;
                                return o.createElement(a, {
                                    key: i
                                }, s ? l : void 0)
                            }
                        })
                    }(a, n, r)
                })
            }
        },
        10375: (e, t, n) => {
            n.d(t, {
                O: () => o
            });
            var r = n(93264),
                i = n(11126);
            let o = (0, r.createContext)({
                locale: i.go.En,
                resources: {},
                fallbackResources: {},
                defaultNamespace: i.zG
            })
        },
        11126: (e, t, n) => {
            var r;
            n.d(t, {
                WZ: () => o,
                go: () => r,
                zG: () => i
            }), (r || (r = {})).En = "en";
            let i = "translations",
                o = e => "en"
        },
        29782: (e, t, n) => {
            n.d(t, {
                E: () => i
            });
            var r = n(11126);
            let i = {
                locales: [r.go.En],
                defaultLocale: r.go.En,
                prefixDefault: !1,
                localeCookie: "PFM_LOCALE"
            }
        },
        85473: (e, t, n) => {
            let r;
            n.d(t, {
                TRPCProvider: () => A,
                trpc: () => f
            });
            var i = n(12428),
                o = n(72919),
                a = n(45447),
                s = n(90188),
                l = n(72140),
                u = n(69339),
                c = n(29045),
                E = n(93264),
                _ = n(15357),
                d = n(35713),
                T = n(68714);
            let f = (0, u.ec)(),
                p = e => () => t => {
                    let {
                        next: n,
                        op: r
                    } = t;
                    return (0, c.LO)(t => n(r).subscribe({
                        next(e) {
                            t.next(e)
                        },
                        error(n) {
                            var r;
                            t.error(n), (null == n ? void 0 : null === (r = n.data) || void 0 === r ? void 0 : r.code) === "UNAUTHORIZED" && n.message === o.ht.ONBOARDING_REQUIRED && e("/onboarding")
                        },
                        complete() {
                            t.complete()
                        }
                    }))
                };

            function A(e) {
                let t = null != r ? r : r = new d.S({
                        defaultOptions: {
                            queries: {
                                staleTime: 3e4
                            },
                            dehydrate: {
                                serializeData: _.ZP.serialize,
                                shouldDehydrateQuery: e => (0, T.d_)(e) || "pending" === e.state.status
                            },
                            hydrate: {
                                deserializeData: _.ZP.deserialize
                            }
                        }
                    }),
                    [n] = (0, E.useState)(() => {
                        var t;
                        return f.createClient({
                            links: [p(e => window.location.replace(e)), (0, l.N8)({
                                transformer: _.ZP,
                                url: (t = e.baseUrl, "".concat(t, "/api/trpc"))
                            })]
                        })
                    });
                return (0, i.jsx)(f.Provider, {
                    client: n,
                    queryClient: t,
                    children: (0, i.jsx)(a.QueryClientProvider, {
                        client: t,
                        children: (0, i.jsx)(s.V, {
                            children: e.children
                        })
                    })
                })
            }
        },
        17322: (e, t, n) => {
            var r, i, o, a, s, l, u, c, E, _, d, T, f, p, A, h, m, O, R, y, g, P, C, S, v, D, U, L, N, F, I, b;
            n.d(t, {
                    AB: () => v,
                    Bl: () => O,
                    DC: () => A,
                    DD: () => E,
                    HN: () => C,
                    Kg: () => f,
                    Ki: () => T,
                    LH: () => s,
                    Nf: () => D,
                    P4: () => U,
                    Qx: () => r,
                    Rn: () => c,
                    TX: () => L,
                    Xt: () => R,
                    Yi: () => p,
                    aN: () => h,
                    co: () => g,
                    fg: () => P,
                    fo: () => y,
                    lS: () => m,
                    ny: () => i,
                    oi: () => o,
                    wJ: () => u,
                    x3: () => S
                }),
                function(e) {
                    e.Amount = "amount", e.Percentage = "percentage"
                }(r || (r = {})),
                function(e) {
                    e.Active = "active", e.Draft = "draft", e.Archived = "archived"
                }(i || (i = {})),
                function(e) {
                    e.Instant = "Instant", e.OneStep = "1 Step", e.TwoSteps = "2_Steps", e.ThreeSteps = "3_Steps", e.FourSteps = "4_Steps"
                }(o || (o = {})),
                function(e) {
                    e.Fixed = "fixed", e.Raw = "raw", e.Variable = "variable"
                }(a || (a = {})),
                function(e) {
                    e.Standard = "standard", e.ProfitSplit = "profit_split", e.RefundFee = "refund_fee"
                }(s || (s = {})),
                function(e) {
                    e.Monthly = "monthly", e.OneTime = "one_time"
                }(l || (l = {})),
                function(e) {
                    e.BalanceBased = "balance_based", e.EquityBased = "equity_based", e.BalanceEquityHighestAtEod = "balance_equity_highest_eod", e.TrailingHighestBalanceEquity = "trailing_highest_balance_equity"
                }(u || (u = {})),
                function(e) {
                    e.Static = "Static", e.Trailing = "Trailing"
                }(c || (c = {})),
                function(e) {
                    e.Pfm = "pfm", e.Firm = "firm"
                }(E || (E = {})),
                function(e) {
                    e.UNLISTED_FIRM_SUBMISSION_DELETE = "UNLISTED_FIRM_SUBMISSION_DELETE", e.PROMO_CREATE = "PROMO_CREATE", e.PROMO_UPDATE = "PROMO_UPDATE", e.PROMO_DELETE = "PROMO_DELETE", e.PROMO_STATUS_UPDATE = "PROMO_STATUS_UPDATE", e.PROMO_DISCOUNT_CREATE = "PROMO_DISCOUNT_CREATE", e.PROMO_DISCOUNT_UPDATE = "PROMO_DISCOUNT_UPDATE", e.PROMO_DISCOUNT_DELETE = "PROMO_DISCOUNT_DELETE", e.PROMO_SORTING_UPDATE = "PROMO_SORTING_UPDATE", e.FIRM_CREATE = "FIRM_CREATE", e.FIRM_UPDATE = "FIRM_UPDATE", e.FIRM_DELETE = "FIRM_DELETE", e.FIRM_STATUS_UPDATE = "FIRM_STATUS_UPDATE", e.FEATURE_CATEGORY_CREATE = "FEATURE_CATEGORY_CREATE", e.FEATURE_CATEGORY_UPDATE = "FEATURE_CATEGORY_UPDATE", e.FEATURE_CATEGORY_DELETE = "FEATURE_CATEGORY_DELETE", e.FEATURE_CREATE = "FEATURE_CREATE", e.FEATURE_UPDATE = "FEATURE_UPDATE", e.FEATURE_DELETE = "FEATURE_DELETE", e.CHALLENGE_CREATE = "CHALLENGE_CREATE", e.CHALLENGE_UPDATE = "CHALLENGE_UPDATE", e.CHALLENGE_DELETE = "CHALLENGE_DELETE", e.CHALLENGE_STATUS_UPDATE = "CHALLENGE_STATUS_UPDATE", e.LOYALTY_WALLET_UPDATE = "LOYALTY_WALLET_UPDATE", e.ACTION_INTENT_STATUS_UPDATE = "ACTION_INTENT_STATUS_UPDATE"
                }(_ || (_ = {})),
                function(e) {
                    e.Created = "created", e.Active = "active", e.Blocked = "blocked"
                }(d || (d = {})),
                function(e) {
                    e.Onboarding = "onboarding", e.Completed = "completed"
                }(T || (T = {})),
                function(e) {
                    e["0-3M"] = "0-3M", e["4-12M"] = "4-12M", e["1-2Y"] = "1-2Y", e["3-5Y"] = "3-5Y", e["5Y+"] = "5Y+"
                }(f || (f = {})),
                function(e) {
                    e.Forex = "forex", e.Crypto = "crypto", e.Stocks = "stocks", e.Futures = "futures", e.Metals = "metals"
                }(p || (p = {})),
                function(e) {
                    e.never = "never", e["1-3"] = "1-3", e["4-9"] = "4-9", e["10+"] = "10+"
                }(A || (A = {})),
                function(e) {
                    e.Compare_firms_and_challenges = "compare_firms_and_challenges", e.View_reviews = "view_reviews", e.Exclusive_offers = "exclusive_offers", e.Loyalty_points = "loyalty_points"
                }(h || (h = {})),
                function(e) {
                    e.Friends_family = "friends_family", e.Google = "google", e.Twitter = "twitter", e.Instagram = "instagram", e.Facebook = "facebook", e.Youtube = "youtube", e.Advertisement = "advertisement", e.Other = "other"
                }(m || (m = {})),
                function(e) {
                    e.AllDay = "all_day", e.Tentative = "tentative", e.SetTime = "set_time"
                }(O || (O = {})),
                function(e) {
                    e.Listed = "listed", e.Unlisted = "unlisted", e.Delisted = "delisted", e.OutOfOperations = "out_of_operations", e.Broker = "broker"
                }(R || (R = {})),
                function(e) {
                    e.Crypto = "crypto", e.Energy = "energy", e.FX = "fx", e.Indices = "indices", e.Metals = "metals", e.OtherCommodities = "otherCommodities", e.Stocks = "stocks", e.Futures = "futures"
                }(y || (y = {})),
                function(e) {
                    e.CFD = "CFD", e.Futures = "futures", e.CryptoOnly = "cryptoOnly", e.StocksOnly = "stocksOnly"
                }(g || (g = {})),
                function(e) {
                    e.PaidOut = "paid_out", e.Pending = "pending", e.Funded = "funded"
                }(P || (P = {})),
                function(e) {
                    e.Zero = "0", e.One = "1", e.Two = "2", e.Three = "3", e.Four = "4", e.Five = "5", e.Six = "6", e.Seven = "7", e.Eight = "8", e.Nine = "9", e.TenPlus = "10+"
                }(C || (C = {})),
                function(e) {
                    e.LessThanOneMonth = "less_than_one_month", e.OneMonthPlus = "one_month_plus", e.ThreeMonthsPlus = "three_months_plus", e.SixMonthsPlus = "six_months_plus", e.OneYearPlus = "one_year_plus", e.ThreeYearsPlus = "three_years_plus"
                }(S || (S = {})),
                function(e) {
                    e.No = "no", e.PayoutDenial = "payout_denial", e.UnjustifiedBreach = "unjustified_breach"
                }(v || (v = {})),
                function(e) {
                    e.known = "known", e.unknown = "unknown"
                }(D || (D = {})),
                function(e) {
                    e.Yes = "yes", e.No = "no"
                }(U || (U = {})),
                function(e) {
                    e.MarketAnalysisInsights = "market_analysis_insights", e.PropFirmEducation = "prop_firm_education", e.PropFirmInnovationTechnologyAI = "prop_firm_innovation_technology_ai", e.PropFirmNewsUpdates = "prop_firm_news_updates", e.PropFirmReviewsComparisons = "prop_firm_reviews_comparisons", e.PropFirmStrategiesTips = "prop_firm_strategies_tips", e.PropTradingBasics = "prop_trading_basics"
                }(L || (L = {})),
                function(e) {
                    e.PayoutsSync = "payouts_sync", e.CheckoutsSync = "checkouts_sync"
                }(N || (N = {})),
                function(e) {
                    e.RISE = "rise", e.WIRE_TRANSFER = "wire_transfer", e.CRYPTO = "crypto", e.WISE = "wise", e.PLANE = "plane", e.CREDIT_CARD = "credit_card"
                }(F || (F = {})),
                function(e) {
                    e.Europe = "Europe", e.Asia = "Asia", e.Africa = "Africa", e.NorthAmerica = "North America", e.SouthAmerica = "South America", e.Australia = "Australia"
                }(I || (I = {})),
                function(e) {
                    e.Popular = "popular", e.AllBestSellers = "all_best_sellers", e.MonthlyAllBestSellers = "monthly_best_sellers", e.CryptoBestSellers = "crypto_best_sellers", e.StocksBestSellers = "stocks_best_sellers", e.Spreads = "spreads", e.FirmsAllowedForCheckouts = "firms_allowed_for_checkouts"
                }(b || (b = {}))
        },
        72919: (e, t, n) => {
            n.d(t, {
                ht: () => r,
                JE: () => u
            });
            var r, i = n(32029),
                o = n(17322),
                a = n(95772);
            let s = a.z.object({
                    tradingInstruments: a.z.nativeEnum(o.Yi).array()
                }),
                l = a.z.object({
                    favoriteFirmIds: a.z.string().array()
                }),
                u = a.z.object({
                    country: a.z.enum(i.$Y.map(e => e.isoAlpha2)),
                    tradingExperience: a.z.nativeEnum(o.Kg),
                    propFirmChallengeExperience: a.z.nativeEnum(o.DC),
                    platformInterests: a.z.nativeEnum(o.aN).array(),
                    referalSource: a.z.nativeEnum(o.lS)
                }).merge(s).merge(l);
            (r || (r = {})).ONBOARDING_REQUIRED = "ONBOARDING_REQUIRED"
        }
    }
]);