"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6870], {
        75568: (e, t, n) => {
            n.d(t, {
                Ry: () => c
            });
            var r = new WeakMap,
                o = new WeakMap,
                i = {},
                l = 0,
                a = function(e) {
                    return e && (e.host || a(e.parentNode))
                },
                u = function(e, t, n, u) {
                    var c = (Array.isArray(e) ? e : [e]).map(function(e) {
                        if (t.contains(e)) return e;
                        var n = a(e);
                        return n && t.contains(n) ? n : (console.error("aria-hidden", e, "in not contained inside", t, ". Doing nothing"), null)
                    }).filter(function(e) {
                        return !!e
                    });
                    i[n] || (i[n] = new WeakMap);
                    var s = i[n],
                        d = [],
                        f = new Set,
                        p = new Set(c),
                        v = function(e) {
                            !e || f.has(e) || (f.add(e), v(e.parentNode))
                        };
                    c.forEach(v);
                    var m = function(e) {
                        !e || p.has(e) || Array.prototype.forEach.call(e.children, function(e) {
                            if (f.has(e)) m(e);
                            else try {
                                var t = e.getAttribute(u),
                                    i = null !== t && "false" !== t,
                                    l = (r.get(e) || 0) + 1,
                                    a = (s.get(e) || 0) + 1;
                                r.set(e, l), s.set(e, a), d.push(e), 1 === l && i && o.set(e, !0), 1 === a && e.setAttribute(n, "true"), i || e.setAttribute(u, "true")
                            } catch (t) {
                                console.error("aria-hidden: cannot operate on ", e, t)
                            }
                        })
                    };
                    return m(t), f.clear(), l++,
                        function() {
                            d.forEach(function(e) {
                                var t = r.get(e) - 1,
                                    i = s.get(e) - 1;
                                r.set(e, t), s.set(e, i), t || (o.has(e) || e.removeAttribute(u), o.delete(e)), i || e.removeAttribute(n)
                            }), --l || (r = new WeakMap, r = new WeakMap, o = new WeakMap, i = {})
                        }
                },
                c = function(e, t, n) {
                    void 0 === n && (n = "data-aria-hidden");
                    var r, o = Array.from(Array.isArray(e) ? e : [e]),
                        i = t || (r = e, "undefined" == typeof document ? null : (Array.isArray(r) ? r[0] : r).ownerDocument.body);
                    return i ? (o.push.apply(o, Array.from(i.querySelectorAll("[aria-live]"))), u(o, i, n, "aria-hidden")) : function() {
                        return null
                    }
                }
        },
        66127: (e, t, n) => {
            n.d(t, {
                Z: () => u
            });
            var r = n(93264);
            let o = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
                i = function() {
                    for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return t.filter((e, t, n) => !!e && n.indexOf(e) === t).join(" ")
                };
            var l = {
                xmlns: "http://www.w3.org/2000/svg",
                width: 24,
                height: 24,
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 2,
                strokeLinecap: "round",
                strokeLinejoin: "round"
            };
            let a = (0, r.forwardRef)((e, t) => {
                    let {
                        color: n = "currentColor",
                        size: o = 24,
                        strokeWidth: a = 2,
                        absoluteStrokeWidth: u,
                        className: c = "",
                        children: s,
                        iconNode: d,
                        ...f
                    } = e;
                    return (0, r.createElement)("svg", {
                        ref: t,
                        ...l,
                        width: o,
                        height: o,
                        stroke: n,
                        strokeWidth: u ? 24 * Number(a) / Number(o) : a,
                        className: i("lucide", c),
                        ...f
                    }, [...d.map(e => {
                        let [t, n] = e;
                        return (0, r.createElement)(t, n)
                    }), ...Array.isArray(s) ? s : [s]])
                }),
                u = (e, t) => {
                    let n = (0, r.forwardRef)((n, l) => {
                        let {
                            className: u,
                            ...c
                        } = n;
                        return (0, r.createElement)(a, {
                            ref: l,
                            iconNode: t,
                            className: i("lucide-".concat(o(e)), u),
                            ...c
                        })
                    });
                    return n.displayName = "".concat(e), n
                }
        },
        71999: (e, t, n) => {
            n.d(t, {
                Z: () => r
            });
            let r = (0, n(66127).Z)("Check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        30455: (e, t, n) => {
            n.d(t, {
                Z: () => r
            });
            let r = (0, n(66127).Z)("ChevronDown", [
                ["path", {
                    d: "m6 9 6 6 6-6",
                    key: "qrunsl"
                }]
            ])
        },
        66453: (e, t, n) => {
            n.d(t, {
                Z: () => r
            });
            let r = (0, n(66127).Z)("Search", [
                ["circle", {
                    cx: "11",
                    cy: "11",
                    r: "8",
                    key: "4ej97u"
                }],
                ["path", {
                    d: "m21 21-4.3-4.3",
                    key: "1qie3q"
                }]
            ])
        },
        25845: (e, t, n) => {
            n.d(t, {
                Z: () => r
            });
            let r = (0, n(66127).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        13928: (e, t, n) => {
            n.d(t, {
                Av: () => l,
                pF: () => r,
                xv: () => i,
                zi: () => o
            });
            var r = "right-scroll-bar-position",
                o = "width-before-scroll-bar",
                i = "with-scroll-bars-hidden",
                l = "--removed-body-scroll-bar-size"
        },
        44338: (e, t, n) => {
            n.d(t, {
                jp: () => m
            });
            var r = n(93264),
                o = n(41441),
                i = n(13928),
                l = {
                    left: 0,
                    top: 0,
                    right: 0,
                    gap: 0
                },
                a = function(e) {
                    return parseInt(e || "", 10) || 0
                },
                u = function(e) {
                    var t = window.getComputedStyle(document.body),
                        n = t["padding" === e ? "paddingLeft" : "marginLeft"],
                        r = t["padding" === e ? "paddingTop" : "marginTop"],
                        o = t["padding" === e ? "paddingRight" : "marginRight"];
                    return [a(n), a(r), a(o)]
                },
                c = function(e) {
                    if (void 0 === e && (e = "margin"), "undefined" == typeof window) return l;
                    var t = u(e),
                        n = document.documentElement.clientWidth,
                        r = window.innerWidth;
                    return {
                        left: t[0],
                        top: t[1],
                        right: t[2],
                        gap: Math.max(0, r - n + t[2] - t[0])
                    }
                },
                s = (0, o.Ws)(),
                d = "data-scroll-locked",
                f = function(e, t, n, r) {
                    var o = e.left,
                        l = e.top,
                        a = e.right,
                        u = e.gap;
                    return void 0 === n && (n = "margin"), "\n  .".concat(i.xv, " {\n   overflow: hidden ").concat(r, ";\n   padding-right: ").concat(u, "px ").concat(r, ";\n  }\n  body[").concat(d, "] {\n    overflow: hidden ").concat(r, ";\n    overscroll-behavior: contain;\n    ").concat([t && "position: relative ".concat(r, ";"), "margin" === n && "\n    padding-left: ".concat(o, "px;\n    padding-top: ").concat(l, "px;\n    padding-right: ").concat(a, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(u, "px ").concat(r, ";\n    "), "padding" === n && "padding-right: ".concat(u, "px ").concat(r, ";")].filter(Boolean).join(""), "\n  }\n  \n  .").concat(i.pF, " {\n    right: ").concat(u, "px ").concat(r, ";\n  }\n  \n  .").concat(i.zi, " {\n    margin-right: ").concat(u, "px ").concat(r, ";\n  }\n  \n  .").concat(i.pF, " .").concat(i.pF, " {\n    right: 0 ").concat(r, ";\n  }\n  \n  .").concat(i.zi, " .").concat(i.zi, " {\n    margin-right: 0 ").concat(r, ";\n  }\n  \n  body[").concat(d, "] {\n    ").concat(i.Av, ": ").concat(u, "px;\n  }\n")
                },
                p = function() {
                    var e = parseInt(document.body.getAttribute(d) || "0", 10);
                    return isFinite(e) ? e : 0
                },
                v = function() {
                    r.useEffect(function() {
                        return document.body.setAttribute(d, (p() + 1).toString()),
                            function() {
                                var e = p() - 1;
                                e <= 0 ? document.body.removeAttribute(d) : document.body.setAttribute(d, e.toString())
                            }
                    }, [])
                },
                m = function(e) {
                    var t = e.noRelative,
                        n = e.noImportant,
                        o = e.gapMode,
                        i = void 0 === o ? "margin" : o;
                    v();
                    var l = r.useMemo(function() {
                        return c(i)
                    }, [i]);
                    return r.createElement(s, {
                        styles: f(l, !t, i, n ? "" : "!important")
                    })
                }
        },
        27263: (e, t, n) => {
            n.d(t, {
                Z: () => P
            });
            var r = n(87204),
                o = n(93264),
                i = n(13928),
                l = n(11458),
                a = (0, n(59434)._)(),
                u = function() {},
                c = o.forwardRef(function(e, t) {
                    var n = o.useRef(null),
                        i = o.useState({
                            onScrollCapture: u,
                            onWheelCapture: u,
                            onTouchMoveCapture: u
                        }),
                        c = i[0],
                        s = i[1],
                        d = e.forwardProps,
                        f = e.children,
                        p = e.className,
                        v = e.removeScrollBar,
                        m = e.enabled,
                        h = e.shards,
                        g = e.sideCar,
                        y = e.noIsolation,
                        b = e.inert,
                        w = e.allowPinchZoom,
                        E = e.as,
                        x = e.gapMode,
                        C = (0, r._T)(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]),
                        R = (0, l.q)([n, t]),
                        S = (0, r.pi)((0, r.pi)({}, C), c);
                    return o.createElement(o.Fragment, null, m && o.createElement(g, {
                        sideCar: a,
                        removeScrollBar: v,
                        shards: h,
                        noIsolation: y,
                        inert: b,
                        setCallbacks: s,
                        allowPinchZoom: !!w,
                        lockRef: n,
                        gapMode: x
                    }), d ? o.cloneElement(o.Children.only(f), (0, r.pi)((0, r.pi)({}, S), {
                        ref: R
                    })) : o.createElement(void 0 === E ? "div" : E, (0, r.pi)({}, S, {
                        className: p,
                        ref: R
                    }), f))
                });
            c.defaultProps = {
                enabled: !0,
                removeScrollBar: !0,
                inert: !1
            }, c.classNames = {
                fullWidth: i.zi,
                zeroRight: i.pF
            };
            var s = n(15949),
                d = n(44338),
                f = n(41441),
                p = !1;
            if ("undefined" != typeof window) try {
                var v = Object.defineProperty({}, "passive", {
                    get: function() {
                        return p = !0, !0
                    }
                });
                window.addEventListener("test", v, v), window.removeEventListener("test", v, v)
            } catch (e) {
                p = !1
            }
            var m = !!p && {
                    passive: !1
                },
                h = function(e, t) {
                    var n = window.getComputedStyle(e);
                    return "hidden" !== n[t] && !(n.overflowY === n.overflowX && "TEXTAREA" !== e.tagName && "visible" === n[t])
                },
                g = function(e, t) {
                    var n = t.ownerDocument,
                        r = t;
                    do {
                        if ("undefined" != typeof ShadowRoot && r instanceof ShadowRoot && (r = r.host), y(e, r)) {
                            var o = b(e, r);
                            if (o[1] > o[2]) return !0
                        }
                        r = r.parentNode
                    } while (r && r !== n.body);
                    return !1
                },
                y = function(e, t) {
                    return "v" === e ? h(t, "overflowY") : h(t, "overflowX")
                },
                b = function(e, t) {
                    return "v" === e ? [t.scrollTop, t.scrollHeight, t.clientHeight] : [t.scrollLeft, t.scrollWidth, t.clientWidth]
                },
                w = function(e, t, n, r, o) {
                    var i, l = (i = window.getComputedStyle(t).direction, "h" === e && "rtl" === i ? -1 : 1),
                        a = l * r,
                        u = n.target,
                        c = t.contains(u),
                        s = !1,
                        d = a > 0,
                        f = 0,
                        p = 0;
                    do {
                        var v = b(e, u),
                            m = v[0],
                            h = v[1] - v[2] - l * m;
                        (m || h) && y(e, u) && (f += h, p += m), u instanceof ShadowRoot ? u = u.host : u = u.parentNode
                    } while (!c && u !== document.body || c && (t.contains(u) || t === u));
                    return d && (o && 1 > Math.abs(f) || !o && a > f) ? s = !0 : !d && (o && 1 > Math.abs(p) || !o && -a > p) && (s = !0), s
                },
                E = function(e) {
                    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
                },
                x = function(e) {
                    return [e.deltaX, e.deltaY]
                },
                C = function(e) {
                    return e && "current" in e ? e.current : e
                },
                R = 0,
                S = [];
            let k = (0, s.L)(a, function(e) {
                var t = o.useRef([]),
                    n = o.useRef([0, 0]),
                    i = o.useRef(),
                    l = o.useState(R++)[0],
                    a = o.useState(f.Ws)[0],
                    u = o.useRef(e);
                o.useEffect(function() {
                    u.current = e
                }, [e]), o.useEffect(function() {
                    if (e.inert) {
                        document.body.classList.add("block-interactivity-".concat(l));
                        var t = (0, r.ev)([e.lockRef.current], (e.shards || []).map(C), !0).filter(Boolean);
                        return t.forEach(function(e) {
                                return e.classList.add("allow-interactivity-".concat(l))
                            }),
                            function() {
                                document.body.classList.remove("block-interactivity-".concat(l)), t.forEach(function(e) {
                                    return e.classList.remove("allow-interactivity-".concat(l))
                                })
                            }
                    }
                }, [e.inert, e.lockRef.current, e.shards]);
                var c = o.useCallback(function(e, t) {
                        if ("touches" in e && 2 === e.touches.length) return !u.current.allowPinchZoom;
                        var r, o = E(e),
                            l = n.current,
                            a = "deltaX" in e ? e.deltaX : l[0] - o[0],
                            c = "deltaY" in e ? e.deltaY : l[1] - o[1],
                            s = e.target,
                            d = Math.abs(a) > Math.abs(c) ? "h" : "v";
                        if ("touches" in e && "h" === d && "range" === s.type) return !1;
                        var f = g(d, s);
                        if (!f) return !0;
                        if (f ? r = d : (r = "v" === d ? "h" : "v", f = g(d, s)), !f) return !1;
                        if (!i.current && "changedTouches" in e && (a || c) && (i.current = r), !r) return !0;
                        var p = i.current || r;
                        return w(p, t, e, "h" === p ? a : c, !0)
                    }, []),
                    s = o.useCallback(function(e) {
                        if (S.length && S[S.length - 1] === a) {
                            var n = "deltaY" in e ? x(e) : E(e),
                                r = t.current.filter(function(t) {
                                    var r;
                                    return t.name === e.type && (t.target === e.target || e.target === t.shadowParent) && (r = t.delta)[0] === n[0] && r[1] === n[1]
                                })[0];
                            if (r && r.should) {
                                e.cancelable && e.preventDefault();
                                return
                            }
                            if (!r) {
                                var o = (u.current.shards || []).map(C).filter(Boolean).filter(function(t) {
                                    return t.contains(e.target)
                                });
                                (o.length > 0 ? c(e, o[0]) : !u.current.noIsolation) && e.cancelable && e.preventDefault()
                            }
                        }
                    }, []),
                    p = o.useCallback(function(e, n, r, o) {
                        var i = {
                            name: e,
                            delta: n,
                            target: r,
                            should: o,
                            shadowParent: function(e) {
                                for (var t = null; null !== e;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
                                return t
                            }(r)
                        };
                        t.current.push(i), setTimeout(function() {
                            t.current = t.current.filter(function(e) {
                                return e !== i
                            })
                        }, 1)
                    }, []),
                    v = o.useCallback(function(e) {
                        n.current = E(e), i.current = void 0
                    }, []),
                    h = o.useCallback(function(t) {
                        p(t.type, x(t), t.target, c(t, e.lockRef.current))
                    }, []),
                    y = o.useCallback(function(t) {
                        p(t.type, E(t), t.target, c(t, e.lockRef.current))
                    }, []);
                o.useEffect(function() {
                    return S.push(a), e.setCallbacks({
                            onScrollCapture: h,
                            onWheelCapture: h,
                            onTouchMoveCapture: y
                        }), document.addEventListener("wheel", s, m), document.addEventListener("touchmove", s, m), document.addEventListener("touchstart", v, m),
                        function() {
                            S = S.filter(function(e) {
                                return e !== a
                            }), document.removeEventListener("wheel", s, m), document.removeEventListener("touchmove", s, m), document.removeEventListener("touchstart", v, m)
                        }
                }, []);
                var b = e.removeScrollBar,
                    k = e.inert;
                return o.createElement(o.Fragment, null, k ? o.createElement(a, {
                    styles: "\n  .block-interactivity-".concat(l, " {pointer-events: none;}\n  .allow-interactivity-").concat(l, " {pointer-events: all;}\n")
                }) : null, b ? o.createElement(d.jp, {
                    gapMode: e.gapMode
                }) : null)
            });
            var A = o.forwardRef(function(e, t) {
                return o.createElement(c, (0, r.pi)({}, e, {
                    ref: t,
                    sideCar: k
                }))
            });
            A.classNames = c.classNames;
            let P = A
        },
        41441: (e, t, n) => {
            n.d(t, {
                Ws: () => a
            });
            var r, o = n(93264),
                i = function() {
                    var e = 0,
                        t = null;
                    return {
                        add: function(o) {
                            if (0 == e && (t = function() {
                                    if (!document) return null;
                                    var e = document.createElement("style");
                                    e.type = "text/css";
                                    var t = r || n.nc;
                                    return t && e.setAttribute("nonce", t), e
                                }())) {
                                var i, l;
                                (i = t).styleSheet ? i.styleSheet.cssText = o : i.appendChild(document.createTextNode(o)), l = t, (document.head || document.getElementsByTagName("head")[0]).appendChild(l)
                            }
                            e++
                        },
                        remove: function() {
                            --e || !t || (t.parentNode && t.parentNode.removeChild(t), t = null)
                        }
                    }
                },
                l = function() {
                    var e = i();
                    return function(t, n) {
                        o.useEffect(function() {
                            return e.add(t),
                                function() {
                                    e.remove()
                                }
                        }, [t && n])
                    }
                },
                a = function() {
                    var e = l();
                    return function(t) {
                        return e(t.styles, t.dynamic), null
                    }
                }
        },
        11458: (e, t, n) => {
            n.d(t, {
                q: () => a
            });
            var r = n(93264);

            function o(e, t) {
                return "function" == typeof e ? e(t) : e && (e.current = t), e
            }
            var i = "undefined" != typeof window ? r.useLayoutEffect : r.useEffect,
                l = new WeakMap;

            function a(e, t) {
                var n, a, u, c = (n = t || null, a = function(t) {
                    return e.forEach(function(e) {
                        return o(e, t)
                    })
                }, (u = (0, r.useState)(function() {
                    return {
                        value: n,
                        callback: a,
                        facade: {
                            get current() {
                                return u.value
                            },
                            set current(value) {
                                var e = u.value;
                                e !== value && (u.value = value, u.callback(value, e))
                            }
                        }
                    }
                })[0]).callback = a, u.facade);
                return i(function() {
                    var t = l.get(c);
                    if (t) {
                        var n = new Set(t),
                            r = new Set(e),
                            i = c.current;
                        n.forEach(function(e) {
                            r.has(e) || o(e, null)
                        }), r.forEach(function(e) {
                            n.has(e) || o(e, i)
                        })
                    }
                    l.set(c, e)
                }, [e]), c
            }
        },
        64608: (e, t, n) => {
            n.d(t, {
                Nr: () => a,
                y1: () => o
            });
            var r = n(93264);

            function o(e, t, n) {
                var o = this,
                    i = (0, r.useRef)(null),
                    l = (0, r.useRef)(0),
                    a = (0, r.useRef)(null),
                    u = (0, r.useRef)([]),
                    c = (0, r.useRef)(),
                    s = (0, r.useRef)(),
                    d = (0, r.useRef)(e),
                    f = (0, r.useRef)(!0);
                d.current = e;
                var p = "undefined" != typeof window,
                    v = !t && 0 !== t && p;
                if ("function" != typeof e) throw TypeError("Expected a function");
                t = +t || 0;
                var m = !!(n = n || {}).leading,
                    h = !("trailing" in n) || !!n.trailing,
                    g = "maxWait" in n,
                    y = "debounceOnServer" in n && !!n.debounceOnServer,
                    b = g ? Math.max(+n.maxWait || 0, t) : null;
                return (0, r.useEffect)(function() {
                    return f.current = !0,
                        function() {
                            f.current = !1
                        }
                }, []), (0, r.useMemo)(function() {
                    var e = function(e) {
                            var t = u.current,
                                n = c.current;
                            return u.current = c.current = null, l.current = e, s.current = d.current.apply(n, t)
                        },
                        n = function(e, t) {
                            v && cancelAnimationFrame(a.current), a.current = v ? requestAnimationFrame(e) : setTimeout(e, t)
                        },
                        r = function(e) {
                            if (!f.current) return !1;
                            var n = e - i.current;
                            return !i.current || n >= t || n < 0 || g && e - l.current >= b
                        },
                        w = function(t) {
                            return a.current = null, h && u.current ? e(t) : (u.current = c.current = null, s.current)
                        },
                        E = function e() {
                            var o = Date.now();
                            if (r(o)) return w(o);
                            if (f.current) {
                                var a = t - (o - i.current);
                                n(e, g ? Math.min(a, b - (o - l.current)) : a)
                            }
                        },
                        x = function() {
                            if (p || y) {
                                var d = Date.now(),
                                    v = r(d);
                                if (u.current = [].slice.call(arguments), c.current = o, i.current = d, v) {
                                    if (!a.current && f.current) return l.current = i.current, n(E, t), m ? e(i.current) : s.current;
                                    if (g) return n(E, t), e(i.current)
                                }
                                return a.current || n(E, t), s.current
                            }
                        };
                    return x.cancel = function() {
                        a.current && (v ? cancelAnimationFrame(a.current) : clearTimeout(a.current)), l.current = 0, u.current = i.current = c.current = a.current = null
                    }, x.isPending = function() {
                        return !!a.current
                    }, x.flush = function() {
                        return a.current ? w(Date.now()) : s.current
                    }, x
                }, [m, g, t, b, h, v, p, y])
            }

            function i(e, t) {
                return e === t
            }

            function l(e, t) {
                return t
            }

            function a(e, t, n) {
                var a = n && n.equalityFn || i,
                    u = (0, r.useReducer)(l, e),
                    c = u[0],
                    s = u[1],
                    d = o((0, r.useCallback)(function(e) {
                        return s(e)
                    }, [s]), t, n),
                    f = (0, r.useRef)(e);
                return a(f.current, e) || (d(e), f.current = e), a(c, e) && d.cancel(), [c, d]
            }
        },
        15949: (e, t, n) => {
            n.d(t, {
                L: () => l
            });
            var r = n(87204),
                o = n(93264),
                i = function(e) {
                    var t = e.sideCar,
                        n = (0, r._T)(e, ["sideCar"]);
                    if (!t) throw Error("Sidecar: please provide `sideCar` property to import the right car");
                    var i = t.read();
                    if (!i) throw Error("Sidecar medium not found");
                    return o.createElement(i, (0, r.pi)({}, n))
                };

            function l(e, t) {
                return e.useMedium(t), i
            }
            i.isSideCarExport = !0
        },
        59434: (e, t, n) => {
            n.d(t, {
                _: () => i
            });
            var r = n(87204);

            function o(e) {
                return e
            }

            function i(e) {
                void 0 === e && (e = {});
                var t, n, i, l = (void 0 === t && (t = o), n = [], i = !1, {
                    read: function() {
                        if (i) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
                        return n.length ? n[n.length - 1] : null
                    },
                    useMedium: function(e) {
                        var r = t(e, i);
                        return n.push(r),
                            function() {
                                n = n.filter(function(e) {
                                    return e !== r
                                })
                            }
                    },
                    assignSyncMedium: function(e) {
                        for (i = !0; n.length;) {
                            var t = n;
                            n = [], t.forEach(e)
                        }
                        n = {
                            push: function(t) {
                                return e(t)
                            },
                            filter: function() {
                                return n
                            }
                        }
                    },
                    assignMedium: function(e) {
                        i = !0;
                        var t = [];
                        if (n.length) {
                            var r = n;
                            n = [], r.forEach(e), t = n
                        }
                        var o = function() {
                                var n = t;
                                t = [], n.forEach(e)
                            },
                            l = function() {
                                return Promise.resolve().then(o)
                            };
                        l(), n = {
                            push: function(e) {
                                t.push(e), l()
                            },
                            filter: function(e) {
                                return t = t.filter(e), n
                            }
                        }
                    }
                });
                return l.options = (0, r.pi)({
                    async: !0,
                    ssr: !1
                }, e), l
            }
        },
        69933: (e, t, n) => {
            n.d(t, {
                M: () => r
            });

            function r(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (e ? .(r), !1 === n || !r.defaultPrevented) return t ? .(r)
                }
            }
        },
        38001: (e, t, n) => {
            n.d(t, {
                Ee: () => w,
                NY: () => E,
                fC: () => b
            });
            var r = n(93264),
                o = n(34500),
                i = n(94884),
                l = n(86025),
                a = n(95641),
                u = n(12428),
                c = "Avatar",
                [s, d] = (0, o.b)(c),
                [f, p] = s(c),
                v = r.forwardRef((e, t) => {
                    let {
                        __scopeAvatar: n,
                        ...o
                    } = e, [i, l] = r.useState("idle");
                    return (0, u.jsx)(f, {
                        scope: n,
                        imageLoadingStatus: i,
                        onImageLoadingStatusChange: l,
                        children: (0, u.jsx)(a.WV.span, { ...o,
                            ref: t
                        })
                    })
                });
            v.displayName = c;
            var m = "AvatarImage",
                h = r.forwardRef((e, t) => {
                    let {
                        __scopeAvatar: n,
                        src: o,
                        onLoadingStatusChange: c = () => {},
                        ...s
                    } = e, d = p(m, n), f = function(e) {
                        let [t, n] = r.useState("idle");
                        return (0, l.b)(() => {
                            if (!e) {
                                n("error");
                                return
                            }
                            let t = !0,
                                r = new window.Image,
                                o = e => () => {
                                    t && n(e)
                                };
                            return n("loading"), r.onload = o("loaded"), r.onerror = o("error"), r.src = e, () => {
                                t = !1
                            }
                        }, [e]), t
                    }(o), v = (0, i.W)(e => {
                        c(e), d.onImageLoadingStatusChange(e)
                    });
                    return (0, l.b)(() => {
                        "idle" !== f && v(f)
                    }, [f, v]), "loaded" === f ? (0, u.jsx)(a.WV.img, { ...s,
                        ref: t,
                        src: o
                    }) : null
                });
            h.displayName = m;
            var g = "AvatarFallback",
                y = r.forwardRef((e, t) => {
                    let {
                        __scopeAvatar: n,
                        delayMs: o,
                        ...i
                    } = e, l = p(g, n), [c, s] = r.useState(void 0 === o);
                    return r.useEffect(() => {
                        if (void 0 !== o) {
                            let e = window.setTimeout(() => s(!0), o);
                            return () => window.clearTimeout(e)
                        }
                    }, [o]), c && "loaded" !== l.imageLoadingStatus ? (0, u.jsx)(a.WV.span, { ...i,
                        ref: t
                    }) : null
                });
            y.displayName = g;
            var b = v,
                w = h,
                E = y
        },
        16335: (e, t, n) => {
            n.d(t, {
                fC: () => R,
                z$: () => S
            });
            var r = n(93264),
                o = n(99385),
                i = n(34500),
                l = n(69933),
                a = n(5425),
                u = n(93779),
                c = n(42095),
                s = n(79523),
                d = n(95641),
                f = n(12428),
                p = "Checkbox",
                [v, m] = (0, i.b)(p),
                [h, g] = v(p),
                y = r.forwardRef((e, t) => {
                    let {
                        __scopeCheckbox: n,
                        name: i,
                        checked: u,
                        defaultChecked: c,
                        required: s,
                        disabled: p,
                        value: v = "on",
                        onCheckedChange: m,
                        ...g
                    } = e, [y, b] = r.useState(null), w = (0, o.e)(t, e => b(e)), R = r.useRef(!1), S = !y || !!y.closest("form"), [k = !1, A] = (0, a.T)({
                        prop: u,
                        defaultProp: c,
                        onChange: m
                    }), P = r.useRef(k);
                    return r.useEffect(() => {
                        let e = null == y ? void 0 : y.form;
                        if (e) {
                            let t = () => A(P.current);
                            return e.addEventListener("reset", t), () => e.removeEventListener("reset", t)
                        }
                    }, [y, A]), (0, f.jsxs)(h, {
                        scope: n,
                        state: k,
                        disabled: p,
                        children: [(0, f.jsx)(d.WV.button, {
                            type: "button",
                            role: "checkbox",
                            "aria-checked": x(k) ? "mixed" : k,
                            "aria-required": s,
                            "data-state": C(k),
                            "data-disabled": p ? "" : void 0,
                            disabled: p,
                            value: v,
                            ...g,
                            ref: w,
                            onKeyDown: (0, l.M)(e.onKeyDown, e => {
                                "Enter" === e.key && e.preventDefault()
                            }),
                            onClick: (0, l.M)(e.onClick, e => {
                                A(e => !!x(e) || !e), S && (R.current = e.isPropagationStopped(), R.current || e.stopPropagation())
                            })
                        }), S && (0, f.jsx)(E, {
                            control: y,
                            bubbles: !R.current,
                            name: i,
                            value: v,
                            checked: k,
                            required: s,
                            disabled: p,
                            style: {
                                transform: "translateX(-100%)"
                            }
                        })]
                    })
                });
            y.displayName = p;
            var b = "CheckboxIndicator",
                w = r.forwardRef((e, t) => {
                    let {
                        __scopeCheckbox: n,
                        forceMount: r,
                        ...o
                    } = e, i = g(b, n);
                    return (0, f.jsx)(s.z, {
                        present: r || x(i.state) || !0 === i.state,
                        children: (0, f.jsx)(d.WV.span, {
                            "data-state": C(i.state),
                            "data-disabled": i.disabled ? "" : void 0,
                            ...o,
                            ref: t,
                            style: {
                                pointerEvents: "none",
                                ...e.style
                            }
                        })
                    })
                });
            w.displayName = b;
            var E = e => {
                let {
                    control: t,
                    checked: n,
                    bubbles: o = !0,
                    ...i
                } = e, l = r.useRef(null), a = (0, u.D)(n), s = (0, c.t)(t);
                return r.useEffect(() => {
                    let e = l.current,
                        t = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "checked").set;
                    if (a !== n && t) {
                        let r = new Event("click", {
                            bubbles: o
                        });
                        e.indeterminate = x(n), t.call(e, !x(n) && n), e.dispatchEvent(r)
                    }
                }, [a, n, o]), (0, f.jsx)("input", {
                    type: "checkbox",
                    "aria-hidden": !0,
                    defaultChecked: !x(n) && n,
                    ...i,
                    tabIndex: -1,
                    ref: l,
                    style: { ...e.style,
                        ...s,
                        position: "absolute",
                        pointerEvents: "none",
                        opacity: 0,
                        margin: 0
                    }
                })
            };

            function x(e) {
                return "indeterminate" === e
            }

            function C(e) {
                return x(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }
            var R = y,
                S = w
        },
        84364: (e, t, n) => {
            n.d(t, {
                B: () => u
            });
            var r = n(93264),
                o = n(34500),
                i = n(99385),
                l = n(8190),
                a = n(12428);

            function u(e) {
                let t = e + "CollectionProvider",
                    [n, u] = (0, o.b)(t),
                    [c, s] = n(t, {
                        collectionRef: {
                            current: null
                        },
                        itemMap: new Map
                    }),
                    d = e => {
                        let {
                            scope: t,
                            children: n
                        } = e, o = r.useRef(null), i = r.useRef(new Map).current;
                        return (0, a.jsx)(c, {
                            scope: t,
                            itemMap: i,
                            collectionRef: o,
                            children: n
                        })
                    };
                d.displayName = t;
                let f = e + "CollectionSlot",
                    p = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: r
                        } = e, o = s(f, n), u = (0, i.e)(t, o.collectionRef);
                        return (0, a.jsx)(l.g7, {
                            ref: u,
                            children: r
                        })
                    });
                p.displayName = f;
                let v = e + "CollectionItemSlot",
                    m = "data-radix-collection-item",
                    h = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o,
                            ...u
                        } = e, c = r.useRef(null), d = (0, i.e)(t, c), f = s(v, n);
                        return r.useEffect(() => (f.itemMap.set(c, {
                            ref: c,
                            ...u
                        }), () => void f.itemMap.delete(c))), (0, a.jsx)(l.g7, {
                            [m]: "",
                            ref: d,
                            children: o
                        })
                    });
                return h.displayName = v, [{
                    Provider: d,
                    Slot: p,
                    ItemSlot: h
                }, function(t) {
                    let n = s(e + "CollectionConsumer", t);
                    return r.useCallback(() => {
                        let e = n.collectionRef.current;
                        if (!e) return [];
                        let t = Array.from(e.querySelectorAll("[".concat(m, "]")));
                        return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current))
                    }, [n.collectionRef, n.itemMap])
                }, u]
            }
        },
        34500: (e, t, n) => {
            n.d(t, {
                b: () => l,
                k: () => i
            });
            var r = n(93264),
                o = n(12428);

            function i(e, t) {
                let n = r.createContext(t);

                function i(e) {
                    let {
                        children: t,
                        ...i
                    } = e, l = r.useMemo(() => i, Object.values(i));
                    return (0, o.jsx)(n.Provider, {
                        value: l,
                        children: t
                    })
                }
                return i.displayName = e + "Provider", [i, function(o) {
                    let i = r.useContext(n);
                    if (i) return i;
                    if (void 0 !== t) return t;
                    throw Error(`\`${o}\` must be used within \`${e}\``)
                }]
            }

            function l(e, t = []) {
                let n = [],
                    i = () => {
                        let t = n.map(e => r.createContext(e));
                        return function(n) {
                            let o = n ? .[e] || t;
                            return r.useMemo(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: o
                                }
                            }), [n, o])
                        }
                    };
                return i.scopeName = e, [function(t, i) {
                    let l = r.createContext(i),
                        a = n.length;

                    function u(t) {
                        let {
                            scope: n,
                            children: i,
                            ...u
                        } = t, c = n ? .[e][a] || l, s = r.useMemo(() => u, Object.values(u));
                        return (0, o.jsx)(c.Provider, {
                            value: s,
                            children: i
                        })
                    }
                    return n = [...n, i], u.displayName = t + "Provider", [u, function(n, o) {
                        let u = o ? .[e][a] || l,
                            c = r.useContext(u);
                        if (c) return c;
                        if (void 0 !== i) return i;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let o = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return r.useMemo(() => ({
                                [`__scope${t.scopeName}`]: o
                            }), [o])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(i, ...t)]
            }
        },
        45258: (e, t, n) => {
            n.d(t, {
                $N: () => V,
                Be: () => z,
                Dx: () => en,
                VY: () => et,
                aV: () => ee,
                dk: () => er,
                fC: () => G,
                h_: () => Q,
                jm: () => q,
                p8: () => E,
                x8: () => eo,
                xz: () => J
            });
            var r = n(93264),
                o = n(69933),
                i = n(99385),
                l = n(34500),
                a = n(5210),
                u = n(5425),
                c = n(78681),
                s = n(39788),
                d = n(2010),
                f = n(79523),
                p = n(95641),
                v = n(3601),
                m = n(27263),
                h = n(75568),
                g = n(8190),
                y = n(12428),
                b = "Dialog",
                [w, E] = (0, l.b)(b),
                [x, C] = w(b),
                R = e => {
                    let {
                        __scopeDialog: t,
                        children: n,
                        open: o,
                        defaultOpen: i,
                        onOpenChange: l,
                        modal: c = !0
                    } = e, s = r.useRef(null), d = r.useRef(null), [f = !1, p] = (0, u.T)({
                        prop: o,
                        defaultProp: i,
                        onChange: l
                    });
                    return (0, y.jsx)(x, {
                        scope: t,
                        triggerRef: s,
                        contentRef: d,
                        contentId: (0, a.M)(),
                        titleId: (0, a.M)(),
                        descriptionId: (0, a.M)(),
                        open: f,
                        onOpenChange: p,
                        onOpenToggle: r.useCallback(() => p(e => !e), [p]),
                        modal: c,
                        children: n
                    })
                };
            R.displayName = b;
            var S = "DialogTrigger",
                k = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, l = C(S, n), a = (0, i.e)(t, l.triggerRef);
                    return (0, y.jsx)(p.WV.button, {
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": l.open,
                        "aria-controls": l.contentId,
                        "data-state": K(l.open),
                        ...r,
                        ref: a,
                        onClick: (0, o.M)(e.onClick, l.onOpenToggle)
                    })
                });
            k.displayName = S;
            var A = "DialogPortal",
                [P, N] = w(A, {
                    forceMount: void 0
                }),
                O = e => {
                    let {
                        __scopeDialog: t,
                        forceMount: n,
                        children: o,
                        container: i
                    } = e, l = C(A, t);
                    return (0, y.jsx)(P, {
                        scope: t,
                        forceMount: n,
                        children: r.Children.map(o, e => (0, y.jsx)(f.z, {
                            present: n || l.open,
                            children: (0, y.jsx)(d.h, {
                                asChild: !0,
                                container: i,
                                children: e
                            })
                        }))
                    })
                };
            O.displayName = A;
            var D = "DialogOverlay",
                M = r.forwardRef((e, t) => {
                    let n = N(D, e.__scopeDialog),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        i = C(D, e.__scopeDialog);
                    return i.modal ? (0, y.jsx)(f.z, {
                        present: r || i.open,
                        children: (0, y.jsx)(T, { ...o,
                            ref: t
                        })
                    }) : null
                });
            M.displayName = D;
            var T = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, o = C(D, n);
                    return (0, y.jsx)(m.Z, {
                        as: g.g7,
                        allowPinchZoom: !0,
                        shards: [o.contentRef],
                        children: (0, y.jsx)(p.WV.div, {
                            "data-state": K(o.open),
                            ...r,
                            ref: t,
                            style: {
                                pointerEvents: "auto",
                                ...r.style
                            }
                        })
                    })
                }),
                L = "DialogContent",
                I = r.forwardRef((e, t) => {
                    let n = N(L, e.__scopeDialog),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        i = C(L, e.__scopeDialog);
                    return (0, y.jsx)(f.z, {
                        present: r || i.open,
                        children: i.modal ? (0, y.jsx)(j, { ...o,
                            ref: t
                        }) : (0, y.jsx)(F, { ...o,
                            ref: t
                        })
                    })
                });
            I.displayName = L;
            var j = r.forwardRef((e, t) => {
                    let n = C(L, e.__scopeDialog),
                        l = r.useRef(null),
                        a = (0, i.e)(t, n.contentRef, l);
                    return r.useEffect(() => {
                        let e = l.current;
                        if (e) return (0, h.Ry)(e)
                    }, []), (0, y.jsx)(W, { ...e,
                        ref: a,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: !0,
                        onCloseAutoFocus: (0, o.M)(e.onCloseAutoFocus, e => {
                            var t;
                            e.preventDefault(), null === (t = n.triggerRef.current) || void 0 === t || t.focus()
                        }),
                        onPointerDownOutside: (0, o.M)(e.onPointerDownOutside, e => {
                            let t = e.detail.originalEvent,
                                n = 0 === t.button && !0 === t.ctrlKey;
                            (2 === t.button || n) && e.preventDefault()
                        }),
                        onFocusOutside: (0, o.M)(e.onFocusOutside, e => e.preventDefault())
                    })
                }),
                F = r.forwardRef((e, t) => {
                    let n = C(L, e.__scopeDialog),
                        o = r.useRef(!1),
                        i = r.useRef(!1);
                    return (0, y.jsx)(W, { ...e,
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var r, l;
                            null === (r = e.onCloseAutoFocus) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current || null === (l = n.triggerRef.current) || void 0 === l || l.focus(), t.preventDefault()), o.current = !1, i.current = !1
                        },
                        onInteractOutside: t => {
                            var r, l;
                            null === (r = e.onInteractOutside) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current = !0, "pointerdown" !== t.detail.originalEvent.type || (i.current = !0));
                            let a = t.target;
                            (null === (l = n.triggerRef.current) || void 0 === l ? void 0 : l.contains(a)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && i.current && t.preventDefault()
                        }
                    })
                }),
                W = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        trapFocus: o,
                        onOpenAutoFocus: l,
                        onCloseAutoFocus: a,
                        ...u
                    } = e, d = C(L, n), f = r.useRef(null), p = (0, i.e)(t, f);
                    return (0, v.EW)(), (0, y.jsxs)(y.Fragment, {
                        children: [(0, y.jsx)(s.M, {
                            asChild: !0,
                            loop: !0,
                            trapped: o,
                            onMountAutoFocus: l,
                            onUnmountAutoFocus: a,
                            children: (0, y.jsx)(c.XB, {
                                role: "dialog",
                                id: d.contentId,
                                "aria-describedby": d.descriptionId,
                                "aria-labelledby": d.titleId,
                                "data-state": K(d.open),
                                ...u,
                                ref: p,
                                onDismiss: () => d.onOpenChange(!1)
                            })
                        }), (0, y.jsxs)(y.Fragment, {
                            children: [(0, y.jsx)(Z, {
                                titleId: d.titleId
                            }), (0, y.jsx)(X, {
                                contentRef: f,
                                descriptionId: d.descriptionId
                            })]
                        })]
                    })
                }),
                _ = "DialogTitle",
                V = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, o = C(_, n);
                    return (0, y.jsx)(p.WV.h2, {
                        id: o.titleId,
                        ...r,
                        ref: t
                    })
                });
            V.displayName = _;
            var B = "DialogDescription",
                z = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, o = C(B, n);
                    return (0, y.jsx)(p.WV.p, {
                        id: o.descriptionId,
                        ...r,
                        ref: t
                    })
                });
            z.displayName = B;
            var H = "DialogClose",
                $ = r.forwardRef((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, i = C(H, n);
                    return (0, y.jsx)(p.WV.button, {
                        type: "button",
                        ...r,
                        ref: t,
                        onClick: (0, o.M)(e.onClick, () => i.onOpenChange(!1))
                    })
                });

            function K(e) {
                return e ? "open" : "closed"
            }
            $.displayName = H;
            var U = "DialogTitleWarning",
                [q, Y] = (0, l.k)(U, {
                    contentName: L,
                    titleName: _,
                    docsSlug: "dialog"
                }),
                Z = e => {
                    let {
                        titleId: t
                    } = e, n = Y(U), o = "`".concat(n.contentName, "` requires a `").concat(n.titleName, "` for the component to be accessible for screen reader users.\n\nIf you want to hide the `").concat(n.titleName, "`, you can wrap it with our VisuallyHidden component.\n\nFor more information, see https://radix-ui.com/primitives/docs/components/").concat(n.docsSlug);
                    return r.useEffect(() => {
                        t && !document.getElementById(t) && console.error(o)
                    }, [o, t]), null
                },
                X = e => {
                    let {
                        contentRef: t,
                        descriptionId: n
                    } = e, o = Y("DialogDescriptionWarning"), i = "Warning: Missing `Description` or `aria-describedby={undefined}` for {".concat(o.contentName, "}.");
                    return r.useEffect(() => {
                        var e;
                        let r = null === (e = t.current) || void 0 === e ? void 0 : e.getAttribute("aria-describedby");
                        n && r && !document.getElementById(n) && console.warn(i)
                    }, [i, t, n]), null
                },
                G = R,
                J = k,
                Q = O,
                ee = M,
                et = I,
                en = V,
                er = z,
                eo = $
        },
        45686: (e, t, n) => {
            n.d(t, {
                gm: () => i
            });
            var r = n(93264);
            n(12428);
            var o = r.createContext(void 0);

            function i(e) {
                let t = r.useContext(o);
                return e || t || "ltr"
            }
        },
        78681: (e, t, n) => {
            n.d(t, {
                I0: () => g,
                XB: () => f,
                fC: () => h
            });
            var r, o = n(93264),
                i = n(69933),
                l = n(95641),
                a = n(99385),
                u = n(94884),
                c = n(12428),
                s = "dismissableLayer.update",
                d = o.createContext({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                f = o.forwardRef((e, t) => {
                    var n, f;
                    let {
                        disableOutsidePointerEvents: p = !1,
                        onEscapeKeyDown: h,
                        onPointerDownOutside: g,
                        onFocusOutside: y,
                        onInteractOutside: b,
                        onDismiss: w,
                        ...E
                    } = e, x = o.useContext(d), [C, R] = o.useState(null), S = null !== (f = null == C ? void 0 : C.ownerDocument) && void 0 !== f ? f : null === (n = globalThis) || void 0 === n ? void 0 : n.document, [, k] = o.useState({}), A = (0, a.e)(t, e => R(e)), P = Array.from(x.layers), [N] = [...x.layersWithOutsidePointerEventsDisabled].slice(-1), O = P.indexOf(N), D = C ? P.indexOf(C) : -1, M = x.layersWithOutsidePointerEventsDisabled.size > 0, T = D >= O, L = function(e) {
                        var t;
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null === (t = globalThis) || void 0 === t ? void 0 : t.document,
                            r = (0, u.W)(e),
                            i = o.useRef(!1),
                            l = o.useRef(() => {});
                        return o.useEffect(() => {
                            let e = e => {
                                    if (e.target && !i.current) {
                                        let t = function() {
                                                m("dismissableLayer.pointerDownOutside", r, o, {
                                                    discrete: !0
                                                })
                                            },
                                            o = {
                                                originalEvent: e
                                            };
                                        "touch" === e.pointerType ? (n.removeEventListener("click", l.current), l.current = t, n.addEventListener("click", l.current, {
                                            once: !0
                                        })) : t()
                                    } else n.removeEventListener("click", l.current);
                                    i.current = !1
                                },
                                t = window.setTimeout(() => {
                                    n.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(t), n.removeEventListener("pointerdown", e), n.removeEventListener("click", l.current)
                            }
                        }, [n, r]), {
                            onPointerDownCapture: () => i.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...x.branches].some(e => e.contains(t));
                        !T || n || (null == g || g(e), null == b || b(e), e.defaultPrevented || null == w || w())
                    }, S), I = function(e) {
                        var t;
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null === (t = globalThis) || void 0 === t ? void 0 : t.document,
                            r = (0, u.W)(e),
                            i = o.useRef(!1);
                        return o.useEffect(() => {
                            let e = e => {
                                e.target && !i.current && m("dismissableLayer.focusOutside", r, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return n.addEventListener("focusin", e), () => n.removeEventListener("focusin", e)
                        }, [n, r]), {
                            onFocusCapture: () => i.current = !0,
                            onBlurCapture: () => i.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        [...x.branches].some(e => e.contains(t)) || (null == y || y(e), null == b || b(e), e.defaultPrevented || null == w || w())
                    }, S);
                    return ! function(e, t = globalThis ? .document) {
                        let n = (0, u.W)(e);
                        o.useEffect(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e, {
                                capture: !0
                            }), () => t.removeEventListener("keydown", e, {
                                capture: !0
                            })
                        }, [n, t])
                    }(e => {
                        D !== x.layers.size - 1 || (null == h || h(e), !e.defaultPrevented && w && (e.preventDefault(), w()))
                    }, S), o.useEffect(() => {
                        if (C) return p && (0 === x.layersWithOutsidePointerEventsDisabled.size && (r = S.body.style.pointerEvents, S.body.style.pointerEvents = "none"), x.layersWithOutsidePointerEventsDisabled.add(C)), x.layers.add(C), v(), () => {
                            p && 1 === x.layersWithOutsidePointerEventsDisabled.size && (S.body.style.pointerEvents = r)
                        }
                    }, [C, S, p, x]), o.useEffect(() => () => {
                        C && (x.layers.delete(C), x.layersWithOutsidePointerEventsDisabled.delete(C), v())
                    }, [C, x]), o.useEffect(() => {
                        let e = () => k({});
                        return document.addEventListener(s, e), () => document.removeEventListener(s, e)
                    }, []), (0, c.jsx)(l.WV.div, { ...E,
                        ref: A,
                        style: {
                            pointerEvents: M ? T ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: (0, i.M)(e.onFocusCapture, I.onFocusCapture),
                        onBlurCapture: (0, i.M)(e.onBlurCapture, I.onBlurCapture),
                        onPointerDownCapture: (0, i.M)(e.onPointerDownCapture, L.onPointerDownCapture)
                    })
                });
            f.displayName = "DismissableLayer";
            var p = o.forwardRef((e, t) => {
                let n = o.useContext(d),
                    r = o.useRef(null),
                    i = (0, a.e)(t, r);
                return o.useEffect(() => {
                    let e = r.current;
                    if (e) return n.branches.add(e), () => {
                        n.branches.delete(e)
                    }
                }, [n.branches]), (0, c.jsx)(l.WV.div, { ...e,
                    ref: i
                })
            });

            function v() {
                let e = new CustomEvent(s);
                document.dispatchEvent(e)
            }

            function m(e, t, n, r) {
                let {
                    discrete: o
                } = r, i = n.originalEvent.target, a = new CustomEvent(e, {
                    bubbles: !1,
                    cancelable: !0,
                    detail: n
                });
                t && i.addEventListener(e, t, {
                    once: !0
                }), o ? (0, l.jH)(i, a) : i.dispatchEvent(a)
            }
            p.displayName = "DismissableLayerBranch";
            var h = f,
                g = p
        },
        3601: (e, t, n) => {
            n.d(t, {
                EW: () => i
            });
            var r = n(93264),
                o = 0;

            function i() {
                r.useEffect(() => {
                    var e, t;
                    let n = document.querySelectorAll("[data-radix-focus-guard]");
                    return document.body.insertAdjacentElement("afterbegin", null !== (e = n[0]) && void 0 !== e ? e : l()), document.body.insertAdjacentElement("beforeend", null !== (t = n[1]) && void 0 !== t ? t : l()), o++, () => {
                        1 === o && document.querySelectorAll("[data-radix-focus-guard]").forEach(e => e.remove()), o--
                    }
                }, [])
            }

            function l() {
                let e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
            }
        },
        39788: (e, t, n) => {
            n.d(t, {
                M: () => d
            });
            var r = n(93264),
                o = n(99385),
                i = n(95641),
                l = n(94884),
                a = n(12428),
                u = "focusScope.autoFocusOnMount",
                c = "focusScope.autoFocusOnUnmount",
                s = {
                    bubbles: !1,
                    cancelable: !0
                },
                d = r.forwardRef((e, t) => {
                    let {
                        loop: n = !1,
                        trapped: d = !1,
                        onMountAutoFocus: h,
                        onUnmountAutoFocus: g,
                        ...y
                    } = e, [b, w] = r.useState(null), E = (0, l.W)(h), x = (0, l.W)(g), C = r.useRef(null), R = (0, o.e)(t, e => w(e)), S = r.useRef({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    r.useEffect(() => {
                        if (d) {
                            let e = function(e) {
                                    if (S.paused || !b) return;
                                    let t = e.target;
                                    b.contains(t) ? C.current = t : v(C.current, {
                                        select: !0
                                    })
                                },
                                t = function(e) {
                                    if (S.paused || !b) return;
                                    let t = e.relatedTarget;
                                    null === t || b.contains(t) || v(C.current, {
                                        select: !0
                                    })
                                };
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            let n = new MutationObserver(function(e) {
                                if (document.activeElement === document.body)
                                    for (let t of e) t.removedNodes.length > 0 && v(b)
                            });
                            return b && n.observe(b, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                            }
                        }
                    }, [d, b, S.paused]), r.useEffect(() => {
                        if (b) {
                            m.add(S);
                            let e = document.activeElement;
                            if (!b.contains(e)) {
                                let t = new CustomEvent(u, s);
                                b.addEventListener(u, E), b.dispatchEvent(t), t.defaultPrevented || (function(e) {
                                    let {
                                        select: t = !1
                                    } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = document.activeElement;
                                    for (let r of e)
                                        if (v(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }(f(b).filter(e => "A" !== e.tagName), {
                                    select: !0
                                }), document.activeElement === e && v(b))
                            }
                            return () => {
                                b.removeEventListener(u, E), setTimeout(() => {
                                    let t = new CustomEvent(c, s);
                                    b.addEventListener(c, x), b.dispatchEvent(t), t.defaultPrevented || v(null != e ? e : document.body, {
                                        select: !0
                                    }), b.removeEventListener(c, x), m.remove(S)
                                }, 0)
                            }
                        }
                    }, [b, E, x, S]);
                    let k = r.useCallback(e => {
                        if (!n && !d || S.paused) return;
                        let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            r = document.activeElement;
                        if (t && r) {
                            let t = e.currentTarget,
                                [o, i] = function(e) {
                                    let t = f(e);
                                    return [p(t, e), p(t.reverse(), e)]
                                }(t);
                            o && i ? e.shiftKey || r !== i ? e.shiftKey && r === o && (e.preventDefault(), n && v(i, {
                                select: !0
                            })) : (e.preventDefault(), n && v(o, {
                                select: !0
                            })) : r === t && e.preventDefault()
                        }
                    }, [n, d, S.paused]);
                    return (0, a.jsx)(i.WV.div, {
                        tabIndex: -1,
                        ...y,
                        ref: R,
                        onKeyDown: k
                    })
                });

            function f(e) {
                let t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            let t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function p(e, t) {
                for (let n of e)
                    if (! function(e, t) {
                            let {
                                upTo: n
                            } = t;
                            if ("hidden" === getComputedStyle(e).visibility) return !0;
                            for (; e && (void 0 === n || e !== n);) {
                                if ("none" === getComputedStyle(e).display) return !0;
                                e = e.parentElement
                            }
                            return !1
                        }(n, {
                            upTo: t
                        })) return n
            }

            function v(e) {
                let {
                    select: t = !1
                } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (e && e.focus) {
                    var n;
                    let r = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== r && (n = e) instanceof HTMLInputElement && "select" in n && t && e.select()
                }
            }
            d.displayName = "FocusScope";
            var m = function() {
                let e = [];
                return {
                    add(t) {
                        let n = e[0];
                        t !== n && (null == n || n.pause()), (e = h(e, t)).unshift(t)
                    },
                    remove(t) {
                        var n;
                        null === (n = (e = h(e, t))[0]) || void 0 === n || n.resume()
                    }
                }
            }();

            function h(e, t) {
                let n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
        },
        5210: (e, t, n) => {
            n.d(t, {
                M: () => u
            });
            var r, o = n(93264),
                i = n(86025),
                l = (r || (r = n.t(o, 2)))["useId".toString()] || (() => void 0),
                a = 0;

            function u(e) {
                let [t, n] = o.useState(l());
                return (0, i.b)(() => {
                    e || n(e => e ? ? String(a++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }
        },
        86675: (e, t, n) => {
            n.d(t, {
                Eh: () => U,
                QH: () => V,
                VY: () => K,
                fC: () => z,
                h_: () => $,
                xz: () => H
            });
            var r = n(93264),
                o = n(69933),
                i = n(99385),
                l = n(34500),
                a = n(78681),
                u = n(3601),
                c = n(39788),
                s = n(5210),
                d = n(88231),
                f = n(2010),
                p = n(79523),
                v = n(95641),
                m = n(8190),
                h = n(5425),
                g = n(75568),
                y = n(27263),
                b = n(12428),
                w = "Popover",
                [E, x] = (0, l.b)(w, [d.D7]),
                C = (0, d.D7)(),
                [R, S] = E(w),
                k = e => {
                    let {
                        __scopePopover: t,
                        children: n,
                        open: o,
                        defaultOpen: i,
                        onOpenChange: l,
                        modal: a = !1
                    } = e, u = C(t), c = r.useRef(null), [f, p] = r.useState(!1), [v = !1, m] = (0, h.T)({
                        prop: o,
                        defaultProp: i,
                        onChange: l
                    });
                    return (0, b.jsx)(d.fC, { ...u,
                        children: (0, b.jsx)(R, {
                            scope: t,
                            contentId: (0, s.M)(),
                            triggerRef: c,
                            open: v,
                            onOpenChange: m,
                            onOpenToggle: r.useCallback(() => m(e => !e), [m]),
                            hasCustomAnchor: f,
                            onCustomAnchorAdd: r.useCallback(() => p(!0), []),
                            onCustomAnchorRemove: r.useCallback(() => p(!1), []),
                            modal: a,
                            children: n
                        })
                    })
                };
            k.displayName = w;
            var A = "PopoverAnchor";
            r.forwardRef((e, t) => {
                let {
                    __scopePopover: n,
                    ...o
                } = e, i = S(A, n), l = C(n), {
                    onCustomAnchorAdd: a,
                    onCustomAnchorRemove: u
                } = i;
                return r.useEffect(() => (a(), () => u()), [a, u]), (0, b.jsx)(d.ee, { ...l,
                    ...o,
                    ref: t
                })
            }).displayName = A;
            var P = "PopoverTrigger",
                N = r.forwardRef((e, t) => {
                    let {
                        __scopePopover: n,
                        ...r
                    } = e, l = S(P, n), a = C(n), u = (0, i.e)(t, l.triggerRef), c = (0, b.jsx)(v.WV.button, {
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": l.open,
                        "aria-controls": l.contentId,
                        "data-state": B(l.open),
                        ...r,
                        ref: u,
                        onClick: (0, o.M)(e.onClick, l.onOpenToggle)
                    });
                    return l.hasCustomAnchor ? c : (0, b.jsx)(d.ee, {
                        asChild: !0,
                        ...a,
                        children: c
                    })
                });
            N.displayName = P;
            var O = "PopoverPortal",
                [D, M] = E(O, {
                    forceMount: void 0
                }),
                T = e => {
                    let {
                        __scopePopover: t,
                        forceMount: n,
                        children: r,
                        container: o
                    } = e, i = S(O, t);
                    return (0, b.jsx)(D, {
                        scope: t,
                        forceMount: n,
                        children: (0, b.jsx)(p.z, {
                            present: n || i.open,
                            children: (0, b.jsx)(f.h, {
                                asChild: !0,
                                container: o,
                                children: r
                            })
                        })
                    })
                };
            T.displayName = O;
            var L = "PopoverContent",
                I = r.forwardRef((e, t) => {
                    let n = M(L, e.__scopePopover),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        i = S(L, e.__scopePopover);
                    return (0, b.jsx)(p.z, {
                        present: r || i.open,
                        children: i.modal ? (0, b.jsx)(j, { ...o,
                            ref: t
                        }) : (0, b.jsx)(F, { ...o,
                            ref: t
                        })
                    })
                });
            I.displayName = L;
            var j = r.forwardRef((e, t) => {
                    let n = S(L, e.__scopePopover),
                        l = r.useRef(null),
                        a = (0, i.e)(t, l),
                        u = r.useRef(!1);
                    return r.useEffect(() => {
                        let e = l.current;
                        if (e) return (0, g.Ry)(e)
                    }, []), (0, b.jsx)(y.Z, {
                        as: m.g7,
                        allowPinchZoom: !0,
                        children: (0, b.jsx)(W, { ...e,
                            ref: a,
                            trapFocus: n.open,
                            disableOutsidePointerEvents: !0,
                            onCloseAutoFocus: (0, o.M)(e.onCloseAutoFocus, e => {
                                var t;
                                e.preventDefault(), u.current || null === (t = n.triggerRef.current) || void 0 === t || t.focus()
                            }),
                            onPointerDownOutside: (0, o.M)(e.onPointerDownOutside, e => {
                                let t = e.detail.originalEvent,
                                    n = 0 === t.button && !0 === t.ctrlKey,
                                    r = 2 === t.button || n;
                                u.current = r
                            }, {
                                checkForDefaultPrevented: !1
                            }),
                            onFocusOutside: (0, o.M)(e.onFocusOutside, e => e.preventDefault(), {
                                checkForDefaultPrevented: !1
                            })
                        })
                    })
                }),
                F = r.forwardRef((e, t) => {
                    let n = S(L, e.__scopePopover),
                        o = r.useRef(!1),
                        i = r.useRef(!1);
                    return (0, b.jsx)(W, { ...e,
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var r, l;
                            null === (r = e.onCloseAutoFocus) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current || null === (l = n.triggerRef.current) || void 0 === l || l.focus(), t.preventDefault()), o.current = !1, i.current = !1
                        },
                        onInteractOutside: t => {
                            var r, l;
                            null === (r = e.onInteractOutside) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current = !0, "pointerdown" !== t.detail.originalEvent.type || (i.current = !0));
                            let a = t.target;
                            (null === (l = n.triggerRef.current) || void 0 === l ? void 0 : l.contains(a)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && i.current && t.preventDefault()
                        }
                    })
                }),
                W = r.forwardRef((e, t) => {
                    let {
                        __scopePopover: n,
                        trapFocus: r,
                        onOpenAutoFocus: o,
                        onCloseAutoFocus: i,
                        disableOutsidePointerEvents: l,
                        onEscapeKeyDown: s,
                        onPointerDownOutside: f,
                        onFocusOutside: p,
                        onInteractOutside: v,
                        ...m
                    } = e, h = S(L, n), g = C(n);
                    return (0, u.EW)(), (0, b.jsx)(c.M, {
                        asChild: !0,
                        loop: !0,
                        trapped: r,
                        onMountAutoFocus: o,
                        onUnmountAutoFocus: i,
                        children: (0, b.jsx)(a.XB, {
                            asChild: !0,
                            disableOutsidePointerEvents: l,
                            onInteractOutside: v,
                            onEscapeKeyDown: s,
                            onPointerDownOutside: f,
                            onFocusOutside: p,
                            onDismiss: () => h.onOpenChange(!1),
                            children: (0, b.jsx)(d.VY, {
                                "data-state": B(h.open),
                                role: "dialog",
                                id: h.contentId,
                                ...g,
                                ...m,
                                ref: t,
                                style: { ...m.style,
                                    "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                                    "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                                    "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                                    "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                                    "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                                }
                            })
                        })
                    })
                }),
                _ = "PopoverClose";
            r.forwardRef((e, t) => {
                let {
                    __scopePopover: n,
                    ...r
                } = e, i = S(_, n);
                return (0, b.jsx)(v.WV.button, {
                    type: "button",
                    ...r,
                    ref: t,
                    onClick: (0, o.M)(e.onClick, () => i.onOpenChange(!1))
                })
            }).displayName = _;
            var V = r.forwardRef((e, t) => {
                let {
                    __scopePopover: n,
                    ...r
                } = e, o = C(n);
                return (0, b.jsx)(d.Eh, { ...o,
                    ...r,
                    ref: t
                })
            });

            function B(e) {
                return e ? "open" : "closed"
            }
            V.displayName = "PopoverArrow";
            var z = k,
                H = N,
                $ = T,
                K = I,
                U = V
        },
        88231: (e, t, n) => {
            n.d(t, {
                ee: () => eq,
                Eh: () => eZ,
                VY: () => eY,
                fC: () => eU,
                D7: () => eO
            });
            var r = n(93264);
            let o = ["top", "right", "bottom", "left"],
                i = Math.min,
                l = Math.max,
                a = Math.round,
                u = Math.floor,
                c = e => ({
                    x: e,
                    y: e
                }),
                s = {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                },
                d = {
                    start: "end",
                    end: "start"
                };

            function f(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function p(e) {
                return e.split("-")[0]
            }

            function v(e) {
                return e.split("-")[1]
            }

            function m(e) {
                return "x" === e ? "y" : "x"
            }

            function h(e) {
                return "y" === e ? "height" : "width"
            }

            function g(e) {
                return ["top", "bottom"].includes(p(e)) ? "y" : "x"
            }

            function y(e) {
                return e.replace(/start|end/g, e => d[e])
            }

            function b(e) {
                return e.replace(/left|right|bottom|top/g, e => s[e])
            }

            function w(e) {
                return "number" != typeof e ? {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    ...e
                } : {
                    top: e,
                    right: e,
                    bottom: e,
                    left: e
                }
            }

            function E(e) {
                let {
                    x: t,
                    y: n,
                    width: r,
                    height: o
                } = e;
                return {
                    width: r,
                    height: o,
                    top: n,
                    left: t,
                    right: t + r,
                    bottom: n + o,
                    x: t,
                    y: n
                }
            }

            function x(e, t, n) {
                let r, {
                        reference: o,
                        floating: i
                    } = e,
                    l = g(t),
                    a = m(g(t)),
                    u = h(a),
                    c = p(t),
                    s = "y" === l,
                    d = o.x + o.width / 2 - i.width / 2,
                    f = o.y + o.height / 2 - i.height / 2,
                    y = o[u] / 2 - i[u] / 2;
                switch (c) {
                    case "top":
                        r = {
                            x: d,
                            y: o.y - i.height
                        };
                        break;
                    case "bottom":
                        r = {
                            x: d,
                            y: o.y + o.height
                        };
                        break;
                    case "right":
                        r = {
                            x: o.x + o.width,
                            y: f
                        };
                        break;
                    case "left":
                        r = {
                            x: o.x - i.width,
                            y: f
                        };
                        break;
                    default:
                        r = {
                            x: o.x,
                            y: o.y
                        }
                }
                switch (v(t)) {
                    case "start":
                        r[a] -= y * (n && s ? -1 : 1);
                        break;
                    case "end":
                        r[a] += y * (n && s ? -1 : 1)
                }
                return r
            }
            let C = async (e, t, n) => {
                let {
                    placement: r = "bottom",
                    strategy: o = "absolute",
                    middleware: i = [],
                    platform: l
                } = n, a = i.filter(Boolean), u = await (null == l.isRTL ? void 0 : l.isRTL(t)), c = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: o
                }), {
                    x: s,
                    y: d
                } = x(c, r, u), f = r, p = {}, v = 0;
                for (let n = 0; n < a.length; n++) {
                    let {
                        name: i,
                        fn: m
                    } = a[n], {
                        x: h,
                        y: g,
                        data: y,
                        reset: b
                    } = await m({
                        x: s,
                        y: d,
                        initialPlacement: r,
                        placement: f,
                        strategy: o,
                        middlewareData: p,
                        rects: c,
                        platform: l,
                        elements: {
                            reference: e,
                            floating: t
                        }
                    });
                    s = null != h ? h : s, d = null != g ? g : d, p = { ...p,
                        [i]: { ...p[i],
                            ...y
                        }
                    }, b && v <= 50 && (v++, "object" == typeof b && (b.placement && (f = b.placement), b.rects && (c = !0 === b.rects ? await l.getElementRects({
                        reference: e,
                        floating: t,
                        strategy: o
                    }) : b.rects), {
                        x: s,
                        y: d
                    } = x(c, f, u)), n = -1)
                }
                return {
                    x: s,
                    y: d,
                    placement: f,
                    strategy: o,
                    middlewareData: p
                }
            };
            async function R(e, t) {
                var n;
                void 0 === t && (t = {});
                let {
                    x: r,
                    y: o,
                    platform: i,
                    rects: l,
                    elements: a,
                    strategy: u
                } = e, {
                    boundary: c = "clippingAncestors",
                    rootBoundary: s = "viewport",
                    elementContext: d = "floating",
                    altBoundary: p = !1,
                    padding: v = 0
                } = f(t, e), m = w(v), h = a[p ? "floating" === d ? "reference" : "floating" : d], g = E(await i.getClippingRect({
                    element: null == (n = await (null == i.isElement ? void 0 : i.isElement(h))) || n ? h : h.contextElement || await (null == i.getDocumentElement ? void 0 : i.getDocumentElement(a.floating)),
                    boundary: c,
                    rootBoundary: s,
                    strategy: u
                })), y = "floating" === d ? {
                    x: r,
                    y: o,
                    width: l.floating.width,
                    height: l.floating.height
                } : l.reference, b = await (null == i.getOffsetParent ? void 0 : i.getOffsetParent(a.floating)), x = await (null == i.isElement ? void 0 : i.isElement(b)) && await (null == i.getScale ? void 0 : i.getScale(b)) || {
                    x: 1,
                    y: 1
                }, C = E(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
                    elements: a,
                    rect: y,
                    offsetParent: b,
                    strategy: u
                }) : y);
                return {
                    top: (g.top - C.top + m.top) / x.y,
                    bottom: (C.bottom - g.bottom + m.bottom) / x.y,
                    left: (g.left - C.left + m.left) / x.x,
                    right: (C.right - g.right + m.right) / x.x
                }
            }

            function S(e, t) {
                return {
                    top: e.top - t.height,
                    right: e.right - t.width,
                    bottom: e.bottom - t.height,
                    left: e.left - t.width
                }
            }

            function k(e) {
                return o.some(t => e[t] >= 0)
            }
            async function A(e, t) {
                let {
                    placement: n,
                    platform: r,
                    elements: o
                } = e, i = await (null == r.isRTL ? void 0 : r.isRTL(o.floating)), l = p(n), a = v(n), u = "y" === g(n), c = ["left", "top"].includes(l) ? -1 : 1, s = i && u ? -1 : 1, d = f(t, e), {
                    mainAxis: m,
                    crossAxis: h,
                    alignmentAxis: y
                } = "number" == typeof d ? {
                    mainAxis: d,
                    crossAxis: 0,
                    alignmentAxis: null
                } : {
                    mainAxis: 0,
                    crossAxis: 0,
                    alignmentAxis: null,
                    ...d
                };
                return a && "number" == typeof y && (h = "end" === a ? -1 * y : y), u ? {
                    x: h * s,
                    y: m * c
                } : {
                    x: m * c,
                    y: h * s
                }
            }

            function P(e) {
                return D(e) ? (e.nodeName || "").toLowerCase() : "#document"
            }

            function N(e) {
                var t;
                return (null == e || null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function O(e) {
                var t;
                return null == (t = (D(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
            }

            function D(e) {
                return e instanceof Node || e instanceof N(e).Node
            }

            function M(e) {
                return e instanceof Element || e instanceof N(e).Element
            }

            function T(e) {
                return e instanceof HTMLElement || e instanceof N(e).HTMLElement
            }

            function L(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof ShadowRoot || e instanceof N(e).ShadowRoot)
            }

            function I(e) {
                let {
                    overflow: t,
                    overflowX: n,
                    overflowY: r,
                    display: o
                } = V(e);
                return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !["inline", "contents"].includes(o)
            }

            function j(e) {
                return [":popover-open", ":modal"].some(t => {
                    try {
                        return e.matches(t)
                    } catch (e) {
                        return !1
                    }
                })
            }

            function F(e) {
                let t = W(),
                    n = M(e) ? V(e) : e;
                return "none" !== n.transform || "none" !== n.perspective || !!n.containerType && "normal" !== n.containerType || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "perspective", "filter"].some(e => (n.willChange || "").includes(e)) || ["paint", "layout", "strict", "content"].some(e => (n.contain || "").includes(e))
            }

            function W() {
                return "undefined" != typeof CSS && !!CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")
            }

            function _(e) {
                return ["html", "body", "#document"].includes(P(e))
            }

            function V(e) {
                return N(e).getComputedStyle(e)
            }

            function B(e) {
                return M(e) ? {
                    scrollLeft: e.scrollLeft,
                    scrollTop: e.scrollTop
                } : {
                    scrollLeft: e.scrollX,
                    scrollTop: e.scrollY
                }
            }

            function z(e) {
                if ("html" === P(e)) return e;
                let t = e.assignedSlot || e.parentNode || L(e) && e.host || O(e);
                return L(t) ? t.host : t
            }

            function H(e, t, n) {
                var r;
                void 0 === t && (t = []), void 0 === n && (n = !0);
                let o = function e(t) {
                        let n = z(t);
                        return _(n) ? t.ownerDocument ? t.ownerDocument.body : t.body : T(n) && I(n) ? n : e(n)
                    }(e),
                    i = o === (null == (r = e.ownerDocument) ? void 0 : r.body),
                    l = N(o);
                if (i) {
                    let e = $(l);
                    return t.concat(l, l.visualViewport || [], I(o) ? o : [], e && n ? H(e) : [])
                }
                return t.concat(o, H(o, [], n))
            }

            function $(e) {
                return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null
            }

            function K(e) {
                let t = V(e),
                    n = parseFloat(t.width) || 0,
                    r = parseFloat(t.height) || 0,
                    o = T(e),
                    i = o ? e.offsetWidth : n,
                    l = o ? e.offsetHeight : r,
                    u = a(n) !== i || a(r) !== l;
                return u && (n = i, r = l), {
                    width: n,
                    height: r,
                    $: u
                }
            }

            function U(e) {
                return M(e) ? e : e.contextElement
            }

            function q(e) {
                let t = U(e);
                if (!T(t)) return c(1);
                let n = t.getBoundingClientRect(),
                    {
                        width: r,
                        height: o,
                        $: i
                    } = K(t),
                    l = (i ? a(n.width) : n.width) / r,
                    u = (i ? a(n.height) : n.height) / o;
                return l && Number.isFinite(l) || (l = 1), u && Number.isFinite(u) || (u = 1), {
                    x: l,
                    y: u
                }
            }
            let Y = c(0);

            function Z(e) {
                let t = N(e);
                return W() && t.visualViewport ? {
                    x: t.visualViewport.offsetLeft,
                    y: t.visualViewport.offsetTop
                } : Y
            }

            function X(e, t, n, r) {
                var o;
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                let i = e.getBoundingClientRect(),
                    l = U(e),
                    a = c(1);
                t && (r ? M(r) && (a = q(r)) : a = q(e));
                let u = (void 0 === (o = n) && (o = !1), r && (!o || r === N(l)) && o) ? Z(l) : c(0),
                    s = (i.left + u.x) / a.x,
                    d = (i.top + u.y) / a.y,
                    f = i.width / a.x,
                    p = i.height / a.y;
                if (l) {
                    let e = N(l),
                        t = r && M(r) ? N(r) : r,
                        n = e,
                        o = $(n);
                    for (; o && r && t !== n;) {
                        let e = q(o),
                            t = o.getBoundingClientRect(),
                            r = V(o),
                            i = t.left + (o.clientLeft + parseFloat(r.paddingLeft)) * e.x,
                            l = t.top + (o.clientTop + parseFloat(r.paddingTop)) * e.y;
                        s *= e.x, d *= e.y, f *= e.x, p *= e.y, s += i, d += l, o = $(n = N(o))
                    }
                }
                return E({
                    width: f,
                    height: p,
                    x: s,
                    y: d
                })
            }

            function G(e) {
                return X(O(e)).left + B(e).scrollLeft
            }

            function J(e, t, n) {
                let r;
                if ("viewport" === t) r = function(e, t) {
                    let n = N(e),
                        r = O(e),
                        o = n.visualViewport,
                        i = r.clientWidth,
                        l = r.clientHeight,
                        a = 0,
                        u = 0;
                    if (o) {
                        i = o.width, l = o.height;
                        let e = W();
                        (!e || e && "fixed" === t) && (a = o.offsetLeft, u = o.offsetTop)
                    }
                    return {
                        width: i,
                        height: l,
                        x: a,
                        y: u
                    }
                }(e, n);
                else if ("document" === t) r = function(e) {
                    let t = O(e),
                        n = B(e),
                        r = e.ownerDocument.body,
                        o = l(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth),
                        i = l(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight),
                        a = -n.scrollLeft + G(e),
                        u = -n.scrollTop;
                    return "rtl" === V(r).direction && (a += l(t.clientWidth, r.clientWidth) - o), {
                        width: o,
                        height: i,
                        x: a,
                        y: u
                    }
                }(O(e));
                else if (M(t)) r = function(e, t) {
                    let n = X(e, !0, "fixed" === t),
                        r = n.top + e.clientTop,
                        o = n.left + e.clientLeft,
                        i = T(e) ? q(e) : c(1),
                        l = e.clientWidth * i.x;
                    return {
                        width: l,
                        height: e.clientHeight * i.y,
                        x: o * i.x,
                        y: r * i.y
                    }
                }(t, n);
                else {
                    let n = Z(e);
                    r = { ...t,
                        x: t.x - n.x,
                        y: t.y - n.y
                    }
                }
                return E(r)
            }

            function Q(e) {
                return "static" === V(e).position
            }

            function ee(e, t) {
                return T(e) && "fixed" !== V(e).position ? t ? t(e) : e.offsetParent : null
            }

            function et(e, t) {
                let n = N(e);
                if (j(e)) return n;
                if (!T(e)) {
                    let t = z(e);
                    for (; t && !_(t);) {
                        if (M(t) && !Q(t)) return t;
                        t = z(t)
                    }
                    return n
                }
                let r = ee(e, t);
                for (; r && ["table", "td", "th"].includes(P(r)) && Q(r);) r = ee(r, t);
                return r && _(r) && Q(r) && !F(r) ? n : r || function(e) {
                    let t = z(e);
                    for (; T(t) && !_(t);) {
                        if (F(t)) return t;
                        if (j(t)) break;
                        t = z(t)
                    }
                    return null
                }(e) || n
            }
            let en = async function(e) {
                    let t = this.getOffsetParent || et,
                        n = this.getDimensions,
                        r = await n(e.floating);
                    return {
                        reference: function(e, t, n) {
                            let r = T(t),
                                o = O(t),
                                i = "fixed" === n,
                                l = X(e, !0, i, t),
                                a = {
                                    scrollLeft: 0,
                                    scrollTop: 0
                                },
                                u = c(0);
                            if (r || !r && !i) {
                                if (("body" !== P(t) || I(o)) && (a = B(t)), r) {
                                    let e = X(t, !0, i, t);
                                    u.x = e.x + t.clientLeft, u.y = e.y + t.clientTop
                                } else o && (u.x = G(o))
                            }
                            return {
                                x: l.left + a.scrollLeft - u.x,
                                y: l.top + a.scrollTop - u.y,
                                width: l.width,
                                height: l.height
                            }
                        }(e.reference, await t(e.floating), e.strategy),
                        floating: {
                            x: 0,
                            y: 0,
                            width: r.width,
                            height: r.height
                        }
                    }
                },
                er = {
                    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
                        let {
                            elements: t,
                            rect: n,
                            offsetParent: r,
                            strategy: o
                        } = e, i = "fixed" === o, l = O(r), a = !!t && j(t.floating);
                        if (r === l || a && i) return n;
                        let u = {
                                scrollLeft: 0,
                                scrollTop: 0
                            },
                            s = c(1),
                            d = c(0),
                            f = T(r);
                        if ((f || !f && !i) && (("body" !== P(r) || I(l)) && (u = B(r)), T(r))) {
                            let e = X(r);
                            s = q(r), d.x = e.x + r.clientLeft, d.y = e.y + r.clientTop
                        }
                        return {
                            width: n.width * s.x,
                            height: n.height * s.y,
                            x: n.x * s.x - u.scrollLeft * s.x + d.x,
                            y: n.y * s.y - u.scrollTop * s.y + d.y
                        }
                    },
                    getDocumentElement: O,
                    getClippingRect: function(e) {
                        let {
                            element: t,
                            boundary: n,
                            rootBoundary: r,
                            strategy: o
                        } = e, a = [..."clippingAncestors" === n ? j(t) ? [] : function(e, t) {
                            let n = t.get(e);
                            if (n) return n;
                            let r = H(e, [], !1).filter(e => M(e) && "body" !== P(e)),
                                o = null,
                                i = "fixed" === V(e).position,
                                l = i ? z(e) : e;
                            for (; M(l) && !_(l);) {
                                let t = V(l),
                                    n = F(l);
                                n || "fixed" !== t.position || (o = null), (i ? !n && !o : !n && "static" === t.position && !!o && ["absolute", "fixed"].includes(o.position) || I(l) && !n && function e(t, n) {
                                    let r = z(t);
                                    return !(r === n || !M(r) || _(r)) && ("fixed" === V(r).position || e(r, n))
                                }(e, l)) ? r = r.filter(e => e !== l) : o = t, l = z(l)
                            }
                            return t.set(e, r), r
                        }(t, this._c) : [].concat(n), r], u = a[0], c = a.reduce((e, n) => {
                            let r = J(t, n, o);
                            return e.top = l(r.top, e.top), e.right = i(r.right, e.right), e.bottom = i(r.bottom, e.bottom), e.left = l(r.left, e.left), e
                        }, J(t, u, o));
                        return {
                            width: c.right - c.left,
                            height: c.bottom - c.top,
                            x: c.left,
                            y: c.top
                        }
                    },
                    getOffsetParent: et,
                    getElementRects: en,
                    getClientRects: function(e) {
                        return Array.from(e.getClientRects())
                    },
                    getDimensions: function(e) {
                        let {
                            width: t,
                            height: n
                        } = K(e);
                        return {
                            width: t,
                            height: n
                        }
                    },
                    getScale: q,
                    isElement: M,
                    isRTL: function(e) {
                        return "rtl" === V(e).direction
                    }
                },
                eo = e => ({
                    name: "arrow",
                    options: e,
                    async fn(t) {
                        let {
                            x: n,
                            y: r,
                            placement: o,
                            rects: a,
                            platform: u,
                            elements: c,
                            middlewareData: s
                        } = t, {
                            element: d,
                            padding: p = 0
                        } = f(e, t) || {};
                        if (null == d) return {};
                        let y = w(p),
                            b = {
                                x: n,
                                y: r
                            },
                            E = m(g(o)),
                            x = h(E),
                            C = await u.getDimensions(d),
                            R = "y" === E,
                            S = R ? "clientHeight" : "clientWidth",
                            k = a.reference[x] + a.reference[E] - b[E] - a.floating[x],
                            A = b[E] - a.reference[E],
                            P = await (null == u.getOffsetParent ? void 0 : u.getOffsetParent(d)),
                            N = P ? P[S] : 0;
                        N && await (null == u.isElement ? void 0 : u.isElement(P)) || (N = c.floating[S] || a.floating[x]);
                        let O = N / 2 - C[x] / 2 - 1,
                            D = i(y[R ? "top" : "left"], O),
                            M = i(y[R ? "bottom" : "right"], O),
                            T = N - C[x] - M,
                            L = N / 2 - C[x] / 2 + (k / 2 - A / 2),
                            I = l(D, i(L, T)),
                            j = !s.arrow && null != v(o) && L !== I && a.reference[x] / 2 - (L < D ? D : M) - C[x] / 2 < 0,
                            F = j ? L < D ? L - D : L - T : 0;
                        return {
                            [E]: b[E] + F,
                            data: {
                                [E]: I,
                                centerOffset: L - I - F,
                                ...j && {
                                    alignmentOffset: F
                                }
                            },
                            reset: j
                        }
                    }
                }),
                ei = (e, t, n) => {
                    let r = new Map,
                        o = {
                            platform: er,
                            ...n
                        },
                        i = { ...o.platform,
                            _c: r
                        };
                    return C(e, t, { ...o,
                        platform: i
                    })
                };
            var el = n(36720),
                ea = "undefined" != typeof document ? r.useLayoutEffect : r.useEffect;

            function eu(e, t) {
                let n, r, o;
                if (e === t) return !0;
                if (typeof e != typeof t) return !1;
                if ("function" == typeof e && e.toString() === t.toString()) return !0;
                if (e && t && "object" == typeof e) {
                    if (Array.isArray(e)) {
                        if ((n = e.length) !== t.length) return !1;
                        for (r = n; 0 != r--;)
                            if (!eu(e[r], t[r])) return !1;
                        return !0
                    }
                    if ((n = (o = Object.keys(e)).length) !== Object.keys(t).length) return !1;
                    for (r = n; 0 != r--;)
                        if (!({}).hasOwnProperty.call(t, o[r])) return !1;
                    for (r = n; 0 != r--;) {
                        let n = o[r];
                        if (("_owner" !== n || !e.$$typeof) && !eu(e[n], t[n])) return !1
                    }
                    return !0
                }
                return e != e && t != t
            }

            function ec(e) {
                return "undefined" == typeof window ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1
            }

            function es(e, t) {
                let n = ec(e);
                return Math.round(t * n) / n
            }

            function ed(e) {
                let t = r.useRef(e);
                return ea(() => {
                    t.current = e
                }), t
            }
            let ef = e => ({
                    name: "arrow",
                    options: e,
                    fn(t) {
                        let {
                            element: n,
                            padding: r
                        } = "function" == typeof e ? e(t) : e;
                        return n && ({}).hasOwnProperty.call(n, "current") ? null != n.current ? eo({
                            element: n.current,
                            padding: r
                        }).fn(t) : {} : n ? eo({
                            element: n,
                            padding: r
                        }).fn(t) : {}
                    }
                }),
                ep = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = 0), {
                            name: "offset",
                            options: e,
                            async fn(t) {
                                var n, r;
                                let {
                                    x: o,
                                    y: i,
                                    placement: l,
                                    middlewareData: a
                                } = t, u = await A(t, e);
                                return l === (null == (n = a.offset) ? void 0 : n.placement) && null != (r = a.arrow) && r.alignmentOffset ? {} : {
                                    x: o + u.x,
                                    y: i + u.y,
                                    data: { ...u,
                                        placement: l
                                    }
                                }
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                ev = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = {}), {
                            name: "shift",
                            options: e,
                            async fn(t) {
                                let {
                                    x: n,
                                    y: r,
                                    placement: o
                                } = t, {
                                    mainAxis: a = !0,
                                    crossAxis: u = !1,
                                    limiter: c = {
                                        fn: e => {
                                            let {
                                                x: t,
                                                y: n
                                            } = e;
                                            return {
                                                x: t,
                                                y: n
                                            }
                                        }
                                    },
                                    ...s
                                } = f(e, t), d = {
                                    x: n,
                                    y: r
                                }, v = await R(t, s), h = g(p(o)), y = m(h), b = d[y], w = d[h];
                                if (a) {
                                    let e = "y" === y ? "top" : "left",
                                        t = "y" === y ? "bottom" : "right",
                                        n = b + v[e],
                                        r = b - v[t];
                                    b = l(n, i(b, r))
                                }
                                if (u) {
                                    let e = "y" === h ? "top" : "left",
                                        t = "y" === h ? "bottom" : "right",
                                        n = w + v[e],
                                        r = w - v[t];
                                    w = l(n, i(w, r))
                                }
                                let E = c.fn({ ...t,
                                    [y]: b,
                                    [h]: w
                                });
                                return { ...E,
                                    data: {
                                        x: E.x - n,
                                        y: E.y - r
                                    }
                                }
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                em = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = {}), {
                            options: e,
                            fn(t) {
                                let {
                                    x: n,
                                    y: r,
                                    placement: o,
                                    rects: i,
                                    middlewareData: l
                                } = t, {
                                    offset: a = 0,
                                    mainAxis: u = !0,
                                    crossAxis: c = !0
                                } = f(e, t), s = {
                                    x: n,
                                    y: r
                                }, d = g(o), v = m(d), h = s[v], y = s[d], b = f(a, t), w = "number" == typeof b ? {
                                    mainAxis: b,
                                    crossAxis: 0
                                } : {
                                    mainAxis: 0,
                                    crossAxis: 0,
                                    ...b
                                };
                                if (u) {
                                    let e = "y" === v ? "height" : "width",
                                        t = i.reference[v] - i.floating[e] + w.mainAxis,
                                        n = i.reference[v] + i.reference[e] - w.mainAxis;
                                    h < t ? h = t : h > n && (h = n)
                                }
                                if (c) {
                                    var E, x;
                                    let e = "y" === v ? "width" : "height",
                                        t = ["top", "left"].includes(p(o)),
                                        n = i.reference[d] - i.floating[e] + (t && (null == (E = l.offset) ? void 0 : E[d]) || 0) + (t ? 0 : w.crossAxis),
                                        r = i.reference[d] + i.reference[e] + (t ? 0 : (null == (x = l.offset) ? void 0 : x[d]) || 0) - (t ? w.crossAxis : 0);
                                    y < n ? y = n : y > r && (y = r)
                                }
                                return {
                                    [v]: h,
                                    [d]: y
                                }
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                eh = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = {}), {
                            name: "flip",
                            options: e,
                            async fn(t) {
                                var n, r, o, i, l;
                                let {
                                    placement: a,
                                    middlewareData: u,
                                    rects: c,
                                    initialPlacement: s,
                                    platform: d,
                                    elements: w
                                } = t, {
                                    mainAxis: E = !0,
                                    crossAxis: x = !0,
                                    fallbackPlacements: C,
                                    fallbackStrategy: S = "bestFit",
                                    fallbackAxisSideDirection: k = "none",
                                    flipAlignment: A = !0,
                                    ...P
                                } = f(e, t);
                                if (null != (n = u.arrow) && n.alignmentOffset) return {};
                                let N = p(a),
                                    O = g(s),
                                    D = p(s) === s,
                                    M = await (null == d.isRTL ? void 0 : d.isRTL(w.floating)),
                                    T = C || (D || !A ? [b(s)] : function(e) {
                                        let t = b(e);
                                        return [y(e), t, y(t)]
                                    }(s)),
                                    L = "none" !== k;
                                !C && L && T.push(... function(e, t, n, r) {
                                    let o = v(e),
                                        i = function(e, t, n) {
                                            let r = ["left", "right"],
                                                o = ["right", "left"];
                                            switch (e) {
                                                case "top":
                                                case "bottom":
                                                    if (n) return t ? o : r;
                                                    return t ? r : o;
                                                case "left":
                                                case "right":
                                                    return t ? ["top", "bottom"] : ["bottom", "top"];
                                                default:
                                                    return []
                                            }
                                        }(p(e), "start" === n, r);
                                    return o && (i = i.map(e => e + "-" + o), t && (i = i.concat(i.map(y)))), i
                                }(s, A, k, M));
                                let I = [s, ...T],
                                    j = await R(t, P),
                                    F = [],
                                    W = (null == (r = u.flip) ? void 0 : r.overflows) || [];
                                if (E && F.push(j[N]), x) {
                                    let e = function(e, t, n) {
                                        void 0 === n && (n = !1);
                                        let r = v(e),
                                            o = m(g(e)),
                                            i = h(o),
                                            l = "x" === o ? r === (n ? "end" : "start") ? "right" : "left" : "start" === r ? "bottom" : "top";
                                        return t.reference[i] > t.floating[i] && (l = b(l)), [l, b(l)]
                                    }(a, c, M);
                                    F.push(j[e[0]], j[e[1]])
                                }
                                if (W = [...W, {
                                        placement: a,
                                        overflows: F
                                    }], !F.every(e => e <= 0)) {
                                    let e = ((null == (o = u.flip) ? void 0 : o.index) || 0) + 1,
                                        t = I[e];
                                    if (t) return {
                                        data: {
                                            index: e,
                                            overflows: W
                                        },
                                        reset: {
                                            placement: t
                                        }
                                    };
                                    let n = null == (i = W.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]) ? void 0 : i.placement;
                                    if (!n) switch (S) {
                                        case "bestFit":
                                            {
                                                let e = null == (l = W.filter(e => {
                                                    if (L) {
                                                        let t = g(e.placement);
                                                        return t === O || "y" === t
                                                    }
                                                    return !0
                                                }).map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]) ? void 0 : l[0];e && (n = e);
                                                break
                                            }
                                        case "initialPlacement":
                                            n = s
                                    }
                                    if (a !== n) return {
                                        reset: {
                                            placement: n
                                        }
                                    }
                                }
                                return {}
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                eg = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = {}), {
                            name: "size",
                            options: e,
                            async fn(t) {
                                let n, r;
                                let {
                                    placement: o,
                                    rects: a,
                                    platform: u,
                                    elements: c
                                } = t, {
                                    apply: s = () => {},
                                    ...d
                                } = f(e, t), m = await R(t, d), h = p(o), y = v(o), b = "y" === g(o), {
                                    width: w,
                                    height: E
                                } = a.floating;
                                "top" === h || "bottom" === h ? (n = h, r = y === (await (null == u.isRTL ? void 0 : u.isRTL(c.floating)) ? "start" : "end") ? "left" : "right") : (r = h, n = "end" === y ? "top" : "bottom");
                                let x = E - m.top - m.bottom,
                                    C = w - m.left - m.right,
                                    S = i(E - m[n], x),
                                    k = i(w - m[r], C),
                                    A = !t.middlewareData.shift,
                                    P = S,
                                    N = k;
                                if (b ? N = y || A ? i(k, C) : C : P = y || A ? i(S, x) : x, A && !y) {
                                    let e = l(m.left, 0),
                                        t = l(m.right, 0),
                                        n = l(m.top, 0),
                                        r = l(m.bottom, 0);
                                    b ? N = w - 2 * (0 !== e || 0 !== t ? e + t : l(m.left, m.right)) : P = E - 2 * (0 !== n || 0 !== r ? n + r : l(m.top, m.bottom))
                                }
                                await s({ ...t,
                                    availableWidth: N,
                                    availableHeight: P
                                });
                                let O = await u.getDimensions(c.floating);
                                return w !== O.width || E !== O.height ? {
                                    reset: {
                                        rects: !0
                                    }
                                } : {}
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                ey = (e, t) => ({ ... function(e) {
                        return void 0 === e && (e = {}), {
                            name: "hide",
                            options: e,
                            async fn(t) {
                                let {
                                    rects: n
                                } = t, {
                                    strategy: r = "referenceHidden",
                                    ...o
                                } = f(e, t);
                                switch (r) {
                                    case "referenceHidden":
                                        {
                                            let e = S(await R(t, { ...o,
                                                elementContext: "reference"
                                            }), n.reference);
                                            return {
                                                data: {
                                                    referenceHiddenOffsets: e,
                                                    referenceHidden: k(e)
                                                }
                                            }
                                        }
                                    case "escaped":
                                        {
                                            let e = S(await R(t, { ...o,
                                                altBoundary: !0
                                            }), n.floating);
                                            return {
                                                data: {
                                                    escapedOffsets: e,
                                                    escaped: k(e)
                                                }
                                            }
                                        }
                                    default:
                                        return {}
                                }
                            }
                        }
                    }(e),
                    options: [e, t]
                }),
                eb = (e, t) => ({ ...ef(e),
                    options: [e, t]
                });
            var ew = n(95641),
                eE = n(12428),
                ex = r.forwardRef((e, t) => {
                    let {
                        children: n,
                        width: r = 10,
                        height: o = 5,
                        ...i
                    } = e;
                    return (0, eE.jsx)(ew.WV.svg, { ...i,
                        ref: t,
                        width: r,
                        height: o,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none",
                        children: e.asChild ? n : (0, eE.jsx)("polygon", {
                            points: "0,0 30,0 15,10"
                        })
                    })
                });
            ex.displayName = "Arrow";
            var eC = n(99385),
                eR = n(34500),
                eS = n(94884),
                ek = n(86025),
                eA = n(42095),
                eP = "Popper",
                [eN, eO] = (0, eR.b)(eP),
                [eD, eM] = eN(eP),
                eT = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [o, i] = r.useState(null);
                    return (0, eE.jsx)(eD, {
                        scope: t,
                        anchor: o,
                        onAnchorChange: i,
                        children: n
                    })
                };
            eT.displayName = eP;
            var eL = "PopperAnchor",
                eI = r.forwardRef((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: o,
                        ...i
                    } = e, l = eM(eL, n), a = r.useRef(null), u = (0, eC.e)(t, a);
                    return r.useEffect(() => {
                        l.onAnchorChange((null == o ? void 0 : o.current) || a.current)
                    }), o ? null : (0, eE.jsx)(ew.WV.div, { ...i,
                        ref: u
                    })
                });
            eI.displayName = eL;
            var ej = "PopperContent",
                [eF, eW] = eN(ej),
                e_ = r.forwardRef((e, t) => {
                    var n, o, a, c, s, d, f, p;
                    let {
                        __scopePopper: v,
                        side: m = "bottom",
                        sideOffset: h = 0,
                        align: g = "center",
                        alignOffset: y = 0,
                        arrowPadding: b = 0,
                        avoidCollisions: w = !0,
                        collisionBoundary: E = [],
                        collisionPadding: x = 0,
                        sticky: C = "partial",
                        hideWhenDetached: R = !1,
                        updatePositionStrategy: S = "optimized",
                        onPlaced: k,
                        ...A
                    } = e, P = eM(ej, v), [N, D] = r.useState(null), M = (0, eC.e)(t, e => D(e)), [T, L] = r.useState(null), I = (0, eA.t)(T), j = null !== (f = null == I ? void 0 : I.width) && void 0 !== f ? f : 0, F = null !== (p = null == I ? void 0 : I.height) && void 0 !== p ? p : 0, W = "number" == typeof x ? x : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...x
                    }, _ = Array.isArray(E) ? E : [E], V = _.length > 0, B = {
                        padding: W,
                        boundary: _.filter(eH),
                        altBoundary: V
                    }, {
                        refs: z,
                        floatingStyles: $,
                        placement: K,
                        isPositioned: q,
                        middlewareData: Y
                    } = function(e) {
                        void 0 === e && (e = {});
                        let {
                            placement: t = "bottom",
                            strategy: n = "absolute",
                            middleware: o = [],
                            platform: i,
                            elements: {
                                reference: l,
                                floating: a
                            } = {},
                            transform: u = !0,
                            whileElementsMounted: c,
                            open: s
                        } = e, [d, f] = r.useState({
                            x: 0,
                            y: 0,
                            strategy: n,
                            placement: t,
                            middlewareData: {},
                            isPositioned: !1
                        }), [p, v] = r.useState(o);
                        eu(p, o) || v(o);
                        let [m, h] = r.useState(null), [g, y] = r.useState(null), b = r.useCallback(e => {
                            e !== C.current && (C.current = e, h(e))
                        }, []), w = r.useCallback(e => {
                            e !== R.current && (R.current = e, y(e))
                        }, []), E = l || m, x = a || g, C = r.useRef(null), R = r.useRef(null), S = r.useRef(d), k = null != c, A = ed(c), P = ed(i), N = r.useCallback(() => {
                            if (!C.current || !R.current) return;
                            let e = {
                                placement: t,
                                strategy: n,
                                middleware: p
                            };
                            P.current && (e.platform = P.current), ei(C.current, R.current, e).then(e => {
                                let t = { ...e,
                                    isPositioned: !0
                                };
                                O.current && !eu(S.current, t) && (S.current = t, el.flushSync(() => {
                                    f(t)
                                }))
                            })
                        }, [p, t, n, P]);
                        ea(() => {
                            !1 === s && S.current.isPositioned && (S.current.isPositioned = !1, f(e => ({ ...e,
                                isPositioned: !1
                            })))
                        }, [s]);
                        let O = r.useRef(!1);
                        ea(() => (O.current = !0, () => {
                            O.current = !1
                        }), []), ea(() => {
                            if (E && (C.current = E), x && (R.current = x), E && x) {
                                if (A.current) return A.current(E, x, N);
                                N()
                            }
                        }, [E, x, N, A, k]);
                        let D = r.useMemo(() => ({
                                reference: C,
                                floating: R,
                                setReference: b,
                                setFloating: w
                            }), [b, w]),
                            M = r.useMemo(() => ({
                                reference: E,
                                floating: x
                            }), [E, x]),
                            T = r.useMemo(() => {
                                let e = {
                                    position: n,
                                    left: 0,
                                    top: 0
                                };
                                if (!M.floating) return e;
                                let t = es(M.floating, d.x),
                                    r = es(M.floating, d.y);
                                return u ? { ...e,
                                    transform: "translate(" + t + "px, " + r + "px)",
                                    ...ec(M.floating) >= 1.5 && {
                                        willChange: "transform"
                                    }
                                } : {
                                    position: n,
                                    left: t,
                                    top: r
                                }
                            }, [n, u, M.floating, d.x, d.y]);
                        return r.useMemo(() => ({ ...d,
                            update: N,
                            refs: D,
                            elements: M,
                            floatingStyles: T
                        }), [d, N, D, M, T])
                    }({
                        strategy: "fixed",
                        placement: m + ("center" !== g ? "-" + g : ""),
                        whileElementsMounted: function() {
                            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return function(e, t, n, r) {
                                let o;
                                void 0 === r && (r = {});
                                let {
                                    ancestorScroll: a = !0,
                                    ancestorResize: c = !0,
                                    elementResize: s = "function" == typeof ResizeObserver,
                                    layoutShift: d = "function" == typeof IntersectionObserver,
                                    animationFrame: f = !1
                                } = r, p = U(e), v = a || c ? [...p ? H(p) : [], ...H(t)] : [];
                                v.forEach(e => {
                                    a && e.addEventListener("scroll", n, {
                                        passive: !0
                                    }), c && e.addEventListener("resize", n)
                                });
                                let m = p && d ? function(e, t) {
                                        let n, r = null,
                                            o = O(e);

                                        function a() {
                                            var e;
                                            clearTimeout(n), null == (e = r) || e.disconnect(), r = null
                                        }
                                        return ! function c(s, d) {
                                            void 0 === s && (s = !1), void 0 === d && (d = 1), a();
                                            let {
                                                left: f,
                                                top: p,
                                                width: v,
                                                height: m
                                            } = e.getBoundingClientRect();
                                            if (s || t(), !v || !m) return;
                                            let h = u(p),
                                                g = u(o.clientWidth - (f + v)),
                                                y = {
                                                    rootMargin: -h + "px " + -g + "px " + -u(o.clientHeight - (p + m)) + "px " + -u(f) + "px",
                                                    threshold: l(0, i(1, d)) || 1
                                                },
                                                b = !0;

                                            function w(e) {
                                                let t = e[0].intersectionRatio;
                                                if (t !== d) {
                                                    if (!b) return c();
                                                    t ? c(!1, t) : n = setTimeout(() => {
                                                        c(!1, 1e-7)
                                                    }, 1e3)
                                                }
                                                b = !1
                                            }
                                            try {
                                                r = new IntersectionObserver(w, { ...y,
                                                    root: o.ownerDocument
                                                })
                                            } catch (e) {
                                                r = new IntersectionObserver(w, y)
                                            }
                                            r.observe(e)
                                        }(!0), a
                                    }(p, n) : null,
                                    h = -1,
                                    g = null;
                                s && (g = new ResizeObserver(e => {
                                    let [r] = e;
                                    r && r.target === p && g && (g.unobserve(t), cancelAnimationFrame(h), h = requestAnimationFrame(() => {
                                        var e;
                                        null == (e = g) || e.observe(t)
                                    })), n()
                                }), p && !f && g.observe(p), g.observe(t));
                                let y = f ? X(e) : null;
                                return f && function t() {
                                    let r = X(e);
                                    y && (r.x !== y.x || r.y !== y.y || r.width !== y.width || r.height !== y.height) && n(), y = r, o = requestAnimationFrame(t)
                                }(), n(), () => {
                                    var e;
                                    v.forEach(e => {
                                        a && e.removeEventListener("scroll", n), c && e.removeEventListener("resize", n)
                                    }), null == m || m(), null == (e = g) || e.disconnect(), g = null, f && cancelAnimationFrame(o)
                                }
                            }(...t, {
                                animationFrame: "always" === S
                            })
                        },
                        elements: {
                            reference: P.anchor
                        },
                        middleware: [ep({
                            mainAxis: h + F,
                            alignmentAxis: y
                        }), w && ev({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === C ? em() : void 0,
                            ...B
                        }), w && eh({ ...B
                        }), eg({ ...B,
                            apply: e => {
                                let {
                                    elements: t,
                                    rects: n,
                                    availableWidth: r,
                                    availableHeight: o
                                } = e, {
                                    width: i,
                                    height: l
                                } = n.reference, a = t.floating.style;
                                a.setProperty("--radix-popper-available-width", "".concat(r, "px")), a.setProperty("--radix-popper-available-height", "".concat(o, "px")), a.setProperty("--radix-popper-anchor-width", "".concat(i, "px")), a.setProperty("--radix-popper-anchor-height", "".concat(l, "px"))
                            }
                        }), T && eb({
                            element: T,
                            padding: b
                        }), e$({
                            arrowWidth: j,
                            arrowHeight: F
                        }), R && ey({
                            strategy: "referenceHidden",
                            ...B
                        })]
                    }), [Z, G] = eK(K), J = (0, eS.W)(k);
                    (0, ek.b)(() => {
                        q && (null == J || J())
                    }, [q, J]);
                    let Q = null === (n = Y.arrow) || void 0 === n ? void 0 : n.x,
                        ee = null === (o = Y.arrow) || void 0 === o ? void 0 : o.y,
                        et = (null === (a = Y.arrow) || void 0 === a ? void 0 : a.centerOffset) !== 0,
                        [en, er] = r.useState();
                    return (0, ek.b)(() => {
                        N && er(window.getComputedStyle(N).zIndex)
                    }, [N]), (0, eE.jsx)("div", {
                        ref: z.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...$,
                            transform: q ? $.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: en,
                            "--radix-popper-transform-origin": [null === (c = Y.transformOrigin) || void 0 === c ? void 0 : c.x, null === (s = Y.transformOrigin) || void 0 === s ? void 0 : s.y].join(" "),
                            ...(null === (d = Y.hide) || void 0 === d ? void 0 : d.referenceHidden) && {
                                visibility: "hidden",
                                pointerEvents: "none"
                            }
                        },
                        dir: e.dir,
                        children: (0, eE.jsx)(eF, {
                            scope: v,
                            placedSide: Z,
                            onArrowChange: L,
                            arrowX: Q,
                            arrowY: ee,
                            shouldHideArrow: et,
                            children: (0, eE.jsx)(ew.WV.div, {
                                "data-side": Z,
                                "data-align": G,
                                ...A,
                                ref: M,
                                style: { ...A.style,
                                    animation: q ? void 0 : "none"
                                }
                            })
                        })
                    })
                });
            e_.displayName = ej;
            var eV = "PopperArrow",
                eB = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                },
                ez = r.forwardRef(function(e, t) {
                    let {
                        __scopePopper: n,
                        ...r
                    } = e, o = eW(eV, n), i = eB[o.placedSide];
                    return (0, eE.jsx)("span", {
                        ref: o.onArrowChange,
                        style: {
                            position: "absolute",
                            left: o.arrowX,
                            top: o.arrowY,
                            [i]: 0,
                            transformOrigin: {
                                top: "",
                                right: "0 0",
                                bottom: "center 0",
                                left: "100% 0"
                            }[o.placedSide],
                            transform: {
                                top: "translateY(100%)",
                                right: "translateY(50%) rotate(90deg) translateX(-50%)",
                                bottom: "rotate(180deg)",
                                left: "translateY(50%) rotate(-90deg) translateX(50%)"
                            }[o.placedSide],
                            visibility: o.shouldHideArrow ? "hidden" : void 0
                        },
                        children: (0, eE.jsx)(ex, { ...r,
                            ref: t,
                            style: { ...r.style,
                                display: "block"
                            }
                        })
                    })
                });

            function eH(e) {
                return null !== e
            }
            ez.displayName = eV;
            var e$ = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    var n, r, o, i, l;
                    let {
                        placement: a,
                        rects: u,
                        middlewareData: c
                    } = t, s = (null === (n = c.arrow) || void 0 === n ? void 0 : n.centerOffset) !== 0, d = s ? 0 : e.arrowWidth, f = s ? 0 : e.arrowHeight, [p, v] = eK(a), m = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[v], h = (null !== (i = null === (r = c.arrow) || void 0 === r ? void 0 : r.x) && void 0 !== i ? i : 0) + d / 2, g = (null !== (l = null === (o = c.arrow) || void 0 === o ? void 0 : o.y) && void 0 !== l ? l : 0) + f / 2, y = "", b = "";
                    return "bottom" === p ? (y = s ? m : "".concat(h, "px"), b = "".concat(-f, "px")) : "top" === p ? (y = s ? m : "".concat(h, "px"), b = "".concat(u.floating.height + f, "px")) : "right" === p ? (y = "".concat(-f, "px"), b = s ? m : "".concat(g, "px")) : "left" === p && (y = "".concat(u.floating.width + f, "px"), b = s ? m : "".concat(g, "px")), {
                        data: {
                            x: y,
                            y: b
                        }
                    }
                }
            });

            function eK(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            var eU = eT,
                eq = eI,
                eY = e_,
                eZ = ez
        },
        2010: (e, t, n) => {
            n.d(t, {
                h: () => u
            });
            var r = n(93264),
                o = n(36720),
                i = n(95641),
                l = n(86025),
                a = n(12428),
                u = r.forwardRef((e, t) => {
                    var n, u;
                    let {
                        container: c,
                        ...s
                    } = e, [d, f] = r.useState(!1);
                    (0, l.b)(() => f(!0), []);
                    let p = c || d && (null === (u = globalThis) || void 0 === u ? void 0 : null === (n = u.document) || void 0 === n ? void 0 : n.body);
                    return p ? o.createPortal((0, a.jsx)(i.WV.div, { ...s,
                        ref: t
                    }), p) : null
                });
            u.displayName = "Portal"
        },
        79523: (e, t, n) => {
            n.d(t, {
                z: () => a
            });
            var r = n(93264),
                o = n(36720),
                i = n(99385),
                l = n(86025),
                a = e => {
                    let {
                        present: t,
                        children: n
                    } = e, a = function(e) {
                        var t, n;
                        let [i, a] = r.useState(), c = r.useRef({}), s = r.useRef(e), d = r.useRef("none"), [f, p] = (t = e ? "mounted" : "unmounted", n = {
                            mounted: {
                                UNMOUNT: "unmounted",
                                ANIMATION_OUT: "unmountSuspended"
                            },
                            unmountSuspended: {
                                MOUNT: "mounted",
                                ANIMATION_END: "unmounted"
                            },
                            unmounted: {
                                MOUNT: "mounted"
                            }
                        }, r.useReducer((e, t) => {
                            let r = n[e][t];
                            return null != r ? r : e
                        }, t));
                        return r.useEffect(() => {
                            let e = u(c.current);
                            d.current = "mounted" === f ? e : "none"
                        }, [f]), (0, l.b)(() => {
                            let t = c.current,
                                n = s.current;
                            if (n !== e) {
                                let r = d.current,
                                    o = u(t);
                                e ? p("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? p("UNMOUNT") : n && r !== o ? p("ANIMATION_OUT") : p("UNMOUNT"), s.current = e
                            }
                        }, [e, p]), (0, l.b)(() => {
                            if (i) {
                                let e = e => {
                                        let t = u(c.current).includes(e.animationName);
                                        e.target === i && t && o.flushSync(() => p("ANIMATION_END"))
                                    },
                                    t = e => {
                                        e.target === i && (d.current = u(c.current))
                                    };
                                return i.addEventListener("animationstart", t), i.addEventListener("animationcancel", e), i.addEventListener("animationend", e), () => {
                                    i.removeEventListener("animationstart", t), i.removeEventListener("animationcancel", e), i.removeEventListener("animationend", e)
                                }
                            }
                            p("ANIMATION_END")
                        }, [i, p]), {
                            isPresent: ["mounted", "unmountSuspended"].includes(f),
                            ref: r.useCallback(e => {
                                e && (c.current = getComputedStyle(e)), a(e)
                            }, [])
                        }
                    }(t), c = "function" == typeof n ? n({
                        present: a.isPresent
                    }) : r.Children.only(n), s = (0, i.e)(a.ref, function(e) {
                        var t, n;
                        let r = null === (t = Object.getOwnPropertyDescriptor(e.props, "ref")) || void 0 === t ? void 0 : t.get,
                            o = r && "isReactWarning" in r && r.isReactWarning;
                        return o ? e.ref : (o = (r = null === (n = Object.getOwnPropertyDescriptor(e, "ref")) || void 0 === n ? void 0 : n.get) && "isReactWarning" in r && r.isReactWarning) ? e.props.ref : e.props.ref || e.ref
                    }(c));
                    return "function" == typeof n || a.isPresent ? r.cloneElement(c, {
                        ref: s
                    }) : null
                };

            function u(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            a.displayName = "Presence"
        },
        95641: (e, t, n) => {
            n.d(t, {
                WV: () => a,
                jH: () => u
            });
            var r = n(93264),
                o = n(36720),
                i = n(8190),
                l = n(12428),
                a = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = r.forwardRef((e, n) => {
                        let {
                            asChild: r,
                            ...o
                        } = e, a = r ? i.g7 : t;
                        return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), (0, l.jsx)(a, { ...o,
                            ref: n
                        })
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {});

            function u(e, t) {
                e && o.flushSync(() => e.dispatchEvent(t))
            }
        },
        70073: (e, t, n) => {
            n.d(t, {
                Ee: () => T,
                ck: () => W,
                fC: () => F,
                mJ: () => I,
                z$: () => _
            });
            var r = n(93264),
                o = n(69933),
                i = n(99385),
                l = n(34500),
                a = n(95641),
                u = n(30198),
                c = n(5425),
                s = n(45686),
                d = n(42095),
                f = n(93779),
                p = n(79523),
                v = n(12428),
                m = "Radio",
                [h, g] = (0, l.b)(m),
                [y, b] = h(m),
                w = r.forwardRef((e, t) => {
                    let {
                        __scopeRadio: n,
                        name: l,
                        checked: u = !1,
                        required: c,
                        disabled: s,
                        value: d = "on",
                        onCheck: f,
                        ...p
                    } = e, [m, h] = r.useState(null), g = (0, i.e)(t, e => h(e)), b = r.useRef(!1), w = !m || !!m.closest("form");
                    return (0, v.jsxs)(y, {
                        scope: n,
                        checked: u,
                        disabled: s,
                        children: [(0, v.jsx)(a.WV.button, {
                            type: "button",
                            role: "radio",
                            "aria-checked": u,
                            "data-state": R(u),
                            "data-disabled": s ? "" : void 0,
                            disabled: s,
                            value: d,
                            ...p,
                            ref: g,
                            onClick: (0, o.M)(e.onClick, e => {
                                u || null == f || f(), w && (b.current = e.isPropagationStopped(), b.current || e.stopPropagation())
                            })
                        }), w && (0, v.jsx)(C, {
                            control: m,
                            bubbles: !b.current,
                            name: l,
                            value: d,
                            checked: u,
                            required: c,
                            disabled: s,
                            style: {
                                transform: "translateX(-100%)"
                            }
                        })]
                    })
                });
            w.displayName = m;
            var E = "RadioIndicator",
                x = r.forwardRef((e, t) => {
                    let {
                        __scopeRadio: n,
                        forceMount: r,
                        ...o
                    } = e, i = b(E, n);
                    return (0, v.jsx)(p.z, {
                        present: r || i.checked,
                        children: (0, v.jsx)(a.WV.span, {
                            "data-state": R(i.checked),
                            "data-disabled": i.disabled ? "" : void 0,
                            ...o,
                            ref: t
                        })
                    })
                });
            x.displayName = E;
            var C = e => {
                let {
                    control: t,
                    checked: n,
                    bubbles: o = !0,
                    ...i
                } = e, l = r.useRef(null), a = (0, f.D)(n), u = (0, d.t)(t);
                return r.useEffect(() => {
                    let e = l.current,
                        t = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "checked").set;
                    if (a !== n && t) {
                        let r = new Event("click", {
                            bubbles: o
                        });
                        t.call(e, n), e.dispatchEvent(r)
                    }
                }, [a, n, o]), (0, v.jsx)("input", {
                    type: "radio",
                    "aria-hidden": !0,
                    defaultChecked: n,
                    ...i,
                    tabIndex: -1,
                    ref: l,
                    style: { ...e.style,
                        ...u,
                        position: "absolute",
                        pointerEvents: "none",
                        opacity: 0,
                        margin: 0
                    }
                })
            };

            function R(e) {
                return e ? "checked" : "unchecked"
            }
            var S = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"],
                k = "RadioGroup",
                [A, P] = (0, l.b)(k, [u.Pc, g]),
                N = (0, u.Pc)(),
                O = g(),
                [D, M] = A(k),
                T = r.forwardRef((e, t) => {
                    let {
                        __scopeRadioGroup: n,
                        name: r,
                        defaultValue: o,
                        value: i,
                        required: l = !1,
                        disabled: d = !1,
                        orientation: f,
                        dir: p,
                        loop: m = !0,
                        onValueChange: h,
                        ...g
                    } = e, y = N(n), b = (0, s.gm)(p), [w, E] = (0, c.T)({
                        prop: i,
                        defaultProp: o,
                        onChange: h
                    });
                    return (0, v.jsx)(D, {
                        scope: n,
                        name: r,
                        required: l,
                        disabled: d,
                        value: w,
                        onValueChange: E,
                        children: (0, v.jsx)(u.fC, {
                            asChild: !0,
                            ...y,
                            orientation: f,
                            dir: b,
                            loop: m,
                            children: (0, v.jsx)(a.WV.div, {
                                role: "radiogroup",
                                "aria-required": l,
                                "aria-orientation": f,
                                "data-disabled": d ? "" : void 0,
                                dir: b,
                                ...g,
                                ref: t
                            })
                        })
                    })
                });
            T.displayName = k;
            var L = "RadioGroupItem",
                I = r.forwardRef((e, t) => {
                    let {
                        __scopeRadioGroup: n,
                        disabled: l,
                        ...a
                    } = e, c = M(L, n), s = c.disabled || l, d = N(n), f = O(n), p = r.useRef(null), m = (0, i.e)(t, p), h = c.value === a.value, g = r.useRef(!1);
                    return r.useEffect(() => {
                        let e = e => {
                                S.includes(e.key) && (g.current = !0)
                            },
                            t = () => g.current = !1;
                        return document.addEventListener("keydown", e), document.addEventListener("keyup", t), () => {
                            document.removeEventListener("keydown", e), document.removeEventListener("keyup", t)
                        }
                    }, []), (0, v.jsx)(u.ck, {
                        asChild: !0,
                        ...d,
                        focusable: !s,
                        active: h,
                        children: (0, v.jsx)(w, {
                            disabled: s,
                            required: c.required,
                            checked: h,
                            ...f,
                            ...a,
                            name: c.name,
                            ref: m,
                            onCheck: () => c.onValueChange(a.value),
                            onKeyDown: (0, o.M)(e => {
                                "Enter" === e.key && e.preventDefault()
                            }),
                            onFocus: (0, o.M)(a.onFocus, () => {
                                var e;
                                g.current && (null === (e = p.current) || void 0 === e || e.click())
                            })
                        })
                    })
                });
            I.displayName = L;
            var j = r.forwardRef((e, t) => {
                let {
                    __scopeRadioGroup: n,
                    ...r
                } = e, o = O(n);
                return (0, v.jsx)(x, { ...o,
                    ...r,
                    ref: t
                })
            });
            j.displayName = "RadioGroupIndicator";
            var F = T,
                W = I,
                _ = j
        },
        30198: (e, t, n) => {
            n.d(t, {
                Pc: () => E,
                ck: () => D,
                fC: () => O
            });
            var r = n(93264),
                o = n(69933),
                i = n(84364),
                l = n(99385),
                a = n(34500),
                u = n(5210),
                c = n(95641),
                s = n(94884),
                d = n(5425),
                f = n(45686),
                p = n(12428),
                v = "rovingFocusGroup.onEntryFocus",
                m = {
                    bubbles: !1,
                    cancelable: !0
                },
                h = "RovingFocusGroup",
                [g, y, b] = (0, i.B)(h),
                [w, E] = (0, a.b)(h, [b]),
                [x, C] = w(h),
                R = r.forwardRef((e, t) => (0, p.jsx)(g.Provider, {
                    scope: e.__scopeRovingFocusGroup,
                    children: (0, p.jsx)(g.Slot, {
                        scope: e.__scopeRovingFocusGroup,
                        children: (0, p.jsx)(S, { ...e,
                            ref: t
                        })
                    })
                }));
            R.displayName = h;
            var S = r.forwardRef((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        orientation: i,
                        loop: a = !1,
                        dir: u,
                        currentTabStopId: h,
                        defaultCurrentTabStopId: g,
                        onCurrentTabStopIdChange: b,
                        onEntryFocus: w,
                        preventScrollOnEntryFocus: E = !1,
                        ...C
                    } = e, R = r.useRef(null), S = (0, l.e)(t, R), k = (0, f.gm)(u), [A = null, P] = (0, d.T)({
                        prop: h,
                        defaultProp: g,
                        onChange: b
                    }), [O, D] = r.useState(!1), M = (0, s.W)(w), T = y(n), L = r.useRef(!1), [I, j] = r.useState(0);
                    return r.useEffect(() => {
                        let e = R.current;
                        if (e) return e.addEventListener(v, M), () => e.removeEventListener(v, M)
                    }, [M]), (0, p.jsx)(x, {
                        scope: n,
                        orientation: i,
                        dir: k,
                        loop: a,
                        currentTabStopId: A,
                        onItemFocus: r.useCallback(e => P(e), [P]),
                        onItemShiftTab: r.useCallback(() => D(!0), []),
                        onFocusableItemAdd: r.useCallback(() => j(e => e + 1), []),
                        onFocusableItemRemove: r.useCallback(() => j(e => e - 1), []),
                        children: (0, p.jsx)(c.WV.div, {
                            tabIndex: O || 0 === I ? -1 : 0,
                            "data-orientation": i,
                            ...C,
                            ref: S,
                            style: {
                                outline: "none",
                                ...e.style
                            },
                            onMouseDown: (0, o.M)(e.onMouseDown, () => {
                                L.current = !0
                            }),
                            onFocus: (0, o.M)(e.onFocus, e => {
                                let t = !L.current;
                                if (e.target === e.currentTarget && t && !O) {
                                    let t = new CustomEvent(v, m);
                                    if (e.currentTarget.dispatchEvent(t), !t.defaultPrevented) {
                                        let e = T().filter(e => e.focusable);
                                        N([e.find(e => e.active), e.find(e => e.id === A), ...e].filter(Boolean).map(e => e.ref.current), E)
                                    }
                                }
                                L.current = !1
                            }),
                            onBlur: (0, o.M)(e.onBlur, () => D(!1))
                        })
                    })
                }),
                k = "RovingFocusGroupItem",
                A = r.forwardRef((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        focusable: i = !0,
                        active: l = !1,
                        tabStopId: a,
                        ...s
                    } = e, d = (0, u.M)(), f = a || d, v = C(k, n), m = v.currentTabStopId === f, h = y(n), {
                        onFocusableItemAdd: b,
                        onFocusableItemRemove: w
                    } = v;
                    return r.useEffect(() => {
                        if (i) return b(), () => w()
                    }, [i, b, w]), (0, p.jsx)(g.ItemSlot, {
                        scope: n,
                        id: f,
                        focusable: i,
                        active: l,
                        children: (0, p.jsx)(c.WV.span, {
                            tabIndex: m ? 0 : -1,
                            "data-orientation": v.orientation,
                            ...s,
                            ref: t,
                            onMouseDown: (0, o.M)(e.onMouseDown, e => {
                                i ? v.onItemFocus(f) : e.preventDefault()
                            }),
                            onFocus: (0, o.M)(e.onFocus, () => v.onItemFocus(f)),
                            onKeyDown: (0, o.M)(e.onKeyDown, e => {
                                if ("Tab" === e.key && e.shiftKey) {
                                    v.onItemShiftTab();
                                    return
                                }
                                if (e.target !== e.currentTarget) return;
                                let t = function(e, t, n) {
                                    var r;
                                    let o = (r = e.key, "rtl" !== n ? r : "ArrowLeft" === r ? "ArrowRight" : "ArrowRight" === r ? "ArrowLeft" : r);
                                    if (!("vertical" === t && ["ArrowLeft", "ArrowRight"].includes(o)) && !("horizontal" === t && ["ArrowUp", "ArrowDown"].includes(o))) return P[o]
                                }(e, v.orientation, v.dir);
                                if (void 0 !== t) {
                                    if (e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) return;
                                    e.preventDefault();
                                    let n = h().filter(e => e.focusable).map(e => e.ref.current);
                                    if ("last" === t) n.reverse();
                                    else if ("prev" === t || "next" === t) {
                                        "prev" === t && n.reverse();
                                        let r = n.indexOf(e.currentTarget);
                                        n = v.loop ? function(e, t) {
                                            return e.map((n, r) => e[(t + r) % e.length])
                                        }(n, r + 1) : n.slice(r + 1)
                                    }
                                    setTimeout(() => N(n))
                                }
                            })
                        })
                    })
                });
            A.displayName = k;
            var P = {
                ArrowLeft: "prev",
                ArrowUp: "prev",
                ArrowRight: "next",
                ArrowDown: "next",
                PageUp: "first",
                Home: "first",
                PageDown: "last",
                End: "last"
            };

            function N(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = document.activeElement;
                for (let r of e)
                    if (r === n || (r.focus({
                            preventScroll: t
                        }), document.activeElement !== n)) return
            }
            var O = R,
                D = A
        },
        94884: (e, t, n) => {
            n.d(t, {
                W: () => o
            });
            var r = n(93264);

            function o(e) {
                let t = r.useRef(e);
                return r.useEffect(() => {
                    t.current = e
                }), r.useMemo(() => (...e) => t.current ? .(...e), [])
            }
        },
        5425: (e, t, n) => {
            n.d(t, {
                T: () => i
            });
            var r = n(93264),
                o = n(94884);

            function i({
                prop: e,
                defaultProp: t,
                onChange: n = () => {}
            }) {
                let [i, l] = function({
                    defaultProp: e,
                    onChange: t
                }) {
                    let n = r.useState(e),
                        [i] = n,
                        l = r.useRef(i),
                        a = (0, o.W)(t);
                    return r.useEffect(() => {
                        l.current !== i && (a(i), l.current = i)
                    }, [i, l, a]), n
                }({
                    defaultProp: t,
                    onChange: n
                }), a = void 0 !== e, u = a ? e : i, c = (0, o.W)(n);
                return [u, r.useCallback(t => {
                    if (a) {
                        let n = "function" == typeof t ? t(e) : t;
                        n !== e && c(n)
                    } else l(t)
                }, [a, e, l, c])]
            }
        },
        86025: (e, t, n) => {
            n.d(t, {
                b: () => o
            });
            var r = n(93264),
                o = globalThis ? .document ? r.useLayoutEffect : () => {}
        },
        93779: (e, t, n) => {
            n.d(t, {
                D: () => o
            });
            var r = n(93264);

            function o(e) {
                let t = r.useRef({
                    value: e,
                    previous: e
                });
                return r.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e])
            }
        },
        42095: (e, t, n) => {
            n.d(t, {
                t: () => i
            });
            var r = n(93264),
                o = n(86025);

            function i(e) {
                let [t, n] = r.useState(void 0);
                return (0, o.b)(() => {
                    if (e) {
                        n({
                            width: e.offsetWidth,
                            height: e.offsetHeight
                        });
                        let t = new ResizeObserver(t => {
                            let r, o;
                            if (!Array.isArray(t) || !t.length) return;
                            let i = t[0];
                            if ("borderBoxSize" in i) {
                                let e = i.borderBoxSize,
                                    t = Array.isArray(e) ? e[0] : e;
                                r = t.inlineSize, o = t.blockSize
                            } else r = e.offsetWidth, o = e.offsetHeight;
                            n({
                                width: r,
                                height: o
                            })
                        });
                        return t.observe(e, {
                            box: "border-box"
                        }), () => t.unobserve(e)
                    }
                    n(void 0)
                }, [e]), t
            }
        },
        69126: (e, t, n) => {
            let r;
            n.d(t, {
                mY: () => e2
            });
            var o = /[\\\/_+.#"@\[\(\{&]/,
                i = /[\\\/_+.#"@\[\(\{&]/g,
                l = /[\s-]/,
                a = /[\s-]/g;

            function u(e) {
                return e.toLowerCase().replace(a, " ")
            }

            function c() {
                return (c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            var s = n(93264),
                d = n.t(s, 2);

            function f(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function p(...e) {
                return t => e.forEach(e => {
                    "function" == typeof e ? e(t) : null != e && (e.current = t)
                })
            }

            function v(...e) {
                return (0, s.useCallback)(p(...e), e)
            }
            let m = (null == globalThis ? void 0 : globalThis.document) ? s.useLayoutEffect : () => {},
                h = d["useId".toString()] || (() => void 0),
                g = 0;

            function y(e) {
                let [t, n] = s.useState(h());
                return m(() => {
                    e || n(e => null != e ? e : String(g++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }

            function b(e) {
                let t = (0, s.useRef)(e);
                return (0, s.useEffect)(() => {
                    t.current = e
                }), (0, s.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            var w = n(36720);
            let E = (0, s.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...r
                } = e, o = s.Children.toArray(n), i = o.find(R);
                if (i) {
                    let e = i.props.children,
                        n = o.map(t => t !== i ? t : s.Children.count(e) > 1 ? s.Children.only(null) : (0, s.isValidElement)(e) ? e.props.children : null);
                    return (0, s.createElement)(x, c({}, r, {
                        ref: t
                    }), (0, s.isValidElement)(e) ? (0, s.cloneElement)(e, void 0, n) : null)
                }
                return (0, s.createElement)(x, c({}, r, {
                    ref: t
                }), n)
            });
            E.displayName = "Slot";
            let x = (0, s.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                return (0, s.isValidElement)(n) ? (0, s.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                i = t[r];
                            /^on[A-Z]/.test(r) ? o && i ? n[r] = (...e) => {
                                i(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...i
                            } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(r, n.props),
                    ref: t ? p(t, n.ref) : n.ref
                }) : s.Children.count(n) > 1 ? s.Children.only(null) : null
            });
            x.displayName = "SlotClone";
            let C = ({
                children: e
            }) => (0, s.createElement)(s.Fragment, null, e);

            function R(e) {
                return (0, s.isValidElement)(e) && e.type === C
            }
            let S = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, s.forwardRef)((e, n) => {
                        let {
                            asChild: r,
                            ...o
                        } = e, i = r ? E : t;
                        return (0, s.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, s.createElement)(i, c({}, o, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                k = "dismissableLayer.update",
                A = (0, s.createContext)({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                P = (0, s.forwardRef)((e, t) => {
                    var n;
                    let {
                        disableOutsidePointerEvents: o = !1,
                        onEscapeKeyDown: i,
                        onPointerDownOutside: l,
                        onFocusOutside: a,
                        onInteractOutside: u,
                        onDismiss: d,
                        ...p
                    } = e, m = (0, s.useContext)(A), [h, g] = (0, s.useState)(null), y = null !== (n = null == h ? void 0 : h.ownerDocument) && void 0 !== n ? n : null == globalThis ? void 0 : globalThis.document, [, w] = (0, s.useState)({}), E = v(t, e => g(e)), x = Array.from(m.layers), [C] = [...m.layersWithOutsidePointerEventsDisabled].slice(-1), R = x.indexOf(C), P = h ? x.indexOf(h) : -1, D = m.layersWithOutsidePointerEventsDisabled.size > 0, M = P >= R, T = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = b(e),
                            r = (0, s.useRef)(!1),
                            o = (0, s.useRef)(() => {});
                        return (0, s.useEffect)(() => {
                            let e = e => {
                                    if (e.target && !r.current) {
                                        let r = {
                                            originalEvent: e
                                        };

                                        function i() {
                                            O("dismissableLayer.pointerDownOutside", n, r, {
                                                discrete: !0
                                            })
                                        }
                                        "touch" === e.pointerType ? (t.removeEventListener("click", o.current), o.current = i, t.addEventListener("click", o.current, {
                                            once: !0
                                        })) : i()
                                    } else t.removeEventListener("click", o.current);
                                    r.current = !1
                                },
                                i = window.setTimeout(() => {
                                    t.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(i), t.removeEventListener("pointerdown", e), t.removeEventListener("click", o.current)
                            }
                        }, [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...m.branches].some(e => e.contains(t));
                        !M || n || (null == l || l(e), null == u || u(e), e.defaultPrevented || null == d || d())
                    }, y), L = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = b(e),
                            r = (0, s.useRef)(!1);
                        return (0, s.useEffect)(() => {
                            let e = e => {
                                e.target && !r.current && O("dismissableLayer.focusOutside", n, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }, [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        [...m.branches].some(e => e.contains(t)) || (null == a || a(e), null == u || u(e), e.defaultPrevented || null == d || d())
                    }, y);
                    return ! function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = b(e);
                        (0, s.useEffect)(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e)
                        }, [n, t])
                    }(e => {
                        P !== m.layers.size - 1 || (null == i || i(e), !e.defaultPrevented && d && (e.preventDefault(), d()))
                    }, y), (0, s.useEffect)(() => {
                        if (h) return o && (0 === m.layersWithOutsidePointerEventsDisabled.size && (r = y.body.style.pointerEvents, y.body.style.pointerEvents = "none"), m.layersWithOutsidePointerEventsDisabled.add(h)), m.layers.add(h), N(), () => {
                            o && 1 === m.layersWithOutsidePointerEventsDisabled.size && (y.body.style.pointerEvents = r)
                        }
                    }, [h, y, o, m]), (0, s.useEffect)(() => () => {
                        h && (m.layers.delete(h), m.layersWithOutsidePointerEventsDisabled.delete(h), N())
                    }, [h, m]), (0, s.useEffect)(() => {
                        let e = () => w({});
                        return document.addEventListener(k, e), () => document.removeEventListener(k, e)
                    }, []), (0, s.createElement)(S.div, c({}, p, {
                        ref: E,
                        style: {
                            pointerEvents: D ? M ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: f(e.onFocusCapture, L.onFocusCapture),
                        onBlurCapture: f(e.onBlurCapture, L.onBlurCapture),
                        onPointerDownCapture: f(e.onPointerDownCapture, T.onPointerDownCapture)
                    }))
                });

            function N() {
                let e = new CustomEvent(k);
                document.dispatchEvent(e)
            }

            function O(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.target,
                    i = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                (t && o.addEventListener(e, t, {
                    once: !0
                }), r) ? o && (0, w.flushSync)(() => o.dispatchEvent(i)): o.dispatchEvent(i)
            }
            let D = "focusScope.autoFocusOnMount",
                M = "focusScope.autoFocusOnUnmount",
                T = {
                    bubbles: !1,
                    cancelable: !0
                },
                L = (0, s.forwardRef)((e, t) => {
                    let {
                        loop: n = !1,
                        trapped: r = !1,
                        onMountAutoFocus: o,
                        onUnmountAutoFocus: i,
                        ...l
                    } = e, [a, u] = (0, s.useState)(null), d = b(o), f = b(i), p = (0, s.useRef)(null), m = v(t, e => u(e)), h = (0, s.useRef)({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    (0, s.useEffect)(() => {
                        if (r) {
                            function e(e) {
                                if (h.paused || !a) return;
                                let t = e.target;
                                a.contains(t) ? p.current = t : F(p.current, {
                                    select: !0
                                })
                            }

                            function t(e) {
                                if (h.paused || !a) return;
                                let t = e.relatedTarget;
                                null === t || a.contains(t) || F(p.current, {
                                    select: !0
                                })
                            }
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            let n = new MutationObserver(function(e) {
                                if (document.activeElement === document.body)
                                    for (let t of e) t.removedNodes.length > 0 && F(a)
                            });
                            return a && n.observe(a, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                            }
                        }
                    }, [r, a, h.paused]), (0, s.useEffect)(() => {
                        if (a) {
                            W.add(h);
                            let e = document.activeElement;
                            if (!a.contains(e)) {
                                let t = new CustomEvent(D, T);
                                a.addEventListener(D, d), a.dispatchEvent(t), t.defaultPrevented || (function(e, {
                                    select: t = !1
                                } = {}) {
                                    let n = document.activeElement;
                                    for (let r of e)
                                        if (F(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }(I(a).filter(e => "A" !== e.tagName), {
                                    select: !0
                                }), document.activeElement === e && F(a))
                            }
                            return () => {
                                a.removeEventListener(D, d), setTimeout(() => {
                                    let t = new CustomEvent(M, T);
                                    a.addEventListener(M, f), a.dispatchEvent(t), t.defaultPrevented || F(null != e ? e : document.body, {
                                        select: !0
                                    }), a.removeEventListener(M, f), W.remove(h)
                                }, 0)
                            }
                        }
                    }, [a, d, f, h]);
                    let g = (0, s.useCallback)(e => {
                        if (!n && !r || h.paused) return;
                        let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            o = document.activeElement;
                        if (t && o) {
                            let t = e.currentTarget,
                                [r, i] = function(e) {
                                    let t = I(e);
                                    return [j(t, e), j(t.reverse(), e)]
                                }(t);
                            r && i ? e.shiftKey || o !== i ? e.shiftKey && o === r && (e.preventDefault(), n && F(i, {
                                select: !0
                            })) : (e.preventDefault(), n && F(r, {
                                select: !0
                            })) : o === t && e.preventDefault()
                        }
                    }, [n, r, h.paused]);
                    return (0, s.createElement)(S.div, c({
                        tabIndex: -1
                    }, l, {
                        ref: m,
                        onKeyDown: g
                    }))
                });

            function I(e) {
                let t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            let t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function j(e, t) {
                for (let n of e)
                    if (! function(e, {
                            upTo: t
                        }) {
                            if ("hidden" === getComputedStyle(e).visibility) return !0;
                            for (; e && (void 0 === t || e !== t);) {
                                if ("none" === getComputedStyle(e).display) return !0;
                                e = e.parentElement
                            }
                            return !1
                        }(n, {
                            upTo: t
                        })) return n
            }

            function F(e, {
                select: t = !1
            } = {}) {
                if (e && e.focus) {
                    var n;
                    let r = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== r && (n = e) instanceof HTMLInputElement && "select" in n && t && e.select()
                }
            }
            let W = function() {
                let e = [];
                return {
                    add(t) {
                        let n = e[0];
                        t !== n && (null == n || n.pause()), (e = _(e, t)).unshift(t)
                    },
                    remove(t) {
                        var n;
                        null === (n = (e = _(e, t))[0]) || void 0 === n || n.resume()
                    }
                }
            }();

            function _(e, t) {
                let n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
            let V = (0, s.forwardRef)((e, t) => {
                    var n;
                    let {
                        container: r = null == globalThis ? void 0 : null === (n = globalThis.document) || void 0 === n ? void 0 : n.body,
                        ...o
                    } = e;
                    return r ? w.createPortal((0, s.createElement)(S.div, c({}, o, {
                        ref: t
                    })), r) : null
                }),
                B = e => {
                    let {
                        present: t,
                        children: n
                    } = e, r = function(e) {
                        var t, n;
                        let [r, o] = (0, s.useState)(), i = (0, s.useRef)({}), l = (0, s.useRef)(e), a = (0, s.useRef)("none"), [u, c] = (t = e ? "mounted" : "unmounted", n = {
                            mounted: {
                                UNMOUNT: "unmounted",
                                ANIMATION_OUT: "unmountSuspended"
                            },
                            unmountSuspended: {
                                MOUNT: "mounted",
                                ANIMATION_END: "unmounted"
                            },
                            unmounted: {
                                MOUNT: "mounted"
                            }
                        }, (0, s.useReducer)((e, t) => {
                            let r = n[e][t];
                            return null != r ? r : e
                        }, t));
                        return (0, s.useEffect)(() => {
                            let e = z(i.current);
                            a.current = "mounted" === u ? e : "none"
                        }, [u]), m(() => {
                            let t = i.current,
                                n = l.current;
                            if (n !== e) {
                                let r = a.current,
                                    o = z(t);
                                e ? c("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? c("UNMOUNT") : n && r !== o ? c("ANIMATION_OUT") : c("UNMOUNT"), l.current = e
                            }
                        }, [e, c]), m(() => {
                            if (r) {
                                let e = e => {
                                        let t = z(i.current).includes(e.animationName);
                                        e.target === r && t && (0, w.flushSync)(() => c("ANIMATION_END"))
                                    },
                                    t = e => {
                                        e.target === r && (a.current = z(i.current))
                                    };
                                return r.addEventListener("animationstart", t), r.addEventListener("animationcancel", e), r.addEventListener("animationend", e), () => {
                                    r.removeEventListener("animationstart", t), r.removeEventListener("animationcancel", e), r.removeEventListener("animationend", e)
                                }
                            }
                            c("ANIMATION_END")
                        }, [r, c]), {
                            isPresent: ["mounted", "unmountSuspended"].includes(u),
                            ref: (0, s.useCallback)(e => {
                                e && (i.current = getComputedStyle(e)), o(e)
                            }, [])
                        }
                    }(t), o = "function" == typeof n ? n({
                        present: r.isPresent
                    }) : s.Children.only(n), i = v(r.ref, o.ref);
                    return "function" == typeof n || r.isPresent ? (0, s.cloneElement)(o, {
                        ref: i
                    }) : null
                };

            function z(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            B.displayName = "Presence";
            let H = 0;

            function $() {
                let e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
            }
            var K = n(87204),
                U = n(13928),
                q = n(11458),
                Y = (0, n(59434)._)(),
                Z = function() {},
                X = s.forwardRef(function(e, t) {
                    var n = s.useRef(null),
                        r = s.useState({
                            onScrollCapture: Z,
                            onWheelCapture: Z,
                            onTouchMoveCapture: Z
                        }),
                        o = r[0],
                        i = r[1],
                        l = e.forwardProps,
                        a = e.children,
                        u = e.className,
                        c = e.removeScrollBar,
                        d = e.enabled,
                        f = e.shards,
                        p = e.sideCar,
                        v = e.noIsolation,
                        m = e.inert,
                        h = e.allowPinchZoom,
                        g = e.as,
                        y = (0, K._T)(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]),
                        b = (0, q.q)([n, t]),
                        w = (0, K.pi)((0, K.pi)({}, y), o);
                    return s.createElement(s.Fragment, null, d && s.createElement(p, {
                        sideCar: Y,
                        removeScrollBar: c,
                        shards: f,
                        noIsolation: v,
                        inert: m,
                        setCallbacks: i,
                        allowPinchZoom: !!h,
                        lockRef: n
                    }), l ? s.cloneElement(s.Children.only(a), (0, K.pi)((0, K.pi)({}, w), {
                        ref: b
                    })) : s.createElement(void 0 === g ? "div" : g, (0, K.pi)({}, w, {
                        className: u,
                        ref: b
                    }), a))
                });
            X.defaultProps = {
                enabled: !0,
                removeScrollBar: !0,
                inert: !1
            }, X.classNames = {
                fullWidth: U.zi,
                zeroRight: U.pF
            };
            var G = n(15949),
                J = n(44338),
                Q = n(41441),
                ee = !1;
            if ("undefined" != typeof window) try {
                var et = Object.defineProperty({}, "passive", {
                    get: function() {
                        return ee = !0, !0
                    }
                });
                window.addEventListener("test", et, et), window.removeEventListener("test", et, et)
            } catch (e) {
                ee = !1
            }
            var en = !!ee && {
                    passive: !1
                },
                er = function(e, t) {
                    var n = window.getComputedStyle(e);
                    return "hidden" !== n[t] && !(n.overflowY === n.overflowX && "TEXTAREA" !== e.tagName && "visible" === n[t])
                },
                eo = function(e, t) {
                    var n = t;
                    do {
                        if ("undefined" != typeof ShadowRoot && n instanceof ShadowRoot && (n = n.host), ei(e, n)) {
                            var r = el(e, n);
                            if (r[1] > r[2]) return !0
                        }
                        n = n.parentNode
                    } while (n && n !== document.body);
                    return !1
                },
                ei = function(e, t) {
                    return "v" === e ? er(t, "overflowY") : er(t, "overflowX")
                },
                el = function(e, t) {
                    return "v" === e ? [t.scrollTop, t.scrollHeight, t.clientHeight] : [t.scrollLeft, t.scrollWidth, t.clientWidth]
                },
                ea = function(e, t, n, r, o) {
                    var i, l = (i = window.getComputedStyle(t).direction, "h" === e && "rtl" === i ? -1 : 1),
                        a = l * r,
                        u = n.target,
                        c = t.contains(u),
                        s = !1,
                        d = a > 0,
                        f = 0,
                        p = 0;
                    do {
                        var v = el(e, u),
                            m = v[0],
                            h = v[1] - v[2] - l * m;
                        (m || h) && ei(e, u) && (f += h, p += m), u = u.parentNode
                    } while (!c && u !== document.body || c && (t.contains(u) || t === u));
                    return d && (o && 0 === f || !o && a > f) ? s = !0 : !d && (o && 0 === p || !o && -a > p) && (s = !0), s
                },
                eu = function(e) {
                    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
                },
                ec = function(e) {
                    return [e.deltaX, e.deltaY]
                },
                es = function(e) {
                    return e && "current" in e ? e.current : e
                },
                ed = 0,
                ef = [];
            let ep = (0, G.L)(Y, function(e) {
                var t = s.useRef([]),
                    n = s.useRef([0, 0]),
                    r = s.useRef(),
                    o = s.useState(ed++)[0],
                    i = s.useState(function() {
                        return (0, Q.Ws)()
                    })[0],
                    l = s.useRef(e);
                s.useEffect(function() {
                    l.current = e
                }, [e]), s.useEffect(function() {
                    if (e.inert) {
                        document.body.classList.add("block-interactivity-".concat(o));
                        var t = (0, K.ev)([e.lockRef.current], (e.shards || []).map(es), !0).filter(Boolean);
                        return t.forEach(function(e) {
                                return e.classList.add("allow-interactivity-".concat(o))
                            }),
                            function() {
                                document.body.classList.remove("block-interactivity-".concat(o)), t.forEach(function(e) {
                                    return e.classList.remove("allow-interactivity-".concat(o))
                                })
                            }
                    }
                }, [e.inert, e.lockRef.current, e.shards]);
                var a = s.useCallback(function(e, t) {
                        if ("touches" in e && 2 === e.touches.length) return !l.current.allowPinchZoom;
                        var o, i = eu(e),
                            a = n.current,
                            u = "deltaX" in e ? e.deltaX : a[0] - i[0],
                            c = "deltaY" in e ? e.deltaY : a[1] - i[1],
                            s = e.target,
                            d = Math.abs(u) > Math.abs(c) ? "h" : "v";
                        if ("touches" in e && "h" === d && "range" === s.type) return !1;
                        var f = eo(d, s);
                        if (!f) return !0;
                        if (f ? o = d : (o = "v" === d ? "h" : "v", f = eo(d, s)), !f) return !1;
                        if (!r.current && "changedTouches" in e && (u || c) && (r.current = o), !o) return !0;
                        var p = r.current || o;
                        return ea(p, t, e, "h" === p ? u : c, !0)
                    }, []),
                    u = s.useCallback(function(e) {
                        if (ef.length && ef[ef.length - 1] === i) {
                            var n = "deltaY" in e ? ec(e) : eu(e),
                                r = t.current.filter(function(t) {
                                    var r;
                                    return t.name === e.type && t.target === e.target && (r = t.delta)[0] === n[0] && r[1] === n[1]
                                })[0];
                            if (r && r.should) {
                                e.cancelable && e.preventDefault();
                                return
                            }
                            if (!r) {
                                var o = (l.current.shards || []).map(es).filter(Boolean).filter(function(t) {
                                    return t.contains(e.target)
                                });
                                (o.length > 0 ? a(e, o[0]) : !l.current.noIsolation) && e.cancelable && e.preventDefault()
                            }
                        }
                    }, []),
                    c = s.useCallback(function(e, n, r, o) {
                        var i = {
                            name: e,
                            delta: n,
                            target: r,
                            should: o
                        };
                        t.current.push(i), setTimeout(function() {
                            t.current = t.current.filter(function(e) {
                                return e !== i
                            })
                        }, 1)
                    }, []),
                    d = s.useCallback(function(e) {
                        n.current = eu(e), r.current = void 0
                    }, []),
                    f = s.useCallback(function(t) {
                        c(t.type, ec(t), t.target, a(t, e.lockRef.current))
                    }, []),
                    p = s.useCallback(function(t) {
                        c(t.type, eu(t), t.target, a(t, e.lockRef.current))
                    }, []);
                s.useEffect(function() {
                    return ef.push(i), e.setCallbacks({
                            onScrollCapture: f,
                            onWheelCapture: f,
                            onTouchMoveCapture: p
                        }), document.addEventListener("wheel", u, en), document.addEventListener("touchmove", u, en), document.addEventListener("touchstart", d, en),
                        function() {
                            ef = ef.filter(function(e) {
                                return e !== i
                            }), document.removeEventListener("wheel", u, en), document.removeEventListener("touchmove", u, en), document.removeEventListener("touchstart", d, en)
                        }
                }, []);
                var v = e.removeScrollBar,
                    m = e.inert;
                return s.createElement(s.Fragment, null, m ? s.createElement(i, {
                    styles: "\n  .block-interactivity-".concat(o, " {pointer-events: none;}\n  .allow-interactivity-").concat(o, " {pointer-events: all;}\n")
                }) : null, v ? s.createElement(J.jp, {
                    gapMode: "margin"
                }) : null)
            });
            var ev = s.forwardRef(function(e, t) {
                return s.createElement(X, (0, K.pi)({}, e, {
                    ref: t,
                    sideCar: ep
                }))
            });
            ev.classNames = X.classNames;
            var em = n(75568);
            let eh = "Dialog",
                [eg, ey] = function(e, t = []) {
                    let n = [],
                        r = () => {
                            let t = n.map(e => (0, s.createContext)(e));
                            return function(n) {
                                let r = (null == n ? void 0 : n[e]) || t;
                                return (0, s.useMemo)(() => ({
                                    [`__scope${e}`]: { ...n,
                                        [e]: r
                                    }
                                }), [n, r])
                            }
                        };
                    return r.scopeName = e, [function(t, r) {
                        let o = (0, s.createContext)(r),
                            i = n.length;

                        function l(t) {
                            let {
                                scope: n,
                                children: r,
                                ...l
                            } = t, a = (null == n ? void 0 : n[e][i]) || o, u = (0, s.useMemo)(() => l, Object.values(l));
                            return (0, s.createElement)(a.Provider, {
                                value: u
                            }, r)
                        }
                        return n = [...n, r], l.displayName = t + "Provider", [l, function(n, l) {
                            let a = (null == l ? void 0 : l[e][i]) || o,
                                u = (0, s.useContext)(a);
                            if (u) return u;
                            if (void 0 !== r) return r;
                            throw Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let n = () => {
                            let n = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let r = n.reduce((t, {
                                    useScope: n,
                                    scopeName: r
                                }) => {
                                    let o = n(e)[`__scope${r}`];
                                    return { ...t,
                                        ...o
                                    }
                                }, {});
                                return (0, s.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: r
                                }), [r])
                            }
                        };
                        return n.scopeName = t.scopeName, n
                    }(r, ...t)]
                }(eh),
                [eb, ew] = eg(eh),
                eE = "DialogPortal",
                [ex, eC] = eg(eE, {
                    forceMount: void 0
                }),
                eR = "DialogOverlay",
                eS = (0, s.forwardRef)((e, t) => {
                    let n = eC(eR, e.__scopeDialog),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        i = ew(eR, e.__scopeDialog);
                    return i.modal ? (0, s.createElement)(B, {
                        present: r || i.open
                    }, (0, s.createElement)(ek, c({}, o, {
                        ref: t
                    }))) : null
                }),
                ek = (0, s.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: n,
                        ...r
                    } = e, o = ew(eR, n);
                    return (0, s.createElement)(ev, {
                        as: E,
                        allowPinchZoom: !0,
                        shards: [o.contentRef]
                    }, (0, s.createElement)(S.div, c({
                        "data-state": eM(o.open)
                    }, r, {
                        ref: t,
                        style: {
                            pointerEvents: "auto",
                            ...r.style
                        }
                    })))
                }),
                eA = "DialogContent",
                eP = (0, s.forwardRef)((e, t) => {
                    let n = eC(eA, e.__scopeDialog),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        i = ew(eA, e.__scopeDialog);
                    return (0, s.createElement)(B, {
                        present: r || i.open
                    }, i.modal ? (0, s.createElement)(eN, c({}, o, {
                        ref: t
                    })) : (0, s.createElement)(eO, c({}, o, {
                        ref: t
                    })))
                }),
                eN = (0, s.forwardRef)((e, t) => {
                    let n = ew(eA, e.__scopeDialog),
                        r = (0, s.useRef)(null),
                        o = v(t, n.contentRef, r);
                    return (0, s.useEffect)(() => {
                        let e = r.current;
                        if (e) return (0, em.Ry)(e)
                    }, []), (0, s.createElement)(eD, c({}, e, {
                        ref: o,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: !0,
                        onCloseAutoFocus: f(e.onCloseAutoFocus, e => {
                            var t;
                            e.preventDefault(), null === (t = n.triggerRef.current) || void 0 === t || t.focus()
                        }),
                        onPointerDownOutside: f(e.onPointerDownOutside, e => {
                            let t = e.detail.originalEvent,
                                n = 0 === t.button && !0 === t.ctrlKey;
                            (2 === t.button || n) && e.preventDefault()
                        }),
                        onFocusOutside: f(e.onFocusOutside, e => e.preventDefault())
                    }))
                }),
                eO = (0, s.forwardRef)((e, t) => {
                    let n = ew(eA, e.__scopeDialog),
                        r = (0, s.useRef)(!1),
                        o = (0, s.useRef)(!1);
                    return (0, s.createElement)(eD, c({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var i, l;
                            null === (i = e.onCloseAutoFocus) || void 0 === i || i.call(e, t), t.defaultPrevented || (r.current || null === (l = n.triggerRef.current) || void 0 === l || l.focus(), t.preventDefault()), r.current = !1, o.current = !1
                        },
                        onInteractOutside: t => {
                            var i, l;
                            null === (i = e.onInteractOutside) || void 0 === i || i.call(e, t), t.defaultPrevented || (r.current = !0, "pointerdown" !== t.detail.originalEvent.type || (o.current = !0));
                            let a = t.target;
                            (null === (l = n.triggerRef.current) || void 0 === l ? void 0 : l.contains(a)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && o.current && t.preventDefault()
                        }
                    }))
                }),
                eD = (0, s.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: n,
                        trapFocus: r,
                        onOpenAutoFocus: o,
                        onCloseAutoFocus: i,
                        ...l
                    } = e, a = ew(eA, n), u = v(t, (0, s.useRef)(null));
                    return (0, s.useEffect)(() => {
                        var e, t;
                        let n = document.querySelectorAll("[data-radix-focus-guard]");
                        return document.body.insertAdjacentElement("afterbegin", null !== (e = n[0]) && void 0 !== e ? e : $()), document.body.insertAdjacentElement("beforeend", null !== (t = n[1]) && void 0 !== t ? t : $()), H++, () => {
                            1 === H && document.querySelectorAll("[data-radix-focus-guard]").forEach(e => e.remove()), H--
                        }
                    }, []), (0, s.createElement)(s.Fragment, null, (0, s.createElement)(L, {
                        asChild: !0,
                        loop: !0,
                        trapped: r,
                        onMountAutoFocus: o,
                        onUnmountAutoFocus: i
                    }, (0, s.createElement)(P, c({
                        role: "dialog",
                        id: a.contentId,
                        "aria-describedby": a.descriptionId,
                        "aria-labelledby": a.titleId,
                        "data-state": eM(a.open)
                    }, l, {
                        ref: u,
                        onDismiss: () => a.onOpenChange(!1)
                    }))), !1)
                });

            function eM(e) {
                return e ? "open" : "closed"
            }
            let [eT, eL] = function(e, t) {
                let n = (0, s.createContext)(t);

                function r(e) {
                    let {
                        children: t,
                        ...r
                    } = e, o = (0, s.useMemo)(() => r, Object.values(r));
                    return (0, s.createElement)(n.Provider, {
                        value: o
                    }, t)
                }
                return r.displayName = e + "Provider", [r, function(r) {
                    let o = (0, s.useContext)(n);
                    if (o) return o;
                    if (void 0 !== t) return t;
                    throw Error(`\`${r}\` must be used within \`${e}\``)
                }]
            }("DialogTitleWarning", {
                contentName: eA,
                titleName: "DialogTitle",
                docsSlug: "dialog"
            }), eI = e => {
                let {
                    __scopeDialog: t,
                    children: n,
                    open: r,
                    defaultOpen: o,
                    onOpenChange: i,
                    modal: l = !0
                } = e, a = (0, s.useRef)(null), u = (0, s.useRef)(null), [c = !1, d] = function({
                    prop: e,
                    defaultProp: t,
                    onChange: n = () => {}
                }) {
                    let [r, o] = function({
                        defaultProp: e,
                        onChange: t
                    }) {
                        let n = (0, s.useState)(e),
                            [r] = n,
                            o = (0, s.useRef)(r),
                            i = b(t);
                        return (0, s.useEffect)(() => {
                            o.current !== r && (i(r), o.current = r)
                        }, [r, o, i]), n
                    }({
                        defaultProp: t,
                        onChange: n
                    }), i = void 0 !== e, l = i ? e : r, a = b(n);
                    return [l, (0, s.useCallback)(t => {
                        if (i) {
                            let n = "function" == typeof t ? t(e) : t;
                            n !== e && a(n)
                        } else o(t)
                    }, [i, e, o, a])]
                }({
                    prop: r,
                    defaultProp: o,
                    onChange: i
                });
                return (0, s.createElement)(eb, {
                    scope: t,
                    triggerRef: a,
                    contentRef: u,
                    contentId: y(),
                    titleId: y(),
                    descriptionId: y(),
                    open: c,
                    onOpenChange: d,
                    onOpenToggle: (0, s.useCallback)(() => d(e => !e), [d]),
                    modal: l
                }, n)
            }, ej = e => {
                let {
                    __scopeDialog: t,
                    forceMount: n,
                    children: r,
                    container: o
                } = e, i = ew(eE, t);
                return (0, s.createElement)(ex, {
                    scope: t,
                    forceMount: n
                }, s.Children.map(r, e => (0, s.createElement)(B, {
                    present: n || i.open
                }, (0, s.createElement)(V, {
                    asChild: !0,
                    container: o
                }, e))))
            };
            var eF = '[cmdk-group=""]',
                eW = '[cmdk-group-items=""]',
                e_ = '[cmdk-item=""]',
                eV = `${e_}:not([aria-disabled="true"])`,
                eB = "cmdk-item-select",
                ez = "data-value",
                eH = (e, t, n) => (function(e, t, n) {
                    return function e(t, n, r, u, c, s, d) {
                        if (s === n.length) return c === t.length ? 1 : .99;
                        var f = `${c},${s}`;
                        if (void 0 !== d[f]) return d[f];
                        for (var p, v, m, h, g = u.charAt(s), y = r.indexOf(g, c), b = 0; y >= 0;)(p = e(t, n, r, u, y + 1, s + 1, d)) > b && (y === c ? p *= 1 : o.test(t.charAt(y - 1)) ? (p *= .8, (m = t.slice(c, y - 1).match(i)) && c > 0 && (p *= Math.pow(.999, m.length))) : l.test(t.charAt(y - 1)) ? (p *= .9, (h = t.slice(c, y - 1).match(a)) && c > 0 && (p *= Math.pow(.999, h.length))) : (p *= .17, c > 0 && (p *= Math.pow(.999, y - c))), t.charAt(y) !== n.charAt(s) && (p *= .9999)), (p < .1 && r.charAt(y - 1) === u.charAt(s + 1) || u.charAt(s + 1) === u.charAt(s) && r.charAt(y - 1) !== u.charAt(s)) && .1 * (v = e(t, n, r, u, y + 1, s + 2, d)) > p && (p = .1 * v), p > b && (b = p), y = r.indexOf(g, y + 1);
                        return d[f] = b, b
                    }(e = n && n.length > 0 ? `${e+" "+n.join(" ")}` : e, t, u(e), u(t), 0, 0, {})
                })(e, t, n),
                e$ = s.createContext(void 0),
                eK = () => s.useContext(e$),
                eU = s.createContext(void 0),
                eq = () => s.useContext(eU),
                eY = s.createContext(void 0),
                eZ = s.forwardRef((e, t) => {
                    let n = e3(() => {
                            var t, n;
                            return {
                                search: "",
                                value: null != (n = null != (t = e.value) ? t : e.defaultValue) ? n : "",
                                filtered: {
                                    count: 0,
                                    items: new Map,
                                    groups: new Set
                                }
                            }
                        }),
                        r = e3(() => new Set),
                        o = e3(() => new Map),
                        i = e3(() => new Map),
                        l = e3(() => new Set),
                        a = e9(e),
                        {
                            label: u,
                            children: c,
                            value: d,
                            onValueChange: f,
                            filter: p,
                            shouldFilter: v,
                            loop: m,
                            disablePointerSelection: h = !1,
                            vimBindings: g = !0,
                            ...y
                        } = e,
                        b = s.useId(),
                        w = s.useId(),
                        E = s.useId(),
                        x = s.useRef(null),
                        C = e7();
                    e4(() => {
                        if (void 0 !== d) {
                            let e = d.trim();
                            n.current.value = e, R.emit()
                        }
                    }, [d]), e4(() => {
                        C(6, D)
                    }, []);
                    let R = s.useMemo(() => ({
                            subscribe: e => (l.current.add(e), () => l.current.delete(e)),
                            snapshot: () => n.current,
                            setState: (e, t, r) => {
                                var o, i, l;
                                if (!Object.is(n.current[e], t)) {
                                    if (n.current[e] = t, "search" === e) O(), P(), C(1, N);
                                    else if ("value" === e && (r || C(5, D), (null == (o = a.current) ? void 0 : o.value) !== void 0)) {
                                        null == (l = (i = a.current).onValueChange) || l.call(i, null != t ? t : "");
                                        return
                                    }
                                    R.emit()
                                }
                            },
                            emit: () => {
                                l.current.forEach(e => e())
                            }
                        }), []),
                        k = s.useMemo(() => ({
                            value: (e, t, r) => {
                                var o;
                                t !== (null == (o = i.current.get(e)) ? void 0 : o.value) && (i.current.set(e, {
                                    value: t,
                                    keywords: r
                                }), n.current.filtered.items.set(e, A(t, r)), C(2, () => {
                                    P(), R.emit()
                                }))
                            },
                            item: (e, t) => (r.current.add(e), t && (o.current.has(t) ? o.current.get(t).add(e) : o.current.set(t, new Set([e]))), C(3, () => {
                                O(), P(), n.current.value || N(), R.emit()
                            }), () => {
                                i.current.delete(e), r.current.delete(e), n.current.filtered.items.delete(e);
                                let t = M();
                                C(4, () => {
                                    O(), (null == t ? void 0 : t.getAttribute("id")) === e && N(), R.emit()
                                })
                            }),
                            group: e => (o.current.has(e) || o.current.set(e, new Set), () => {
                                i.current.delete(e), o.current.delete(e)
                            }),
                            filter: () => a.current.shouldFilter,
                            label: u || e["aria-label"],
                            disablePointerSelection: h,
                            listId: b,
                            inputId: E,
                            labelId: w,
                            listInnerRef: x
                        }), []);

                    function A(e, t) {
                        var r, o;
                        let i = null != (o = null == (r = a.current) ? void 0 : r.filter) ? o : eH;
                        return e ? i(e, n.current.search, t) : 0
                    }

                    function P() {
                        if (!n.current.search || !1 === a.current.shouldFilter) return;
                        let e = n.current.filtered.items,
                            t = [];
                        n.current.filtered.groups.forEach(n => {
                            let r = o.current.get(n),
                                i = 0;
                            r.forEach(t => {
                                i = Math.max(e.get(t), i)
                            }), t.push([n, i])
                        });
                        let r = x.current;
                        T().sort((t, n) => {
                            var r, o;
                            let i = t.getAttribute("id"),
                                l = n.getAttribute("id");
                            return (null != (r = e.get(l)) ? r : 0) - (null != (o = e.get(i)) ? o : 0)
                        }).forEach(e => {
                            let t = e.closest(eW);
                            t ? t.appendChild(e.parentElement === t ? e : e.closest(`${eW} > *`)) : r.appendChild(e.parentElement === r ? e : e.closest(`${eW} > *`))
                        }), t.sort((e, t) => t[1] - e[1]).forEach(e => {
                            let t = x.current.querySelector(`${eF}[${ez}="${encodeURIComponent(e[0])}"]`);
                            null == t || t.parentElement.appendChild(t)
                        })
                    }

                    function N() {
                        let e = T().find(e => "true" !== e.getAttribute("aria-disabled")),
                            t = null == e ? void 0 : e.getAttribute(ez);
                        R.setState("value", t || void 0)
                    }

                    function O() {
                        var e, t, l, u;
                        if (!n.current.search || !1 === a.current.shouldFilter) {
                            n.current.filtered.count = r.current.size;
                            return
                        }
                        n.current.filtered.groups = new Set;
                        let c = 0;
                        for (let o of r.current) {
                            let r = A(null != (t = null == (e = i.current.get(o)) ? void 0 : e.value) ? t : "", null != (u = null == (l = i.current.get(o)) ? void 0 : l.keywords) ? u : []);
                            n.current.filtered.items.set(o, r), r > 0 && c++
                        }
                        for (let [e, t] of o.current)
                            for (let r of t)
                                if (n.current.filtered.items.get(r) > 0) {
                                    n.current.filtered.groups.add(e);
                                    break
                                }
                        n.current.filtered.count = c
                    }

                    function D() {
                        var e, t, n;
                        let r = M();
                        r && ((null == (e = r.parentElement) ? void 0 : e.firstChild) === r && (null == (n = null == (t = r.closest(eF)) ? void 0 : t.querySelector('[cmdk-group-heading=""]')) || n.scrollIntoView({
                            block: "nearest"
                        })), r.scrollIntoView({
                            block: "nearest"
                        }))
                    }

                    function M() {
                        var e;
                        return null == (e = x.current) ? void 0 : e.querySelector(`${e_}[aria-selected="true"]`)
                    }

                    function T() {
                        var e;
                        return Array.from(null == (e = x.current) ? void 0 : e.querySelectorAll(eV))
                    }

                    function L(e) {
                        let t = T()[e];
                        t && R.setState("value", t.getAttribute(ez))
                    }

                    function I(e) {
                        var t;
                        let n = M(),
                            r = T(),
                            o = r.findIndex(e => e === n),
                            i = r[o + e];
                        null != (t = a.current) && t.loop && (i = o + e < 0 ? r[r.length - 1] : o + e === r.length ? r[0] : r[o + e]), i && R.setState("value", i.getAttribute(ez))
                    }

                    function j(e) {
                        let t = M(),
                            n = null == t ? void 0 : t.closest(eF),
                            r;
                        for (; n && !r;) r = null == (n = e > 0 ? function(e, t) {
                            let n = e.nextElementSibling;
                            for (; n;) {
                                if (n.matches(t)) return n;
                                n = n.nextElementSibling
                            }
                        }(n, eF) : function(e, t) {
                            let n = e.previousElementSibling;
                            for (; n;) {
                                if (n.matches(t)) return n;
                                n = n.previousElementSibling
                            }
                        }(n, eF)) ? void 0 : n.querySelector(eV);
                        r ? R.setState("value", r.getAttribute(ez)) : I(e)
                    }
                    let F = () => L(T().length - 1),
                        W = e => {
                            e.preventDefault(), e.metaKey ? F() : e.altKey ? j(1) : I(1)
                        },
                        _ = e => {
                            e.preventDefault(), e.metaKey ? L(0) : e.altKey ? j(-1) : I(-1)
                        };
                    return s.createElement(S.div, {
                        ref: t,
                        tabIndex: -1,
                        ...y,
                        "cmdk-root": "",
                        onKeyDown: e => {
                            var t;
                            if (null == (t = y.onKeyDown) || t.call(y, e), !e.defaultPrevented) switch (e.key) {
                                case "n":
                                case "j":
                                    g && e.ctrlKey && W(e);
                                    break;
                                case "ArrowDown":
                                    W(e);
                                    break;
                                case "p":
                                case "k":
                                    g && e.ctrlKey && _(e);
                                    break;
                                case "ArrowUp":
                                    _(e);
                                    break;
                                case "Home":
                                    e.preventDefault(), L(0);
                                    break;
                                case "End":
                                    e.preventDefault(), F();
                                    break;
                                case "Enter":
                                    if (!e.nativeEvent.isComposing && 229 !== e.keyCode) {
                                        e.preventDefault();
                                        let t = M();
                                        if (t) {
                                            let e = new Event(eB);
                                            t.dispatchEvent(e)
                                        }
                                    }
                            }
                        }
                    }, s.createElement("label", {
                        "cmdk-label": "",
                        htmlFor: k.inputId,
                        id: k.labelId,
                        style: tt
                    }, u), te(e, e => s.createElement(eU.Provider, {
                        value: R
                    }, s.createElement(e$.Provider, {
                        value: k
                    }, e))))
                }),
                eX = s.forwardRef((e, t) => {
                    var n, r;
                    let o = s.useId(),
                        i = s.useRef(null),
                        l = s.useContext(eY),
                        a = eK(),
                        u = e9(e),
                        c = null != (r = null == (n = u.current) ? void 0 : n.forceMount) ? r : null == l ? void 0 : l.forceMount;
                    e4(() => {
                        if (!c) return a.item(o, null == l ? void 0 : l.id)
                    }, [c]);
                    let d = e5(o, i, [e.value, e.children, i], e.keywords),
                        f = eq(),
                        p = e8(e => e.value && e.value === d.current),
                        v = e8(e => !!c || !1 === a.filter() || !e.search || e.filtered.items.get(o) > 0);

                    function m() {
                        var e, t;
                        h(), null == (t = (e = u.current).onSelect) || t.call(e, d.current)
                    }

                    function h() {
                        f.setState("value", d.current, !0)
                    }
                    if (s.useEffect(() => {
                            let t = i.current;
                            if (!(!t || e.disabled)) return t.addEventListener(eB, m), () => t.removeEventListener(eB, m)
                        }, [v, e.onSelect, e.disabled]), !v) return null;
                    let {
                        disabled: g,
                        value: y,
                        onSelect: b,
                        forceMount: w,
                        keywords: E,
                        ...x
                    } = e;
                    return s.createElement(S.div, {
                        ref: e6([i, t]),
                        ...x,
                        id: o,
                        "cmdk-item": "",
                        role: "option",
                        "aria-disabled": !!g,
                        "aria-selected": !!p,
                        "data-disabled": !!g,
                        "data-selected": !!p,
                        onPointerMove: g || a.disablePointerSelection ? void 0 : h,
                        onClick: g ? void 0 : m
                    }, e.children)
                }),
                eG = s.forwardRef((e, t) => {
                    let {
                        heading: n,
                        children: r,
                        forceMount: o,
                        ...i
                    } = e, l = s.useId(), a = s.useRef(null), u = s.useRef(null), c = s.useId(), d = eK(), f = e8(e => !!o || !1 === d.filter() || !e.search || e.filtered.groups.has(l));
                    e4(() => d.group(l), []), e5(l, a, [e.value, e.heading, u]);
                    let p = s.useMemo(() => ({
                        id: l,
                        forceMount: o
                    }), [o]);
                    return s.createElement(S.div, {
                        ref: e6([a, t]),
                        ...i,
                        "cmdk-group": "",
                        role: "presentation",
                        hidden: !f || void 0
                    }, n && s.createElement("div", {
                        ref: u,
                        "cmdk-group-heading": "",
                        "aria-hidden": !0,
                        id: c
                    }, n), te(e, e => s.createElement("div", {
                        "cmdk-group-items": "",
                        role: "group",
                        "aria-labelledby": n ? c : void 0
                    }, s.createElement(eY.Provider, {
                        value: p
                    }, e))))
                }),
                eJ = s.forwardRef((e, t) => {
                    let {
                        alwaysRender: n,
                        ...r
                    } = e, o = s.useRef(null), i = e8(e => !e.search);
                    return n || i ? s.createElement(S.div, {
                        ref: e6([o, t]),
                        ...r,
                        "cmdk-separator": "",
                        role: "separator"
                    }) : null
                }),
                eQ = s.forwardRef((e, t) => {
                    let {
                        onValueChange: n,
                        ...r
                    } = e, o = null != e.value, i = eq(), l = e8(e => e.search), a = e8(e => e.value), u = eK(), c = s.useMemo(() => {
                        var e;
                        let t = null == (e = u.listInnerRef.current) ? void 0 : e.querySelector(`${e_}[${ez}="${encodeURIComponent(a)}"]`);
                        return null == t ? void 0 : t.getAttribute("id")
                    }, []);
                    return s.useEffect(() => {
                        null != e.value && i.setState("search", e.value)
                    }, [e.value]), s.createElement(S.input, {
                        ref: t,
                        ...r,
                        "cmdk-input": "",
                        autoComplete: "off",
                        autoCorrect: "off",
                        spellCheck: !1,
                        "aria-autocomplete": "list",
                        role: "combobox",
                        "aria-expanded": !0,
                        "aria-controls": u.listId,
                        "aria-labelledby": u.labelId,
                        "aria-activedescendant": c,
                        id: u.inputId,
                        type: "text",
                        value: o ? e.value : l,
                        onChange: e => {
                            o || i.setState("search", e.target.value), null == n || n(e.target.value)
                        }
                    })
                }),
                e0 = s.forwardRef((e, t) => {
                    let {
                        children: n,
                        label: r = "Suggestions",
                        ...o
                    } = e, i = s.useRef(null), l = s.useRef(null), a = eK();
                    return s.useEffect(() => {
                        if (l.current && i.current) {
                            let e = l.current,
                                t = i.current,
                                n, r = new ResizeObserver(() => {
                                    n = requestAnimationFrame(() => {
                                        let n = e.offsetHeight;
                                        t.style.setProperty("--cmdk-list-height", n.toFixed(1) + "px")
                                    })
                                });
                            return r.observe(e), () => {
                                cancelAnimationFrame(n), r.unobserve(e)
                            }
                        }
                    }, []), s.createElement(S.div, {
                        ref: e6([i, t]),
                        ...o,
                        "cmdk-list": "",
                        role: "listbox",
                        "aria-label": r,
                        id: a.listId
                    }, te(e, e => s.createElement("div", {
                        ref: e6([l, a.listInnerRef]),
                        "cmdk-list-sizer": ""
                    }, e)))
                }),
                e1 = s.forwardRef((e, t) => {
                    let {
                        open: n,
                        onOpenChange: r,
                        overlayClassName: o,
                        contentClassName: i,
                        container: l,
                        ...a
                    } = e;
                    return s.createElement(eI, {
                        open: n,
                        onOpenChange: r
                    }, s.createElement(ej, {
                        container: l
                    }, s.createElement(eS, {
                        "cmdk-overlay": "",
                        className: o
                    }), s.createElement(eP, {
                        "aria-label": e.label,
                        "cmdk-dialog": "",
                        className: i
                    }, s.createElement(eZ, {
                        ref: t,
                        ...a
                    }))))
                }),
                e2 = Object.assign(eZ, {
                    List: e0,
                    Item: eX,
                    Input: eQ,
                    Group: eG,
                    Separator: eJ,
                    Dialog: e1,
                    Empty: s.forwardRef((e, t) => e8(e => 0 === e.filtered.count) ? s.createElement(S.div, {
                        ref: t,
                        ...e,
                        "cmdk-empty": "",
                        role: "presentation"
                    }) : null),
                    Loading: s.forwardRef((e, t) => {
                        let {
                            progress: n,
                            children: r,
                            label: o = "Loading...",
                            ...i
                        } = e;
                        return s.createElement(S.div, {
                            ref: t,
                            ...i,
                            "cmdk-loading": "",
                            role: "progressbar",
                            "aria-valuenow": n,
                            "aria-valuemin": 0,
                            "aria-valuemax": 100,
                            "aria-label": o
                        }, te(e, e => s.createElement("div", {
                            "aria-hidden": !0
                        }, e)))
                    })
                });

            function e9(e) {
                let t = s.useRef(e);
                return e4(() => {
                    t.current = e
                }), t
            }
            var e4 = "undefined" == typeof window ? s.useEffect : s.useLayoutEffect;

            function e3(e) {
                let t = s.useRef();
                return void 0 === t.current && (t.current = e()), t
            }

            function e6(e) {
                return t => {
                    e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }
            }

            function e8(e) {
                let t = eq(),
                    n = () => e(t.snapshot());
                return s.useSyncExternalStore(t.subscribe, n, n)
            }

            function e5(e, t, n, r = []) {
                let o = s.useRef(),
                    i = eK();
                return e4(() => {
                    var l;
                    let a = (() => {
                            var e;
                            for (let t of n) {
                                if ("string" == typeof t) return t.trim();
                                if ("object" == typeof t && "current" in t) return t.current ? null == (e = t.current.textContent) ? void 0 : e.trim() : o.current
                            }
                        })(),
                        u = r.map(e => e.trim());
                    i.value(e, a, u), null == (l = t.current) || l.setAttribute(ez, a), o.current = a
                }), o
            }
            var e7 = () => {
                let [e, t] = s.useState(), n = e3(() => new Map);
                return e4(() => {
                    n.current.forEach(e => e()), n.current = new Map
                }, [e]), (e, r) => {
                    n.current.set(e, r), t({})
                }
            };

            function te({
                asChild: e,
                children: t
            }, n) {
                let r;
                return e && s.isValidElement(t) ? s.cloneElement("function" == typeof(r = t.type) ? r(t.props) : "render" in r ? r.render(t.props) : t, {
                    ref: t.ref
                }, n(t.props.children)) : n(t)
            }
            var tt = {
                position: "absolute",
                width: "1px",
                height: "1px",
                padding: "0",
                margin: "-1px",
                overflow: "hidden",
                clip: "rect(0, 0, 0, 0)",
                whiteSpace: "nowrap",
                borderWidth: "0"
            }
        },
        87204: (e, t, n) => {
            n.d(t, {
                _T: () => o,
                ev: () => i,
                pi: () => r
            });
            var r = function() {
                return (r = Object.assign || function(e) {
                    for (var t, n = 1, r = arguments.length; n < r; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };

            function o(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) 0 > t.indexOf(r[o]) && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
                return n
            }

            function i(e, t, n) {
                if (n || 2 == arguments.length)
                    for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
                return e.concat(r || Array.prototype.slice.call(t))
            }
            Object.create, Object.create, "function" == typeof SuppressedError && SuppressedError
        }
    }
]);